# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the Player’s Concern**  
   - Determine if the player reports a deposit issue such as funds deducted but not credited, deposit not reflected, or rejected deposit.  
   - Ask for specific details: e.g., payment method used, approximate transaction time, and if applicable, the amount involved.

2. **Request Proof of Payment/Deposit**  
   - Instruct the player to provide evidence supporting their claim:  
     - For GCash/PayMaya deposits:  
       - Upload a screenshot of the GCASH/PayMAYA confirmation message or transaction history that includes sender and recipient details.  
       - Alternatively, provide a detailed receipt showing these details.  
     - For other methods (GrabPay, USDT, Bank Transfer):  
       - Request relevant transaction confirmation or receipt screenshots.

3. **Check Deposit Record**  
   - Instruct the player to view their deposit record:  
     - From the homepage, click on 'Member', then 'Deposit Record'.  
     - Take a screenshot of the deposit record if needed for verification.  
   - Confirm whether the deposit is Pending, Completed, or Not Reflected.

4. **Verify the Deposit Status**  
   - If the deposit appears **pending** but not credited, or **not reflected** after a reasonable processing time (30-45 minutes), proceed with verification.  
   - If the deposit shows as **failed** or rejected, inform the player that the funds will be automatically reimbursed within 2-3 days.  
   - If funds are deducted but not credited, continue with verification steps.

5. **Assess the Submitted Proof**  
   - Verify that the screenshot or receipt contains the required information:  
     - Sender and recipient details (e.g., account name or number).  
     - Transaction date and time.  
     - Payment confirmation message or receipt number.

6. **Proceed with Deposit Verification**  
   - If the proof is **sufficient**:  
     - Verify the details against the system records.  
     - If matched, credit the deposit to the player's account and notify them of successful deposit confirmation.  
   - If the proof **lacks information** or is unclear:  
     - Request additional evidence or a clearer screenshot.  
     - Inform the player that verification may take additional time.

7. **Resolution in Case of Uncredited Deposits**  
   - For **funds deducted but not credited**:  
     - If proof verifies payment, the system will automatically reimburse the funds within 24 hours.  
     - Advise the player to wait for this period.  
     - If reimbursement does not occur after 24 hours, advise contacting the payment provider (Cashier like GCash, PayMaya, etc.) for further assistance.

8. **Alternative Deposit Methods During Issues**  
   - Recommend using alternative methods if GCash/PayMaya has ongoing issues:  
     - USDT, Online Bank Transfer, GrabPay, or GoTyme.  
   - Ensure the player is aware of the available options and the associated processing times.

9. **Follow-up and Escalation**  
   - If verification is delayed due to missing or unclear proof, or if the reimbursement has not been processed within the expected timeframe, escalate to the back office or manager.  
   - Notify the player of ongoing investigations and estimated resolution times.

10. **Close the Case**  
   - Once the deposit is credited or properly reimbursed, inform the player of the resolution.  
   - Confirm they are satisfied and advise them on how to view updated deposit records if needed.  
   - Document the case details and proof for future reference.

## Notes

- Always ensure the proof of payment shows clear sender and recipient information to facilitate swift verification.  
- Deposit refunds for rejected transactions are processed automatically within approximately 2-3 days; inform players accordingly.  
- For issues where the deposit does not appear after 45 minutes, consider instructing players to use backup deposit methods as applicable.  
- Reiterate that processing times may vary during high transaction volumes or network issues, and advise patience.  

## Key points for communicating with players

- Clearly instruct them to provide detailed proofs such as transaction screenshots showing sender, recipient, date, and amount.  
- Remind players that automatic reimbursement occurs within 24 hours for deducted funds not credited.  
- Advise patience during network or system delays and suggest alternative deposit methods if frequent issues occur.