# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial information from the player**
   - Confirm the player's username.
   - Ask the player to specify the deposit amount and the method used.
   - Request a clear screenshot or image of the deposit receipt, inbox bank slip, or transaction confirmation.

2. **Initial assessment**
   - Check if the deposit reflects in the player's account:
     - If credited, no further action is needed.
     - If not credited, proceed to verification steps.
   
3. **Verify deposit details**
   - Review the submitted receipt/image to ensure clarity and that it includes key details (e.g., transaction number, date, amount).
   - Cross-reference the submitted receipt with the transaction details provided by the player.
   
4. **Investigate deposit status**
   - Check the transaction status in the payment system and bank/merchant records:
     - Confirm if the deposit is pending, under processing, or completed.
   - Determine if the deposit is delayed due to processing times, system congestion, or maintenance.
   
5. **Communicate deposit delay or issue**
   - If the deposit is pending or delayed:
     - Inform the player that deposits can be delayed due to high payment volumes or bank processing times.
     - Advise patience and suggest checking again after the expected processing window.
   - If the deposit has not credited after the expected window, escalate the issue:
     - Request the player to resend their receipt or transaction proof.
   - If the deposit is credited in the bank/merchant records but not reflected in the account:
     - Confirm that the receipt matches the transaction and investigate potential system issues.
   
6. **Verify deposit if not reflected after normal processing time**
   - Request the player to resend their deposit receipt or inbox bank slip.
   - Submit the receipt/image for verification in the back office/system.
   - Allow the finance team to investigate with the bank/merchant.
   
7. **Follow-up and resolution**
   - If the deposit is verified and confirmed:
     - Credit the amount to the player's account.
     - Inform the player that the deposit has been successfully credited after verification.
   - If the deposit cannot be verified or confirmed:
     - Advise the player that the deposit could not be credited and suggest contacting their bank or payment provider.
     - Consider issuing any necessary guidance or escalation procedures if required.
   
8. **Address deposit method issues**
   - If the player used GCASH and it is under maintenance:
     - Inform the player that GCASH deposits/withdrawals are temporarily unavailable.
     - Recommend alternative payment methods such as MAYA or GOTYME.

## Notes
- Always ask for a clear screenshot or image of the deposit receipt for verification purposes.
- Be aware that deposits may reflect slowly due to system congestion or ongoing maintenance.
- Ensure ongoing communication with the player, especially if delays occur, providing clear instructions and expected timeframes.
- Escalate unresolved verification issues to the finance or technical team as per internal protocols.

## Key points for communicating with players
- Reassure players that delays are often due to processing volume or maintenance.
- Encourage patience and ask for receipts if the deposit hasn't credited after the expected window.
- Inform players about alternative payment methods if their current method is under maintenance.