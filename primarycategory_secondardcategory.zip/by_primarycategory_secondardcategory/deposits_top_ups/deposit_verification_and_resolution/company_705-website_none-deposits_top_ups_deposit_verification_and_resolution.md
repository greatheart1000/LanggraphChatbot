# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report of a missing deposit.**  
   - Gather details such as the amount deposited, the deposit method used, date and time of transaction, and any relevant account or transaction identifiers.

2. **Instruct the player to provide a detailed deposit receipt for verification.**  
   - For GCash deposits, the receipt must include sender and recipient information, reference number, QR invoice number, and transaction amount.  
   - Advise the player to access their GCash account, select 'Inbox', and take a screenshot of the QRPH invoice/receipt showing transaction details.  
   - Ensure the screenshot clearly shows all required information, including the negative (-) sign if applicable.

3. **Verify the deposit receipt documentation submitted by the player.**  
   - Confirm that the receipt shows sender and recipient info, reference number, QR invoice number, and the amount.  
   - Check that the receipt matches the deposit made, especially the transaction amount and details.

4. **Check deposit records in the back office system.**  
   - Access the 'Deposit Record' section by clicking 'Member' on the homepage, then selecting 'Deposit Record'.  
   - Confirm whether the deposit transaction is reflected in the system.

5. **Determine the status of the deposit: reflected, pending, or not credited.**  
   - If the deposit **is reflected** and credited to the player's account, inform the player and close the inquiry.  
   - If the deposit **is not reflected** within 30 to 45 minutes for GCash or PayMaya, or immediately if the deposit is rejected, proceed to step 6.  
   - If the funds were deducted but not credited or credited late, continue to step 6.

6. **For funds deducted but not credited,**  
   - Explain to the player that:  
     - Funds deducted from their e-wallet or payment method will be automatically reimbursed within 2-3 days.  
     - During system delays (e.g., current issues with GCash), processing may take longer.  
   - Advise the player to wait for the reimbursement timeframe.  
   - Suggest alternative deposit methods if urgent deposit is needed: PayMaya, GrabPay, GoTyme, USDT, or online bank transfer.

7. **If the deposit was rejected during the transaction process,**  
   - Inform the player that the deducted funds will be reimbursed automatically within 2-3 days.  
   - Recommend the player contact GCash Customer Service if reimbursement is not received within this period.  
   - Confirm that the receipt and transaction records support the rejection status.

8. **If the deposit record does not match the receipt, or the deposit is missing entirely, escalate the case for further support.**  
   - Request player to recheck their payment provider for confirmation.  
   - Advise the player to retain the deposit receipt for reference.

9. **Remind players that ongoing issues with GCash (e.g., maintenance or technical problems) might temporarily suspend deposits or withdrawals via GCash.**  
   - Suggest using alternative deposit methods like PayMaya, GrabPay, GoTyme, USDT, or online banking until GCash resumption.

10. **Document all actions and communication in the support system.**  
    - Attach relevant screenshots, deposit records, and transaction details.  
    - Log the case, including status and any instructions given.

11. **If the deposit was confirmed successful but credited late, instruct the player to wait up to 24 hours, and check their deposit record again.**  
    - Advise them to contact support if the deposit still does not reflect after this period.

12. **Close the case once the deposit is verified and credited, or reimbursement process is initiated.**  
    - Confirm the player is informed of the resolution and next steps if applicable.

## Notes

- Always request a clear screenshot of the deposit receipt, ensuring key information is visible for verification.
- When deposit issues occur, prioritize guiding players through alternative deposit options.
- Be transparent about processing times and system delays affecting deposit crediting.
- Reassure players that deducted funds will be reimbursed automatically if they encounter failure or rejection during the transaction.
- Maintain professionalism and ensure clear communication about timings and procedures based on the QA FAQs.

## Key points for communicating with players

- Emphasize the importance of providing detailed receipts with sender and recipient info.
- Clearly explain reimbursement timelines (2-3 days for rejected transactions or undelivered funds).
- Encourage patience during system issues or delays, offering alternative deposit methods.
- Advise players to contact their payment provider if reimbursements are delayed beyond the expected period.
- Keep all records of the deposit, receipt, and communication for support reference.