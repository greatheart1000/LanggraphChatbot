# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player’s inquiry about deposit status or issues.**  
   Identify if the player reports a delayed, pending, uncredited, or failed deposit, or requests verification.

2. **Request the player to provide detailed deposit proof.**  
   - Ask for a screenshot of the deposit receipt showing the sender and recipient information (e.g., GCash or PayMaya transaction details).  
   - If applicable, instruct the player to generate a deposit record by:  
     - Going to the homepage, clicking **Member**, then **Deposit Record**.  
     - Taking a screenshot of the record, including reference number or transaction ID if available.

3. **Instruct the player to verify deposit records, if available.**  
   - Ask the player to open **Member** > **Deposit Record** and share the screenshot.

4. **Assess the deposit submission details.**  
   - Confirm that the receipt or deposit record includes sender and recipient information, transaction ID, timestamp, and amount.

5. **Perform system and manual checks based on the submitted information.**  
   - Check deposit records in the back office:  
     - Verify if the deposit appears in the deposit record.  
     - Confirm matching details (amount, date, sender, recipient).  
   - For wallet deposits via GCash or PayMaya, check inbox transaction in the sender’s wallet, if possible.

6. **Determine deposit status:**
   - If **deposit is confirmed in records but not credited to account:**  
     - Verify if the deposit is still pending due to network or processing delays, especially for GCash/PayMaya deposits.  
   - If **deposit is not found or details are insufficient:**  
     - Inform the player that the deposit is unverified and request additional proof if needed.

7. **Address common issues:**
   - **Pending or delayed deposits (e.g., GCash/PayMaya):**  
     - Explain that GCash/PayMaya deposits may be delayed due to network issues and advise to wait up to 30-45 minutes for processing.  
   - **Failed or uncredited deposits:**  
     - Confirm with the player if the deposit record or receipt shows successful transaction details.  
     - If deposit failed, suggest alternative deposit methods: PayMaya (2% rebate), USDT, or Online Bank Transfer.  
   - **If deposit is deducted but not credited:**  
     - Reassure the player that funds are secured and will be reimbursed within 24 hours.  
     - Request the deposit receipt or screenshot for verification to accelerate the process.

8. **If deposit is not credited after the retention period:**
   - Advise the player to send the detailed receipt, deposit record screenshot, and any relevant inbox transaction proof.  
   - Submit these to the finance team for verification.

9. **Follow up on the deposit verification.**  
   - Once verified, inform the player that their deposit has been credited to their account.  
   - If the deposit remains uncredited after all checks and the deposit was confirmed, escalate the case internally for further investigation.

10. **Document all communication and steps taken.**  
    - Log the verification process, proof submitted, and resolution status in the support system.

## Notes

- Always request a clear screenshot of the deposit receipt highlighting sender, recipient, amount, date, and transaction ID.  
- Deposit delays are common with GCash/PayMaya due to network fluctuations; advise patience and provide alternative methods if persistent issues occur.  
- Reimbursement of deducted but uncredited funds typically occurs within 24 hours; inform players accordingly.  
- Use the deposit record to assist in verification, which can be accessed from the **Member** area under **Deposit Record**.

## Key points for communicating with players

- Emphasize the importance of providing detailed proof, including screenshots of deposit receipts or inbox transactions.  
- Explain that deposits may be delayed due to network issues but are usually processed within 30-45 minutes.  
- Remind players that alternative deposit methods are available if issues persist, notably PayMaya with a 2% rebate.  
- Reassure players that deducted funds will be reimbursed within 24 hours if not credited.