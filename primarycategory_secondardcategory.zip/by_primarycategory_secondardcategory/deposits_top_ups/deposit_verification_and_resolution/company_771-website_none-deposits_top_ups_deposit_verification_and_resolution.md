# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the player's deposit method and issue**
   - Determine if the player reports a deposit (e.g., GCASH, PayMaya, alternative methods) being pending, delayed, not credited, or not reflected.
   - Clarify if the player has already initiated the deposit and the current status (pending, not credited, not showing).

2. **Request relevant proof of payment from the player**
   - Ask the player to provide a clear screenshot of the transaction verification, including:
     - Proof of payment in their GCash or PayMaya app (transaction history or inbox receipt).
     - Depositor and recipient details visible.
     - Amount and date of transaction.
     - Transaction reference or receipt number if available.
   - Instruct the player to access deposit records:
     - For GCASH: go to Home > Member > Deposit Record.
   - If unable to locate the deposit record, request the player to generate a deposit receipt via:
     - GCASH Inbox (for inbox receipts).
     - Transaction history or invoice in the app.

3. **Check the deposit status in the system**
   - Access the player's deposit record within the back office:
     - Verify if the deposit is marked as processed, pending, or not reflected.
   - Confirm if the deposit amount matches the proof provided.
   - Note if the deposit shows as completed or pending.

4. **Assess if the deposit has been credited or not**
   - If the deposit is marked as credited in the deposit record and the player’s balance is updated, inform the player that the deposit was successful.
   - If the deposit shows as pending or is not reflected:
     - Advise the player to wait for up to 30–45 minutes, as network fluctuations may cause delays (especially for GCASH/MSM deposits).
     - Suggest refreshing their balance periodically.

5. **If the deposit is delayed, not reflecting, or pending due to network issues**
   - Explain that GCASH/PayMaya deposits may be delayed due to network fluctuations.
   - Confirm that the funds are secure and will be processed once the network stabilizes.
   - Recommend the player consider using alternative deposit methods with faster processing and potential rebates, such as：
     - PayMaya (may include a 3% rebate, or 6% if applicable).
     - Online bank transfer, USDT, GrabPay, Gotyme, or other supported methods.
   - If the player agrees to switch methods, assist with the new deposit process accordingly.

6. **For deposits deducted but not credited**
   - Advise the player to provide the deposit proof (screenshot of the transaction history showing sender and recipient info).
   - Verify the deposit details against the system record.
   - If verified, inform the player that the deposit will be reimbursed (generally within 2–3 days).
   - If the deposit is not credited after verification, escalate the issue to the finance team or responsible department for resolution.

7. **If deposits are not credited or delayed beyond 45 minutes**
   - Request the player to re-submit proof of payment if not already provided.
   - Confirm the transaction details, including date, amount, and reference number.
   - Advise to wait some additional time, considering network delays.
   - If the problem persists, escalate to the financial or technical support team for further investigation.

8. **If the player reports a failed or unavailable deposit method (e.g., GCASH issues)**
   - Recommend switching to an alternative method such as PayMaya, USDT, or online bank transfer.
   - Highlight that these methods may offer faster processing or rebates.
   - Assist with the new deposit process if needed.

9. **Document the case and update the deposit record**
   - Record all communication, proof submitted, and system checks.
   - Submit any additional proof or reports to the relevant teams for further verification if the deposit is disputed or not credited.

10. **Close the issue once resolved**
    - Confirm with the player that their balance has been updated.
    - Provide additional support if needed.
    - Thank the player for their cooperation and inform them they can contact support again if further issues arise.

## Notes
- Always verify the proof of deposit by checking the screenshot of the transaction history or inbox receipt, ensuring sender and recipient information are clear.
- Remind players that network fluctuations, particularly with GCash/PayMaya, may cause processing delays, but funds are generally secure.
- Encourage players to use alternative methods like Maya (PayMaya) for more stable and quicker processing, especially if they experienced repeated issues.
- Clearly communicate that deposits are credited after verification and may involve some processing time depending on the method used.

## Key points for communicating with players
- Emphasize patience during network delays, especially for GCash and PayMaya.
- Guide players on how to generate and locate deposit proof.
- Suggest alternative deposit channels for faster and more reliable processing with rebates.
- Always verify proof thoroughly before processing reimbursement or escalation.