# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive player inquiry about deposit issue**  
   - Determine the nature of the issue: deposit not reflected, delayed, or missing.  
   - Ask the player to provide relevant deposit details and documentation.

2. **Collect necessary information from the player**  
   - Deposit record screenshot (e.g., payment receipt, deposit slip).  
   - Payment receipt screenshot (if available).  
   - Confirm the following details are included:
     - Reference number  
     - Date and time of transaction  
     - Payment method used (GCASH or MAYA)  
     - Transaction amount  
     - Player’s account username  

3. **Verify the submitted documentation and information**  
   - Check that the reference number, date, and time on the deposit record and receipt match.  
   - Confirm the status of the receipt:  
     - For GCASH, the receipt should read 'Paid' or 'Sent' to be valid; 'Received' is not valid for deposits.  
   - Confirm the deposit method used (GCASH or MAYA).  
   - If supporting documents are incomplete or inconsistent, advise the player to re-submit or contact the payment provider for clarification.

4. **Check system and transaction status**  
   - Search the transaction in the back office/system using the reference number and relevant details.  
   - Verify if the deposit has been recorded/posted.  
   - Check for delays caused by bank processing, gateway maintenance, or high system load.

5. **Determine the appropriate response based on system verification**  
   - If the deposit appears in the system:  
     - Confirm the amount, method, and timestamp with the player’s documentation.  
     - If everything matches, inform the player that the deposit is successfully credited to their account.  
     - If there is a discrepancy, escalate for further investigation.

   - If the deposit does not appear in the system:  
     - Check for ongoing maintenance or known delays, especially for GCASH (e.g., during downtime or maintenance).  
     - If GCASH is under maintenance or no receipt is available, suggest using MAYA as an alternative.  
     - Advise the player to wait for system processing, which can take some time due to bank processing or gateway issues.  
     - If the deposit has been pending beyond expected timeframes, proceed to escalate the issue for detailed investigation.

6. **Handle specific deposit issues**  
   - **Delayed or non-reflected deposits:**  
     - Confirm submission of valid receipts where applicable.  
     - If delays persist, request the player to wait or re-deposit if instructed.  
     - Suggest checking the system status, especially for maintenance windows of payment services.  

   - **GCASH deposit issues:**  
     - Ask the player to submit a GCASH deposit issue ticket via the GCASH Help Center, including all relevant details (Full name, Number, Reference No, Date, Amount, Merchant, etc.).  
     - Verify the receipt status ('Paid' or 'Sent') and provide guidance based on GCASH maintenance notifications.  
     - If no receipt or during GCASH downtime, inform the player regarding potential refunds or alternative payment methods (e.g., PayMaya).  

   - **Uncredited GCash transfer without receipt:**  
     - Inform the player a refund is typically issued within 2-3 working days.  
     - Advise contacting GCASH support if necessary and sharing transaction details for further assistance.

   - **Expired or failed QR code payments:**  
     - Instruct the player to generate a new QR code before paying again.  

7. **Escalation and further investigation**  
   - If the deposit remains uncredited after verifying the documentation and waiting for system processing:  
     - Escalate the case to the back office or technical team with all collected documentation and system check results.  
     - Notify the player of the escalation and estimated resolution timeframe.

8. **Follow-up and resolution**  
   - Keep the player informed of progress during investigation.  
   - Once the deposit is confirmed or refund processed:  
     - Confirm with the player that the funds are credited or refunded.  
     - Close the case with documentation of the resolution.

## Notes

- Always verify document matchings (reference, date, time) before proceeding.  
- During GCASH maintenance, advise players to switch to MAYA or wait until services are restored.  
- Remind players that system delays largely depend on bank processing or gateway issues outside immediate control.  
- For unresolved cases, escalate promptly with all supporting evidence.  

## Key points for communicating with players

- Inform players to submit clear screenshots of deposit records and receipts, ensuring all details match.  
- Explain that delays may occur due to external processing or maintenance, and they should check system status regularly.  
- Encourage players to use alternative methods if their primary service is unavailable.  
- For issues with no receipt or during maintenance, inform players about refund timelines and ongoing support options.