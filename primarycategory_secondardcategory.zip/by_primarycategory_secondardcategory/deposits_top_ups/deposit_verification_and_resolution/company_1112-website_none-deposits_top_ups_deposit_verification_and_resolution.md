# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Initiate the investigation upon player contact**:
   - Greet the player and confirm the deposit issue.
   - Request the username associated with the deposit account.
   - Ask for the deposit proof, such as a GCASH or MAYA receipt, screenshot, or bank slip, depending on the payment method used.
   - If the deposit was via GCASH, request the GCASH Inbox Receipt or screenshot.

2. **Verify the provided information**:
   - Ensure the username is correct and matches the account.
   - Confirm the deposit proof clearly shows relevant details like transaction amount, date, and transaction ID.
   - Check for the presence of the GCASH or MAYA receipt. If unavailable, inform the player that verification cannot proceed without it.

3. **Check the transaction in the system**:
   - Use the system tools to locate the deposit transaction using the provided receipt details, transaction ID, or reference number.
   - Confirm whether the system has recorded the deposit:
     - If the deposit has been matched and credited, inform the player that the funds are now reflected in their account.
     - If the deposit has not been found, proceed to further checks.

4. **Assess the deposit status and potential delays**:
   - Verify if the deposit is delayed due to payment gateway or system load, especially for GCASH or MAYA transactions.
   - Inform the player that deposits may be delayed due to external providers or high transaction volumes.
   
5. **Perform additional verification if needed**:
   - If the deposit does not appear, advise the player to check their transaction history or inbox receipt of GCASH/MAYA.
   - Confirm the deposit receipt details against the system record.
   - For GCASH, if the receipt is missing and the deposit does not reflect in the account after 24–48 hours, recommend contacting GCASH support for further assistance.

6. **Handle deposit delays or non-reflecting transactions**:
   - If the deposit is delayed, instruct the player to wait and check again later.
   - Advise to gather all relevant receipts and contact support if the deposit remains uncredited after an appropriate waiting period.
   - For GCASH or MAYA under maintenance, suggest alternative payment methods or platforms if available.

7. **Provide resolution based on the findings**:
   - **If the deposit is verified and credited**:
     - Confirm the successful credit to the player's account.
   - **If the transaction cannot be verified or is missing**:
     - Advise the player to contact their payment provider (GCASH support or bank) for further investigation.
     - Remind that refunds, if applicable, are handled by the payment provider, not by the platform.
   - **If the deposit was successful but not reflected**:
     - Document the case and escalate for system verification.
   
8. **Document the case and communicate with the player**:
   - Summarize the findings.
   - If ongoing investigation is required, inform the player of the expected timeline.
   - Provide guidance on steps they can take with their payment provider if necessary.

9. **Close the inquiry**:
   - Once the deposit is confirmed or resolved, inform the player accordingly.
   - Encourage future verification promptly to avoid delays.
   - Offer additional support if needed.

## Notes
- Always request the GCASH or MAYA deposit receipt or bank slip for verification.
- Deposits via GCASH can experience delays due to third-party processing or maintenance, often reflecting within 24–48 hours.
- If deposits do not reflect after a reasonable period, players should verify with their payment provider.
- For missing receipts or uncredited transactions, contact GCASH or MAYA customer support directly.
- System delays are common during high transaction volumes; patience and clear communication are advised.

## Key points for communicating with players
- Clearly explain that deposit delays are often due to external processing times or system load.
- Emphasize the importance of providing the correct username and deposit proof.
- Advise patience and contact with the payment provider if receipts are missing or delays persist beyond 48 hours.
- Never promise specific processing times; encourage players to check back later and keep documentation of their receipts.