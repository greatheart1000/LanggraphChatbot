# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player Information**
   - Confirm the player's username and contact details.
   - If the issue involves a specific deposit, request relevant details such as the deposit amount, method used, and, if applicable, the receipt or transaction ID.

2. **Instruct Player on How to Deposit or Verify Deposit**
   - Guide the player to click the 'Deposit' button located at the upper right corner of the homepage.
   - Ask the player to choose their preferred deposit method (G-Cash, PayMaya, GrabPay, Bank, or USDT).
   - Instruct them to click 'Go' to proceed with the deposit transaction.

3. **Check Deposit Status in the System**
   - Access the back office or process management system.
   - Search for the player’s account and locate the specific deposit attempt based on the provided details or receipt.
   - Verify if the deposit has been credited in the system.

4. **If Deposit is Credited**
   - Inform the player that the deposit has been successfully credited.
   - Advise them to check their account balance.
   - Close the ticket as resolved.

5. **If Deposit is Not Credited**
   - Collect the player's G-Cash receipt (if available), username, and any relevant details.
   - Contact Lodibet support via LiveChat and provide the receipt and username.
   - Request assistance to verify and credit the funds.
   - Advise the player to wait for confirmation if the support team resolves the issue.

6. **Addressing Deposit Method Unavailability**
   - Explain to the player that some deposit methods (e.g., G-Cash, PayMaya, GrabPay, Bank, USDT) may be temporarily unavailable due to maintenance.
   - Suggest alternative deposit methods supported at the time, such as PAYMAYA, GRABPAY, or bank transfers.
   - If the issue persists, instruct the player to contact Lodibet support via LiveChat for further assistance.

7. **Handling Deposit Method Failures or Errors**
   - Confirm with the player if they followed the correct steps (click 'Deposit,' select method, click 'Go').
   - If the deposit process was completed but funds are not credited, proceed with step 5 (verification and support contact).
   - Remind the player not to share sensitive information outside official channels and to keep receipts handy for verification.

8. **Follow-up and Escalation**
   - If the deposit still shows no credit after support intervention, escalate the issue according to internal protocol.
   - Keep the player informed of progress and expected resolution times.
   - Close the case once the deposit is credited or the issue is resolved.

## Notes
- Always verify the receipt and account details before contacting support.
- Emphasize to players that deposit processing times may vary, especially during maintenance or technical issues.
- Use supported contact channels (LiveChat) for deposit-related verification and assistance.
- Do not attempt to manually credit funds without confirmation or proper authorization.

## Key points for communicating with players
- Ask players to provide receipts and username when deposits are not credited.
- Inform players of potential temporary unavailability of deposit methods.
- Encourage patience and direct them to support if problems persist.
- Reassure players that their deposits are being verified and will be credited as soon as possible.