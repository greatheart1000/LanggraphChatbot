# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. Receive the player's report of a deposit issue, noting whether the deposit does not reflect in their balance.

2. Request relevant information from the player:
   - A clear screenshot of the successful deposit receipt from GCash or Maya (only receipts from GCash INBOX are accepted; receipts from GCASH Transaction are not valid).
   - The player's username.
   - Details of the deposit transaction, including the amount and date/time.

3. Confirm the deposit method used:
   - If the player used a QR code, verify they are using the most recent QR code provided by the site.
   - Ask if the deposit was made via GCash or Maya.

4. Check the deposit status in the system:
   - Search for the transaction using the provided receipt and username.
   - Verify whether the deposit appears as successful in the system.

5. If the deposit shows as successful but has not credited to the player's balance:
   - Advise the player to refresh their app or account balance.
   - Confirm if the deposit is recent and whether deposit processing might be delayed due to provider maintenance or statement updates.

6. Perform verification:
   - If the receipt is valid and the transaction shows as successful in the system, credit the deposit to the player's account.
   - If the deposit does not reflect in the system:
     - Check if the deposit receipt was from GCash INBOX (not from GCASH Transaction).
     - Verify the correctness and clarity of the receipt.
     - Ensure the player used the latest QR code; older codes may cause delays.

7. For deposits not reflected after verification:
   - Remind the player to wait 24 hours in case of refunds or delays.
   - If the deposit was made via GCash or Maya and still does not appear after this period, escalate the issue to support or relevant department with all collected details.

8. If the deposit fails or is refunded:
   - Inform the player that funds are typically refunded to their GCash or Maya account within 24 hours.
   - Advise them to contact GCash or Maya customer support if the funds are not credited after 24 hours.

9. If the payment provider is under maintenance:
   - Notify the player of possible delays.
   - Reassure them that funds will be credited once maintenance is completed.

10. Document all actions taken, including screenshots, system checks, and communication with the player, in the case record.

## Notes

- Always verify that the receipt submitted is from GCash INBOX, as receipts from GCash Transaction are not accepted for verification.
- Advise players to always use the latest QR code to avoid deposit delays.
- Clarify that deposit processing can be delayed during maintenance or due to statement updates; prompt players to wait up to 24 hours before further escalation.
- Emphasize the importance of providing clear, legible receipts for efficient verification.

## Key points for communicating with players

- Encourage patience if the deposit does not reflect immediately.
- Remind players to use the current QR code for deposits.
- Instruct players to provide complete and clear screenshot proof when reporting issues.
- Explain that refunds typically process within 24 hours if a deposit fails.
- Reassure players that support will verify the transaction and credit the account if the deposit was successful.