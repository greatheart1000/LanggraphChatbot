# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Greet the player and gather initial information**
   - Ask for their username or game ID.
   - Inquire about the nature of the issue (e.g., deposit pending, not reflected, verification needed).

2. **Request relevant proof of deposit**
   - For deposits, ask the player to provide:
     - A successful transaction receipt or screenshot.
     - Details of the deposit transaction.
   - Emphasize the importance of clarity in the receipt (e.g., clear transaction ID, amount, date).

3. **Verify the deposit status in the system**
   - Check the player's deposit history and status using their user ID or game ID.
   - Confirm whether the deposit is marked as successful or pending.

4. **Perform deposit verification checks**
   - Cross-check the provided receipt/screenshot with transaction records.
   - Confirm that the transaction meets the following:
     - Is marked successful via the payment provider.
     - Matches the deposit details provided by the player.
   - Note: If the deposit is pending, ask the player to wait while the system verifies the transaction.

5. **Determine the appropriate action based on verification**
   - **If the deposit is marked as successful** and the details match:
     - Confirm to the player that their deposit has been verified.
     - Advise the player that the funds will be reflected in their account shortly or have been credited.
   - **If the deposit is pending**:
     - Instruct the player to wait for confirmation.
     - Optionally, advise to verify with the payment provider if necessary.
   - **If the deposit is not reflected** in the account despite verification:
     - Ask the player to submit the transaction receipt or screenshot.
     - Re-verify the transaction details.
     - Inform the player that their deposit will be credited once the system completes verification.

6. **Address deposit issues or failures**
   - **If the deposit fails or is invalid:**
     - Advise the player to contact their payment provider for issues.
     - Suggest attempting the deposit again with a successful receipt.
   - **If the deposit remains uncredited after verification:**
     - Escalate to the technical team or back office for further investigation.
     - Document all submitted proof and details.

7. **Confirm resolution and close the case**
   - Once the deposit is successfully credited:
     - Notify the player of successful resolution.
     - Encourage them to check their account balance.
   - If unresolved issues persist:
     - Keep the case open with notes for escalation.
     - Continue communication or inform the player when updates are available.

8. **Record all interactions and actions taken**
   - Log the submission of receipts, transaction details, verification outcomes, and resolutions.

## Notes
- Always request a clear, legible transaction receipt or screenshot when verifying deposits.
- For deposits that do not reflect immediately, ensure players submit detailed proof and advise patience.
- Verification involves cross-checking player-provided information with payment provider records.
- The minimum deposit and withdrawal amount is 100 PHP; maximum is 25,000 PHP daily. Limits may vary if account restrictions are in effect.

## Key points for communicating with players
- Clearly instruct players to provide successful deposit receipts or screenshots.
- Remind players to check with their payment providers if deposits do not reflect promptly.
- Be transparent about verification processes and timeframes.
- Escalate unresolved deposit issues promptly to technical or back-office teams.