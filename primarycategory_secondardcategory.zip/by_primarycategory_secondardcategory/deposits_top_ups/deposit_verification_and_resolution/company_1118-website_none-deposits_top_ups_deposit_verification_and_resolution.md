# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Greet the player and listen to their concern.**  
   Determine if the issue is related to a deposit not credited, delayed, or not reflected in the account, based on the player's description.

2. **Request the relevant deposit proof from the player.**  
   - Ask for the deposit record (e.g., transaction ID, deposit slip, or screen shot of inbox receipt).  
   - For GCash or Maya deposits: request a screenshot of the inbox receipt showing reference number, date/time, and amount.  
   - Confirm the player's username.

3. **Check the provided deposit proof against system records.**  
   - Verify if the deposit corresponds to a transaction in the system.  
   - Ensure that the reference number, date, and time on the deposit record and receipt match.  
   - If provided with the inbox receipt from GCash/Maya, verify it shows the correct details.

4. **Assess the status of the deposit based on the verification:**

   - **If the deposit is processed and reflected:**  
     - Confirm with the player that the balance shows the credited amount.  
     - Close the inquiry, informing the player that the deposit has been successfully credited.

   - **If the deposit is not reflected or not received:**

     a. **Check for potential delays or maintenance issues:**  
        - For GCash: inform the player that delays may occur due to merchant bank issues or GCash maintenance; there is no fixed timeframe.  
        - Suggest trying an alternative payment channel such as Maya if applicable.

     b. **If delay persists:**  
        - Ask the player to provide the deposit inbox receipt (screenshot) and their username for further support investigation.

     c. **If no proof or receipt can be provided:**  
        - Advise the player to contact the payment provider for resolution or refund if necessary.

5. **Handle specific scenarios:**

   - **For delayed or missing GCash deposits:**  
     - Inform the player that GCash deposits can be delayed or not generate receipts due to maintenance.  
     - Notify the player when GCash service is back online if applicable.

   - **If receipts are not generated:**  
     - Explain that GCash transactions might not generate receipts; refunds are not issued solely due to receipt absence.  
     - Emphasize the importance of providing deposit inbox receipts for verification.

6. **If the deposit is confirmed but still not reflected in the account:**  
   - Verify that the deposit record and proof match.  
   - If confirmed, escalate to back-office support for investigation.  
   - Advise the player to wait until the issue is resolved, as the funds are safe.

7. **For situations where deposit issues cannot be resolved or proof is unavailable:**  
   - Inform the player that if no proof can be provided or the deposit cannot be verified, the issue may be beyond immediate resolution and require support escalation or payment provider contact.

8. **Record all exchanges and evidence in the support ticket.**  
   - Attach screenshots of inbox receipts, deposit records, and relevant correspondence.  
   - Document the steps taken for future reference and resolution.

9. **Close the ticket after resolution or when instructing the player to wait for system updates.**

## Notes
- Always verify that the reference number, date, and time on deposit documents match to avoid processing delays.
- Remind players that deposit processing times may vary, especially during high volume or maintenance periods.
- Inform players that GCash deposits may experience delays due to merchant bank issues or ongoing maintenance, with no fixed completion timeframe.
- For GCash deposits not generating receipts, clarify that this is outside the company's responsibility, and refunds are not issued solely on receipt absence, so support must rely on inbox receipts and system verification.

## Key points for communicating with players
- Emphasize the importance of matching reference numbers, dates, and times on receipts and deposits.
- Explain that delays can occur, especially during maintenance or high volume periods.
- Encourage providing clear proof (screenshots of inbox receipt or deposit record) to facilitate swift resolution.
- Clearly inform that GCash deposits may be delayed or not generate receipts during maintenance, with no fixed resolution timeframe.