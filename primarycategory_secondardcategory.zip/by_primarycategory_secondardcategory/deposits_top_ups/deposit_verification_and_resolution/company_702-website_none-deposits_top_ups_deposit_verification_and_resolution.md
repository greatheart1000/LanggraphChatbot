# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive player's deposit inquiry or issue report.**  
   - Determine the nature of the concern: pending deposit, uncredited funds, rejected deposit, or deposit delay.

2. **Request relevant deposit details from the player.**  
   - Ask for a **detailed receipt or screenshot** showing:
     - Sender and recipient information (e.g., GCash, PayMaya, or alternative platform).  
     - Transaction details, including reference or invoice number.  
     - For GCash: instruct them to access 'Inbox' and generate the QRPH invoice or receipt.

3. **Guide the player to view their deposit record if necessary.**  
   - Instruct:  
     - Login to the homepage.  
     - Click on 'Member'.  
     - Select 'Deposit Record'.  
     - Take a screenshot for verification purposes.  

4. **Verify the transaction based on the provided receipt or screenshot.**  
   - Confirm that the receipt clearly shows sender and recipient details, transaction number, and, if possible, the timestamp.  
   - Ensure the deposit meets the current minimum requirements:  
     - GCash: currently able to accept deposits of **300 PHP or more**.  
     - For GCash deposits: check if the deposit amount is at least 200 PHP (according to site-specific rules) and if the payment was successfully initiated.

5. **Check transaction status and potential delays.**  
   - If the deposit was made via GCash or PayMaya, inform the player that transactions may experience delays of **30 to 45 minutes** due to system fluctuations.  
   - For deposits below the current threshold (e.g., 300 PHP for GCash), advise using alternative methods like PayMaya, USDT, or Online Bank Transfer.

6. **Assess the deposit state: credited, pending, deducted but not credited, or rejected.**  
   - If the funds are **deducted but not credited**:  
     - Inform that the amount will be **automatically reimbursed within 24 hours**.  
     - Advise to check for reimbursement within this period or contact GCash support if no reimbursement is received.  
   - If the deposit is **pending or delayed**:  
     - Counsel patience and suggest waiting **30-45 minutes**.  
     - Confirm receipt after that period or ask the player to resubmit proof if still not reflected.

7. **Verify if the deposit has been credited to the player's account.**  
   - Check in the 'Deposit Record'.  
   - If not credited, confirm the receipt details with the player and request additional proof if necessary.

8. **Handle rejected or failed deposits.**  
   - If a deposit transaction was rejected or failed:  
     - Notify the player that funds deducted during such transactions will be **automatically reimbursed within 24 hours**.  
     - Advise verifying with payment provider if needed.  
  
9. **For ongoing issues or unresolved cases:**  
   - Escalate the issue to the finance or technical team with all proof collected.  
   - Advise players to keep their proof (screenshots, receipts) for support verification.

10. **Advise on alternative deposit methods if problems persist.**  
    - Recommend switching to PayMaya (which includes a **2% rebate**), USDT, GrabPay, Gotyme, or Online Bank Transfer during GCash or PayMaya system issues.

11. **Close the case after resolution.**  
    - Confirm that the deposit is correctly credited or reimbursed.  
    - Inform the player of the next steps if further assistance is needed.  
    - Document the resolution and any relevant proof for internal records.

## Notes

- Always ask for a **clear, detailed receipt** showing the sender and recipient information for each deposit issue.  
- Be aware that **system delays** are common during network fluctuations, especially with GCash and PayMaya.  
- When verifying, **timely confirmation** (within 30-45 minutes) is crucial; delays beyond that should be escalated with proof of transaction.  
- Reimbursements for deducted funds will normally be processed within **24 hours** unless there are exceptional circumstances.  
- Use alternative deposit methods during technical difficulties to ensure smooth fund transfer for players.

## Key points for communicating with players

- Clearly explain that deposit verification requires a detailed receipt and the deposit record screenshot.  
- Remind players that GCash deposits currently have a **30-45 minute processing delay** due to system issues.  
- Reassure that funds deducted but not credited will be reimbursed within **24 hours**.  
- Suggest alternative payment options if they experience persistent delays or problems with GCash.  
- Keep communication polite, reassuring, and informative to minimize frustration and ensure clarity.