# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the player’s deposit issue**:
   - Determine if the player reports that a deposit has not credited, is missing, or is reversed/not reflected in their account.

2. **Gather necessary information from the player**:
   - Ask for the specific deposit method used (e.g., GCash, PayMaya, online bank, GrabPay, PalwanPay).
   - Request the deposit details, including the date and time of the transaction.
   - Instruct the player to provide relevant screenshots:
     - Transfer receipt (successful transaction receipt from GCash/PayMaya or online bank)
     - Deposit history receipt showing the transaction

3. **Verify the provided documentation**:
   - Check that the screenshots cover the same time frame as the deposit history.
   - Confirm that the transfer receipt indicates a successful transfer.
   - Ensure the timestamps on the receipts match the player’s claim and deposit history.

4. **Perform system and transaction checks**:
   - Verify whether the deposit appears in the system:
     - If it appears, proceed to confirm the credited amount.
     - If it does not appear, proceed to further investigation.
   - Cross-check the deposit details with transaction logs for consistency.

5. **Assess deposit status and potential issues**:
   - If the deposit is not credited or not reflected:
     - Confirm with the player whether the deposit has been reversed or is pending.
     - For unsettled or delayed deposits (e.g., due to system maintenance or unstable transactions like GCASH), notify the player of current system status.
   - For failed GCASH/PayMaya transactions:
     - Advise the player to check the transaction reference with their payment provider and contact their support if necessary.
   - If the deposit was made but not credited:
     - Ensure the screenshots match the deposit timeframe.
     - Advise the player to submit the transfer receipt and deposit history as proof.

6. **Address deposit issues based on causality**:
   - If deposit appears to be successful but not credited:
     - Ask the player to resubmit screenshots if needed.
     - Escalate the case for further investigation if the problem persists.
   - If the deposit was reversed or failed:
     - Guide the player to contact their payment provider support for resolution.
   
7. **Remind the player of deposit policies**:
   - First deposits must be at least 500 PHP.
   - Subsequent deposits can start from 50 or 100 PHP, depending on the channel.
   - For deposits not credited or not reflected:
     - Encourage rechecking the deposit, ensuring proper transfer, and submitting validated proof.

8. **Provide clear instructions for next steps or escalation**:
   - If all documentation is correct but the deposit is still unresolved, escalate the case following internal procedures.
   - Communicate expected time frames for resolution and ask the player to wait patiently during system maintenance or ongoing investigations.

## Notes

- During system maintenance or when deposit channels like QRPH are unavailable, advise players to use alternative channels such as PayMaya, GrabPay, PalwanPay, or bank cards.
- Remind players that deposit verification requires matching timestamps and complete screenshots of transfer receipts and deposit history.
- Inform players that deposit delays or failures may occur during system maintenance, and they should attempt again later or use alternative deposit methods.

## Key points for communicating with players

- Always request clear, timestamped screenshots of transfer receipts and deposit history.
- Remind players of the minimum deposit amounts: 500 PHP for first deposits, 50/100 PHP afterwards depending on the channel.
- Clarify that deposit delays can occur during system maintenance, especially with GCASH.
- Encourage players to contact their payment provider if deposits are not credited or reversed.
- Be transparent about the process and expected resolution times, especially during ongoing system or channel maintenance.