# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather player information and deposit evidence**
   - Ask the player to provide their username.
   - Request the deposit receipt from their payment method (e.g., GCASH INBOX or MAYA transaction screenshot).
   - If the receipt is not available, advise the player to contact their payment provider for assistance or refunds.

2. **Verify the submitted deposit evidence**
   - Confirm that the receipt shows a payment status of 'Paid' or 'Sent' (for GCASH receipts).
   - Do not accept receipts showing 'Received' as proof of payment; advise the player to contact GCash support if needed.
   - Ensure the receipt corresponds to the correct username and transaction details.

3. **Check the transaction status in the system**
   - Search for the player's transaction in the back-office system using their username and deposit details.
   - Determine if the deposit appears as pending, processed, or uncredited.

4. **Determine the nature of the deposit issue and proceed accordingly**

   - **If the deposit is delayed but the receipt indicates payment:**
     - Inform the player that delays can occur due to bank processing times, payment gateway maintenance, or high volume.
     - Advise patience, as deposits will credit once processing completes.
     - If the deposit remains uncredited after a reasonable period, escalate and verify the transaction with the payment provider or bank.

   - **If the deposit does not reflect in the player's balance:**
     - Verify the receipt submitted.
     - Confirm the transaction in the system; if missing, escalate the case for further investigation.
     - For GCASH deposits not credited, advise the player to contact GCASH support for refunds if the receipt shows 'Paid' or 'Sent' but not reflected in their account.

   - **If the deposit via QRPH bounces or is not received:**
     - Inform the player that refunds are generally processed after 24 to 48 hours if the deposit bounces.
     - Request the player to monitor their balance for the refund.
   
   - **If the deposit is still pending or not received due to maintenance:**
     - Notify the player that the current payment method may be under maintenance and deposits might be delayed.
     - Recommend using alternative payment methods (e.g., Maya) if available.
     - Instruct the player to wait until the maintenance is completed before retrying.

5. **Guide the player on next steps if deposit issues persist**
   - If the deposit was sent but is uncredited after verification and waiting, escalate the case to the support team for manual review.
   - Confirm the player has retained all evidence and relevant transaction details for reference.

6. **Communicate resolution and close the case**
   - Provide the player with a clear explanation based on the review:
     - Confirm if the deposit is pending, credited, refunded, or failed.
     - If credit is pending, advise patiently waiting.
     - If refunded or unable to be credited, inform about the process taken.
   - Confirm the player understands the situation and has any additional questions addressed.
   - Close the support case once the issue is resolved or escalated appropriately.

## Notes
- Always request the deposit receipt (from GCASH INBOX or MAYA) and username as evidence.
- Ensure receipts show 'Paid' or 'Sent' as the transaction status to validate the payment.
- For uncredited deposits, advise players to contact their payment provider (e.g., GCASH support) if receipts are valid but funds are not reflected.
- Deposits may be delayed temporarily due to maintenance or high volume; patience is recommended.
- When refunding via payment provider (like GCASH), direct players to contact that provider for processing refunds if their receipt confirms a completed payment.

## Key points for communicating with players
- Emphasize the importance of retaining deposit receipts and providing clear transaction details.
- Clearly explain potential delays caused by maintenance or bank processing.
- Encourage patience during pending cases and assure follow-up actions are underway.
- Guide players on contacting their payment provider if receipts are valid but funds are not credited.