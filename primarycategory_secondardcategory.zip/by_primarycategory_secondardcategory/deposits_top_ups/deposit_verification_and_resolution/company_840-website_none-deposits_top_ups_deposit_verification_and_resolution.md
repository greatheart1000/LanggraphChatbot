# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or notification of an issue.**  
   - Collect detailed information from the player, including the deposit method used (e.g., GCash, Maya, Online Bank Transfer), the exact deposit amount, date, and time of the transaction.  
   - Ask if the deposit is deducted but not credited, delayed, or not reflected in the account balance.

2. **Verify the player's deposit record in the system.**  
   - Guide the player to view their Deposit Record:  
     - Log in to the account.  
     - Navigate to "Profile" > "Deposit Record."  
     - Request the player to take a screenshot of this record showing the deposit details.  
   - Confirm with the player if the deposit record matches their transaction.

3. **Collect proof of payment from the player.**  
   - Instruct the player to provide a screenshot or proof of payment, which varies depending on the deposit method:  
     - For GCash/PayMaya: Access the respective app, generate the deposit receipt/invoice (e.g., via GCASH Inbox > generate QRPH invoice), and take a screenshot.  
     - For bank transfers or other methods: Obtain a transaction receipt or screenshot showing sender, recipient, date, and amount.

4. **Assess the deposit status based on provided documentation.**  
   - If the player reports funds deducted but not credited:  
     - Verify that the deposit receipt shows the sender and recipient details clearly.  
     - Inform the player that if the funds are deducted but not yet credited, the system will automatically reimburse the amount within 2 to 3 days.  
     - Advise the player to monitor their account for the reimbursement.

   - If the deposit is delayed or not reflected:  
     - Confirm receipt of the proof of payment.  
     - Check the transaction details against the deposit record.  
     - If the deposit is via GCash or Maya and shows as completed in the app:  
       - Suggest refreshing the account balance after a few minutes.  
       - Confirm the deposit receipt details, including sender, recipient, and date/time.  
     - If the deposit is via GCash/Maya and still not reflected after verification:  
       - Advise using alternative deposit methods such as PayMaya (with 2% rebate), USDT, GrabPay, or Online Bank Transfer.  
       - Inform that processing may take 30–45 minutes.

5. **If the deposit is not posted or not reflected after verification:**  
   - Verify that the deposit receipt includes all required information (sender and recipient details).  
   - Confirm in the system if the deposit transaction exists.  
   - If it does, process the deposit for credit manually after verification.  
   - If the transaction does not appear or cannot be verified:  
     - Advise the player to contact their payment provider (e.g., GCash Customer Service) for further assistance.  
     - Recommend providing the transaction ID or screenshot to their provider if needed.

6. **Alternative deposit methods and troubleshooting:**  
   - If GCash or Maya deposits face issues or unavailability (e.g., maintenance), guide players to use alternative methods: PayMaya, USDT, GrabPay, or Online Bank Transfer.  
   - Remind players that deposits typically process within 30–45 minutes after initiation.

7. **Reimbursements and refunds:**  
   - If funds are deducted but not credited and the deposit does not appear after 2–3 days, advise players to contact their payment provider for a refund.  
   - Notify that reimbursements happen automatically after verification; if delays occur, escalation to support or provider is necessary.

8. **Complete the case:**
   - Once the deposit has been verified and credited in the system, inform the player of successful deposit recognition.  
   - Provide further instructions if applicable (e.g., refresh the account, check deposit records).  
   - Confirm that any issues have been resolved or escalate if unresolved.

## Notes

- Always require a screenshot of the deposit record and proof of payment for verification.  
- Remind players that deposit processing involves verification which may take up to 30–45 minutes, especially during high-volume periods or system maintenance.  
- For GCash deposits, ensure the deposit invoice is generated through GCASH Inbox to obtain a valid receipt.  
- Inform players that in case of deductions but no credit, reimbursements should be reflected within 2 to 3 days.  
- Encourage the use of alternative deposit methods if persistent issues occur with GCash or Maya.

## Key points for communicating with players

- Emphasize the importance of providing clear deposit receipts with sender and recipient details.  
- Clarify that deposit verification may take up to 30–45 minutes after proof submission.  
- Advise on alternative deposit options if delays or technical issues persist.  
- Be transparent about processing times, reimbursements, and escalation steps when necessary.