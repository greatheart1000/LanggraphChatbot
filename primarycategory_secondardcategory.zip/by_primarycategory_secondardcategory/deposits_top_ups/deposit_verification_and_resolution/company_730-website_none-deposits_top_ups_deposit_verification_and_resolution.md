# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player Information and Deposit Details**
   - Request the player to provide the proof of payment, such as a screenshot of the transaction confirmation message or transaction history from their payment method (GCASH, PayMaya, Maya, etc.).
   - Ask for the detailed deposit receipt or screenshot showing sender and recipient information.
   - Confirm the deposit amount and the selected deposit method.

2. **Verify Deposit Record in the System**
   - Guide the player to access their deposit record:
     - Log into the homepage.
     - Click on 'Member.'
     - Select 'Deposit Record.'
   - Instruct the player to take a screenshot of the deposit record for reference.
   - Cross-check the deposit record with the proof of payment provided.

3. **Check for Deposit Status**
   - Determine if the deposit has already been credited to the player's account:
     - If credited, inform the player that the deposit was successful.
     - If pending or not credited:
       - Confirm whether the deposit appears in the deposit record.
       - Check for any indications of rejection or delay.

4. **Assess Deposit Issues Based on Payment Method and Network Conditions**
   - If the deposit is delayed or pending due to GCash network issues:
     - Explain that fluctuations and delays are common during network instability.
     - Advise the player to wait and check again later.
     - Suggest using an alternative deposit method like Maya or online banking for smoother transactions.
     - If the player used Maya, inform them that it offers a 6% rebate and higher stability.
   - If the player used GCash or PayMaya during GCash outages:
     - Recommend switching to Maya or online banking.
     - Remind that PayMaya deposits include a 2% rebate.
   - If the deposit is rejected:
     - Inform the player that funds deducted will be reimbursed within 2–3 days.
     - Advise to provide proof of payment for verification if needed.

5. **Verify Payment and Process Deposit**
   - Use the provided proof to verify the transaction:
     - Confirm the details match the deposit record.
     - Check for any network or transaction errors.
   - If the deposit is uncredited but the proof is valid:
     - Resubmit the deposit for manual processing.
     - Contact support if necessary, attaching the proof of payment.

6. **Handle Deposit Discrepancies or Missing Credits**
   - If the deposit does not appear in the system after verification:
     - Escalate the case to the support team for manual review.
     - Communicate to the player that their deposit is under review.
     - Keep the player informed about the progress.
   - If the deposit is rejected:
     - Reimburse the deducted funds within 2–3 days.
     - Provide the player with instructions on how to deposit again using alternative methods if needed.

7. **Follow Up and Finalize the Resolution**
   - Confirm with the player once the deposit is credited or reimbursed.
   - Ensure the deposit record is correct and matches the payment proof.
   - Advise the player to retain screenshots of deposit records and transaction history for future reference.

## Notes

- GCash network issues can cause deposits to be pending; always check the deposit record and advise waiting or switching channels.
- Alternative deposit methods such as Maya or Online Bank Transfer are recommended during GCash outages.
- Providing a screenshot of the transaction in the payment app (GCash, PayMaya, Maya) is essential for deposit verification.
- Reimbursements for deducted funds generally occur within 24 hours, but delays up to 2–3 days are possible in cases of rejection.
- Always verify sender and recipient details, including screenshot proof, before processing manual credits or reimbursements.

## Key points for communicating with players

- Clearly explain that network fluctuations can cause delays or pending statuses.
- Encourage the use of alternative methods like Maya, which offers better stability and rebates.
- Remind players to keep screenshots of their transaction history and deposit record.
- Reassure that funds are secure and will be processed as soon as the deposit is verified.
- Keep the tone helpful and transparent, providing updates on the case status and next steps.