# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive and document the player's deposit inquiry or issue report.**  
   - Collect the player's account details, including username, email, and contact information.  
   - Ask for details about the deposit, such as the amount, payment method used, and transaction date/time.

2. **Request proof of payment if not already provided.**  
   - Ask the player to upload a screenshot or record of the transaction receipt or confirmation, including sender and recipient details.  
   - Emphasize that proof must clearly show the transaction details, especially for e-wallets like GCash, PayMaya, or bank transfers.

3. **Verify the transaction details in the system.**  
   - Check if the deposit has been processed and credited in your system.  
   - Confirm that the deposited amount matches the player's record and that the payment method used corresponds with the transaction.

4. **If the deposit has been credited:**
   - Confirm to the player that their deposit has been received and credited to their account.  
   - Advise them to check their account balance or transaction history for confirmation.

5. **If the deposit is pending or delayed:**
   - Inform the player that deposit transactions via GCash, PayMaya, or bank transfer typically take between 30 to 45 minutes during normal operations.  
   - Explain that delays may occur due to network fluctuations or system issues, especially with GCash or other e-wallet transactions.  
   - Recommend waiting for 30-45 minutes and refreshing their account.  
   
6. **If the deposit has not been credited after the expected processing time:**
   - Ask the player if they have already uploaded proof of payment.  
   - Verify their submitted proof against the transaction's details.  
   - If confirmed that the payment was successful from their end, advise waiting longer or switching to an alternative deposit method.

7. **Offer alternative deposit methods if delays persist or issues occur:**
   - Suggest using PayMaya, USDT, GrabPay, or Online Bank Transfer as alternatives.  
   - Remind the player that these methods also typically process within 30 to 45 minutes but may sometimes experience delays during high-volume periods or network issues.

8. **In case of repeat issues or confirmed failed transactions:**
   - Guide the player to reattempt deposit with a different method if suitable.  
   - Verify that account details are correct and linked properly.  
   - For deposits below 1,000 PHP via GCash, recommend using PayMaya for smoother processing based on policies.

9. **For unresolved deposit issues or extended delays:**
   - Request the player to provide all relevant transaction details, proof of payment, and screenshots.  
   - Escalate the case to the finance or back-office team for further investigation if necessary.

10. **Confirm and close the case:**
    - Once the deposit is credited, inform the player that their issue is resolved.  
    - Advise them to check their account balance and transaction history to verify the credited amount.  
    - Recommend contacting support again if the deposit is still not reflected after confirmation.

## Notes
- Always verify the transaction receipt or proof of payment, including sender and recipient details, especially for e-wallet and bank transfer deposits.
- Deposits via GCash may be delayed due to network fluctuations; users are advised to wait 30-45 minutes before taking further action.
- During system or network issues, advise players to use alternative deposit methods like PayMaya, USDT, GrabPay, or online bank transfers.
- Deposit and withdrawal processing times typically range from 30 to 45 minutes, but can extend during high-volume periods or technical disruptions.
- If a deposit or bonus does not reflect, ensure the player's account meets all eligibility criteria and check transaction records before escalating.
- Remember that deposits are only credited after verification, and withdrawals require completing the designated turnover first (e.g., betting in eligible games).