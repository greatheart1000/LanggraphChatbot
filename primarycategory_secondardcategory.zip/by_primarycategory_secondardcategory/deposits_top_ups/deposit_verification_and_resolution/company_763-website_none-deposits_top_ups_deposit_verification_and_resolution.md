# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the deposit concern from the player**, including details of the issue (e.g., deposit not reflecting, delay, or uncredited deposit).

2. **Request the player to provide a detailed deposit receipt** showing:
   - Sender information (e.g., GCash/Maya account details)
   - Recipient information (player's account or wallet)
   - Transaction details (reference number, date, amount)

   *Note: For GCash/Maya deposits, the receipt can be obtained by the player through the payment app's Inbox, where they should generate the QRPH invoice and take a screenshot.*

3. **Ask the player to access their deposit record**:
   - Navigate to the homepage
   - Click on "Member"
   - Select "Deposit Record"
   - Take a screenshot if needed

4. **Verify the receipt and deposit record**:
   - Confirm that the receipt clearly shows sender, recipient, and transaction details
   - Check that the deposit record matches the provided receipt

5. **Instruct the player to submit the screenshot(s) of**:
   - The deposit receipt
   - The deposit record

6. **Check for deposit reflection in the system**:
   - Review the deposit record for matching transaction reference and amount
   - If the deposit has not reflected or the balance hasn't updated:
     - Confirm the details match
     - Ensure the receipt shows the correct sender/recipient info

7. **Perform back-office verification**:
   - Use the provided receipt and deposit record details for manual verification
   - Confirm the transaction status with GCash/Maya network records if necessary

8. **Communicate to the player based on the verification outcome**:

   - **If the deposit is verified and has not yet been credited**:
     - Inform the player that the deposit is being processed
     - Note that deposits via GCash are subject to 30-45 minutes processing time; alternative methods like PayMaya or bank transfer may process faster
     - Advise the player to wait for verification and system update

   - **If the deposit is verified and credited to their account**:
     - Confirm the deposit has been successfully processed
     - Guide the player to refresh their wallet or account to see the updated balance

   - **If the deposit does not match or verification fails**:
     - Request the player to double-check the receipt and deposit details
     - If discrepancies persist, escalate to the finance/support team with all submitted evidence

9. **Address common issues**:
   - If the deposit is delayed or pending due to network issues:
     - Advise the player to wait up to 30-45 minutes for GCash payments or check the transaction status in their payment app
   - If the deposit does not reflect after extended wait:
     - Confirm the accuracy of the deposit details
     - Reiterate the need for a clear receipt and deposit record
     - Escalate the case if verification is unsuccessful after resource checks

10. **Recommend alternative deposit methods if delays persist or if the player experiences consistent issues**:
    - Suggest using PayMaya (which offers a 6% rebate and higher stability)
    - Consider online bank transfers or USDT, especially during GCash network fluctuations

11. **Follow up and close the case**:
    - Confirm with the player once the deposit is verified and credited
    - Provide guidance on how to view deposit records and receipts if they need future reference
    - Thank the player for their patience and ensure satisfaction with the resolution

## Notes
- Always ask for clear, legible screenshots showing sender and recipient details and transaction reference number.
- For deposit issues, processing times can vary; delays are often caused by network fluctuations or system verification.
- When verifying GCash or Maya deposits, the receipt must include the current date/time, sender info, and the transaction reference for faster processing.
- Use the deposit record in the user's account for additional confirmation.

## Key points for communicating with players
- Emphasize the importance of providing a detailed receipt showing sender, recipient, and transaction info.
- Explain that verification might take up to 30-45 minutes for GCash deposits and suggest alternative methods for faster deposits.
- Reassure players that their funds are secured and will be credited after successful verification.
- Encourage patience during system checks and network stabilizations, especially during GCash network fluctuations.