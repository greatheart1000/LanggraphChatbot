# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the nature of the deposit issue or inquiry.**  
   - Determine if the player is reporting a deposit not reflected in their account, a delayed or pending deposit, a failed deposit, or a technical issue with a specific deposit method (e.g., GCASH, PayMaya, USDT).  
   - Clarify if the player is providing proof or requesting verification.

2. **Request and collect necessary information and evidence from the player.**  
   - For deposit verification:  
     - Obtain a screenshot or proof of payment, including transaction confirmation message from the payment provider (GCASH/PayMaya, or other relevant app).  
     - Ask for details such as sender and recipient info, deposit amount, transaction reference if available.  
   - For deposit record check:  
     - Direct the player to access Deposit Record in their Member account:  
       * Homepage > Member > Deposit Record.  
     - Request a screenshot showing sender and recipient details if needed.

3. **Verify the deposit proof and details provided.**  
   - Confirm the screenshot shows the necessary transaction details.  
   - Check the transaction in the payment provider’s app (GCASH/PayMaya or others) if possible, to verify the confirmed payment.

4. **Check the deposit status in the system.**  
   - Look up the deposit record in the back office system using the provided details.  
   - Confirm whether the payment has been credited or is still pending.

5. **Determine the appropriate action based on deposit status and system verification.**  
   - **If the deposit is not reflected in the user’s account and deposit proof is valid:**  
     - If within the standard processing time (30–45 mins for GCash/PayMaya), advise the player to wait and check later.  
     - If the deposit is delayed beyond 45 mins, escalate for manual review or verification.  
   - **If the deposit is pending due to network delays (common with GCash):**  
     - Inform the player that delays are often caused by network fluctuations and can take up to 30–45 minutes.  
     - Recommend waiting or trying alternative deposit methods if urgent.  
   - **If the deposit is confirmed in the payment provider but not credited in the system:**  
     - Submit the proof to support for verification.  
     - Once verified, credit the deposit to the player's account and notify them of completion.  
   - **If the deposit is erroneous, deducted but not credited, or the deposit record shows issues:**  
     - Confirm the transaction details.  
     - Reimburse the deducted funds to the player's account if applicable.  
     - Inform the player of the reimbursement or next steps.

6. **Advise the player on alternative deposit methods if issues persist.**  
   - If GCASH is down or not credited, suggest using alternatives such as PayMaya (with 2% rebate), USDT, GrabPay, Gotyme, or Online Bank Transfer.  
   - Remind about the minimum deposit amount for GCASH (e.g., 200 PHP or 500 PHP, depending on current rules).

7. **Educate the player on the deposit rules and expected processing times.**  
   - Explain that deposits typically process immediately but may be delayed due to network issues.  
   - Clarify that network fluctuations might cause pending status and to monitor their balance later.  
   - Emphasize that all deposit transactions require proof for verification when issues arise.

8. **If further assistance is needed or the issue is unresolved:**  
   - Escalate to more specialized support with all collected proof and details.  
   - Keep the player informed of progress and next steps.

## Notes

- Always verify screenshots and transaction details for authenticity and completeness.  
- For delayed deposits, advise waiting 30–45 minutes and checking back later.  
- Highlight that deposits via GCash, PayMaya, USDT, GrabPay, and Online Bank Transfer are processed in 30–45 minutes, but delays can occur due to network fluctuations.  
- When providing proof, ensure the screenshot contains sender/recipient details and amount.  
- Reimburse any funds deducted but not credited if verified as an error or system fault.

## Key points for communicating with players

- Remind players that GCash deposits of 200 PHP or more are accepted, and for PayMaya, a 2% rebate is available.  
- Explain that network delays may cause pending status, and advise patience or switching to alternative methods if necessary.  
- Clearly instruct players on how to access their deposit record and how to provide proof of payment.  
- Reassure players that all verified deposits will be credited after validation, typically within 30–45 minutes, unless system issues arise.