# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry**  
   - Obtain from the player:  
     - Successful deposit receipt (screenshot or transaction confirmation)  
     - Username or game ID  
     - In-game deposit history  

2. **Verify the provided information**  
   - Check if the player has uploaded a clear, valid screenshot or proof of the successful deposit.  
   - Confirm the username or game ID matches the account.  
   - Review the in-game deposit history for corresponding transaction details.  

3. **Check the deposit status in the system**  
   - Review the transaction details in the back office or system records.  
   - Confirm whether the deposit has been processed automatically.  
   - Evaluate if the deposit reflects in the account within the expected processing time (up to 72 hours).  
   - For delays or missing credits:  

     - Ensure the player has provided a valid transaction receipt.  
     - Verify if the deposit transaction is present in the payment provider's records.  

4. **Assess if the deposit has been credited**  
   - If the deposit has been credited:  
     - Inform the player that the deposit has been successfully credited and is visible in their account.  

   - If the deposit has not been credited:  
     - Check if the deposit receipt is uploaded properly and clearly.  
     - Confirm if the deposit meets minimum deposit limits (e.g., 100 PHP) and maximum deposit limits (e.g., 25,000 PHP).  
     - For automated processing delays, advise the player to wait up to 72 hours, depending on their payment method.  
     - If the 72-hour period has passed or if the deposit is not credited despite proper proof and adherence to rules, proceed to escalate the issue.  

5. **Resolve deposit issues**  
   - **If the deposit receipt is valid and verified but funds are delayed:**  
     - Advise the player to wait, and inform them that the system processes deposits automatically.  
   
   - **If the deposit receipt is invalid, incomplete, or not uploaded:**  
     - Request a clear, valid screenshot of the successful deposit transaction.  
     - Explain the importance of uploading a clear proof for verification.  
   
   - **If the deposit was sent to the wrong wallet:**  
     - Inform the player that such funds are returned automatically after 3 days.  
     - Advise them to contact support if they do not receive the funds after this period.  
  
6. **Request additional information if needed**  
   - If the issue remains unresolved, ask the player to provide:  
     - Transaction ID (if available)  
     - Exact date and time of the payment  
     - Any relevant screenshots or proof of the deposit  

7. **Follow up and escalate if necessary**  
   - If unable to resolve with the provided information, escalate the case to the technical or payment team for further investigation.  
   - Keep the player informed of the escalation status and expected resolution timeframe.  

8. **Close the support case**  
   - Once the deposit is verified and credited, inform the player that the issue has been resolved.  
   - Confirm the deposit amount and that it is reflected in their account.  
   - Record all relevant details and communication for future reference.  

## Notes
- Always verify deposit proof thoroughly; unclear screenshots can delay resolution.  
- Remind players that deposits are processed automatically and can take up to 72 hours depending on the payment method.  
- For deposit delays or issues, avoid multiple deposit attempts—advise to wait or provide proper proof instead.  
- Ensure compliance with deposit limits, which are between 50 PHP and 20,000 PHP, and the daily withdrawal limit of 25,000 PHP.  

## Key points for communicating with players
- Clearly ask for a successful deposit receipt, username or game ID, and deposit history.  
- Reassure players that deposits are processed automatically but may be delayed due to system overload or verification steps.  
- Advise patience and provide guidance on how to provide proper proof for faster resolution.  
- Always keep the player updated on the status of their issue and avoid promising fixed resolution times beyond system processing estimates.