# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive player inquiry regarding deposit issues or verification.**  
   - Confirm the player’s account details and nature of the issue (e.g., deposit not reflected, delayed, rejected, or unrecharged).

2. **Request and collect relevant deposit information from the player.**  
   - For deposit verification, ask the player to provide a detailed receipt that includes sender and recipient information for GCash or PayMaya transactions.  
   - If the deposit was made via GCash:  
     - Instruct the player to log into their GCash account.  
     - Ask them to generate a deposit receipt by selecting 'Inbox' to generate the QRPH invoice.  
   - If using alternative methods, request a screenshot of the deposit record from the 'Deposit Record' section in their account (Home > Member > Deposit Record).

3. **Verify the submitted deposit information.**  
   - Check that the receipt clearly shows the sender and recipient information.  
   - Confirm the date, time, and amount on the receipt match the deposit record.  
   - Ensure the receipt has a negative (-) sign indicating the payment was processed.

4. **Assess the deposit status based on the player's information and system records.**  
   - If the deposit is pending verification (e.g., takes 30-45 minutes for GCash or similar methods), inform the player that the process is ongoing.  
   - If the deposit record exists and the receipt matches:  
     - Proceed to check whether the deposit has been credited.

5. **Determine the deposit outcome and apply the appropriate resolution.**  
   - **If the deposit has not been credited yet:**  
     - Advise the player to wait for the verification process to complete.  
     - If using GCash or similar methods, explain that delays can occur due to network fluctuations and advise alternatives like Maya, which offers higher stability and a 6% rebate.  
   - **If the deposit was deducted but not credited:**  
     - Inform the player that such funds will be automatically reimbursed within 2-3 days.  
     - Remind the player to monitor their account and contact GCash or the respective payment provider if reimbursement does not arrive within this timeframe.  
   - **If the deposit transaction was rejected:**  
     - Assure the player that the deducted funds will be reimbursed within 2-3 days.  
     - If the reimbursement does not occur, advise contacting GCash Customer Service.  
   - **If the deposit was successful but not reflected in the account:**  
     - Confirm the deposit record and receipt match before escalating.  
     - If mismatch or issue persists beyond 45 minutes, escalate for further system review.

6. **Handle delays or technical issues proactively.**  
   - During system or network delays, clarify to the player that their funds are secure and will be credited once the system stabilizes.  
   - Recommend using alternative deposit methods like PayMaya, GrabPay, or online bank transfer in case of ongoing issues with GCash.

7. **Document the case and communicate clearly with the player.**  
   - Summarize the verification results, expected processing time, and next steps.  
   - If applicable, provide guidance on how to obtain the deposit receipt for future verification and records.

8. **Escalate or follow up if unresolved.**  
   - If the deposit is not credited within the expected timeframe or the player reports unresolved issues, escalate the case to the back office with all relevant information:  
     - Player's account details, receipt screenshots, deposit record screenshot, transaction timestamps, and any correspondence.

## Notes

- Always verify that the deposit receipt includes sender and recipient information; incomplete receipts cannot be used for verification.  
- During system disruptions, prioritize alternative deposit methods for faster processing.  
- Reimbursements for deducted but unrewarded deposits are automatically issued within 2-3 days.  
- Use clear, empathetic communication to reassure players about the security of their funds and the steps being taken.

## Key points for communicating with players

- Emphasize the importance of providing detailed receipts showing sender and recipient info.  
- Inform players about typical verification times (30-45 minutes) and the possibility of delays during network issues.  
- Recommend using Maya for higher stability and a 6% deposit rebate.  
- Advise players to retain screenshots of their deposit records and receipts for smooth verification.  
- Guide them to contact GCash support if reimbursement or refunds are not received within the specified timeframe.