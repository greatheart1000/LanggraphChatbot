# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive and review the player's report**  
   - Collect the player's account username.  
   - Ask the player to describe the issue (e.g., deposit not credited, delay).  
   - Request the player to provide a clear screenshot of the deposit transaction receipt from the payment provider (e.g., GCash INBOX, PayMaya, Gotyme, Grab).  

2. **Verify the provided information**  
   - Confirm that the screenshot clearly shows the transaction receipt, including the reference number if available.  
   - Ensure the account username matches and is correctly recorded.  
   - If the receipt lacks necessary details, advise the player to locate and resend the correct receipt.  

3. **Check deposit status and system records**  
   - Review the screenshot against your deposit verification system or back office records.  
   - Verify whether the deposit has been confirmed and posted by the payment provider or merchant.  
   - Determine if the deposit appears in the player's account balance after the payment confirmation.  
  
4. **Address common issues and delays**  
   - If the deposit is delayed beyond 24-48 hours, explain to the player that external system issues or maintenance may have caused the delay.  
   - Inform the player that deposits are credited once the payment provider confirms and posts the transaction.  
   - Remind the player to wait up to 24-48 hours and to follow up if the deposit remains uncredited after this period.  

5. **Investigate missing deposits or unresolved issues**  
   - If the deposit has not been credited after the expected time, advise the player to provide additional proof (receipt screenshot) for manual review.  
   - Check if the transaction reference number matches and confirm the receipt with the payment provider if necessary.  
   - If the deposit is confirmed on the payment provider's side but not reflected in the account, escalate for manual processing or follow-up.  

6. **Determine resolution or next steps**  
   - If the deposit is verified and confirmed, credit the deposit to the player's account and notify them of the successful top-up.  
   - If the deposit is unconfirmed or invalid, inform the player that further review is needed or that the deposit cannot be credited, depending on findings.  
   - For unresolved issues after follow-up, escalate the case to the relevant department for further investigation.  

7. **Communicate clearly to the player**  
   - Provide updates at each step, including when requesting receipts, confirming receipt of documents, and final resolutions.  
   - Remind players to verify their transaction receipts and ensure correct deposit procedures in future transactions.  

8. **Close the case**  
   - Once resolved, confirm that the deposit has been credited or adequately explained, and document the case.  
   - Advise the player to contact support immediately if further issues occur.  

## Notes

- Always request a clear screenshot of the deposit receipt, including transaction reference number if available.  
- Be aware that deposits may be delayed due to external system issues or maintenance and advise players accordingly.  
- Follow up after 1-2 hours if the deposit remains pending beyond the expected time.  
- Refunds or deposits delayed beyond 24-48 hours are processed manually; inform players to wait or follow up as needed.  

## Key points for communicating with players

- Emphasize the importance of providing a clear, legible screenshot of the transaction receipt.  
- Be patient and advise players to wait 24-48 hours for deposit processing due to external system factors.  
- Keep players informed of each stage of verification and resolution process.  
- Escalate cases where deposits are confirmed but not credited in the system or where receipt details are unclear.