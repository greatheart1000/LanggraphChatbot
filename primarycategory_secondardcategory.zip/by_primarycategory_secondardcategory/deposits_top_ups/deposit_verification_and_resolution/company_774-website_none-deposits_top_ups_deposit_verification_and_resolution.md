# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial information from the player**
   - Ask for the deposit details, including the deposit amount, date, and method used (e.g., GCash, PayMaya, USDT, Online Bank Transfer).
   - Confirm whether the player has a deposit receipt or screenshot showing the transaction, specifically including sender and recipient details.
   
2. **Verify the deposit method and status in the system**
   - Check the player's deposit record under the Deposit Record page or relevant system logs.
   - If the deposit was made via GCash:
     - Ask the player to open GCash Inbox and generate the QRPH invoice.
     - Request a screenshot of the deposit receipt, clearly showing sender (player's GCash account) and recipient (company account).
   
3. **Determine if the deposit is credited or pending**
   - For GCash:
     - Confirm whether the deposit appears in the player's account balance.
     - Note: GCash network fluctuations may cause delays; advise the player to wait 30-45 minutes or until the deposit is processed.
   - For alternative methods (PayMaya, USDT, Bank Transfer):
     - Check the corresponding transaction logs or receipt status.
   
4. **Identify if the deposit is successful but not reflected in the balance**
   - If the transaction shows as successful on the player's side but not in the account:
     - Verify the receipt against transaction logs.
     - If proof of successful payment exists, inform the player that the deposit is being processed; may take additional time due to network issues.
   
5. **Handle unprocessed or uncredited deposits**
   - If the deposit is deducted from the player's wallet or account but not credited:
     - Reimburse the player automatically within 2-3 days.
     - Request a detailed deposit receipt or screenshot showing the sender and recipient information for verification.
     - Advise the player to wait if the process is ongoing; suggest alternative deposit methods if delays persist.
   
6. **Proceed with deposit verification when proof is provided**
   - Submit the receipt or screenshot (showing sender and recipient details) to the back office/system for verification.
   - Monitor the verification process; delays can occur due to network fluctuations.
   
7. **In case of deposit rejection or failure**
   - Inform the player that if the deposit was rejected, the funds should be reimbursed or returned within 2-3 days.
   - If no reimbursement is received after this period, advise the player to contact the wallet provider (e.g., GCash) for further assistance.
   
8. **Advise on alternative deposit methods if issues persist**
   - If GCash deposits are unstable or unavailable:
     - Recommend using PayMaya (which may include a 2% rebate), USDT, or Online Bank Transfer.
     - For withdrawals, PayMaya may be used, typically with a 6% rebate on each deposit.
   - Suggest switching to alternative payment methods to facilitate smoother transactions.
   
9. **Ensure proper documentation for claims or disputes**
   - Encourage players to retain screenshots of deposit receipts, QRPH invoices, and transaction logs.
   - Provide all supporting proof when submitting a verification request or raising a dispute with the relevant wallet provider.
   
10. **Close the case after successful verification and crediting**
    - Confirm with the player that funds are now reflected in their account.
    - Notify the player that the deposit process is complete.
    - Advise them to refresh their account balance and contact support if issues reoccur.

## Notes

- Always confirm deposit success by checking both the player's transaction record and the receipt.
- Due to fluctuations, deposits via GCash may be delayed; advising a wait time of 30-45 minutes is standard.
- Providing a detailed deposit receipt, including sender and recipient information, is essential for timely verification.
- If a deposit is deducted but not credited within 2-3 days, reimbursement will be processed automatically; if not, players should contact their wallet provider for assistance.
- Alternative deposit methods such as PayMaya, USDT, or Bank Transfer are recommended during GCash network issues, especially since rebate incentives exist on certain methods.

## Key points for communicating with players

- Remind players to check their GCash Inbox and generate the QRPH invoice to obtain a deposit receipt.
- Explain that network issues may delay processing times but funds are secure.
- Encourage players to keep screenshots of all relevant transactions and receipts.
- Recommend switching to alternative payment methods if GCash remains unstable.
- Assure players that deposits are secure and will be credited once verified, with delays due to external network issues.