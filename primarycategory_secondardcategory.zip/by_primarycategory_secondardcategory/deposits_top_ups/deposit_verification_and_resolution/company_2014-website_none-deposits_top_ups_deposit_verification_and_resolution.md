# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or issue report.**  
   Note the deposit amount, method used (e.g., GCash, PayMaya, USDT, GrabPay, online bank transfer), and any relevant transaction details provided by the player.

2. **Request the player to provide a clear screenshot of the deposit receipt or transaction record.**  
   - Ensure the screenshot shows sender and recipient details, date, time, and amount.  
   - Confirm the receipt clearly indicates the deposit method (e.g., GCash sender info).  
   - This is crucial for verification.

3. **Assist the player in verifying the deposit transaction.**  
   - Check the transaction history in the player's e-wallet or bank account if possible.  
   - Confirm the deposit details against the screenshot provided.

4. **Determine whether the deposit has been received and is pending or delayed.**  
   - If deposit was made via GCash or other e-wallets, inform the player that due to network fluctuations or delays, deposits may be pending or delayed.  
   - Standard processing time is 30 to 45 minutes; advise waiting within this period.  
   - For other methods, be aware that deposits are processed upon verification and should reflect shortly after receipt.

5. **Verify the deposit in the system.**  
   - Review the submitted screenshot and details in the verification system or back office tools.  
   - Confirm that the deposit transaction appears in the system records.

6. **If the deposit has arrived and is verified:**  
   - Credit the amount to the player’s account.  
   - Notify the player that the deposit has been successfully credited.  
   - If applicable, inform about any bonuses, cashback, or rebates that will be credited automatically and within 2 hours if eligible.

7. **If the deposit has not arrived after 30-45 minutes (or longer if network delays are ongoing):**  
   - Ask the player to wait a little longer, respecting the typical processing window.  
   - If still not received, review the screenshot and transaction details again.  
   - Confirm whether the player used an accepted method and provided a clear receipt.  
   - If verification is inconclusive, advise the player to consider alternative deposit methods such as PayMaya, USDT, GrabPay, or bank transfer.  
   - Encourage the player to re-submit the screenshot if needed.

8. **In case of persistent delay or issue:**  
   - Escalate the case to the back office or relevant department for manual review.  
   - Explain to the player that the issue is under review and that they will be updated once resolved.

9. **If the deposit appears to be confirmed but still not credited after usual processing time:**  
   - Confirm with the customer support or back office team for verification status.  
   - Communicate to the player that the deposit is under review and the team will update once completed.

10. **In cases of deposit or network issues:**
    - Inform players that due to network fluctuations or delays in GCash or other systems, deposits may be pending.  
    - Reassure that all funds are secure and will be credited automatically once processed.  
    - Suggest the use of alternative payment methods if delays persist.

## Notes

- Always collect a clear screenshot of the deposit receipt showing sender and recipient details.
- Remind players that deposits via GCash may take 30 to 45 minutes; delays beyond this may require further verification.
- For unresolved issues, escalate to the back office for manual review. Do not attempt to credit deposits manually without verification.
- Inform players that bonuses, cashback, and rebates are automatically credited within 2 hours if eligible, and advise patience if they do not appear immediately.

## Key points for communicating with players

- Emphasize patience within the standard 30–45 minute processing time for GCash deposits.
- Stress the importance of providing clear, detailed screenshots to facilitate verification.
- Reassure that all funds are secure and pending deposits will be credited automatically once confirmed.
- When delays happen, recommend alternative deposit methods such as PayMaya, USDT, GrabPay, or bank transfer.