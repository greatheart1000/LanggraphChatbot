# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Greet the player and verify deposit concern.**  
   - Confirm if the player reports a delay, missing deposit, or failed transaction related to GCash, PayMaya, Maya, or other e-wallets.

2. **Request relevant deposit details.**  
   - Ask the player to provide the following:  
     - Screenshot of the deposit receipt, transaction confirmation message, or transaction history showing sender and recipient details.  
     - Specific details such as invoice number, deposit amount, date/time, and the payment method used.  
   - Remind the player that a detailed receipt must include sender and recipient info, with a visible negative (-) sign for confirmed payments.

3. **Guide the player to obtain the deposit receipt if not already provided.**  
   - Instruct the player to log into their GCash or Maya account.  
   - For GCash:  
     - Access 'Inbox' to generate the QRPH invoice.  
     - Take a screenshot of the deposit receipt showing complete details.  
   - For Maya:  
     - Access transaction history, or generate the receipt if applicable.  
     - Take a screenshot of the confirmation message or receipt.

4. **Check the submitted proof of payment.**  
   - Review the screenshot or receipt to verify that it shows:  
     - Sender and recipient details.  
     - Confirmation message or invoice ID.  
     - Transaction amount matching the player’s claimed deposit.

5. **Determine deposit status based on the proof received.**  
   - **If proof is complete and details match:**  
     - Proceed to verify if the deposit has reflected in the player's account.  
   - **If proof is incomplete, unclear, or missing:**  
     - Inform the player that additional detailed proof is required.  
     - Request a clear screenshot showing the full transaction details, including invoice number and sender/recipient info.

6. **Verify if the deposit has been credited to the player's account.**  
   - Check the deposit record in the back office:  
     - Click on 'Member' > 'Deposit Record'.  
     - Look for the specified deposit details matching the provided receipt.  
   - **If the deposit is reflected:**  
     - Confirm successful deposit.  
     - Inform the player that the deposit has been credited and close the case.  
   - **If the deposit is not reflected:**  
     - Confirm the deposit receipt and transaction details.  
     - Advise the player to wait 30 to 45 minutes during GCash or Maya network delays, especially if GCash or Maya deposits are delayed or pending.  
     - Suggest that the player refresh their account after this period.  
     - If the deposit remains uncredited after 45 minutes, proceed to escalate.

7. **If the deposit does not reflect after standard waiting time:**  
   - Ask the player to resend the deposit proof if necessary.  
   - Capture the current deposit record for reference.  
   - Escalate the case with all gathered info and proof to the back office or finance team for further verification and processing.

8. **Inform about alternative methods and current issues if applicable.**  
   - If the player’s deposit involved GCash and is delayed or failed:  
     - Explain that GCash is experiencing network delays; deposits may be pending and funds are secure.  
     - Recommend using Maya for potentially smoother transactions; note that using Maya can provide a 2% rebate.  
     - Advise using alternative deposit methods such as PayMaya, GrabPay, GoTyme, USDT, or Online Bank Transfer.  
   - Emphasize that deposits via GCash may take 30 to 45 minutes for processing, especially during network issues.

9. **Handle failed deposits or transactions.**  
   - If the receipt shows the transaction was not successful or the deposit failed,  
     - Recommend the player try alternative deposit options.  
     - Guide them to re-initiate the deposit with correct details and different payment methods if needed.

10. **Close the case or follow-up as appropriate.**  
    - Provide the player with any further instructions, such as waiting times or alternative deposit options.  
    - Confirm that the issue has been escalated if unresolved after 45 minutes, and inform the player support will follow up.

## Notes

- Always insist on a detailed screenshot of the transaction with sender and recipient info.  
- Encourage patience during network fluctuations, particularly with GCash deposits.  
- Deposits via GCash, Maya, and other e-wallets are subject to network conditions; delays of up to 45 minutes are normal during congestion or maintenance.  
- Use the 'Deposit Record' in the back office for verification; always check if the deposit has been credited before proceeding.  
- When providing proof, ensure the receipt has a negative sign indicating a successful payment.  
- During GCash or Maya network issues, recommend alternative deposit methods for smoother processing.