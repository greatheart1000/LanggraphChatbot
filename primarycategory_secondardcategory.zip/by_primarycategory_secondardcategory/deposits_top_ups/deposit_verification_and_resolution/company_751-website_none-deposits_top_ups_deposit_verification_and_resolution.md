# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or issue report.**  
   - Confirm the deposit method used (e.g., GCash, PayMaya, USDT, Online Bank Transfer, GrabPay, Gotyme).  
   - Request relevant details such as the transaction date, amount, and payment method.

2. **Verify the player's submitted deposit evidence.**  
   - Collect a clear screenshot or photo of the deposit receipt or transaction confirmation.  
   - For GCash deposits, ensure the receipt shows:  
     - Sender name or number (GCash/Maya)  
     - Recipient name or number  
     - Date and time of transaction  
     - Amount sent  
     - Negative (-) sign confirming successful transaction processing  
   - For other methods, verify that the screenshot clearly displays similar details.

3. **Access the deposit record in the back office.**  
   - In the system, navigate to the player's member profile.  
   - Open the 'Deposit Record' section.  
   - Check for a matching transaction record that adheres to the provided receipt details.

4. **Compare the submitted proof with deposit records.**  
   - Confirm that the details (amount, date/time, sender, recipient) match the system record.  
   - Verify the receipt details are clear and legible, matching the deposited amount and time.

5. **Assess the deposit status based on the verification.**  
   - **If the record and receipt match and the deposit has credited to the player's account:**  
     - Inform the player that the deposit has been successfully credited.  
     - Close the case.

   - **If the receipt shows a successful transaction but the deposit has not reflected:**  
     - Check if the deposit is pending or delayed due to network issues, especially for GCash or PayMaya deposits.  
     - Advise the player that deposit delays can occur due to network fluctuations, which may take 30 to 45 minutes.

   - **If no matching record or receipt details:**  
     - Explain that without sufficient proof or matching records, the deposit cannot be verified.  
     - Request a clearer or additional screenshot or receipt.

6. **Handle deposits that are pending or not credited due to technical issues.**  
   - If the deposit was deducted but not credited after 30 to 45 minutes, instruct the player to wait or resubmit evidence:  
     - For GCash deposits, advise to check 'Inbox' within their GCash account and generate the deposit receipt (QRPH invoice).  
     - Share these instructions if needed: log in, select 'Inbox', take a screenshot of the deposit receipt showing sender/recipient info.  
   - Recommend alternative deposit methods if GCash or the current method is experiencing ongoing issues:  
     - PayMaya (with 2% rebate)  
     - USDT  
     - Online Bank Transfer  
     - GrabPay or Gotyme (if applicable)  

7. **Advise the player on refund or reimbursement procedures.**  
   - If funds were deducted but not credited, inform that the funds will be automatically reimbursed within 2 to 3 days.  
   - If reimbursement is delayed beyond this period or the issue persists, instruct to contact the respective payment provider's customer service for assistance.

8. **Escalate cases needing further investigation.**  
   - If verification fails due to insufficient proof, or if the deposit is delayed beyond reasonable time without resolution, escalate to the back-office support team with all collected documentation (screenshots, deposit record details, player communication).  
   - Remind the player that delays might be due to network fluctuations and that their funds are secure.

## Notes

- Always ensure the deposit receipt is clear, includes all necessary transaction details, and clearly shows a successful (-) sign if applicable.  
- Do not process refunds or reimbursements without verified proof matching system records.  
- GCash deposits are only accepted for amounts of 200 PHP or more; for lower amounts, advise alternative methods.  
- During GCash network issues, deposits are temporarily limited to 500 PHP or more (if applicable).  

## Key points for communicating with players

- Explain that deposit delays can occur due to network fluctuations, especially with GCash or PayMaya.  
- Remind players to make and retain clear, complete deposit screenshots, particularly the one from their GCash or other e-wallet inbox.  
- Clearly advise on the normal processing time (30–45 minutes) and the steps to verify deposit receipts.  
- Encourage players to use alternative methods if they encounter ongoing issues with their current deposit method.  
- Reassure players that funds deducted but not credited are usually reimbursed automatically within 2–3 days, but they can contact support if delayed.