# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive and review the player’s deposit inquiry.**  
   Collect the following information from the player:
   - Player username  
   - Payment method used (e.g., GCash, Maya, Gotyme)  
   - Deposit amount  
   - Date and time of the transaction  
   - Screenshot or receipt of the deposit (if available)  

2. **Check for any system or platform notifications regarding ongoing maintenance.**  
   - Verify if the payment provider (e-wallet platform) is under maintenance.  
   - If the provider is under maintenance, inform the player that their balance may appear temporarily stuck and will be automatically restored once the maintenance ends. Do not process further until maintenance concludes.

3. **Verify the deposit transaction in the back office/system.**  
   - Confirm if the deposit has been successfully transferred via the payment provider (e-wallet platform).  
   - Check if the deposit has been verified by the finance department and credited to the player’s account.  

4. **If the deposit has been credited successfully:**  
   - Notify the player that their deposit has been received and credited to their account.  
   - Advise that deposits may take some time due to banking network delays, but they should see the credit reflected shortly.  
   - Close the case if no further issues are reported.  

5. **If the deposit has not been credited or is unverified:**  
   - Ask the player to prepare a screenshot of the deposit receipt (e.g., GCash, PayMaya, Gotyme) along with their username.  
   - Instruct the player to submit the screenshot to support for verification.  
   - Verify the receipt details against the transaction in your system.  
   - Remind the player to ensure the following:
     - Use of current QR code (avoid old codes).  
     - Correct payment method is used for depositing.  

6. **Assess the deposit status based on receipt verification:**  
   - If the receipt matches a successful transaction, escalate for manual processing or check with the finance department.  
   - If the receipt is missing or incorrect, guide the player to double-check the transaction details and resubmit if necessary.  

7. **In case of unresolved deposit issues:**  
   - Clearly inform the player that deposits are processed according to policy and processing times may vary, especially during high volume.  
   - Advise to wait a reasonable period and retry the verification if needed.  
   - Keep open communication and escalate to a supervisor if the deposit remains uncredited after a significant delay or if technical issues persist.  

8. **Document all interactions and verification results.**  
   - Attach relevant screenshots and notes to the case for future reference.  
   - Follow your company's internal procedures for resolution and escalation if required.

## Notes

- Always confirm if the deposit is under maintenance or system issue before proceeding with manual verification.  
- Emphasize to players the importance of using the current QR code and correct payment method to avoid QR code problems.  
- Remind agents to handle deposit issues promptly and keep players informed throughout the process.

## Key points for communicating with players

- Inform players about possible delays due to banking network issues or maintenance.  
- Guide players to submit clear, recent receipts with correct transaction details.  
- Explain that deposits may take some time to process, especially during high volume.  
- Encourage players to double-check transaction details if deposits are not credited.  
- Reassure players that their balance will be restored automatically if affected by maintenance.