# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player Deposit Information**
   - Ask the player for details of the transaction:
     - Payment method (e.g., GCash, PayMaya, Bank Transfer, MAYA)
     - Transaction reference number or receipt
     - Date and time of the deposit
   - Request a clear screenshot or photo of the deposit receipt or transaction confirmation showing:
     - Sender and recipient details
     - Amount
     - Transaction reference number
     - Date and time
   - If using GCash or PayMaya, advise the player to generate or locate the receipt/invoice and include it for verification.

2. **Check Payment Records and Transaction Status**
   - Verify the transaction in the player's e-wallet app (e.g., GCash, PayMaya) or bank account:
     - Confirm the transaction exists with matching details
     - Check for the correct amount and date
   - Retrieve the transaction receipt/invoice from the player's payment inbox if available.

3. **Assess Deposit Status**
   - Determine whether the deposit:
     - Was successful and the funds are pending credit
     - Was deducted but not credited
     - Was rejected or failed
   - Note: Deposits made via GCash or PayMaya will normally process within a maximum of 12 hours once verified.

4. **Verify the Transaction with Support Systems**
   - Submit the player's deposit receipt/invoice and transaction reference to the finance or verification system for validation.
   - Confirm whether the deposit has been processed on the back end:
     - If verified, proceed to credit the player's account
     - If not verified, inform the player that verification is pending or unsuccessful

5. **Handle Uncredited Deposits with Successful Payment**
   - If the deposit was successfully made, but funds are not credited:
     - Allow up to 12 hours for automatic processing
     - If still uncredited after this period:
       - Re-verify the provided receipt and transaction details
       - Escalate to the finance team for manual review if necessary

6. **Address Deposits Deducted but Not Credited**
   - Inform the player that funds deducted from their payment provider (e.g., GCash) will typically be reimbursed to their account within 2-3 days if not credited.
   - If reimbursement does not occur within this period:
     - Advise the player to contact their payment provider (e.g., GCash customer service) for assistance

7. **Reimburse or Confirm Credit**
   - When the deposit is verified:
     - Credit the player's account with the confirmed amount
     - Send a confirmation message to the player with the credited amount and transaction details

8. **If Deposit Is Rejected or Cannot Be Verified**
   - Explain to the player:
     - The deposit could not be verified due to insufficient or unclear proof
     - Advise to re-submit clearer receipts or contact support if unsure
   - Refrain from crediting funds until verification is successful

9. **Document and Close the Case**
   - Record all relevant transaction details, including receipt screenshots, reference numbers, and verification results
   - Update the player's deposit record in the system
   - Inform the player of the deposit status:
     - Confirm credited amount or explain any delays or issues

## Notes
- Always request clear and legible screenshots of receipts, including sender and recipient details, transaction reference, and date/time.
- Deposits via MAYA may encounter issues; suggest using alternative methods like GCash or bank transfers if problems persist.
- Deposits that have already been processed and credited cannot be canceled.
- For transactions involving large sums or suspected issues, escalate to senior support or finance.

## Key points for communicating with players
- Clearly inform players of the maximum processing time (up to 12 hours for automatic processing).
- Advise players to retain deposit receipts and monitor transaction statuses.
- Explain that reimbursement occurs within 2-3 days if funds are deducted but not credited.
- Encourage players to contact their payment provider if reimbursements are delayed.
- Remain transparent about verification steps and the time required for manual review if needed.