# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial information from the player**
   - Request the following details:
     - Successful deposit receipt (screenshot or transaction ID)
     - Player’s username or game ID
     - In-game deposit history (if available)
   - Clarify the specific issue (e.g., deposit pending, not reflected, not credited, or other).

2. **Verify the deposit status with the player’s provided information**
   - Confirm that the deposit receipt shows a successful transaction.
   - Check if the deposit is pending or reflected in the account:
     - If the deposit is pending or not yet credited, instruct the player to wait for automatic system processing.
     - Confirm the payment method used (e.g., Gcash, Bkash, Nagad, etc.), ensuring it is an authorized method.

3. **Perform system checks and review transaction details**
   - Cross-verify transaction details with the internal transaction database or payment gateway logs.
   - Confirm the transaction status:
     - If marked as successful and funds are not credited:
       - Ask the player to provide a clear screenshot of the transaction receipt showing details.
       - Check if the deposit amount matches the intended deposit, without alterations.
     - If transaction failed or has a problem:
       - Inform the player accordingly and advise retrying the deposit.

4. **Address deposit not reflecting or not credited issues**
   - If the deposit is confirmed successful but funds are not reflected:
     - Verify the transaction details against the deposit history.
     - Ensure the deposit amount meets the minimum (e.g., 100 Taka) and does not exceed daily limits based on VIP status.
     - Advise the player to wait for the maximum processing time (usually 1–5 minutes, up to a few hours in rare cases).
     - If the amount still does not appear after this period:
       - Collect the following:
         - Screenshot of the successful deposit receipt
         - Player’s username or game ID
         - In-game deposit history
       - Escalate or escalate to the back office for review and manual processing.

5. **Resolve deposit pending or not received cases**
   - If the deposit remains pending:
     - Confirm the player has uploaded a clear screenshot of the successful transaction.
     - Confirm the correctness of all details (amount, payment method).
     - Advise the player to be patient while the system verifies the transaction.
     - Remind the player that deposits are processed within 1–5 minutes and up to a maximum of a few hours.

6. **Handle deposit issues related to policy or limits**
   - Check for compliance with deposit policies:
     - Minimum deposit is typically 100 Taka.
     - Limits vary with VIP level and daily transaction caps (if applicable).
   - If the deposit exceeds limits or violates policy:
     - Notify the player of the applicable limits and seek further guidance if necessary.
   
7. **Address withdrawal-related issues or other discrepancies (if applicable)**
   - If the issue also involves withdrawal, verify:
     - That the account meets all eligibility criteria.
     - That the player has submitted all required verification documents if necessary.
   - Adhere to existing withdrawal procedures, noting possible delays (up to several hours).

8. **Document and communicate resolutions**
   - Keep records of all submitted evidence and correspondence.
   - If the issue is resolved automatically or via system processing, inform the player of successful credit.
   - If manual intervention is required, communicate expected resolution time and follow up accordingly.

9. **Close the case**
   - Confirm with the player once the deposit has been successfully credited.
   - Advise the player to check their account balance or deposit history.
   - Provide guidance on next steps if issues persist.

## Notes
- Always request a clear screenshot of the successful deposit receipt for verification.
- Emphasize patience: deposit processing generally takes 1–5 minutes, with possible delays up to a few hours.
- Ensure all communication is polite and clear regarding what the player needs to do or expect.

## Key points for communicating with players
- Verify deposit success through the receipt, username, and deposit history.
- Highlight that deposits are automatically processed after verification.
- Encourage players to wait the standard processing time before escalating.
- Collect and review all required evidence before escalating issues.
- Maintain transparency about processing times and policies.