# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather player information**  
   - Collect the player's game account name.  
   - Ask for the specific deposit details they are inquiring about, such as the payment method used, transaction ID, or receipt proof.

2. **Verify if the deposit is reflected in the player's account**  
   - Check the player's account balance for the deposited funds.  
   - Use the transaction ID, payment receipt, or proof of payment provided by the player to locate the transaction in the system.

3. **Determine the status of the deposit**  
   - If the deposit does not appear in the account:  
     - Confirm whether there is ongoing system maintenance or platform updates that might cause delays.  
     - Verify the correctness of the transaction details (amount, transfer ID, payment method).  
     - Check the transaction status through the relevant payment provider or bank transfer system.

4. **If the deposit proceeds are not reflected after initial checks**  
   - Request the player to provide a screenshot of the deposit confirmation or receipt.  
   - Ask the player to send the confirmation ID and any other relevant proof along with their game account name.  
   - Instruct the player not to leave the chat until further verification is completed.

5. **Perform system and transaction verification**  
   - Use the provided proof or screenshot to confirm the deposit was successful from the payment provider or bank.  
   - Cross-verify that the transfer ID and amount are correct and match the player's deposit details.

6. **Resolve based on verification outcome**  
   - If the deposit is confirmed successful:  
     - Notify the player that their deposit has been received and credited to their account.  
     - Clarify if any additional steps are needed (e.g., bonus crediting according to promotion terms).  
     - Close the inquiry after confirming resolution.

   - If the deposit is not found or not confirmed:  
     - Inform the player that the deposit has not been reflected or verified yet.  
     - Advise the player to contact their payment provider or bank for further verification.  
     - Keep the case open for further updates if the player provides additional proof.

7. **Follow-up if funds still do not arrive or appear**  
   - Ask the player to verify that the transfer ID and transfer amount are correct.  
   - If the transfer is delayed or the deposit does not appear after a reasonable processing time, request additional deposit proof, such as a deposit slip or confirmation ID.  
   - Escalate the case or advise the player to contact their bank or payment provider if delays persist.

8. **Document all interactions and findings**  
   - Save all screenshots, proof IDs, and communication with the player.  
   - Record transaction details and verification results in the case notes for future reference.

## Notes

- Always verify the player's transaction proof before escalating or providing further instructions.  
- Do not instruct players to perform actions beyond what is supported by the current platform or payment providers.  
- Emphasize that deposits may take some time due to platform updates or banking delays, especially during system maintenance.  
- In case of ongoing issues, escalate the case according to internal procedures and inform the player about potential processing times.

## Key points for communicating with players

- Confirm the transaction details and proof with the player clearly.  
- Remind players to keep their payment confirmation or receipt for verification purposes.  
- Ensure transparency regarding processing times and potential delays caused by system updates or banking processes.  
- Reassure players that their funds are being checked thoroughly and will be credited once verified.