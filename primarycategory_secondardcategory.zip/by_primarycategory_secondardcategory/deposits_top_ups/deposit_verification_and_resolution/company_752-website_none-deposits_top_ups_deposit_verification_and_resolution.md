# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player's Deposit Details**
   - Confirm which deposit method was used (e.g., GCash, PayMaya, USDT, Online Bank Transfer).
   - Request relevant transaction information:
     - For GCash/PayMaya: screenshot of inbox/transaction history showing confirmation message, detailed receipt with sender/recipient info, reference number, date, and time.
     - For other methods: proof of payment or receipt including sender and recipient details.
   - Ask the player to provide the deposit record if available:
     - Instruct the player to go to the homepage, click on 'Member,' then 'Deposit Record,' and take a screenshot.

2. **Verify the Deposit Receipt and Record**
   - Check the submitted proof against the following:
     - Correct recipient details matching your account.
     - Amount and date matching the player’s claim.
     - Presence of confirmation message or receipt with sender and recipient info.
   - For GCash/PayMaya:
     - Confirm the screenshot shows a valid inbox transaction or QRPH invoice.
     - Ensure the receipt includes sender and recipient info.
   - For other methods:
     - Confirm the payment proof is clear, legible, and includes the required info.

3. **Check System and Back Office Records**
   - Look up the deposit record in the system to see if it has been credited.
   - Check the deposit history for the amount, date, and status.
   - If deposit is marked as credited, verify the amount has reflected in the player's account balance.

4. **Identify the Status and Potential Issues**
   - **If the deposit has been credited:**
     - Confirm the amount is visible in the player's account.
     - Advise the player that the deposit is successful.
   - **If funds were deducted but not credited:**
     - Inform the player that funds will be reimbursed within 24 hours.
     - If reimbursement does not occur within this period, advise contacting GCash Customer Service.
   - **If the deposit is pending or not reflected:**
     - Check for network delays or system processing delays.
     - Inform the player that during GCash network fluctuations, deposits may be pending and funds are secure.
     - Recommend waiting 15-30 minutes; suggest using Maya (with 2% rebate) for smoother processing when applicable.
   
5. **Assess Deposit Issues and Provide Resolution**
   - **For confirmed deposit failure or uncredited funds:**
     - Confirm the proof of payment matches the transaction.
     - Inform the player that the funds will be automatically reimbursed within 2-3 days or 24 hours, depending on the situation.
     - Remind the player that deposits cannot be canceled or refunded once processed.
     - Advise to provide detailed proof of payment (receipt, screenshot, inbox message).
   - **For deposits below the current minimum (e.g., 200 PHP or 300 PHP, depending on the issue):**
     - Inform the player of the current GCash deposit limitations.
     - Suggest alternative deposit methods: PayMaya (with 2% rebate), USDT, Online Bank Transfer, GrabPay, GoTyme.
   
6. **Escalate if Validation is Insufficient or Confirmation Fails**
   - If the player's proof is unclear or incomplete:
     - Request clearer or additional proof.
   - If the deposit still cannot be verified after checking system records:
     - Inform the player that the issue requires further investigation and escalate to the relevant department.
   
7. **Update the Player and Close the Case**
   - Clearly communicate the deposit status:
     - Confirm successful credit.
     - Explain automatic reimbursement if funds were deducted but not credited.
     - Clarify delays due to network fluctuations or maintenance.
   - Advise on alternative deposit methods if current method is unavailable or problematic.
   - Confirm the player understands the next steps and timing.

## Notes
- Always request and verify proof of payment to expedite resolution.
- During GCash network issues, deposits may be delayed; reassure players their funds are secure.
- Deposits will generally be credited within 15-30 minutes; delays beyond this should be escalated.
- Deposits will be reimbursed automatically within 24 hours if deducted but not credited.
- Use the current site configuration and official instructions for minimum deposit amounts and available methods, especially during system issues.

## Key points for communicating with players
- Confirm the method used and request clear, legible proof.
- Clearly explain whether the deposit is successful, pending, or failed.
- Advise on alternative deposit options during GCash issues.
- Remind players that deposits cannot be canceled or refunded once processed, but reimbursements occur if funds are deducted without credit.
- Encourage patience during network fluctuations and advise waiting 15-30 minutes before further action.