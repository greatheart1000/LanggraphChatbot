# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit issue report.**  
   - Confirm the player’s username or Game ID.  
   - Ask for a clear screenshot or receipt of the successful deposit transaction.  
   - Request a screenshot of the in-game deposit history.  

2. **Verify the provided information.**  
   - Review the screenshot/receipt for the deposit details.  
   - Cross-check the transaction with the player's in-game deposit history.  
   - Check whether the deposit has been reflected in the player's account.  

3. **Determine the deposit status.**  
   - If the deposit has reflected correctly and appears in the account, inform the player that the deposit is successful.  
   - If the deposit has not reflected yet, advise the player to wait a few hours for processing.  

4. **Investigate pending or rejected deposits.**  
   - Confirm with the payment provider or bank if the transaction is pending or rejected.  
   - Ask the player for additional details such as transaction ID or proof of transfer if not already provided.  
   - Check the deposit history and screenshots again for accuracy and completeness.  

5. **Assist with deposit issues.**  
   - If the deposit is pending or rejected, advise the player to verify the transaction status with their payment provider.  
   - Request the player to submit the transaction ID, the deposit screenshot, username/Game ID, and deposit history if not provided.  
   - Escalate the case to the support team or relevant department if the issue cannot be resolved immediately.  

6. **Resolve confirmed deposit issues.**  
   - Approve the deposit if verified and reflected correctly in the account.  
   - Inform the player that their deposit has been successfully processed and credited.  
   - Note any discrepancies or issues that require further investigation for future reference.  

7. **Follow up on unresolved issues.**  
   - Keep the player informed of progress if the issue requires internal review.  
   - Encourage the player to monitor their account and contact support if the deposit still does not reflect after a few hours.  

8. **Close the case.**  
   - Confirm with the player once the issue is resolved or provide clear instructions if further action is necessary.  
   - Document the case details, including screenshots, transaction IDs, and steps taken, for quality assurance and audit purposes.  

## Notes

- Always ask for a **successful deposit screenshot** and **in-game deposit history** for verification.  
- Be aware that deposit processing may be delayed due to system or gateway issues; advise patience beforehand.  
- When deposits are pending or rejected, verify transaction status directly with the relevant payment provider.  
- Maintain clear communication with players, providing updates and requesting additional information as needed.  

## Key points for communicating with players

- Emphasize the importance of providing clear, unedited screenshots of deposit receipts and in-game history.  
- Remind players to wait a few hours if their deposit is not immediately reflected.  
- Guide players to verify transaction status with their payment provider if issues persist.  
- Clearly inform players when their deposit has been successfully credited or if further investigation is needed.