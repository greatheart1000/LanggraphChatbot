# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather player information and deposit details**
   - Ask the player to provide their game username.
   - Request a screenshot of the deposit receipt or transaction confirmation from GCASH or PayMAYA inbox.
   - Confirm that the player is using the current QR code for deposits (not an old one).

2. **Verify deposit receipt and system status**
   - Check if the receipt screenshot clearly shows the transaction details, including the amount, date, and transaction ID.
   - Confirm that the deposit was sent via GCASH or PayMAYA, as appropriate.
   
3. **Perform system checks in the back office**
   - Search for the transaction in the system using the provided receipt details or transaction ID.
   - If available, check the deposit status:
     - Pending
     - Failed
     - Credited
   - Verify whether the deposit amount matches the expected deposit.

4. **Determine the deposit status and appropriate actions**
   
   **If the deposit is reflected in the system / account:**
   - Instruct the player to refresh their account balance.
   - Ensure the balance updates accordingly.
   - If the balance does not update after refresh, escalate to technical support.

   **If the deposit is pending:**
   - Inform the player that deposit observation delays can occur due to system processing times.
   - Advise the player to wait patiently for 24 to 48 hours, especially for GCash deposits, which may experience delays.
   - Remind the player that the deposit should be credited automatically once system updates.

   **If the deposit does not reflect within 24 hours:**
   - Confirm that the player has provided a valid receipt and that the correct QR code is being used.
   - Advise the player that deposits not reflected within 24 hours will be refunded.
   - If the receipt is valid and the transaction is confirmed, inform the player that the support team will verify and process the refund if necessary.
   
   **If the deposit failed or no receipt is available:**
   - Verify the absence of a valid receipt or transaction confirmation.
   - Explain that if the deposit failed or no receipt is provided, funds are expected to be refunded by the payment provider within 48 to 72 hours.
   - Remind the player always to send a screenshot of the transaction receipt for resolution.

5. **Guide the player through re-submission if deposit is not reflected**
   - Advise the player to go to Deposit in PINASJILI and select GCASH or PayMAYA.
   - If prompted, set Channel to Daypay before entering the deposit amount.
   - Enter the deposit amount exactly as sent.
   - Confirm the deposit without paying again if prompted.
   - If the deposit still does not reflect, re-submit with the receipt for verification.

6. **Handling deposits under processing**
   - Confirm with the player that deposits under processing cannot be refunded.
   - Remind the player that delays may be due to bank or GCash system issues, with automatic processing expected within 24 to 48 hours once system updates.
   
7. **Final verification and follow-up**
   - Encourage the player to refresh their balance after confirmation of deposit processing.
   - If issues persist, escalate the case to technical support with all collected information and receipts.
   - Confirm that old QR codes are not used, as they may cause deposit failures.
   
## Notes
- Always verify that the player has a clear, legible transaction receipt.
- Remind players that delays can happen during system observation periods and are usually resolved automatically.
- Make sure deposit screenshots are attached and visible for easier verification.
- Inform players that deposits under processing cannot be refunded, and they should wait for system updates.
- For deposits not reflected within 24 hours, process refunds according to policy once confirmed.

## Key points for communicating with players
- Emphasize the importance of sending a clear screenshot of the transaction receipt.
- Clearly explain delay times (24-48 hours) for GCash/PayMAYA deposits.
- Reassure players that the support team is responsible for verification and refunds if applicable.
- Always advise players to use the current QR code to avoid failures.