# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit query or issue report.**  
   Determine whether the player reports a missing, pending, or rejected deposit.

2. **Request the necessary deposit proof from the player.**  
   - For GCash deposits:  
     - Log in to the player's GCash account.  
     - Guide the player to select 'Inbox' to generate the QRPH invoice.  
     - Instruct them to take a screenshot of the deposit receipt or transaction confirmation, ensuring it includes sender and recipient details.  
   - For PayMaya or other methods, request the detailed receipt showing sender and recipient information.  
   - If applicable, ask for the deposit record screenshot from 'Member' > 'Deposit Record.'

3. **Verify the completeness of the deposit proof.**  
   - Check that the screenshot or receipt clearly displays the sender (your payment account), recipient (your company account), and transaction details (amount, date, time).  
   - Confirm the receipt is from a valid, recognized payment provider account.

4. **Assess the deposit status based on the player's report and proof.**  
   - **If the proof is complete and clear:**  
     - Proceed to verify whether the deposit has been credited to the player's account.  
     - Check the player's deposit record in the system:  
       - Navigate to 'Member' > 'Deposit Record.'  
       - Confirm if the deposit amount appears and equals the proof provided.

   - **If the proof is incomplete or unclear:**  
     - Inform the player of the need for a clear, detailed deposit receipt, including sender and recipient information.  
     - Advise them to resend a valid screenshot.  
     - Do not process until the proof is satisfactory.

5. **Determine if the deposit has been credited or is pending.**  
   - **If credited:**  
     - Confirm with the player that the deposit is reflected in their account balance.  
     - If not credited, check the deposit record for any pending status.  
   
   - **If pending or not credited:**  
     - Inform the player that deposits may take 30–45 minutes for GCash, but GCash currently has technical issues; therefore, delays are expected during system stabilization.  
     - If GCash is unavailable (due to reported issues):  
       - Suggest alternative deposit methods: PayMaya (with 2% rebate), USDT, GrabPay, GoTyme, or Online Bank Transfer.  
     - Advise the player to wait and monitor their deposit record.

6. **Handle cases of deduction without credit (deposit deducted but not credited):**  
   - Confirm with the player that funds have been deducted from their payment account.  
   - If funds are deducted but not credited within 30–45 minutes, inform the player that the deposit will be automatically reimbursed within 24 hours.  
   - Advise the player to contact their payment provider (e.g., GCash Customer Service) if reimbursement is delayed beyond this period.

7. **Address rejected deposits or failed transactions:**  
   - If the deposit was rejected during processing, explain the automatic reimbursement process occurring within 2 to 3 days.  
   - Advise the player to provide deposit proof if they believe there has been an inconsistency, and escalate to the relevant department if necessary.

8. **Resolve deposit issues and update the player:**
   - For verified deposits, ensure the amount appears in the player's balance and update records accordingly.  
   - For unresolved issues, escalate to the back-office or relevant department with all evidence and details.

9. **Document all actions taken and communicate clearly with the player:**
   - Confirm receipt of deposit proof.  
   - Keep the player informed about processing timeframes and potential delays.  
   - Advise them to avoid multiple submissions; wait for the system to process their claim.

## Notes

- Always verify that the deposit receipt includes detailed sender and recipient information, particularly for GCash and PayMaya transactions.  
- Deposit delays are common during GCash system issues; informing players upfront helps maintain transparency.  
- Deposits made via GCash are subject to system stability; alternative methods are encouraged during known issues.  
- For deposits not reflected after the appropriate timeframe, always request the proof of payment before escalation.  
- Reimbursements for failed GCash transactions are automatic within 2–3 days; players can contact GCash Customer Service for further assistance if delays occur.  

## Key points for communicating with players

- Encourage players to provide clear, detailed proof including sender and recipient info.  
- Remind players that GCash deposits may be delayed due to technical issues and suggest alternative methods.  
- Inform players about automatic reimbursements for unsuccessful deposits and advise contacting their payment provider if necessary.  
- Emphasize patience during system stabilizations and avoid multiple submissions to prevent confusion.