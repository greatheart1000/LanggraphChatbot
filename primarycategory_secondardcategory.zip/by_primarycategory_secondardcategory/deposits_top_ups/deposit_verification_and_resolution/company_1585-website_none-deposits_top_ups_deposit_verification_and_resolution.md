# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive player inquiry about deposit status.**  
   Ask the player for specific details about the deposit, including if available:
   - Deposit receipt (from GCASH or MAYA inbox)
   - Transaction date and amount
   - Sender and recipient details (as shown on the receipt)

2. **Request and collect the deposit proof from the player.**  
   - Advise the player to provide a screenshot or photo of their deposit receipt showing sender, recipient, amount, and date/time.
   - Ensure the receipt clearly displays the transaction confirmation and details.

3. **Check for deposit reflection in the player’s account.**  
   - Verify in the system whether the deposit has been credited.
   - Instruct the player to check their wallet/balance after some time if the deposit is not yet reflected, especially during high volume periods or bank processing delays.

4. **Verify receipt in the system.**  
   - Review the submitted receipt against the transaction in the back-office system.
   - Confirm the details match the recorded transaction, including sender, recipient, amount, and date.

5. **Identify the deposit status based on verification:**
   
   **If the deposit is reflected and verified:**  
   - Inform the player that the deposit has been successfully credited.
   - Close the case with a confirmation message.

   **If the deposit is not reflected but the receipt is verified:**  
   - Explain that deposits may be delayed due to bank processing times or system delays.
   - Advise the player to wait a reasonable period and recheck later.
   - Confirm that the deposit will be credited once confirmed by the system.

   **If the deposit is not reflected and the receipt cannot be verified:**  
   - Check if the player has provided a valid and clear receipt.
   - If not, request a clearer receipt or additional proof.
   - If the receipt is valid but the deposit still cannot be matched, escalate to the back-office or relevant support team for further investigation.

6. **Handle deposits not arriving or delayed:**
   - If the deposit does not arrive within the expected processing time, advise the player to submit the deposit receipt.
   - Contact support with the receipt for system verification.
   - Note that if funds were deducted but not credited, GCash deposits are typically refunded within 24–48 hours.
   - For GCASH or MAYA deposits during maintenance or delays, instruct the player to retry after maintenance or use the alternative method (e.g., MAYA instead of GCASH).

7. **Address specific cases of failed or pending deposits:**
   - **For GCash deposits:**  
     - If the deduction occurred but the deposit is not reflected, provide the receipt for verification.  
     - GCash refunds are processed within 24–48 hours; escalate if refund is delayed.

   - **For Maya deposits:**  
     - Follow similar steps as GCash, submitting the receipt and waiting for verification or refunds.

8. **Notify and instruct players about rules and processing times:**
   - Clearly communicate that deposits are subject to verification and processing times.
   - Mention that bonuses may have specific turnover requirements before withdrawal.
   - Remind players that refunds are automatic if the bank has not received funds within 3 days.

9. **Escalate unresolved issues.**  
   - If you cannot verify the deposit after multiple attempts or the deposit remains pending beyond reasonable time, escalate to the dedicated support or finance team for further investigation.

## Notes
- Always ensure the deposit receipt clearly shows sender and recipient details for validation.
- Be aware that deposits may be delayed due to maintenance or bank processing times; advise patience and rechecking.
- GCash deposits that are deducted but not reflected result in refunds typically within 24–48 hours.
- During GCASH maintenance, advise players to retry deposit later or switch to MAYA as an alternative.

## Key points for communicating with players
- Confirm receipt and transaction details clearly.
- Advise patience during processing delays, especially during maintenance.
- Use the provided receipt or screenshot as the primary proof for verification.
- Keep players informed about expected times for refunds or deposit clearance.
- Escalate issues promptly if verification is not successful or if delays extend beyond standard processing times.