# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit query or issue report.**  
   - Determine if the player reports a missing deposit, rejected transaction, or deposit not reflecting in the account.

2. **Request detailed proof of payment from the player.**  
   - Ask for a clear deposit receipt or screenshot showing the sender and recipient information, including date, time, and amount.  
   - For GCash, advise the player to access their GCASH Inbox to generate the QRPH invoice or transaction receipt.  
   - For PayMaya or other wallets, request the transaction confirmation message or receipt screenshot.

3. **Verify the quality and completeness of submitted proof.**  
   - Confirm that the receipt/screenshot clearly shows the sender (payment wallet / bank), recipient (our account), date, time, and amount.  
   - Ensure the receipt is readable and contains all required details.

4. **Check deposit status in the system.**  
   - Access the player's deposit record via:  
       - Homepage > Member > Deposit Record  
   - Review for a matching transaction date, amount, and receipt details.

5. **Assess deposit confirmation and processing status.**  
   - If the deposit appears in the system and is credited:  
     - Confirm to the player that the deposit has been successfully credited.  
   - If the deposit is pending or not yet reflected:  
     - Inform the player that deposits via GCASH/PayMaya may be delayed due to network issues or verification time.  
     - Advise to wait for a few minutes up to 45 minutes and refresh their account.  
     - Suggest using alternative methods if long delays persist (e.g., USDT, Online Bank Transfer, GrabPay, GoTyme, PayMaya).

6. **Handle rejected or unreimbursed deposits.**  
   - If the transaction was rejected but funds deducted:  
     - Explain to the player that the funds will be automatically reimbursed within 2-3 days.  
     - If reimbursement is not received after this period, advise contacting the wallet's customer service.  
   - For deposits deducted but not credited within 24 hours:  
     - Assure that automatic reimbursement will occur within 24 hours.  
     - If reimbursement does not happen, escalate to finance or relevant back-office team.

7. **Inform the player of current deposit limitations, if applicable.**  
   - Currently, GCash accepts deposits of 500 PHP or more; deposits below that amount should be made via alternative methods mentioned above.

8. **Advise on steps if deposit verification fails.**  
   - If the receipt is unclear or insufficient, request a new, clearer screenshot.  
   - Ensure the proof includes all necessary sender and recipient information.  
   - If verification cannot be completed, recommend the player try alternative deposit methods.

9. **If discrepancies or issues persist after verification attempts:**  
   - Escalate to the finance or technical team following internal procedures.  
   - Keep detailed notes, including timestamped screenshots and system responses.

## Notes

- Always instruct players to take clear, legible screenshots of their transaction confirmation messages or receipts.  
- Remind players that deposit verification can take some time, especially during high traffic or network delays.  
- Emphasize the use of alternative deposit methods if delays or issues persist.  
- Reimbursements for unreimbursed deductions are automatic within 2-3 days; monitor accordingly.

## Key points for communicating with players

- Clearly explain that deposit verification involves reviewing transaction receipts for sender and recipient details.  
- Inform players about typical verification times (up to 45 minutes), and advise patience.  
- Advise to check their deposit records regularly in their account.  
- Reassure players that funds deducted but not credited will be reimbursed automatically within 2-3 days, or sooner if flagged.  
- Suggest alternative deposit methods if technical issues continue.