# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive and understand the player's issue**  
   - Identify if the player’s deposit is pending, not reflected, or not credited to their account.

2. **Request necessary information from the player**  
   - Ask for a clear screenshot of the successful deposit receipt showing transaction details.  
   - Obtain the player's username or game ID.  
   - Request their in-game deposit history or transaction history.

3. **Verify the deposit details in the system**  
   - Check if the deposit transaction is listed as successful in the payment method records (e.g., Bkash, Nagad).  
   - Confirm that the deposit transaction reflects correctly on the system, including amount and date.

4. **Assess if the deposit has been processed properly**  
   - If the deposit is marked as successful in your payment records but not reflected in the player's account:  
     - Ensure the correct account details were used.  
     - Verify the screenshot matches the system record.  
   - If the deposit remains pending or not credited:  
     - Check the deposit transaction details again.  
     - Confirm initial deposit success with the player.

5. **Determine the appropriate resolution based on findings**  
   - **If the deposit is successful but not reflected after a short processing time:**  
     - Explain that deposit processing times can vary; usually it is automated within a few minutes to hours.  
     - Advise patience.  
   - **If the deposit has not arrived or is pending:**  
     - Request the player to wait up to a reasonable processing period.  
     - Confirm all details and request the player to recheck the deposit in their payment app.  
   - **If the deposit has failed or was unsuccessful:**  
     - Inform the player that the deposit did not go through and advise retrying the transaction via the official platform.

6. **Handle deposit issues that require escalation or further investigation**  
   - If the deposit is successful in the payment system but not reflected in the player's account, and the player has provided proper documentation:  
     - Escalate the case to the back office system for manual verification.  
   - If there are discrepancies or suspicious activity, escalate according to company protocols.

7. **Communicate clearly with the player**  
   - Confirm receipt of their submitted information.  
   - Explain the possible reasons for delays or issues based on the verification outcome.  
   - Keep the player informed about the progress or resolution status.

8. **Follow up and close the case**  
   - Once the deposit is verified and credited, notify the player that the issue is resolved.  
   - If the deposit cannot be verified or system issues persist, advise the player on further steps (e.g., retry, contact support with additional proof).

## Notes

- Deposit processing times may vary; deposits are generally processed automatically within a few minutes to hours.  
- Always request a screenshot of the successful deposit receipt with transaction details.  
- Ensure the correct account details and transaction proof are provided; discrepancies should be escalated.  
- Check both the payment method system and internal deposit records for consistency.  
- Inform players to verify their transaction success in their payment app before contacting support.

## Key points for communicating with players

- Emphasize that deposit processing times can vary based on system load.  
- Ask for clear, unedited screenshots of the deposit receipt showing transaction details.  
- Confirm the correctness of the account details provided by the player.  
- Encourage patience and recheck the deposit in their payment app if not reflected promptly.  
- Escalate issues with proper documentation and screenshots for faster resolution.