# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report of issue.**  
   - Note the player's username and the details of the deposit problem they are experiencing.

2. **Request the player to provide proof of deposit.**  
   - Ask the player to send a screenshot of the deposit receipt from the GCash or PayMaya inbox (not the transaction history).  
   - Ensure the screenshot clearly shows the payment details, including the amount and date.  
   - Advise the player to include their username in the message for easier verification.

3. **Verify the details provided by the player.**  
   - Check the submitted screenshot for clear indication of the deposit.  
   - Confirm the receipt matches the expected amount and transaction time (if applicable).  
   - If the deposit is via GCash, review the inbox receipt (not the transaction history).  
   - For PayMaya, follow the same process, ensuring the receipt is from the inbox.

4. **Assess the deposit status based on the verification:**

   - **If the receipt is clear and matches the deposit:**  
     1. Check the payment provider’s records to see if the deposit has been reflected on their end.  
     2. Confirm if the deposit has been credited to the player's account in the system.  
        - This may involve checking the back office system or payment processing logs.

   - **If the deposit has not reflected in the account:**  
     1. Contact the payment provider (GCash or PayMaya) for confirmation and status update.  
     2. If the provider confirms the payment was successful, manually post the deposit to the player's account.  
     3. If the provider indicates the payment failed or refund is initiated, inform the player that their funds will be refunded within 24–48 hours and advise them to wait for the provider's message or contact the provider directly.

5. **Handle delays or issues:**

   - **If the deposit is delayed due to system or provider maintenance:**  
     1. Inform the player that delays may occur due to ongoing maintenance or issues with GCash/PayMaya.  
     2. Advise to wait for the maintenance window to complete and check the deposit status again later.

   - **If the deposit is delayed or not credited after verification:**  
     1. Submit the screenshot and relevant details to support for further assistance.  
     2. Advise the player to wait while we verify with the payment service provider.

6. **If the deposit cannot be verified (e.g., no receipt, unclear receipt):**  
   - Inform the player that the deposit could not be verified due to missing or unclear proof.  
   - Recommend the player resubmit a clear screenshot of the receipt if they believe the deposit was successful.  
   - If the player reports a failed deposit, advise them to contact GCash or PayMaya support directly.

7. **Finalize the resolution:**

   - **Successful deposit verification:**  
     1. Confirm in the system that the deposit has been credited.  
     2. Notify the player that their funds have been successfully added to their account.  
     3. Close the case once confirmed.

   - **Failed or unverified deposit:**  
     1. Process a refund if applicable, adhering to the company refund policies.  
     2. Notify the player of the refund action and expected timeline (within 24–48 hours if applicable).  
     3. Advise to contact the payment provider for further assistance if needed.

## Notes

- Always review the deposit receipt from the inbox, not the transaction history, for accurate verification.
- Maintain clear communication with the player, setting expectations on potential delays due to provider maintenance or third-party issues.
- Ensure all evidence (screenshots, communication logs) are stored securely for audit purposes.

## Key points for communicating with players

- Request a screenshot from the GCash or PayMaya inbox showing the payment details, including your username.
- Remind players that deposits can be delayed due to system maintenance or issues with GCash/PayMaya.
- Encourage players to contact their payment provider directly if they suspect a failed or incomplete deposit.
- Inform players that refunds may take 24–48 hours depending on the situation.