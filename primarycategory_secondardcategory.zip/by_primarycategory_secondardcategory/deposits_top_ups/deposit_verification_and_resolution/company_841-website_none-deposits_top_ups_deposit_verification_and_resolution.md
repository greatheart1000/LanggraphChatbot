# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather information from the player**:
   - Confirm the deposit method used (e.g., GCash, PayMaya, online bank transfer, USDT).
   - Ask for the date and approximate amount of the deposit.
   - Request the screenshot or proof of payment (transaction receipt or confirmation message) showing sender and recipient details if available.
   - If applicable, request the deposit record screenshot accessed via Member > Deposit Record.

2. **Identify the deposit status**:
   - Check if the deposit has been credited to the player's account by reviewing the Deposit Record:
     - Instruct the player to navigate to **Home > Member > Deposit Record**.
     - Ask them to take a screenshot of the record showing the relevant transaction if needed.

3. **Verify the deposit proof**:
   - Confirm that the submitted proof of payment includes sender and recipient information.
   - For GCASH, request the generation of QRPH invoice from GCASH Inbox and the screenshot of that invoice.
   - For Maya or other methods, verify that the proof clearly shows the transaction details.

4. **Check for deposit delays or pending status**:
   - For GCash deposits, inform the player that delays may occur due to network fluctuations.
   - Advise the player to refresh their balance after a few minutes if the deposit is pending.
   - For Maya deposits, advise waiting up to the usual processing times; consider alternative deposit methods if delays persist.

5. **Cross-reference the deposit record**:
   - Compare the provided proof and deposit record screenshot:
     - If the deposit appears credited, confirm successful processing.
     - If not credited or pending, advise the player that the deposit is under review.

6. **Resolve uncredited or pending deposits**:
   - If the deposit has not been credited after typical processing time and verification:
     - Request the player to resend the proof of payment or transaction screenshot.
     - Check the deposit record for discrepancies.
     - If the transaction is confirmed on the payment provider’s side but not credited, inform the player that the deposit is being verified and credited accordingly.
     - For delays or system issues, advise the player to consider alternative deposit methods (e.g., PayMaya, USDT, online bank transfer).

7. **Handle insufficient or invalid proof**:
   - If proof of payment is incomplete, unclear, or not provided:
     - Inform the player that additional or clearer proof is necessary.
     - Request a detailed receipt showing sender and recipient information.
     - Advise resubmitting the proof for further review.

8. **Address deposit discrepancies or non-reflection**:
   - If the amount deducted from the payment platform does not match the deposit record:
     - Encourage the player to verify the transaction on their payment app.
     - Confirm the exact amount and details with the payment provider if needed.
   - If the deposit still does not reflect after verification:
     - Escalate the case to the finance team with all supporting documentation (proof of payment, deposit record screenshot).

9. **Provide guidance on deposit timelines and alternatives**:
   - Remind that deposit processing generally takes 3–5 minutes but may take longer during congestion.
   - Suggest alternative deposit channels if delays persist or if the current method is problematic.
   - Confirm the successful credit once verified.

10. **Document the resolution**:
    - Ensure all relevant screenshots, proof of payment, deposit record, and notes are attached to the customer case.
    - Inform the player of successful deposit verification or the next steps if issues remain.

## Notes
- Always verify if the payment proof explicitly shows sender and recipient details.
- For GCash deposits, generating a QRPH invoice from GCASH Inbox and capturing its screenshot is recommended.
- System delays may cause pending deposits; advise players appropriately.
- When deposits are not credited, require detailed proof of payment and screenshot of deposit record for verification.
- Encourage players to keep track of their deposit records and transaction history for quicker resolution.

## Key points for communicating with players
- Clarify the expected processing times (typically 3–5 minutes).
- Explain that delays can occur due to system or network issues.
- Encourage players to submit clear, detailed proof of payment for efficient verification.
- Advise alternative deposit methods if persistent delays happen with GCash or Maya.