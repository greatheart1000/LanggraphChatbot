# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive and understand the player's deposit inquiry or issue.**  
   - Clarify if the deposit has not reflected, is pending, or was deducted without crediting.  
   - Ask the player for specific details if not provided (e.g., deposit amount, transaction date/time, payment method used).

2. **Verify the payment details provided by the player.**  
   - Request the player to share a clear screenshot of the payment proof for GCASH or PayMaya, showing the transaction history with sender, recipient, amount, and time.  
   - If GCash deposit is slow, advise using PayMaya as an alternative.  
   - Confirm that the screenshot is clear and includes all relevant details.

3. **Access the deposit record in the system.**  
   - Log into the 'Member' section of the platform.  
   - Go to 'Deposit Record.'  
   - Locate the relevant deposit entry based on the provided details (date, amount, payment method).  
   - Take a screenshot of the deposit record for reference.

4. **Compare the player's proof of payment with the deposit record.**  
   - Ensure the transaction details (sender, recipient, amount, date/time) match the system record.  
   - For deposits not appearing in the account, verify receipt of the deposit record screenshot.

5. **Determine if the deposit has been verified and credited.**  
   - If the deposit shows in the deposit record and the account balance updates accordingly, the issue is resolved.  
   - If not credited, proceed to request further proof from the player.

6. **Request additional proof if needed.**  
   - If the deposit is not reflected, ask the player to provide the detailed receipt showing sender and recipient information.  
   - For GCASH, advise the player to access GCash Inbox to generate the QRPH invoice and take a screenshot of the deposit receipt, including QR or reference number.

7. **Review the transaction status and potential delays.**  
   - Check if the deposit is pending or delayed due to network issues, especially for GCash transactions.  
   - Advise the player to wait 30 to 45 minutes for GCash transactions, or longer if network issues persist.  
   - Highlight that deposits may be delayed if the payment account is not linked or if there are other system issues.

8. **Proceed with verification and processing.**  
   - If the proof of payment and deposit record are correct and match, mark the deposit as verified.  
   - Confirm that the deposit will be credited to the player's account once verified.

9. **Reimbursements and corrections if applicable.**  
   - If funds were deducted but not credited, inform the player that the funds will be reimbursed within 2 to 3 days.  
   - Advise contacting GCASH Customer Service if the reimbursement does not reflect within the period.

10. **Escalate if the issue persists or involves suspicious activity.**  
    - If verification fails or the deposit cannot be confirmed, escalate the case following internal protocols, and inform the player of any further verification steps or possible account restrictions.

## Notes

- Always ensure players submit clear, readable screenshots showing transaction details for quick verification.  
- Remind players of the minimum (100 PHP) and maximum (50,000 PHP) deposit limits when applicable.  
- Deposits via channels other than GCash or PayMaya (e.g., USDT, Grabpay, bank transfer) may have different processing steps.  
- Keep players informed about expected processing times (generally 30 to 45 minutes for GCash, longer during delays).  
- Do not invent new procedures; always follow the verified steps based on existing FAQs.

## Key points for communicating with players

- Encourage patience during network delays, especially for GCash transactions.  
- Confirm receipt of proof and deposit record before escalating.  
- Guide players to access their transaction history and generate receipts or invoices as needed.  
- Clearly explain the verification process and expected timelines.