# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the Player's Deposit Inquiry or Issue Report**  
   - Confirm whether the player reports a deposit not credited, a delay, or a failed transaction.
   - Determine which deposit method was used (e.g., GCash, PayMaya, USDT, Online Bank Transfer).

2. **Request and Collect Proof of Deposit**  
   - Instruct the player to provide a detailed receipt or proof of payment that clearly shows:  
     - Transaction number  
     - Sender and recipient information (e.g., GCash or PayMaya account details)  
     - Date and amount of the deposit  
     - For GCash deposits: instruct the player to access their GCash Inbox, generate the QRPH invoice, and take a screenshot of the receipt.  
   - Remind the player that the receipt should be visible, include all relevant details, and be formatted clearly for verification.

3. **Check the Deposit Record in the System**  
   - Guide the agent to access the deposit record:  
     - Log in to the back office system.  
     - Navigate to the 'Member' section.  
     - Select 'Deposit Record'.  
     - Confirm whether the deposit appears and verify the details (amount, date, method, transaction number).

4. **Evaluate the Proof of Payment and System Record**  
   - Confirm if the provided receipt and deposit record match:  
     - Check for the presence of transaction number, sender, and recipient info.  
     - Verify the deposit amount and date.  
   - If the deposit record is found: proceed to the next step.  
   - If not found, inform the player that the deposit is unverified; advise on re-submitting proof or waiting for system update.

5. **Assess the Deposit Status**  
   - Determine if the deposit is pending, delayed, or rejected:  
     - Due to network issues, GCash and PayMaya deposits may be pending or delayed.  
     - If GCash deposit is below 500 PHP, inform the player that only deposits of 500 PHP or more are accepted via GCash; suggest alternative methods.  
     - If the deposit was rejected or failed, inform the player funds will be reimbursed within 2-3 days; for issues, advise contacting the payment provider’s support.

6. **Confirm Deposit Processing Time and Conditions**  
   - For GCash or PayMaya:  
     - Deposits may take 30–45 minutes to process, especially during network issues.  
     - During fluctuations, funds are secure and will be credited when the network stabilizes.  
   - For USDT or Online Bank Transfer:  
     - Confirm if the deposit was completed successfully and check receipt or transaction details.

7. **Resolve Based on Deposit Status**  
   - **If deposit is credited in the system:**  
     - Confirm with the player that the funds are now in their account.  
     - Advise to refresh their balance; if still not visible, escalate as necessary.  
   - **If the deposit is pending or delayed beyond 45 minutes:**  
     - Encourage patience; monitor the transaction status.  
     - If delays persist, verify whether the proof document aligns with the deposit record.  
   - **If the deposit has failed or was rejected:**  
     - Inform the player that the deducted funds will be reimbursed within 2–3 days.  
     - If no reimbursement is received within that period, instruct the player to contact the payment platform’s customer support for further assistance.

8. **Handle Uncredited Deposits and Reimbursements**  
   - For funds deducted but not credited:  
     - Reassure the player that the funds will be automatically reimbursed within 24 hours (or 2–3 days for GCash).  
     - If reimbursement is delayed beyond the timeframe, escalate the issue for further investigation and request the player to contact their payment provider.

9. **Advise on Alternative Deposit Methods When GCash Has Issues**  
   - Suggest the player switch to:  
     - PayMaya (with 2% rebate)  
     - USDT  
     - Online Bank Transfer  
     - GrabPay, GoTyme (if applicable)  
   - Remind the player to allow 30–45 minutes for GCash transactions to complete during network issues.

10. **Document and Close the Ticket**  
    - Record all actions performed, including proof received, deposit record checks, and resolutions provided.  
    - Confirm with the player that their issue has been addressed or explain if further escalation is necessary.  
    - Close the case once resolved, ensuring the player is satisfied with the explanation or remedy.

## Notes
- Always verify that the deposit receipt includes critical details such as transaction number and sender/recipient info.
- Deposits below 500 PHP via GCash are not accepted; recommend alternative methods if applicable.
- During network fluctuations, transactions may be delayed but funds are secure.
- Reimbursements for uncredited funds are typically completed within 24 hours or 2–3 days depending on the deposit method.

## Key points for communicating with players
- Clearly advise the player to access their GCash Inbox to generate and screenshot the deposit receipt.
- Emphasize patience during network delays, especially with GCash or PayMaya.
- Remind players of deposit limits and alternative methods if they encounter restrictions or issues.
- Always confirm the presence and accuracy of the deposit record in the system before proceeding.
- Ensure the player understands their proof of deposit must include all relevant details for verification.