# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather player's information**
   - Ask the player to provide their username.
   - Request the inbox receipt from GCash or PayMaya showing 'Paid' or 'Sent' status.
   - Verify that the receipt is from the wallet inbox and not from transaction history, as only inbox receipts are accepted for deposit verification.

2. **Check deposit records**
   - In the system, verify if a deposit record exists for the provided receipt.
   - Confirm whether the deposit has been marked as successful or pending.
   - Inform the player if their deposit appears successful in their wallet inbox but is not reflected in their account.

3. **Assess deposit status**
   - If the deposit does not appear in the player's account within 24 hours, instruct the player to check their wallet inbox receipt.
   - Determine if the receipt shows 'Paid' or 'Sent' after confirming with the wallet provider, such as GCash or Maya.
   - If the receipt is correct and indicates payment, advise the player that delays could occur due to system maintenance or high volume periods.

4. **Trace delays or non-reflection**
   - If the deposit is not reflected after a reasonable period:
     - Explain to the player that deposits may be delayed by the payment merchant (e.g., GCash).
     - Recommend waiting up to 48–72 hours for the deposit to reflect or revert.
   - Advise the player to check again later or contact their wallet provider's customer service if no update occurs.

5. **Follow up on unresolved cases**
   - If the deposit is still not reflected after 48–72 hours:
     - Ask the player to resend their username and the inbox receipt from GCash or Maya.
     - Escalate the case internally for further investigation or support from the payment provider.
   - Ensure the player understands that processing delays are possible during maintenance or high volume periods.

6. **Additional guidance**
   - Remind the player that if there are no receipts in their GCash or Maya inbox, the deposit might not have been successful.
   - Advise the player to only use receipts from their wallet inbox for verification to prevent issues.

## Notes
- Deposits may not reflect immediately; patience is required.
- Always verify the receipt shows 'Paid' or 'Sent'.
- Contact the wallet provider if there are discrepancies or suspected issues on their end.
- Respect the 48–72 hour window for deposit reflection or revert before escalating.

## Key points for communicating with players
- Confirm receipt from wallet inbox, not transaction history.
- Advise patience during delays, which can extend up to 72 hours.
- Emphasize checking with wallet provider support if needed.
- Keep the player informed about the process and escalation procedures if issues persist.