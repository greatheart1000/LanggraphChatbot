# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report of uncredited deposit.**  
   - Confirm the specific issue: deposit not reflected, pending, not credited, or not shown.  
   - Ask the player to provide details of the transaction.

2. **Instruct the player to gather and submit the necessary proof of deposit.**  
   - Request a detailed deposit receipt showing the sender and recipient information from GCash or PayMaya.  
   - If applicable, ask for a screenshot of the deposit record from their payment app (e.g., Home > Member > Deposit Record).  
   - For QRPH invoice deposits, instruct the player to generate and share the QRPH invoice image via GCash Inbox.

3. **Verify the completeness of submitted proof.**  
   - Ensure the receipt or screenshot clearly shows the:\n  - Transaction amount.\n  - Sender (payer) and recipient (platform) details.\n  - Transaction date and time.\n  - Payment method used (GCash/PayMaya).  
   - If information is incomplete or unclear, instruct the player to reproduce a clearer screenshot or receipt.

4. **Check the deposit record in the system.**  
   - Guide the agent to access the deposit records via: Home > Member > Deposit Record.\n   - Confirm if the submitted transaction appears in the player's deposit history.  
   - Verify the amount, date, and transaction ID if available.

5. **Compare submitted proof with the deposit record.**  
   - Match the details provided with the system record.  
   - If deposit is reflected and verified:  
     - Confirm with the player that the deposit has been credited.\n     - Advise the player to check their balance again.\n     - Close the case as resolved.  

   - If deposit is not reflected or is pending:\n     - Proceed to the next step.

6. **For deposits not reflected or pending:**
   - Resubmit the deposit receipt and instruct the player to verify:\n     - That the transaction was completed in their payment app.\n     - The sender and recipient details are correctly shown.\n   - Wait at least 30-45 minutes after initiating the deposit (per site policy).  
   - If a significant delay occurs, inform the player that network fluctuations may cause pending status and advise waiting a bit longer.

7. **If the deposit amount was deducted but not credited after the waiting period:**
   - Explain to the player that the deducted funds will be reimbursed to their payment account automatically within 2–3 days.\n   - Advise them to contact their payment provider if the reimbursement is not received within this period.  
   - Provide guidance on using alternative deposit methods: PayMaya, USDT, GrabPay, or Online Bank Transfer, especially if repeated delays occur.

8. **If the deposit is confirmed with the payment provider but still not credited in the account:**
   - Request the player to share the transaction confirmation from their payment provider.\n   - Escalate the issue to the finance team for further verification.  
   - Advise the player to stay updated and allow additional processing time.

9. **If the deposit is not found or cannot be verified:**
   - Inform the player that the deposit could not be verified with the provided receipt or record.\n   - Suggest they recheck the transaction in their payment app for accuracy.\n   - Recommend resubmitting the deposit proof if applicable.  
   - If necessary, guide regarding further escalation to finance support.

10. **For deposits made via QRPH invoice:**
    - Confirm the player generated the QRPH invoice in GCash Inbox.\n    - Verify the QRPH invoice image shared by the player.\n    - Ensure the deposit details match the invoice.\n    - Proceed with crediting if verification is successful.

11. **Communicate with the player regarding delays or issues:**
    - Remind that deposits via GCash or PayMaya may experience network delays.\n    - Recommend using alternative methods if delays persist.\n    - Advise patience and provide estimated processing times.

12. **Record all steps and correspondence.**  
    - Attach relevant screenshots, receipts, and verification notes in the case file.\n    - Update the player's deposit status accordingly.

13. **Close the case:**
    - When deposit confirmation and verification are complete, inform the player.\n    - Confirm the credited amount has been reflected.\n    - Thank the player for their patience and cooperation.

## Notes

- Always verify that the payment account used is associated with the platform; deposits from non-associated accounts may not be credited.  
- Emphasize the importance of clear, legible proof submissions to facilitate quick verification.  
- Remind players of the processing times: approximately 30-45 minutes for GCash, with potential delays during network fluctuations.  
- In cases of repeated failure or unresolved issues after following these steps, escalate to the finance or technical support team with all documented proof.  

## Key points for communicating with players

- Request detailed deposit receipts showing sender and recipient info.\n- Explain that verification can take a few minutes, longer during delays.\n- Advise patience and suggest alternative deposit methods if delays continue.\n- Reassure that funds will be reimbursed if deducted but not credited.\n- Offer step-by-step guidance for generating proofs in GCash or PayMaya.