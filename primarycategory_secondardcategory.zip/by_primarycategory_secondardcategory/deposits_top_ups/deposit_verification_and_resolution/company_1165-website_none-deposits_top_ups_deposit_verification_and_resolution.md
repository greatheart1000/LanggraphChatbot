# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report about non-reflection of funds.**
   
2. **Request and review the player’s provided deposit information:**
   - Ask the player to send a screenshot of the deposit receipt or transaction details.
   - Confirm the specific deposit method used (e.g., GCash or Maya).

3. **Check the deposit status in the back office/system:**
   - Verify whether the transaction appears in the deposit system.
   - Confirm if the deposit has been successfully processed or is still pending.
   
4. **For GCash or Maya deposits:**
   - Confirm that the player has submitted the GCash inbox receipt or Maya receipt.
   - Check the receipt to ensure the deposit was sent successfully.
   - If the receipt is unavailable, advise the player to contact the respective payment provider’s Help Center to obtain it.
   
5. **Assess the deposit delay or issue:**
   - If the deposit was made via GCash or Maya and the receipt confirms the payment, proceed to verify its status.
   - If the deposit does not reflect after 24 hours, instruct the player to contact support again, providing proof of deposit.
   - If GCash is under maintenance, advise the player to use Maya for deposits or withdrawals until maintenance is finished.

6. **Notify the player of the verification outcome:**
   - If the deposit has been verified in the system, inform the player that the funds will be credited shortly; processing delays may occur due to high traffic or system issues.
   - If the deposit has not been verified, escalate the issue to the Support/Back Office team for further investigation, providing all collected evidence.

7. **Follow up and close the case:**
   - Monitor the system to confirm when the deposit credits to the player's account.
   - Communicate updates to the player, including any additional actions required.
   - Once the funds are credited, confirm with the player and close the inquiry.

## Notes

- Always keep a record of the submitted receipt or transaction details.
- Deposits may be delayed due to system congestion or bank issues; patience and clear communication are key.
- For unresolved deposit issues, escalate promptly with all relevant evidence to ensure a timely resolution.

## Key points for communicating with players

- Clearly explain that deposits can be delayed due to system or bank issues and that they may need to wait up to 24 hours.
- Advise players to send a screenshot of the deposit receipt or transaction details for verification.
- If a deposit via GCash or Maya does not credit after 24 hours, instruct them to contact support again with proof.
- Remind players to avoid using the same QR code without confirmation to prevent delays.
- Recommend using Maya if GCash is under maintenance for deposit and withdrawal transactions.