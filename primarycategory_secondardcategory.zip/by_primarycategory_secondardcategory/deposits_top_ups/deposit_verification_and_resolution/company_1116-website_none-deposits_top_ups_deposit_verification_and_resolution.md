# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or issue report.**  
   Gather the necessary information from the player:
   - Full username (e.g., PINASROYAL username)
   - Details of the deposit (date, amount, deposit method)
   - Description of the issue (e.g., deposit not reflecting or not credited)

2. **Request relevant proof of deposit.**  
   - Instruct the player to provide a screenshot of the deposit receipt showing:
     - Transaction amount
     - Method (GCash, Maya, Gotyme)
     - Date and time (if visible)
   - If the deposit was made via GCash and no receipt is available, advise the player to contact GCash directly to verify or obtain the receipt.

3. **Verify deposit receipt and transaction details.**  
   - Check the submitted screenshot for clarity and correctness.
   - Confirm the amount and method match the player's report.
   - For GCash transactions, ensure the receipt clearly shows the transaction.

4. **Check the deposit status in the relevant payment app or system.**  
   - Confirm if the deposit shows as posted or processed in the player's e-wallet app (GCash, Maya, or Gotyme).  
   - For delayed reflection:
     - Inform the player that GCash and PayMaya deposits can take up to 24-48 hours to reflect due to network/system delays.  
     - Advise the player to wait within this period before requesting further action.

5. **Determine if the deposit has been credited to the player's account.**  
   - If the deposit is visible in the payment app but not in the account:
     - Ask the player to refresh the page or log out and log back in.  
     - If still not visible, consider the deposit as possibly under processing.
   - If the deposit does not appear in the app:
     - Verify if the deposit was successfully sent from the app.  
     - If the deposit is under processing or pending, advise the player to wait.  
     - Keep a record of the receipt and transaction details.

6. **Identify the cause of the delay or issue.**  
   - If the deposit was sent but not reflected in the account after 24-48 hours:
     - Check for system issues or maintenance alerts for the payment provider (GCash, Maya, Gotyme).
   - If the deposit shows as posted in the payment app but not in the account:
     - Confirm whether the deposit is still under processing.
   
7. **Proceed to resolution or escalation based on findings:**
   - **If the deposit is confirmed as successful and pending:**  
     - Advise the player to allow more time within the 24-48 hours window.
   - **If the deposit was not received or there is a discrepancy:**  
     - Gather all evidence (screenshots, timestamps).  
     - Escalate the case to the back office or support team for further verification with the merchant/payment provider.  
     - Inform the player that support team will review and contact them shortly.

8. **Communicate clearly with the player regarding next steps or resolution.**  
   - If deposit is verified and credited, confirm the credited amount.  
   - If refund or further review is needed, explain that the support team is investigating and will get back to them.

## Notes

- Always collect clear, legible screenshots showing the deposit details.
- For GCash or PayMaya, deposits may take up to 24–48 hours; inform players accordingly.
- If a deposit does not reflect after this period, support should verify with the respective payment provider.
- Use the player’s provided receipt and transaction details as key proof during verification.
- Inform players to avoid repeated requests or multiple submissions within a short period, to prevent delays.

## Key points for communicating with players

- Remind players that deposit reflection can take up to 24–48 hours, especially via GCash or PayMaya.
- Encourage players to keep their deposit receipts until the transaction is fully reflected and credited.
- Clearly explain that the support team will verify the transaction and resolve issues as quickly as possible.
- Advise players to contact the payment provider directly if they suspect issues with the deposit receipt or transaction status.