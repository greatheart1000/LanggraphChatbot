# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the player's issue**
   - Determine if the player reports that a deposit is not reflected, pending, or not credited.
   - Ask the player to specify the deposit method used (e.g., GCash, PayMaya, bank transfer) and the deposit amount.

2. **Request relevant details and proof of payment**
   - Instruct the player to provide:
     - A screenshot of the deposit receipt or transaction history showing sender and recipient details.
     - For GCash or PayMaya deposits: instruct the player to generate the invoice via the respective app's inbox (for GCash, specifically the QRPH invoice).
     - The transaction reference number if available.
   - Clarify that detailed receipt proof is necessary to proceed with verification.

3. **Verify the deposit record in the system**
   - Guide the player to view their deposit record:
     - On the homepage, click on **Member**.
     - Select **Deposit Record**.
     - Ask the player to take a screenshot of the deposit record for reference.
   - Check if the deposit appears in the deposit record.
   - If not visible, confirm whether the deposit was made with the correct details and method.

4. **Assess whether the deposit is reflected or pending**
   - If the deposit appears in the deposit record:
     - Confirm whether the amount credited matches the deposit.
     - If credited, inform the player that the deposit is successfully reflected.
     - If not credited, proceed to resolution steps.
   - If the deposit does not appear or is pending:
     - Acknowledge the pending status.
     - Inform the player that deposits may be reimbursed within 24 hours if not credited.
   
5. **Handle deposits not credited or delayed**
   - For deposits not credited:
     - Request the player to resend the detailed screenshot of the deposit receipt, showing sender and recipient details.
     - Advise the player that the team will verify the proof and update their account accordingly.
   - For pending deposits:
     - Explain that verification might take a few minutes; advise patience.
     - If the deposit remains pending or unreimbursed beyond 24 hours:
       - Ask the player to contact their payment provider (e.g., GCash, PayMaya) for further assistance.

6. **Special considerations for specific deposit methods**
   - For GCash or PayMaya:
     - Ensure the player provides a screenshot of the transaction invoice generated via inbox.
     - Verify that the receipt shows sender and recipient details.
   - For bank transfers or other methods:
     - Confirm receipt of the bank slip or transaction screenshot.
   - Note: Deposits may be delayed due to network issues or high transaction volume; encourage the player to refresh their balance or try alternative deposit methods if persistent issues occur.

7. **Resolution and refund procedures**
   - If a deduction was made but the deposit was not credited:
     - Reassure the player that the deducted funds will be reimbursed automatically within 24 hours.
     - Advise the player to check their deposit record and balance.
   - If funds are not reimbursed after 24 hours:
     - Recommend contacting the relevant e-wallet or bank support for further assistance.
   - If the deposit was made with the correct proof and system verification confirms payment:
     - Confirm the deposit has been credited and advise the player accordingly.

8. **Follow-up and escalation**
   - If verification cannot be completed due to inadequate proof or system issues:
     - Advise the player to resubmit a clearer receipt or additional proof.
     - Escalate the issue to the technical team if the deposit remains unresolved after standard checks.

9. **Document all interactions**
   - Save all screenshots, proof of payment, deposit record images, and communication logs.
   - Record the status of the deposit in the support ticket for further review.

## Notes
- Always remind players to keep their deposit receipts until their deposit is fully credited.
- Deposits may take a few minutes to reflect after proof submission; patience is recommended.
- During periods of network issues or high transaction volume, deposits may be delayed. Advise players to wait or use alternative methods.
- Reimbursements for deducted but uncredited funds are processed within 24 hours. Encourage players to contact support if not received.

## Key points for communicating with players
- Be clear that verification requires a detailed receipt showing sender and recipient details.
- Explain that deposits not reflected within 24 hours are automatically reimbursed.
- Encourage players to check their deposit records directly through their Member area.
- Remind players that delays can occur due to network issues or high transaction volume and to remain patient.