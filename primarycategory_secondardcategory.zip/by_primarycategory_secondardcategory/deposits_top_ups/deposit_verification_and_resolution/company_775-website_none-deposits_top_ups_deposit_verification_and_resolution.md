# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or notification of missing/uncredited deposit.**  
   - Determine if the player reports a deposit not reflecting in their account, a delay, or a deduction without credited funds.

2. **Request and collect detailed deposit proof from the player.**  
   - Ask for a detailed deposit receipt that clearly shows sender and recipient information for GCash or PayMaya deposits.  
   - If available, request a screenshot of the inbox transaction (e.g., GCash Inbox → QRPH invoice) showing the payment details and invoice number.  
   - For other methods like Maya or online bank transfer, request appropriate transaction proofs as available.

3. **Verify the submission of the deposit proof.**  
   - Confirm receipt includes the sender and recipient information, and if applicable, the invoice number or transaction details.  
   - Ensure the screenshot is clear and shows relevant data.

4. **Check the deposit record in the system.**  
   - Navigate to the deposit record in the player's profile (Member > Deposit Record).  
   - Confirm the transaction time and details match the submitted proof.

5. **Verify the deposit with the payment provider (Gcash, PayMaya, etc.).**  
   - Cross-check the payment details against the provider’s transaction records via the provided proof or screenshot.  
   - For GCash/PayMaya, ensure the receipt matches the transaction, with clear sender/recipient info and optionally the invoice number or bank name.

6. **Determine the status of the deposit based on verification outcome:**  
   - **If verified:**
     - Proceed to credit the deposit to the player's account.  
     - Notify the player that the deposit has been successful and is credited.  
     - Advise the player to refresh or check their balance.
   
   - **If not verified or insufficient info:**  
     - Inform the player that verification failed due to missing or unclear proof.  
     - Advise them to provide a clearer receipt or additional transaction details.

7. **Handle delays or pending deposits:**  
   - If the deposit is within the normal processing window (30-45 minutes for GCash, network fluctuations considered), notify the player to wait and refresh later.  
   - Remind that delays may happen due to network issues, especially with GCash, and recommend alternative deposit methods such as PayMaya, USDT, or Online Bank Transfer if the delay exceeds 45 minutes or during known outages.

8. **If the deposit was deducted but not credited after verification:**  
   - Confirm the matching transaction details with the player's proof.  
   - If verified, the system will automatically reimburse the funds within 24 hours.  
   - Inform the player of this process; if reimbursement does not occur within this timeframe, advise them to contact support again.

9. **For uncredited deposits after verification or prolonged delays:**  
   - Escalate the case to the finance or technical team for further investigation.  
   - Advise the player to wait or attempt via an alternative deposit method.

10. **If deposit issues relate to network problems (e.g., "pending" status or no credit after 45 minutes):**  
    - Explain to the player that such delays are often due to fluctuations in the payment provider's network.  
    - Suggest waiting a bit longer or trying alternative methods if urgent.

11. **Document all actions, including received proofs, verification outcomes, and communication with the player.**  
    - Ensure all relevant screenshots, receipts, and transaction details are attached in the support ticket.

## Notes

- Always ensure the deposit receipt clearly shows sender and recipient details to facilitate verification.  
- In cases of deposit deduction but no credit, the system automatically refunds within 24 hours—inform players accordingly.  
- During network outages or delays, recommend alternative methods such as PayMaya, USDT, or Online Bank Transfer.  
- For deposits via Maya, note that users may receive a 6% rebate and that there are no deposit/withdrawal limits, which can affect processing times.  
- Be cautious with incomplete or unclear proofs; request clarifications before escalating.

## Key points for communicating with players

- Emphasize the importance of providing a clear, detailed deposit receipt showing sender/recipient info.  
- Remind players that deposit verification can take up to 30-45 minutes, especially during network fluctuations.  
- Suggest using alternative deposit methods if delays persist or if there are repeated issues with GCash.  
- Clarify that reimbursements are processed automatically if a deduction was made but no credited funds are received, typically within 24 hours.  
- Keep the player informed throughout the process and avoid unnecessary technical jargon to ensure clarity.