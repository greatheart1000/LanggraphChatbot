# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report of a non-credited deposit.**  
   - Gather details about the issue, including the deposit method, approximate time of transaction, and any referenced transaction ID or receipt if available.

2. **Request the player to provide a detailed deposit receipt showing the sender and recipient information.**  
   - Accept screenshots or images of the deposit receipt, transaction invoice, or confirmation from GCash/PayMaya that includes sender and recipient details, date, and amount.  
   - Advise the player to view their GCash or Maya inbox to generate the deposit receipt if necessary.

3. **Guide the player to locate and prepare their deposit record if available.**  
   - Instruct the player to access their account:  
     - On the website or app, go to 'Member' section.  
     - Select 'Deposit Record'.  
     - Take a screenshot of this record for submission.

4. **Request the player to submit the deposit receipt and record for verification.**  
   - Ensure the receipt clearly shows sender and recipient details (e.g., GCash or PayMaya information).  
   - Collect any deposit reference number or transaction ID if provided.

5. **Verify the submitted information against the system records.**  
   - Check the deposit record within your back office system for matching details.  
   - Confirm that the receipt information matches the transaction logs and deposit records.

6. **Assess the deposit status based on verification:**
   
   - **If the deposit is confirmed and verified:**  
     - Process the deposit in the system.  
     - Credit the funds to the player's account.  
     - Notify the player that their deposit has been successfully credited.

   - **If the deposit is not yet verified or still pending:**  
     - Inform the player that their deposit is under review.  
     - Advise to wait approximately 30–45 minutes for GCash or Maya network processing, or check back later if delays occur due to network issues.  
     - Suggest using alternative payment methods such as PayMaya, USDT, Grabpay, or Bank Transfer for faster processing if urgent.

   - **If the deposit does not match any system record:**  
     - Confirm that the player has provided accurate and detailed receipt information.  
     - Advise to double-check the transaction details in their GCash/Maya account.  
     - If discrepancies persist, escalate to the finance team for further investigation.

7. **For deposits deducted but not credited:**  
   - Reimburse the deducted funds automatically within 2–3 days if verification confirms the deposit.  
   - Remind the player to check their balance after this period.  
   - If reimbursement does not occur, advise them to contact GCash or PayMaya customer support.

8. **Follow up if needed:**  
   - If the deposit remains uncredited after verification, keep the case open for further investigation.  
   - Escalate to the appropriate team if discrepancies or delays persist beyond typical processing times.

## Notes
- Always require a detailed receipt showing sender and recipient information for deposit verification.
- Remind players that GCash deposits can be delayed due to network fluctuations; recommend using PayMaya as an alternative if delays happen.
- Encourage players to refresh their wallet balances after the approximate processing time (30–45 minutes).
- For ongoing issues, advise players to contact GCash or PayMaya customer support directly.

## Key points for communicating with players
- Emphasize the importance of providing clear, detailed receipts showing their GCash or Maya transaction information.
- Inform players that deposit verification may take up to 30–45 minutes, especially during network congestion.
- Recommend alternative deposit methods if delays persist or issues are unresolved.
- Ensure players understand that their deposit will be credited after successful verification.