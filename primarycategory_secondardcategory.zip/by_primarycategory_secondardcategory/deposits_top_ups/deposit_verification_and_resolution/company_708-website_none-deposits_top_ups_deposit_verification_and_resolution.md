# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report**
   - Confirm the deposit method used (GCash, Maya, others).
   - Ask for the deposit details, including amount, date/time, and payment method.

2. **Determine the deposit method and verify eligibility**
   - If the deposit method is GCash:
     - Confirm if the amount is at least 500 PHP, as GCash deposits are supported only for 500 PHP or more.
     - If deposit is below 500 PHP, advise using Maya or alternative methods.
   - If the deposit method is Maya:
     - Proceed, as Maya deposits are generally supported without minimums.
   - If using other methods (GrabPay, Gotyme, USDT, Online Bank Transfer):
     - Follow respective procedures for each method as per available policies.

3. **Collect deposit proof from the player**
   - Instruct the player to provide a clear screenshot of the deposit receipt that includes:
     - Sender details
     - Recipient details
     - Deposit amount
     - Date and time of transaction
     - Reference number if available
   - For GCash:
     - Guide the player to log in to GCash, open Inbox, generate the QRPH invoice, and take a screenshot of this receipt.
   - For Maya:
     - Ask for a similar screenshot showing the transaction details.

4. **Verify the deposit receipt and details**
   - Check if the provided receipt clearly shows the sender and recipient information.
   - Confirm that the deposit amount matches the record.
   - For GCash:
     - Ensure the deposit is for at least 500 PHP.
   - For deposits below the minimum for GCash:
     - Verify the deposit record if available.
     - Advise the player to use Maya if applicable, especially if depositing below 500 PHP.

5. **Check deposit status in the system**
   - Access the player’s Deposit Record via their account (Home > Member > Deposit Record).
   - Confirm if the deposit has been credited to the account:
     - If the deposit has appeared:
       - Verify that the deposit corresponds with the receipt.
       - Confirm completion to the player.
     - If the deposit does not appear:
       - Advise the player to wait a few minutes, as network delays (particularly with GCash) may occur.
       - If still absent after a reasonable wait:
         - Resubmit the verification with the same receipt.
         - Or escalate to the system or payment provider support.

6. **Handle delayed deposits or network issues**
   - Inform the player that GCash deposits support delays caused by network fluctuations.
   - Suggest alternative methods such as Maya, online banking, or other supported options if delays persist.
   - Recommend resubmitting deposit proof if no reflection within 30-45 minutes.

7. **In case of rejected or deducted funds before reflection**
   - If funds are deducted and the deposit is rejected:
     - Reimburse automatically within 2 to 3 days.
     - Advise the player to monitor their account for reimbursement.
     - If reimbursement is not received in this timeframe, refer the player to contact their payment provider (e.g., GCash).

8. **For uncredited deposits or unresolved issues**
   - Request the player to resend the deposit receipt or screenshot.
   - Confirm the deposit occurred from an account associated with PHPARK.
   - Escalate the case to the relevant support or finance team if verification fails or deposit does not reflect after multiple attempts.

9. **Follow-up and resolution**
   - Once the deposit is credited:
     - Notify the player of successful verification.
     - Update the deposit status as completed in the system.
   - If the deposit cannot be verified or is delayed beyond a reasonable period:
     - Explain the situation and advise alternative deposit methods.
     - Escalate the case as needed.

## Notes
- GCash deposits are supported only for amounts of 500 PHP or more; deposits below this must use Maya or other methods.
- Maya offers a 6% rebate on each recharge and supports unlimited deposits and withdrawals.
- Always ensure receipt screenshots include sender and recipient details, deposit amount, and timestamp.
- Deposit reflection may be delayed due to network issues; advise patience and provide guidance on alternative methods.
- Refunds for funds deducted or rejected are automatically processed within 2-3 days; advise players to contact GCash support if delays occur.

## Key points for communicating with players
- Confirm the amount and payment method before proceeding.
- Clarify that GCash deposits require at least 500 PHP and are subject to network delays.
- Advise using Maya if deposits are below 500 PHP or for faster processing.
- Emphasize the importance of providing clear, full screenshots of deposit receipts.
- Inform players about automatic refunds for deducted or rejected funds within 2-3 days.
- Suggest alternative deposit options if delays or issues persist.