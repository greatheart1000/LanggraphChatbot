# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's report of a deposit not reflecting in their account.**  
   - Confirm the issue and gather initial details.

2. **Request the player to provide relevant proof of deposit.**  
   - Ask for a screenshot of the successful deposit receipt from GCash or PayMaya.  
   - Obtain the player's game account username.  

3. **Gather additional information if necessary.**  
   - If the player does not have a receipt, request any transaction reference or proof of transfer to assist verification.

4. **Check the deposit status in the system:**  
   - Verify whether the deposit appears in the back-office system and is marked as successful.  
   - Confirm if the deposit receipt provided matches the transaction record.

5. **Perform receipt verification:**  
   - Review the uploaded screenshot or proof for clarity and validity.  
   - Determine if the transaction was successful and reflects in the provider's system.

6. **If the deposit receipt shows a successful transfer but funds are not reflected:**  
   - Notify the player that the funds are pending verification and that the finance team will update the balance once confirmed.  
   - Explain that delays can happen due to high transaction volume or processing times, especially if deposits are delayed by merchant maintenance or processing volume for GCASH, which may take some time to process after maintenance.

7. **If the receipt indicates an unsuccessful payment:**  
   - Inform the player that the deposit was not successful and the funds will be refunded by GCash or PayMaya within 48 hours, especially if the receipt has a plus sign (+) indicating a failed payment.

8. **Follow up if necessary:**  
   - If the deposit is verified as successful and still not reflected, submit the transaction details to the finance team for a manual update or resubmission.  
   - Advise the player to contact GCash or PayMaya support if the transfer is confirmed successful on their end but not reflected in their balance, and share these details with support for further follow-up.

9. **Close the case:**  
   - Once the deposit is verified and the balance updated, inform the player of the successful resolution and thank them for their patience.

## Notes

- Always ask for clear, legible screenshots of deposit receipts to facilitate verification.  
- Keep the player informed about potential delays caused by system maintenance or high transaction volume.  
- If the transaction is pending or delayed, remind players that they may need to wait until their provider confirms the transfer.

## Key points for communicating with players

- Clarify that deposit delays can be due to high transaction volume or merchant maintenance, especially for GCASH deposits.  
- Reinforce the importance of submitting proof of deposit and the game username for prompt verification.  
- Explain that refunds are processed within 48 hours if the payment was unsuccessful.