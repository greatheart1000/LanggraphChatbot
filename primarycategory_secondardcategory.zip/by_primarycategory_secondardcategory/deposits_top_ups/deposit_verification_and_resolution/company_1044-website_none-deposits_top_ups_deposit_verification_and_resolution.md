# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player Information**
   - Request the player's username associated with the deposit.
   - Ask for the deposit receipt or screenshot showing the transaction, including the deposit amount, date, and method (e.g., GCash, PayMaya, inbox deposit slip).
   - If applicable, request the deposit reference number or account identifier used for the transaction.

2. **Verify Receipt and Details**
   - Confirm that the submitted receipt or screenshot is clear and clearly shows the relevant details (transaction amount, date/time, payment method).
   - Cross-check the deposit timestamp and amount with the player's account records or system logs.

3. **Check System Records for Deposit**
   - Search the system for a matching deposit record using the provided deposit reference number, timestamp, amount, and payment method.
   - For wallet transactions (GCash or PayMaya), verify if the transaction appears in the system as credited to the player's account.

4. **Assess the Deposit Status**
   - If the deposit is found and credited:
     - Confirm that the deposit reflects correctly in the player's balance.
     - Inform the player that the deposit has been successfully credited.
   - If the deposit is not found or not credited:
     - Proceed to further investigation.

5. **Investigate Missing or Delayed Deposits**
   - Confirm if the deposit receipt or screenshot matches the deposit details submitted by the player.
   - Check if the deposit is still under verification with the wallet provider:
     - For GCash or PayMaya, deposits may require merchant verification and can be delayed during high transaction volume.
     - For GCASH, if the deposit is deducted but not credited, the amount usually bounces back within 24 hours to the wallet.
     - For GCASH/Mayaya, if the deposit is not reflected after 48 hours, escalate to finance or support teams.
   - Advise the player to re-check their balance after a few minutes, especially if the deposit was made during high volume periods.

6. **Follow Up on Uncredited Deposits**
   - If the deposit does not reflect and the system shows no record:
     - Confirm the deposit receipt, transaction details, and the payment method.
     - Submit all supporting information (receipt, username, deposit time) to the finance or technical team for back-end verification.
     - Explain to the player that the team will review the case and follow up; processing times may vary.

7. **Handle Specific Wallet-Related Issues**
   - For GCash deposits:
     - If the deposit is deducted but not credited, inform the player that funds usually bounce back within 24 hours.
     - If the deposit remains unreflected after 48 hours, advise the player to contact GCASH support at help.gcash.com or by calling 2882.
   - For temporary deposit unavailability or stabilization:
     - Inform the player that GCash deposits are temporarily unavailable; suggest alternative deposit methods such as Paymaya or Gotyme.
   
8. **Escalate Problematic Cases**
   - If the deposit receipt reference is not found or the payment is confirmed as completed on the wallet but not reflected in the system:
     - Escalate the issue to the finance or technical team for further investigation.
   
9. **Communicate Resolution to Player**
   - Once verified and credited, notify the player of successful deposit update.
   - If refunds are necessary (e.g., merchant did not confirm the payment), inform the player of the refund process and typical timeline (within 24-48 hours).
   - For wallet refunds (e.g., GCash bounce-backs), advise the player to monitor their wallet over the next 24 hours.

10. **Close the Case**
    - Record all relevant details of the investigation and resolution.
    - Confirm with the player that their deposit issue is resolved or advise further steps if pending.
    - Advise the player to contact support again if they experience further issues with deposits.

## Notes
- Always ask for a clear deposit receipt or screenshot to facilitate verification.
- Deposits may be delayed during high transaction volume; advise patience and rechecking after a few minutes.
- For GCash, if the deposit is deducted but not reflected, the amount is expected to bounce back to the wallet within 24 hours.
- If no record of the deposit exists after verification, the transaction might not have been completed successfully.
- Support agents must escalate unresolved issues to finance or technical teams for deeper investigation.

## Key points for communicating with players
- Confirm the exact deposit method and transaction details.
- Explain that deposit verification can take some time, especially during high-volume periods.
- Inform players about refund timelines (24-48 hours) if applicable.
- Remind players to retain deposit receipts and contact support with proof if issues persist.