# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather deposit details from the player**
   - Request the player to provide the detailed deposit receipt showing the sender and recipient information (e.g., transaction history, inbox screenshot, or official deposit record).
   - If applicable, ask for a screenshot of the deposit record from Member > Deposit Record.

2. **Verify the deposit in the player’s account**
   - Check the player’s deposit record under Member > Deposit Record to see if the transaction has been credited.
   - Confirm whether the deposit appears as pending or credited.

3. **Assess deposit status and delays**
   - If the deposit is credited and reflects in the balance, no further action is needed.
   - If the deposit is still pending or not credited:
     - Inform the player that deposits can be delayed due to network fluctuations or high transaction volume.
     - Notify that deposits via GCASH can take around 15–30 minutes, and sometimes up to 30–45 minutes for GCash deposits during network congestion.
     - Advise the player to refresh their balance after a short wait.

4. **If the deposit does not reflect after reasonable wait**
   - Confirm receipt of the deposit receipt screenshot, transaction history, or proof of payment.
   - Verify sender and recipient details on the receipt.
   - If using GCash or PayMaya:
     - Ensure the player has provided a detailed receipt showing sender and recipient info (including date, amount, and reference if available).
     - Check if the transaction appears in the player’s GCash inbox or PayMaya transaction history.
   - If the deposit was made through alternative methods (e.g., Maya, USDT, Online Bank Transfer):
     - Request corresponding proof such as transaction confirmation or reference number.

5. **Handle delays or failed deposits**
   - If the deposit is delayed beyond the typical processing time:
     - Advise the player to wait a bit longer, up to 30–45 minutes.
     - If still not reflected, recommend using alternative deposit methods such as PayMaya, GrabPay, Gotyme, USDT, or Online Bank Transfer.
   - If the player has provided proof but the deposit is uncredited:
     - Escalate the issue to the finance team for manual verification.
     - Ask the player to submit all available evidence (receipt, screenshot, transaction ID).

6. **Assist with resolve or re-process if needed**
   - For confirmed und credited deposits:
     - The finance team will verify the transaction details.
     - Once verified, credit the deposit manually if the deposit is valid.
   - For duplicated or accidental deposits:
     - Verify proofs of both transactions.
     - Adjust the balance accordingly and inform the player of the correction.

7. **Inform the player of outcome**
   - If the deposit is verified and credited:
     - Confirm successful top-up and advise to check their balance.
   - If the deposit cannot be verified after review:
     - Notify the player that the deposit could not be confirmed and suggest re-trying with a different method, if necessary.
     - Remind the player to keep supporting documents ready for further verification.

8. **Document the case**
   - Log all submitted proofs and correspondence.
   - Follow up with the finance or technical team if further investigation is required.

## Notes
- Always remind players that deposit times can vary due to network fluctuates, especially for GCash.
- Encourage players to retain transaction receipts/screenshots until the deposit has been credited.
- Suggest alternative methods proactively if delays persist.

## Key points for communicating with players
- Confirm receipt of deposit proof and clearly explain processing times.
- Advise patience during high-volume periods and network fluctuations.
- Offer alternative methods such as PayMaya or Online Bank Transfer when delays occur.
- Instruct players to check their deposit records in the account for verification.
- Escalate unresolved deposit issues with supporting evidence to the finance team promptly.