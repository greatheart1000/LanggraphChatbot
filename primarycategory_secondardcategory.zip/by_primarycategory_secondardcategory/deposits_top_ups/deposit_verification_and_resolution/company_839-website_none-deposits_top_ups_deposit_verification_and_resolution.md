# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's inquiry or issue report**  
   - Identify whether the issue pertains to a deposit made via GCash, Maya, or alternative methods such as PayMaya, USDT, GrabPay, or online bank transfer.  
   - Confirm the specific deposit method and any reference numbers or transaction details provided by the player.

2. **Request the player to provide detailed deposit proof**  
   - Instruct the player to submit a clear screenshot of their deposit receipt, invoice, or transaction confirmation showing sender and recipient details.  
   - For GCash/Maya, ask the player to log in to their account, open Inbox, and generate the receipt or invoice (e.g., QRPH invoice).  
   - Ensure the screenshot clearly displays the transaction amount, sender and recipient information, and date/time.

3. **Verify the deposit receipt and transaction details**  
   - Check that the receipt includes sender and recipient details, confirming it was a valid transaction.  
   - Confirm the deposit amount matches what was intended and that the reference number/note (if available) aligns.  
   - If the player used GCash or PayMaya, verify if the deposit was made via transfer, invoice, or QR invoice.  
   - For delays or pending transactions, inform the player that GCash deposits may take 30 to 45 minutes to process, especially during maintenance or network issues.

4. **Perform system and account checks**  
   - Access the player's account to verify if the deposit has been credited or recorded.  
   - Check the transaction history or deposit record in the account dashboard.  
   - If the deposit appears as “pending,” “transferring,” or similar, advise the player to wait and verify later as delays can occur due to network fluctuations or system delays.

5. **If the deposit is confirmed but not credited**  
   - Confirm the transaction details with your back-office/payment system.  
   - If the deposit is missing or not credited after the expected processing time, escalate by verifying the receipt against system records.  
   - Consider alternative deposit methods like PayMaya, USDT, GrabPay, or online bank transfer if delays persist or if GCash systems are temporarily unavailable.

6. **Resolve deposit issues**  
   - If the receipt and transaction details are correct but the deposit is not credited, verify whether system delays or maintenance are ongoing.  
   - Advise the player to wait and check again later.  
   - If the player’s deposit is confirmed but not reflected after a reasonable period, or if there’s a discrepancy, escalate or request support to manually verify the transaction.

7. **Assist with deposit rejections, missing deposits, or errors**  
   - Instruct the player to provide all relevant proof again.  
   - Confirm the correctness of the recipient information used during deposit.  
   - Ensure the player understands that their funds are secure and pending further verification if issues occur.

8. **Handle alternative deposit methods if GCash/Maya are unavailable**  
   - Recommend the player switch to alternative methods such as PayMaya, USDT, GrabPay, or online bank transfer if GCash is temporarily unavailable or during maintenance.  
   - For GCash unavailability, also suggest using Maya as a feasible alternative for withdrawal or deposit processes.

9. **Communicate clearly regarding processing times and status updates**  
   - Remind players that deposits via GCash typically take 30 to 45 minutes.  
   - Advise them to monitor their account balance and transaction history.  
   - Inform players that delays due to high transaction volume or system maintenance can extend processing times.

10. **Close the case or escalate if necessary**  
    - Once verified and credited, inform the player of successful deposit confirmation.  
    - If the issue cannot be resolved at front-line support, escalate with all supporting documentation provided, including receipts, screenshots, and system records.

## Notes

- Always insist on clear, visible screenshots of deposit transactions showing sender, recipient, amount, and date/time.  
- Remind players that deposits are processed upon receipt and verification of their proof.  
- Be aware that system delays or maintenance, especially with GCash, can impact deposit processing times, and advise patience accordingly.  
- In case of persistent issues, recommend switching to alternative deposit methods that are operational.  
- Acknowledge and reassure players that their funds are secure during the verification process.

## Key points for communicating with players

- Emphasize the typical deposit processing time (30 to 45 minutes for GCash).  
- Encourage players to provide detailed, clear proof to expedite verification.  
- Advise patience during system maintenance or network-related delays.  
- Offer alternative payment options if GCash services are temporarily unavailable.  
- Assure players of their funds' safety, even if processing is delayed.