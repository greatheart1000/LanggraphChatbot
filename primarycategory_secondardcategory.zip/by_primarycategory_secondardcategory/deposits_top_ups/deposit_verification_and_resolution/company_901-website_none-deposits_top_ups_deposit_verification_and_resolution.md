# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial information from the player**:
   - Request the player's Game ID or username.
   - Ask for details about the deposit or withdrawal issue.

2. **Request required verification documents**:
   - For deposit verification:
     - A clear screenshot of the Game ID or username.
     - A screenshot of the successful deposit transaction (payment receipt).
   - For withdrawal verification:
     - A clear screenshot of the Game ID or username.
     - Proof of withdrawal (e.g., withdrawal receipt or transaction screenshot).

3. **Check the submitted documents**:
   - Confirm that the screenshots clearly display the Game ID or username.
   - Verify that transaction receipts or proof match the claimed deposit/withdrawal.
   - Ensure that the total deposit or withdrawal amounts meet the minimum / maximum limits:
     - Minimum deposit is 100 PHP.
     - Maximum deposit is 50,000 PHP.

4. **Perform system and account checks**:
   - Cross-verify the deposit or withdrawal receipt with the transaction logs or history.
   - For deposit:
     - Confirm if the credited amount appears in the player's balance. Refresh the site to update.
   - For withdrawal:
     - Confirm if the withdrawal is processed or pending in the transaction history.

5. **Determine resolution based on verification results**:

   - **If all required information is provided and verified**:
     - For deposit:
       - Confirm deposit is credited and notify the player that the deposit has been verified and added to their balance.
     - For withdrawal:
       - Inform the player that the withdrawal request is processed after verification; processing times may vary.
       - Notify the player when the status changes or funds are received.

   - **If information is missing, unclear, or insufficient**:
     - Remind the player to upload clear, legible screenshots including all transaction details, payment receipt, and Game ID/username.
     - Request resubmission with clearer images if needed.
     - Do not proceed with verification until adequate documents are received.

6. **Handle delays and potential issues**:
   - Inform the player that delays of up to 24 to 72 hours are possible due to banking reasons.
   - If the funds are not received after this period, advise the player to contact support again with the relevant documentation.

7. **Escalate or close the case**:
   - Escalate any discrepancies, suspected fraud, or unresolved issues to the appropriate back-office team.
   - Once the deposit or withdrawal is verified and credited or processed, close the case and confirm resolution with the player.

## Notes

- Always ensure screenshots are clear and include all relevant transaction details.
- Keep players informed about processing times and delays due to banking or system checks.
- Verify that transaction amounts do not fall below 100 PHP or exceed 50,000 PHP for deposits.
- For account-related issues such as forgotten passwords or updating transaction passwords, request specific personal verification details, but this is outside the deposit verification scope.

## Key points for communicating with players

- Clearly explain the documentation needed: Game ID screenshot, transaction receipt, and relevant details.
- Remind players of minimum and maximum deposit limits.
- Inform about possible delays of up to 72 hours and advise to contact support if delays exceed this period.
- Encourage resubmission of unclear or incomplete documents for efficient verification.