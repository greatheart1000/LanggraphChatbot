# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather Player's Deposit Details**
   - Request the player to provide the detailed deposit receipt, including:
     - Sender and recipient information (e.g., GCash, Maya, PayMaya)
     - Transaction or reference number
     - Date and time of the deposit
     - Deposit amount
   - Encourage the player to include a screenshot of the deposit record or the transaction from their wallet/app (e.g., GCash Inbox), especially if the deposit has not reflected.

2. **Check the Player's Deposit Record**
   - Guide the player to access their deposit record:
     - Go to Member > Deposit Record
   - Ask the player to take a screenshot of the deposit record for support verification.

3. **Verify Deposit Details**
   - Confirm the receipt shows:
     - The sender (e-wallet or payment service)
     - The recipient (company account)
     - Accurate transaction/reference number
     - Deposit amount matching the player's claim
   - Ensure the deposit record screenshot corresponds with the receipt details.

4. **Assess Deposit Status**
   - Determine if the deposit:
     - Has been credited to the account
     - Is pending verification
     - Was deducted but not credited
     - Is missing or not reflected in the player’s account

5. **For Deposits Not Credited or Missing**
   - Confirm the deposit receipt includes all necessary details.
   - If the deposit shows as deducted from the sender but not credited:
     - Inform the player that refunds are typically processed within 24 hours.
     - Advise the player to contact GCash, Maya, or relevant service support if refunds are not received within 24 hours.

6. **For Deposits Not Reflected in Game Account**
   - Request the player to provide:
     - The detailed receipt
     - Screenshots of the deposit record or deposit from their wallet/app
     - The transaction/reference number
   - Verify the deposit details against the records.
   - If verified, process the credit to the player's game account.

7. **Processing Deposit Verification**
   - Once verified:
     - Credit the deposit to the player's account.
     - Notify the player that their deposit has been successfully credited.
   - If verification fails:
     - Inform the player that the deposit cannot be verified with the provided information.
     - Request resubmission of a clearer, detailed receipt or screenshot for further review.

8. **Handling Deposit Delays and Failures**
   - Advise the player that GCash deposits usually process within 30 to 45 minutes. Processing may take longer during high traffic or system issues.
   - Suggest alternative deposit methods if delays exceed typical processing times:
     - PayMaya, USDT, GrabPay, or Online Bank Transfer
   - If the deposit still does not arrive after verification:
     - Assist in submitting a refund request if applicable.
     - Direct the player to contact payment provider support for unresolved issues.

9. **For Bonuses Not Credited**
   - Explain that bonuses are automatically distributed based on system eligibility.
   - If the player does not see a bonus:
     - Confirm eligibility criteria are met.
     - Let the player know bonuses are usually credited within the expected window.
     - If not received but the deposit is verified, the bonus will typically be credited automatically.

10. **Escalate Cases Requiring Further Investigation**
    - If deposit issues persist or there are discrepancies beyond standard procedures:
      - Escalate to the back-office team with all supporting documentation.
      - Keep the player informed about ongoing investigations.

## Notes
- Always verify the details in the deposit receipt and record to prevent errors.
- Deposit refunds for deducted but not credited funds are typically processed within 24 hours.
- Encourage players to retain their deposit receipts and screenshots until the transaction is fully resolved.
- Maintain clear communication, emphasizing patience during verification delays or system disruptions.

## Key points for communicating with players
- Remind players to provide detailed receipts, including sender, recipient, date, amount, and transaction number.
- Clarify processing times: GCash deposits generally process within 30-45 minutes, but delays may occur.
- Explain that bonuses are automatically distributed and delays in bonus crediting are usually due to eligibility or system processing.
- Advise on alternative deposit methods if persistent delays occur.
- Encourage players to contact their payment provider support directly if refunds or issues are not resolved within 24 hours.