# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial deposit information from the player**:
   - Request the player's username.
   - Ask the player to provide the deposit slip or screenshot showing:
     - Date and time of the deposit.
     - Deposit amount.
     - Reference number or transaction ID.
   - Confirm the player used the correct amount within the deposit limits:
     - Minimum deposit: 100 PHP.
     - Maximum single deposit: 50,000 PHP.
   - Verify that the deposit was made through the recommended or current deposit channels and not via direct bank deposits if advised otherwise.

2. **Check the deposit details and system records**:
   - Review the provided deposit slip or screenshot to ensure:
     - The date/time corresponds with the deposit.
     - The amount matches the player's reported deposit.
     - The reference number or transaction ID is visible and legible.
   - Confirm the deposit was made within acceptable timeframes and according to site policies.

3. **Perform system verification**:
   - Cross-reference the deposit details with the payment provider or merchant system.
   - Check if the deposit has been credited to the merchant's system.
     - If the deposit has been received and credited:
       - Proceed to credit the player's account.
       - Inform the player that the deposit is successfully verified and credited.
     - If the deposit has not been credited:
       - Verify if the player used the correct reference/transaction ID.
       - Confirm the amount deposited matches the screenshot.
       - Otherwise, instruct the player to recheck their payment or deposit slip.

4. **Resolving non-reflecting deposits**:
   - If the deposit does not reflect in the player's account after verification:
     - Confirm the correctness of the amount and reference details with the player.
     - Check the merchant/payment system for any delays or issues.
     - Request the player to provide additional proof if needed.
     - If necessary, contact the merchant or payment provider for manual verification.
     - Communicate the findings and notify the player of the next steps or any delays.

5. **Guidance based on deposit conditions**:
   - Ensure the deposit amount is within the allowed limits.
   - Advise the player not to reuse old QR codes or payment links.
   - Remind the player to always use the current deposit method.
   - Confirm if promotions or bonus conditions are applicable, and advise accordingly.

## Notes

- Always request a screenshot or deposit slip showing clear details for deposit verification.
- Do not proceed with crediting funds before confirming the deposit is received and verified.
- Keep records of all deposit proof for audit and resolution purposes.
- If the deposit qualifies, credit the account promptly and inform the player. If not, provide clear instructions for further action.

## Key points for communicating with players

- Clearly explain the importance of providing accurate deposit details and proof.
- Remind players of the deposit limits (minimum 100 PHP, maximum 50,000 PHP per deposit).
- Encourage players to retain a screenshot of the successful deposit slip for reference.
- Be professional and transparent about any delays due to verification or merchant checks.