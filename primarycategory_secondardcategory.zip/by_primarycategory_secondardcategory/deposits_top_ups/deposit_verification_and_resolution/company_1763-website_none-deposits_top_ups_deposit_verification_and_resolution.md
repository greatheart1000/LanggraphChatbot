# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Identify the player's issue**
   - Determine whether the player reports that a deposit has not been credited, shows as zero balance, or requests verification of a deposit or withdrawal.
   - Ask the player for the relevant transaction details, such as the payment invoice, transaction reference number, date, amount, or payment method.

2. **Request necessary proof(s)**
   - Instruct the player to provide the payment invoice showing 'QRPH Invoicev no:…' or a transaction reference, as applicable.
   - For verification, ensure the provided proof is clear and contains all necessary information for validation.

3. **Verify the transaction in the back office/system**
   - Check the player's account transaction history for matching deposit or withdrawal entries.
   - Confirm the presence of the payment invoice or transaction reference in the system.
   - Validate that the transaction details (amount, date, account) match the player's report and proof.

4. **Assess the verification status**
   - **If the transaction is successfully found and verified**:
     - Confirm that the deposit has been credited to the player's account.
     - Inform the player that their deposit has been credited and reflect in their account.
   
   - **If the transaction is not yet credited or verified**:
     - Explain to the player that the deposit is pending verification and may take some time depending on bank processing and platform review.
     - Advise patience while system and bank checks are completed.
     - Remind the player to ensure the payment invoice and details are correct and to avoid duplicate payments.

5. **Handle uncredited deposits or discrepancies**
   - If the payment invoice or proof indicates a successful transaction but the deposit is not reflected:
     - Ask the player to resend the payment proof if unclear.
     - Confirm the exact payment details and ensure they match the transaction.
     - Escalate to technical or finance teams if the transaction cannot be found or verified after multiple checks.
   
6. **Guide on withdrawal issues**
   - Verify that the player has correct account details.
   - Advise that withdrawals are processed after initiating the request and checking account details.
   - Inform the player that delays may occur due to system verification or bank processing times.

7. **During system or maintenance periods**
   - Notify the player that deposits or withdrawals may be temporarily unavailable.
   - Advise checking the platform for updates or further instructions.

8. **Final steps**
   - Confirm with the player once their deposit has been verified and credited.
   - If issues persist, escalate to the appropriate department following internal procedures.
   - Close the case with a summary of actions taken and the current status.

## Notes

- Always require a clear payment invoice showing 'QRPH Invoicev no:…' when verifying deposits or withdrawals.
- Be patient and transparent with players about possible delays due to verification processes.
- Ensure the account details are correct before processing withdrawal requests.
- During maintenance, transactions may be temporarily unavailable; inform the player accordingly.

## Key points for communicating with players

- Emphasize the need for providing valid proof for fast verification.
- Remind players that deposits require time for processing and verification.
- Encourage players to double-check their payment details and contact support with any issues or discrepancies.