# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial information from the player**
   - Request the player's username and details of the deposit, including:
     - Payment method used (e.g., GCash, Maya, bank transfer)
     - Deposit amount
     - Date and time of the transaction
     - Merchant or platform involved (if applicable)
     - Transaction reference number or ID
     - Any available deposit receipt or screenshot from the payment platform inbox

2. **Check the deposit status in the system**
   - Verify whether the deposit has reflected in the player’s account.
   - Confirm if the deposit status matches the payment provider's records.
   - Note: Deposits can be delayed due to high system load, payment provider processing times, or bank delays (supported by FAQs). 

3. **Identify the possible cause of delay or non-reflection**
   - If the deposit has not yet appeared:
     - Determine if the payment method is GCash or another platform known to experience delays.
     - Check for current GCash or related merchant maintenance or issues, which can cause delays.
     - Consider system load or processing times; advise the player that delays of up to 24 hours are typical in some cases.

4. **Request supporting documentation if not already provided**
   - Ask the player to submit a deposit receipt or screenshot showing the transaction.
   - For GCash deposits:
     - Confirm that the player has submitted a screenshot of the GCash payment receipt.
     - Inform that refunds are handled by GCash if the deduction was made but the balance is not credited.
   - For other methods, ask for a clear proof of payment receipt.

5. **Verify received documentation**
   - Review the submitted deposit receipt or screenshot.
   - Cross-check the details (amount, date, reference number) with system records.
   - Confirm if the receipt shows the transaction was successful on the payment platform.

6. **Investigate deposit issues if the deposit did not reflect**
   - If the deposit receipt confirms a successful payment but the deposit is not reflected:
     - Advise the player to wait up to 24–48 hours for automatic processing, especially for GCash.
     - Check if the deposit was flagged for review or system delays.
     - If the deposit still does not appear after this period:
       - For GCash, advise the player to follow up with GCash support about the transaction.
       - Provide transaction details or receipt to support for further investigation if requested.
     - Note: For GCash, refunds will be processed automatically within 24–48 hours if the amount was deducted but not credited to the account (supported by FAQs).

7. **Handle specific scenarios for GCash deposits**
   - If a GCash deposit does not reflect:
     - Confirm with GCash support about the transaction status.
     - Remind the player that refunds for failed or uncredited GCash deposits are processed automatically by GCash within 24–48 hours if the money was deducted.
     - Encourage the player to wait and monitor their balance.

8. **Escalate or advise further actions**
   - If the deposit still does not appear after 48 hours:
     - Escalate the case to the finance or technical team with all collected evidence.
     - Advise the player to continue monitoring their payment platform account and GCash support for updates.
     - Remind players that they may contact support with all transaction details for further assistance.

9. **Close the case after resolution**
   - Once the deposit is verified and credited:
     - Confirm to the player that their deposit has been successfully reflected.
   - If unresolved or refund not processed:
     - Update the player on current progress or escalate the case.
     - Remind players that refunds are managed by GCash or the respective payment provider, not the company.

## Notes
- Always request a deposit receipt or screenshot when a deposit does not reflect.
- GCash deposits often require patience: automatic refunds occur within 24–48 hours if the payment was deducted but not credited.
- Delays may occur due to system maintenance, provider issues, or bank delays; advise patience and continuous monitoring.
- For GCash-related issues, the primary resolution is coordination with GCash support; the company's role is to assist with documentation and investigation.

## Key points for communicating with players
- Clearly explain that delays are common due to system or payment provider issues.
- Ask for specific proof of payment (screenshots, reference numbers).
- Inform players about the typical 24–48 hour refund window for GCash if applicable.
- Encourage patience and continuous follow-up with GCash or relevant payment support channels.
- Keep players informed of progress and escalation procedures if delays persist beyond 48 hours.