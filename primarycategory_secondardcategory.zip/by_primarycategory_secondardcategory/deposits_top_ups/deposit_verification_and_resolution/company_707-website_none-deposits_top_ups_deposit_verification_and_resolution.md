# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Receive the player's deposit inquiry or report of missing/uncredited deposit.**  
   - Confirm the specific issue: deposit not reflected, deposit rejected, or deposit missing.

2. **Request the player to provide relevant deposit proof.**  
   - Instruct the player to submit a detailed deposit receipt or screenshot showing the sender and recipient information (e.g., transaction history, deposit record).  
   - For GCash/PayMaya deposits, advise the player to access their transaction history through their wallet app and generate the deposit receipt (e.g., inbox transaction details or QRPH invoice).  
   - For deposits made via other channels (e.g., online bank transfer), request the relevant transaction confirmation or screenshot.

3. **Guide the player to access their deposit record for verification.**  
   - Instruct the player to:  
     a) Log in to the platform.  
     b) Go to the homepage.  
     c) Click ‘Member’.  
     d) Select ‘Deposit Record’.  
     e) Take a screenshot of the deposit record to share with support.

4. **Verify the submitted deposit documentation.**  
   - Check that the deposit receipt or screenshot clearly shows the sender and recipient details, transaction date and time, and amount.  
   - Confirm that the deposit record in the platform matches the submitted receipt.

5. **Perform internal checks based on deposit status:**  
   - If the deposit is **not yet credited**:  
     a) Confirm the deposit details and transaction status.  
     b) Check if the deposit is still under processing (e.g., GCash or PayMaya may take approximately 30–45 minutes).  
     c) Advise the player to wait and refresh their account after this period.  
   - If the deposit **was rejected or funds were deducted but not credited**:  
     a) Confirm with the payment provider (e.g., GCash/PayMaya) if the transaction was successful.  
     b) Verify if the deposit record and receipt are consistent with the transaction history.  
     c) Inform the player that rejected or deducted funds are **automatically reimbursed** within 2-3 days; no further action needed unless reimbursement is delayed.

6. **Handle specific cases as below:**  
   - **Deposit not reflected in the balance**:  
     - Ask for the deposit receipt or screenshot; confirm sender and recipient in transaction history.  
     - If the deposit is still not credited after the processing time, escalate with the deposit record and transaction evidence.  
   - **Deposit is pending or delay suspected**:  
     - Inform the player that processing times can vary; advise patience.  
   - **Deposit via GCash/PayMaya unavailable or slow**:  
     - Suggest alternative deposit methods such as USDT, Online Bank Transfer, or other e-wallets if applicable.  
   - **Deposit not credited due to technical issues with GCash or PayMaya**:  
     - Recommend using an alternative method if possible.

7. **If the deposit has been verified but has not yet been credited in the system:**  
   - Confirm that all documentation is complete and correct.  
   - Check if the deposit falls within the system processing guidelines.  
   - Escalate the case to the back office for further verification if needed.

8. **If the deposit is successfully verified but remains uncredited after a reasonable period:**  
   - Follow up with the back-office or technical team.  
   - Instruct the player to wait while the system updates, or escalate if delays exceed designated processing times.

9. **Provide final resolution to the player:**
   - For confirmed deposits: inform that the funds will be credited shortly (or have been credited).  
   - For rejected or deducted-then-reimbursed deposits: confirm reimbursement is in process or completed.  
   - For unresolved issues: escalate appropriately, attaching all collected documentation.

10. **Close the case after resolution or follow-up completion.**

## Notes
- Always ensure the deposit receipt clearly shows both sender and recipient details for verification purposes.
- Inform players that deposit processing times may vary depending on the channel used.
- Reimbursements for rejected or deducted funds are automatic within 2–3 days; advise players to check their account and contact support if they do not see the reimbursement within this timeframe.
- Encourage the use of the platform’s deposit record feature for efficient tracking and verification.
- Be transparent about the current limitations of deposit channels (e.g., GCASH downtime) and suggest alternatives if necessary.

## Key points for communicating with players
- Clarify that deposits are only credited after successful verification, which may take up to 30–45 minutes or more depending on the channel.
- Remind players to keep their transaction receipts or deposit records for reference.
- Advise patience during processing delays and ensure they understand the automatic reimbursement process for failed or rejected deposits.
- Encourage players to contact support with all relevant proof if issues persist beyond normal processing times.