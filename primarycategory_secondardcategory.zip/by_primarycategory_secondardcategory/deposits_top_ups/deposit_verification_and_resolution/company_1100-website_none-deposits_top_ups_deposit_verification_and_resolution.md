# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather player deposit details**
   - Ask the player for their username or Player ID.
   - Request specific deposit information:
     - Deposit record/details (date, time, amount, transaction/reference ID).
     - Deposit receipt image or screenshot, if available.
   - Confirm if the transaction receipt is in their GCASH inbox or elsewhere.
   
2. **Verify deposit success status on the player's end**
   - Instruct the player to check if the payment was successful:
     - For GCash, confirm if the receipt is available and matches the transaction.
     - For bank slips or other payment methods, verify the date, time, and reference number.

3. **Check if the deposit has been credited in the account**
   - Investigate back-end systems for the deposit record based on the provided details.
   - Confirm whether the deposit has been received and processed:
     - If the deposit has reflected in the player's account, inform the player and close the case.
     - If the deposit is delayed or not visible yet, proceed with further verification.

4. **If the deposit hasn't reflected, verify and compare details**
   - Cross-check the submitted deposit record and receipt:
     - Confirm that the date, time, amount, and reference number match.
     - Ensure the receipt contains the correct details.
   - If there is a mismatch:
     - Request the player to review and resubmit correct receipts.
     - Advise verifying that the payment was completed successfully on their end.

5. **Assess possible reasons for delay or non-appearance**
   - Inform the player that deposits can be delayed due to bank or payment system maintenance.
   - For GCash deposits:
     - Confirm whether the deposit is pending or canceled, especially if maintenance is ongoing.
     - If no receipt is in the GCash inbox, mention that the payment may be refunded by the merchant within 2-3 working days.
   - If no receipt or record is available:
     - Advise the player to contact GCash customer support to retrieve the receipt.

6. **Follow-up on uncredited deposits without receipts or confirmation**
   - If the deposit was deducted from the player's account but does not show in the system:
     - Ask the player to provide the deposit receipt or transaction proof.
     - If no receipt is available, advise contacting the payment provider support.
     - Note that refunds or credits may take 24-48 hours if applicable.
   
7. **Escalate or record the case for further investigation**
   - If all details are correct and the deposit still hasn't been credited after system checks:
     - Log the case for further investigation by the finance or technical team.
     - Advise the player to wait up to 24-48 hours if system delays are suspected.
     - Confirm that the deposit record and receipt details are provided before escalation.

8. **Handle refunds or failed deposits**
   - If a deposit is canceled or refunded (e.g., due to maintenance or discrepancies):
     - Inform the player that refunds are typically processed within 24-48 hours.
     - Recommend contacting the payment provider for status updates if necessary.
     - Keep records of the player's deposit details and refund status.

9. **Communicate with the player throughout the process**
   - Clearly explain the possible reasons for delays:
     - Maintenance, high volume, or system issues.
   - Advise on expected timeframes:
     - Up to 24-48 hours for deposits to reflect, or 2-3 working days for refunds.
   - Ensure the player understands that verification is necessary if discrepancies are present.

10. **Close the case once verified**
    - Confirm the deposit has been credited or refunded.
    - Provide the player with next steps if needed.
    - Update internal records and finalize the support ticket.

## Notes
- Always ask for and verify the deposit receipt or transaction proof whenever possible.
- Be aware that GCash maintenance may cause delays or cancellation of QR deposits, with refunds typically processed within about 24 hours.
- For deposits with no receipts and no reflection in the account after 48 hours, escalate the case for further review.
- During high-volume periods or system maintenance, delays are common; communicate this clearly to players.
- When handling bank slip or transaction details, ensure they match the submitted receipt to proceed with verification.

## Key points for communicating with players
- Confirm the exact deposit date, time, and amount match your records.
- Advise players to keep receipts or transaction proofs ready and accurate.
- Explain that system delays may occur due to maintenance or technical issues.
- Instruct players to contact their payment provider for unresolved issues and provide necessary details for support.
- Always inform players of current processing times (24-48 hours, 2-3 days, etc.) and advise patience during system updates.