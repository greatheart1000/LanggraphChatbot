# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Collect Player Information**
   - Ask the player to provide the transaction receipt from the GCASH inbox or their transaction history.
   - Confirm the username used for the deposit.

2. **Verify Deposit Receipt**
   - Check the provided inbox receipt or transaction history to ensure the deposit was made and received.
   - Confirm that the username used matches the one on the player's account.
   - Ensure the receipt clearly shows the deposit amount and transaction details.

3. **Check Deposit Reflection Timeframe**
   - Inform the player that deposits can be delayed due to processing times of banking or merchant systems.
   - If the deposit is not reflected immediately, advise waiting a reasonable period as reflection time can vary.

4. **Follow-Up if Deposit Does Not Reflect**
   - **If the deposit has not reflected after 24 hours:**
     - Contact the support team or check the system for delays.
     - Advise the player to wait a little longer, but if still unresolved, proceed to escalation.

   - **If the deposit is still not reflected after a reasonable wait:**
     - Request the player to resend the deposit receipt.
     - Verify again that the receipt matches the transaction in the inbox or transaction history.

5. **Investigate Unreflected Deposit**
   - **If the receipt or transaction history is unavailable or does not show the deposit:**
     - Advise the player to contact GCash customer service for refund.
     - Inform the player that GCash refunds are typically processed within 24-48 hours.

6. **Resolve or Escalate**
   - **If the deposit is confirmed in the inbox receipt:**
     - Manually credit the account if the system has not automatically reflected the deposit.
     - Inform the player of the successful resolution.

   - **If unresolved after repeated checks:**
     - Escalate the case to the support supervisor or relevant department for further investigation.

7. **Alternate Payment Options**
   - If GCash is undergoing maintenance or unavailability is confirmed, advise the player to use an alternative payment method such as Maya or PayMaya and retry depositing once services are back to normal.

## Notes
- Always verify that the transaction receipt clearly shows the deposit details before proceeding.
- Ensure all communication with the player is polite and informative, especially regarding delays related to banking or merchant processing.
- Follow up and escalate cases where necessary, especially if the deposit delay exceeds 24 hours or if no transaction receipt can be provided.

## Key points for communicating with players
- Emphasize that deposit reflection times can vary and delays are normal.
- Request a clear inbox receipt or screenshot to facilitate quicker resolution.
- Advise using alternative payment methods if GCASH is temporarily unavailable.