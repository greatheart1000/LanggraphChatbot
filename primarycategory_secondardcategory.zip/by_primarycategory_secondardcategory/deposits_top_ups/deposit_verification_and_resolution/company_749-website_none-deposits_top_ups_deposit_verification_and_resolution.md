# Deposits & Top-ups - Deposit Verification and Resolution

## Steps

1. **Gather initial player information**
   - Ask the player to specify the deposit issue (e.g., delay, non-reflection, no credit).
   - Request details of the deposit:
     - Payment provider used (GCash, PayMaya, etc.)
     - Deposit amount
     - Date and time of the transaction
     - Transaction number or reference, if available
     - Screenshot of the transaction receipt showing sender and recipient information
   - Confirm whether the deposit was processed through GCash or PayMaya, or used an alternative method.

2. **Check the deposit record in the system**
   - Instruct the player:
     - On the homepage, click on 'Member'
     - Select 'Deposit Record'
     - Advise the player to take a screenshot of the deposit record for verification
   - Review the player's deposit record for the specified transaction:
     - Verify if the deposit appears and its status (pending, credited, etc.)
     - Confirm whether the record shows the correct amount and details

3. **Assess deposit status and potential issues**
   - If the deposit is reflected and credited properly:
     - Inform the player that the deposit has been successfully credited
     - Advise them to refresh their balance later if the deposit was recent
     - Close the case
   - If the deposit is pending or not credited:
     - Determine if the delay is due to network issues (notably GCash network fluctuations)
       - Explain that funds are secure and will be processed once the network stabilizes
       - Recommend the player to refresh their balance after some time
       - Suggest trying alternative deposit methods if the delay exceeds 30-45 minutes:
         - PayMaya (with 2% rebate)
         - USDT
         - Online Bank Transfer
     - If the deposit record shows the transaction but no credit:
       - Verify the detailed receipt provided matches the transaction record
       - Confirm that the receipt includes sender and recipient info, and shows the payment was sent, not received
       - For GCash, also request a screenshot of the inbox transaction indicating the bank name

4. **Verify the authenticity and completeness of documentation**
   - Ensure the player provides:
     - A comprehensive receipt showing sender and recipient info
     - A screenshot of the inbox transaction, especially for GCash
     - The deposit record screenshot from the 'Deposit Record' page
     - Any reference or transaction number
   - If documentation is incomplete or unclear:
     - Request clarification or additional evidence
     - Advise the player to resend clear screenshots

5. **Perform manual review and follow-up**
   - Use the provided details to locate the transaction in the back-office system or payment provider logs
   - Verify that the transaction was successfully processed on the payment provider’s end
   - If the transaction is verified but not credited:
     - Initiate the deposit credit process manually, if system permits
   - If the transaction appears incomplete or failed:
     - Guide the player to initiate a new deposit using an alternative method, if necessary
     - Advise on waiting for the pending transaction to resolve

6. **Address deposit delays and network issues**
   - For GCash network fluctuation delays:
     - Inform the player that deposits may be pending due to network instability
     - Reassure that funds are secure and will be credited once the network stabilizes
     - Encourage waiting and refreshing the balance later
     - Recommend using PayMaya or online banking for more stable transactions
   - For deposits that remain uncredited beyond 45 minutes:
     - Escalate the issue to the finance department for further investigation
     - Consider requesting additional proof of payment if needed

7. **Communicate resolution and next steps**
   - If the deposit is verified and credited:
     - Confirm receipt with the player
     - Advise them to check their balance after some minutes
   - If refund or reimbursement is necessary due to issues:
     - Follow the standard procedures (not detailed in FAQs) or escalate to the finance team
   - For unresolved cases after thorough review:
     - Escalate to senior support or finance team with all collected evidence
     - Keep the player informed about progress and expected resolution times

## Notes

- Always ensure the player provides a detailed receipt that clearly shows sender and recipient info and indicates the transaction was processed.
- GCash deposits may experience delays due to network issues; advise using alternative methods like PayMaya, USDT, or online banking.
- Confirm the deposit record status before proceeding with verification or crediting.
- Reassure players that their funds are secure during delays and processing may take 30 to 45 minutes or longer in some cases.
- Use the deposit record screenshot to assist in internal verification and resolution.

## Key points for communicating with players

- Clearly explain that network issues with GCash may cause delays but funds are secure.
- Recommend using PayMaya or other alternatives for a smoother deposit experience.
- Emphasize the importance of providing complete, clear documentation for deposit verification.
- Keep players updated on progress and advise patience during system disruptions.