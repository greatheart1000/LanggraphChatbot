# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Receive the player's inquiry about deposits or withdrawals** to identify whether they are requesting information, submitting verification, or reporting delays.

2. **Verify the player's identity and account status**, ensuring they are logged into the correct account.

3. **Determine the nature of the request:**
   - If the player is submitting a deposit or withdrawal receipt:
     - Ask the player to provide the transaction details (e.g., date, amount, payment method).
     - Guide the player to access their transaction records:
       - On the homepage, click **Member**.
       - Choose **Deposit Record** or **Withdrawal Record**.
       - Instruct the player to take a clear screenshot showing the transaction details.
     - Send the screenshot to support for verification.
     - Confirm receipt and inform the player that the verification process will be completed shortly.

4. **Check the platform’s deposit and withdrawal policies:**
   - Confirm the deposit and withdrawal limits:
     - Withdrawal limits are generally from 500 PHP to 20,000 PHP, depending on account and transaction type.
   - Confirm process requirements:
     - Deposits require proof of payment (screenshot of the transaction confirmation).
     - Withdrawals are processed after completion of KYC/verification steps and fulfilling any required turnover.

5. **Assess if the transaction is delayed or on hold:**
   - If system maintenance or network issues are ongoing (e.g., GCash maintenance), inform the player that withdrawals via GCash may be temporarily unavailable.
   - Suggest alternative options, such as using PayMaya.
   - Assure the player that funds are secure and will be credited once systems are operational.

6. **For withdrawal delays or restrictions:**
   - Verify if the player's account has completed all required verification steps.
   - Confirm that the withdrawal amount is within the allowed limits.
   - If the transaction was initiated during maintenance, inform the player that their funds are safe and will be credited once processing resumes.

7. **Maintain communication with the player:**
   - Provide clear instructions on submitting proof (screenshots) if needed.
   - Explain any delays or limitations based on system status or account restrictions.
   - Escalate to the relevant department if further investigation is required.

8. **Close the case:**
   - Confirm that all necessary information has been gathered.
   - Inform the player of the next steps or expected timeframes.
   - Document the interaction and actions taken for record-keeping.

## Notes

- Always ensure to verify the transaction details by requesting a screenshot of the transaction record.
- Remind players that during system maintenance, processing delays are possible but their funds remain safe.
- Use alternative payment methods like PayMaya if GCash is temporarily unavailable.
- Inform players that deposit limits and withdrawal policies depend on their account and current platform rules.

## Key points for communicating with players

- Clearly inform players about the need for proof of payment via screenshot.
- Explain that withdrawal limits are typically from 500 PHP to 20,000 PHP.
- Keep players updated regarding potential delays due to maintenance or system issues.
- Reassure players that their funds are secure and will be processed once systems are operational.