# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Identify the player's query or issue regarding deposits or withdrawals.**  
   - Determine if the player reports a delayed or failed deposit/withdrawal, or asks about limits and procedures.

2. **Collect relevant information from the player.**  
   - For deposits: ask which payment method they used (e.g., GCash, PayMaya, USDT, GrabPay, bank transfer).  
   - For withdrawals: confirm the method used (e.g., GCash, PayMaya).  
   - Obtain the transaction receipt or QR code (for deposits) or transaction record (for withdrawals).  
   - For delays, note the time elapsed since the transaction (~30-45 minutes for GCash).  

3. **Verify the transaction details in the system.**  
   - Check whether the deposit or withdrawal is pending, successful, or failed, based on transaction status.  
   - Confirm the amount involved and whether it falls within the established limits:  
     - GCash withdrawal limits are PHP 500 to PHP 20,000.  
   - For deposits via GCash or PayMaya, verify if the transaction has been processed on the payment platform.  

4. **If the transaction is delayed (especially for GCash deposits or withdrawals):**  
   - Advise the player to wait an additional 30-45 minutes for processing.  
   - Ask the player to refresh their account balance after this period.  

5. **If the deposit or withdrawal appears pending or unreceived after the waiting period:**  
   - Request the player submit a clear screenshot or detailed receipt of the transaction.  
   - Consider using alternative methods such as PayMaya, USDT, GrabPay, or bank transfer to facilitate smoother processing.  

6. **If the transaction failed or was rejected:**  
   - Inform the player of the failure and recommend retrying the deposit or withdrawal using an alternative method.  
   - Suggest switching to PayMaya if GCash transactions persistently fail for amounts below PHP 500, as it offers a smoother process.  

7. **Explain the rules applicable to deposits and withdrawals:**  
   - Deposits and withdrawals are processed through verified e-wallet accounts like GCash or Maya, or other methods listed.  
   - System verifications and compliance checks (including game activity requirements) may delay withdrawal processing.  
   - Deposits are subject to network and bank delays; processing times are usually around 30-45 minutes.  
   - Players should ensure they meet all requirements (e.g., completed bets or turn-over activities) for withdrawals if applicable.  

8. **If the player inquires about limits or guidelines:**  
   - Clarify that GCash withdrawal limits are PHP 500 to PHP 20,000.  
   - For withdrawal amounts below PHP 500, recommend using PayMaya for a better experience.  
   - When in doubt, advise the player to use alternative methods for smoother and quicker transactions.  

9. **For unresolved issues or suspected system errors:**  
   - Escalate to technical support with all collected transaction details and player communications.  
   - Encourage the player to keep their transaction receipts ready for follow-up.  

## Notes

- Always verify transaction details against the system records before advising the player.  
- Remind players to use verified and supported payment methods and to follow the instructions for generating transaction receipts or QR codes.  
- Keep players informed about expected processing times and alternative options to avoid frustration.  

## Key points for communicating with players

- Clearly explain GCash withdrawal limits (PHP 500 to PHP 20,000).  
- Recommend PayMaya for withdrawals below PHP 500 for faster processing.  
- Advise patience during delays and prompt players to submit transaction proof if delays persist.  
- Encourage the use of alternative deposit and withdrawal methods if issues remain unresolved.