# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Initiate the inquiry and verify the customer's account details.**  
   - Confirm the player's account number or username.  
   - Determine whether the issue concerns deposits, withdrawals, or record checking.

2. **Ask the player for relevant transaction information or records.**  
   - If checking deposit or withdrawal records:  
     - Request confirmation of the transaction date or amount, if available.  
     - Advise the player to take a screenshot of the deposit or withdrawal record for their reference.

3. **Guide the player to check their deposit and withdrawal records.**  
   - Instruct the player to:  
     - Click 'Member' on the homepage.  
     - Select 'Deposit Record' or 'Withdrawal Record' accordingly.  
     - Take a screenshot of the record for proof verification.

4. **Determine if the player's issue involves deposit or withdrawal delays or failure.**  
   - Check for any system maintenance notices relevant to the transaction method (e.g., GCash or Maya).  
   - Confirm if the transaction involved GCash, and if so, whether GCash services are currently operational.

5. **If the issue involves GCash deposits or withdrawals:**  
   - Explain to the player that GCash is experiencing technical issues.  
   - State that GCash deposits are currently unavailable.  
   - Clarify that GCash withdrawals are also unavailable at this time.  
   - Inform the player of alternative deposit methods: Maya (which allows deposits and withdrawals) and Online Banking.  
   - For withdrawals, specify that only Maya can be used currently.

6. **Advise the player on deposit or withdrawal limits, if applicable:**  
   - For GCash withdrawals, notify that the permitted amount is from 500 PHP to 20,000 PHP.  
   - For other channels, confirm their specific policies if relevant, or advise standard processing times.

7. **Verify the correctness of the transaction details provided by the player:**  
   - Check that the deposit amount and transaction references match the records.  
   - Ensure the receipt includes sender and recipient information for verification.  
   - Confirm that the e-wallet or bank details linked with the transaction correspond with the player's account information.

8. **Assess if the issue is caused by delays or system maintenance:**  
   - If the transaction was recent, inform the player that approved deposits are usually credited within 2-3 days, and withdrawals are processed in approximately 30-45 minutes, but delays can occur during system maintenance or high volumes.  
   - Advise the player to wait or resubmit if the transaction was recent, and to provide proof if needed.

9. **In case of failed or delayed transactions:**  
   - Recommend the player resubmit the request if applicable.  
   - Request additional proof or screenshots if necessary.  
   - Confirm that they have followed the correct procedures, including verification of account info and accurate transaction details.

10. **If the player’s records or transaction details are insufficient:**
    - Advise the player to verify their inbox or transaction history with the relevant payment provider (such as GCash messages or inbox).  
    - Suggest resubmitting the transaction or providing further proof.

11. **Escalate the case if delays extend beyond the advised timeframes or if issues persist:**  
    - Collect all relevant details, records, and proof from the player.  
    - Contact the relevant department or technical team for further investigation.  
    - Keep the player informed about the escalation and estimated resolution time.

## Notes

- Always verify all transaction details against records and receipts before confirming or explaining delays.  
- During maintenance periods or system issues, recommend alternative methods (such as Maya or Online Bank Transfer).  
- Clear communication about processing times and current technical issues helps manage player expectations.  
- Ensure players understand that deposits are only credited after verification and confirmation of correctness.