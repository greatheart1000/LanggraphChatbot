# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Identify the player's issue**  
   - Determine whether the player reports a deposit or withdrawal not reflecting in their balance or experiencing delays.  
   - Ask the player for specific details about the transaction, including date, amount, and method used.  

2. **Request relevant transaction evidence**  
   - For deposits:  
     - Ask the player to provide a screenshot of the transaction receipt, ensuring it includes sender and recipient details.  
   - For withdrawals:  
     - Instruct the player to provide their 'Withdrawal Record' from Profile -> Withdrawal Record, including any relevant screenshots.  
   - If applicable, request any additional information such as order numbers or transaction IDs.  

3. **Verify transaction details in the back office**  
   - Check the player's transaction record:  
     - For deposits: compare the submitted receipt with the system record.  
     - For withdrawals: review the 'Withdrawal Record' in the player's profile for status and details.  
   - Confirm if the transaction has been processed, pending, or failed.  
   - Note: Delays may occur due to high processing volume; inform the player accordingly.  

4. **Assess if the transaction has reflected or been processed**  
   - If the deposit or withdrawal is successfully processed and reflected in the system but not visible to the player:  
     - Advise the player that processing is complete and their balance will update shortly.  
   - If the transaction is marked as pending or failed:  
     - Inform the player of the current status and any further steps.  

5. **Handle delayed or unreflected transactions**  
   - If a deposit or withdrawal is delayed or not reflected:  
     - Verify the submitted receipt or transaction record matches the official system record.  
     - Advise the player to wait, as processing delays can happen.  
     - Encourage the player to check their transaction records periodically.  
     - If the transaction remains unresolved after a reasonable period, escalate the issue to the finance team with all provided transaction details.  

6. **Address specific payment method issues**  
   - For GCash withdrawals:  
     - Notify the player that GCash withdrawal services are temporarily suspended during system maintenance.  
     - Recommend using alternative methods such as Maya until GCash is operational again.  
   - For failed GCash withdrawals:  
     - Suggest trying alternative payment options like PayMaya.  

7. **Communicate resolution and next steps**  
   - Once the transaction is verified and processed:  
     - Inform the player that their deposit or withdrawal has been successfully completed.  
     - Provide the transaction ID or order number, if available.  
   - If issues persist, advise the player to contact support with all transaction details for further assistance.  

## Notes

- Always verify the submitted evidence against the system record before updating the player.  
- Emphasize to players that delays can occur, particularly during high volume periods.  
- Maintain transparency on system maintenance affecting services like GCash withdrawals.  

## Key points for communicating with players

- Collect all relevant transaction details and evidence initially provided by the player.  
- Clearly explain that processing times may vary due to system volume or maintenance.  
- Provide alternative solutions or payment methods if relevant (e.g., Maya, PayMaya).  
- Keep the player informed at each stage of verification and processing to reduce follow-up inquiries.