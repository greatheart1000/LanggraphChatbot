# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Identify the player's query or issue related to deposit or withdrawal limitations/delays.**  
   - Ask the player to specify if they are inquiring about deposit records, withdrawal records, delays, or unbinding/changing linked accounts.

2. **Request necessary information from the player to verify their identity and transaction details.**  
   - For record verification: Ask for their full name, account username, and specific transaction date or approximate amount if applicable.  
   - For account unbinding or changes: Request the full name, username, the withdrawal e-wallet to unbind (GCash or PayMaya), reason for removal, and request a clear photo of valid ID plus a selfie holding the ID.

3. **Guide the player to view their deposit or withdrawal records if applicable.**  
   - Direct them to the following on the Home page:  
     - For deposits: Home page > Member > Deposit Record  
     - For withdrawals: Home page > Member > Withdrawal Record  
   - Advise them to take a screenshot of the record for your reference.

4. **Assist in verifying the deposit or withdrawal status based on the screenshot or record shared.**  
   - Check the transaction status in the system to confirm if it is completed or delayed.  
   - Explain to the player that deposits and withdrawals may experience delays due to network fluctuations or high transaction volume, with a typical processing time of approximately 3-5 minutes but potentially extending to several hours.  
   - Reassure the customer that funds are secure and will be credited or processed once verification is complete.

5. **If the player reports a delay or issues with deposit/withdrawal processing:**
   - Advise them that delays can happen due to network traffic or transaction volume, and that they should wait up to several hours.  
   - Suggest alternative methods such as using Maya E-wallet for smoother transactions, especially if delays persist.

6. **For players requesting to unbind or change their linked e-wallet withdrawal account:**
   - Confirm which e-wallet (GCash or PayMaya) they want to unbind.  
   - Collect the required details: full name, username, e-wallet account details to remove, and the reason for removal.  
   - Instruct them to upload a clear photo of their valid ID and a selfie holding the ID for verification purposes.

7. **If the player needs a GCASH deposit receipt:**
   - Guide them to log in to their GCASH account.  
   - Instruct them to open Inbox and generate the QRPH invoice.  
   - Advise them to take a screenshot of the deposit receipt and share it for verification.

8. **Once all information and verification steps are completed, communicate the appropriate resolution:**
   - Confirm whether the transaction is confirmed, pending, or requires further investigation.  
   - If delays are confirmed, inform the player of the estimated wait time and possible alternative solutions.

9. **Close the case with appropriate documentation and follow-up instructions.**  
   - Ensure the player understands the next steps and reassure them that the issue is being addressed or resolved.

## Notes

- Screenshots are essential for deposit and withdrawal record verification, especially for delays or discrepancies.  
- In case of unbinding or changing accounts, full verification through ID and selfie is mandatory.  
- Delays are common during high volume periods; patience is advised.  
- Using Maya E-wallet for transactions is recommended for higher stability and no deposit/withdrawal limits.

## Key points for communicating with players

- Always verify the transaction record before providing updates.  
- Explain delays as a normal process due to network or volume issues, not as a fault of the system.  
- Use clear instructions for viewing records, generating receipts, or submitting verification documents.  
- Keep the player informed about the status of their case and next steps.