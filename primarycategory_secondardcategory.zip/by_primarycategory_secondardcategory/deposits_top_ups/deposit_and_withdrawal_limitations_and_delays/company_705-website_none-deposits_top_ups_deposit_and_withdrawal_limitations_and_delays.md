# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Identify the player's query or issue regarding deposits or withdrawals.**  
   - Determine if the player reports a delay, failed transaction, or requests deposit/withdrawal information.

2. **Collect relevant account information from the player.**  
   - Ask for the player's registered username or account ID.  
   - Confirm the specific deposit or withdrawal method used (e.g., GCash QR, Maya, Paymaya, USDT, Grabpay, online bank transfer).  
   - Request the transaction details if available, such as amount and date of the transaction.  
   - If applicable, ask the player to provide verification receipts showing sender and recipient details to facilitate system verification.

3. **Check the player's transaction in the back office or system.**  
   - For deposits via GCash QR:  
     - Verify if the deposit has been approved or is pending.  
     - Confirm if the receipt and payment details match the transaction.  
   - For other methods:  
     - Check if the transaction is processed, pending, or rejected.  
     - Review verification status if applicable.  
   - If the deposit or withdrawal is not yet processed (beyond 15-30 minutes):  
     - Advise the player to wait up to 30-45 minutes for processing due to possible system delays.  
   - If the transaction is rejected or failed:  
     - Confirm whether the rejection was automatic or system-related, and inform the player accordingly.

4. **Determine if the delay or failure is due to system issues or other causes.**  
   - Possible causes include high volume, system problems, exceeding turnover requirements, or incomplete verification.  
   - If the deposit or withdrawal is delayed or failed, verify if all verification requirements (e.g., detailed receipts) are met.  
   - In case of suspected system issues, inform the player that the system is experiencing high volume or maintenance and that the transaction will be processed once issues are resolved.

5. **Assist the player with alternative solutions if necessary.**  
   - Suggest using alternative deposit methods such as Paymaya, USDT, Grabpay, or online bank transfer for faster processing if delays persist.  
   - Advise the player to recheck their receipts and transaction details for accuracy.

6. **Address deposit and withdrawal policies and restrictions.**  
   - Explain that deposits are subject to system verification and may require detailed receipts.  
   - Clarify that withdrawals may be delayed or fail due to exceeding turnover requirements, incomplete verification, or system issues.  
   - Inform that once system issues are resolved, pending transactions will be processed and funds returned if necessary.  
   - Remind the player that rejected payments are automatically reimbursed within 2-3 days.

7. **For successful transactions, confirm the completion.**  
   - If the deposit or withdrawal has been processed successfully, inform the player and provide details if needed.  
   - Guide the player to check their account balance or withdrawal record accordingly.

8. **If the player still experiences issues or if further verification is needed:**  
   - Escalate the case to the relevant support team with all collected details and screenshots.  
   - Advise the player to follow up if the issue persists beyond 45 minutes or if they do not receive funds.

## Notes

- Always verify the deposit or withdrawal with a receipt or detailed confirmation to avoid disputes.  
- Inform players that deposit bonuses, such as the 100% bonus for new members on a 100 PHP deposit, require claiming within 12 hours via the Reward Center and meeting turnover requirements before withdrawal.  
- Caution players that repeated use of the same IP address, bank card, or phone number may lead to the confiscation of rewards and profits as per policy.

## Key points for communicating with players

- Be clear about processing times: deposits and withdrawals may take 30-45 minutes, especially during system delays.  
- Suggest alternative deposit methods during delays for faster processing.  
- Gather all relevant transaction details before proceeding to system checks.  
- Keep the player informed about the status and next steps, especially if escalation is required.