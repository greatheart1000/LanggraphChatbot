# Deposits & Top-ups - Deposit and Withdrawal Limitations and Delays

## Steps

1. **Identify the player's query regarding deposit or withdrawal issues**  
   - Confirm if the player reports delays, limitations, or technical issues with GCash, PayMaya, or online banking.  
   - Determine whether the concern is about deposit or withdrawal processes.

2. **Request relevant transaction details and verification proof**  
   - Ask the player to provide a screenshot of their deposit or withdrawal record once they have completed the transaction.  
   - Instruct them to navigate to 'Member' > 'Deposit Record' or 'Withdrawal Record' to view and capture their transaction details.

3. **Check the player's transaction record**  
   - Verify whether the deposit or withdrawal has been reflected in the system by inspecting the provided screenshot.  
   - Confirm if the transaction appears correctly and matches the reported amount and method.

4. **Assess system and method availability based on current site conditions**  
   - Determine if GCash is functional; if not, explore alternative payment methods such as MAYA or online banking for deposits.  
   - For withdrawals, note that GCash may be unavailable; in such cases, process withdrawals through Maya or other available methods.

5. **Verify deposit and withdrawal limitations**  
   - Confirm that the transaction amount falls within the established limits:  
     - GCash deposits: minimum 500 PHP or more.  
     - GCash withdrawals: range from 500 PHP to 20,000 PHP.  
     - For amounts below these limits, advise using PayMaya or other channels accordingly.  
   - If the transaction exceeds limits, inform the player to adjust their amount or use alternative methods.

6. **Address delays and processing times**  
   - Explain that deposits via GCash or PayMaya may experience delays of up to 30-45 minutes due to network processing.  
   - If delays persist beyond this timeframe, verify the transaction proof and suggest alternative payment options.

7. **Handle deposit or withdrawal recharges if activity inactivity is suspected**  
   - If a withdrawal request is made but the player has experienced inactivity in deposits within the past month, advise them that a recharge matching their current balance may be needed before withdrawal processing.

8. **For unresolved issues or discrepancies**  
   - If the transaction does not reflect properly or the player reports ongoing issues after verification, escalate the case according to internal procedures.  
   - Confirm that the player has submitted all required proof and that the transaction was processed according to system policies.

9. **Record and close the case**  
   - Document the transaction details, screenshots, and verification steps in the system.  
   - Communicate the findings and any necessary next steps to the player before closing the inquiry.

## Notes

- GCash deposits start from a minimum of 500 PHP, with a maximum withdrawal limit of 20,000 PHP.  
- During technical issues with GCash or local mobile operators, alternative methods like MAYA and online banking are available and recommended.  
- Deposits made via GCash or PayMaya may take up to 30-45 minutes; advise players accordingly.  
- For deposits or withdrawals below 500 PHP, use PayMaya or other supported methods.  
- Verification requires providing a screenshot of the transaction record from the 'Member' section.  
- Always confirm with players whether their transaction has been reflected in their account before proceeding.