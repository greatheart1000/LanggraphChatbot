# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Receive and log the player's deposit inquiry**  
   - Record the player's details, including the specific issue (e.g., missing deposit, deposit rejection, deposit unavailability).  
   - Clarify which deposit method the player used (GCash, PayMaya, etc.).

2. **Request the necessary proof of payment**  
   - For deposit issues, ask the player to provide a detailed receipt or screenshot showing sender and recipient information from their GCash or PayMaya account.  
   - Instruct the player to generate this receipt by logging into their GCash account, accessing the 'Inbox' to generate the invoice, and taking a screenshot.  
   - For deposit verification, also request the transaction details visible in the GCash/PayMaya transaction history, including amount, date, sender, and recipient.

3. **Check the player's submitted proof of payment**  
   - Verify the receipt or screenshot to ensure it clearly shows the required information: sender and recipient details, amount, and date.  
   - For multiple receipts or references, gather all relevant transaction references provided.

4. **Perform system and transaction checks**  
   - Search the player's deposit record within the system by navigating to 'Member' > 'Deposit Record'.  
   - Cross-reference the submitted proof with the deposit record and transaction history to confirm whether the deposit has been received and processed.

5. **Assess deposit status based on system findings**  
   - **If the deposit is successfully processed and recorded:**  
     - Inform the player of the successful deposit.  
     - Confirm that funds should now be available in their account.

   - **If the deposit is missing or not recorded:**  
     - Check if the deposit confirmation from the player matches the deposited amount and time frame.  
     - If no record exists, advise the customer how to proceed if the deposit is believed to be missing.

   - **If the deposit is rejected:**  
     - Explain that funds deducted and rejected will be automatically reimbursed within 2 to 3 days.  
     - If reimbursement is delayed beyond this period, advise the player to contact GCash customer service for assistance.

6. **In case of deposit unavailability or technical issues**  
   - Inform the player that GCash is currently experiencing technical issues with local mobile operators.  
   - Suggest alternative deposit methods such as PayMaya, GrabPay, GoTyme, USDT, or Online Banking.

7. **Provide guidance for rejected or unresolved deposits**  
   - Rejected deposits are reimbursed automatically within 2 to 3 days; inform players accordingly.  
   - If funds are not reimbursed after this period, instruct the player to contact GCash or PayMaya customer support with their transaction details for further assistance.

8. **Escalate or advise further action if necessary**  
   - If proof of payment is incomplete or unclear, request additional documentation.  
   - For unresolved issues or disputes, escalate to the appropriate support team or advise the player to contact their payment provider’s customer support.

## Notes

- Always verify that the player provides a detailed receipt or transaction screenshot, showing sender and recipient details.  
- Ensure all transaction details (amount, date, sender, recipient) are clearly visible for verification.  
- Reimbursements for rejected deposits are processed automatically within 2 to 3 days; inform the player about this timeline.  
- When GCash deposits are unavailable, always suggest alternative deposit options to minimize disruption for the player.

## Key points for communicating with players

- Be clear that proof must show both sender and recipient details along with the transaction amount and date.  
- Remind players that if a deposit was rejected, reimbursement occurs within 2 to 3 days.  
- Keep players informed of current GCash service issues and available alternative payment methods.  
- Be empathetic, ensuring players understand the steps being taken and the expected resolution time.