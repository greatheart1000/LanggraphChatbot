# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Gather Player Deposit Details**
   - Confirm the deposit method used (e.g., GCASH, PAYMAYA, or Maya).
   - For GCASH deposits:
     - Request the player to provide the QRPH invoice generated from their GCASH Inbox.
     - Ask for proof of payment, such as the deposit receipt or a screenshot.
   - For Maya deposits:
     - Confirm the deposit was completed via Maya/E-wallet.
   - For all methods:
     - Collect the deposit amount, date, and transaction reference number if available.

2. **Verify the Deposit Submission**
   - Check if the player has provided the necessary proof:
     - For GCASH: QRPH invoice, deposit receipt, or screenshot.
     - For Maya: transaction details or screenshot if required.
   - If the player reports a pending or uncredited deposit:
     - Request the deposit record or receipt.
     - Confirm that all provided details match the transaction (amount, date, reference).

3. **Perform System and Manual Checks**
   - Verify in the back office systems if the deposit transaction appears:
     - Confirm the transaction's status (e.g., pending, authorized, completed).
   - For GCASH:
     - Ensure that the provided QRPH invoice and proof of payment are consistent.
   - For Maya:
     - Confirm the transaction status within the wallet system.
   - Check for any discrepancies or delays:
     - Deposits typically process automatically.
     - Bonuses/promotions may take up to 12 hours to be credited, if applicable.

4. **Resolve Pending or Uncredited Deposits**
   - If the deposit is pending or not yet credited:
     - Review the provided proof to confirm accuracy.
     - If valid, inform the player that the deposit is under review and will be credited shortly.
     - Escalate to the appropriate department if the deposit remains uncredited beyond normal processing times.
   - If the deposit cannot be verified:
     - Inform the player and request additional proof or details.
     - Avoid manual crediting unless verified according to policy.

5. **Confirm Successful Deposit and Update Player Account**
   - Once verified, ensure the deposit has been credited to the player's account.
   - For Maya transactions:
     - Emphasize the 6% rebate on each recharge.
     - Confirm no limits apply on deposit amounts.
   - For GCASH or PAYMAYA:
     - Confirm the deposit is reflected in the system after validation.
   - Notify the player of successful crediting:
     - Communicate the deposit details and any promotional benefits.

6. **Handling Exceptions and Discrepancies**
   - If the deposit details do not match or the proof is insufficient:
     - Inform the player and request additional verification.
   - If the deposit is suspected to be fraudulent or erroneous:
     - Follow internal procedures for review and escalation.
     - Do not manually credit funds without proper verification.

7. **Follow-Up and Documentation**
   - Log all communication, proof received, and actions taken.
   - Keep records of deposit receipts, screenshots, or transaction details.
   - Ensure all steps comply with the platform's policies and verification procedures.

## Notes
- Deposits using Maya are recommended due to its higher stability, safety, and a 6% rebate on each recharge.
- Typical deposit processing times are automatic but can take up to 12 hours if bonuses or promotions are involved.
- Always request clear, legible proof of payment from players, especially when deposits are pending or not automatically credited.
- Escalate any unresolved issues or suspected fraud to relevant support teams promptly.

## Key points for communicating with players
- Confirm all transaction details clearly and politely.
- Advise players that deposits are typically credited automatically and can take up to 12 hours if bonuses apply.
- Remind players to keep proof of payment ready for verification.
- Explain the importance of matching recipient details in the transaction to avoid delays.