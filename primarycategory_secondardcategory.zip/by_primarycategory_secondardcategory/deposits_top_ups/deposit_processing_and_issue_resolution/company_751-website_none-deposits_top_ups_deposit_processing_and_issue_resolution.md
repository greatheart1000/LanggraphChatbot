# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Receive player inquiry about deposit issues or requests for deposit processing.**  
   - Confirm the deposit method the player intends to use or has used (e.g., online banking, GCash, Maya, PayMaya, USDT).  
   - Obtain necessary details: for online banking - the deposit amount; for GCash or PayMaya - the amount; for USDT - transaction details.

2. **If the player wants to deposit via online banking:**  
   - Guide the player to click on *Deposit* on the homepage.  
   - Instruct to select *Online Banking Channel*.  
   - Prompt the player to input the recharge amount (note: no specific minimum mentioned for online banking; verify with current site rules).  
   - Advise to click *Next* to proceed.  
   - Instruct the player to navigate to their online banking account, paste the account details, and complete the payment.

3. **If the player intends to deposit via GCash:**  
   - Confirm the deposit amount is at least 200 PHP.  
   - Ask the player to take a screenshot of the deposit receipt showing GCash sender and recipient details (proof of deposit).  
   - Instruct the player to log into GCash, select *Inbox* to generate the QRPH invoice, and take a screenshot.  
   - Remind the player that GCash deposits are subject to delays during network issues and may take 30 to 45 minutes to process.

4. **If the player uses PayMaya or Maya:**  
   - Inform that these methods provide benefits such as a 6% rebate on each recharge and higher stability.  
   - Confirm the amount the player is depositing.  
   - Advise that deposits are usually processed quickly but advise patience if there are delays due to network issues.

5. **If the player deposits via USDT or other methods:**  
   - Collect relevant transaction details (such as transaction hash, wallet address, amount).  
   - Verify the transaction details in the back office or system based on the provided information.

6. **Check the deposit record:**  
   - Access the player's account in the system.  
   - Navigate to *Member* > *Deposit Record*.  
   - Verify if the deposit transaction appears in the record.  
   - If available, advise the player to take a screenshot of the deposit record for verification.

7. **If the deposit is pending or delayed:**  
   - Inform the player that delays are common during high volume or network issues, especially for GCash deposits.  
   - Confirm the player's proof of deposit (receipt, transaction hash, or screenshot).  
   - If the deposit is pending longer than expected, advise the player to refresh their balance later, or consider alternative deposit methods like Maya or PayMaya.  
   - For GCash, remind that deposits may take longer due to network fluctuations; advise patience.

8. **If a deposit is confirmed but not reflected in the wallet:**  
   - Verify the deposit record and receipt.  
   - Check whether the deposit receipt is clear and contains sender/recipient info.  
   - If all documentation is correct but the deposit is still not credited, escalate to the finance or technical team for further investigation.

9. **In case of failed or suspicious deposits:**  
   - Review the deposit record and proof submitted by the player.  
   - Confirm the deposit amount and details.  
   - Verify if the deposit meets the minimum deposit requirement (e.g., PHP 200 for GCash).  
   - If validated, advise the player on next steps or escalate to the responsible team.

10. **Closing the case:**  
    - Ensure the deposit has been successfully credited or a clear resolution has been provided.  
    - Communicate the outcome to the player, including any necessary follow-up instructions.  
    - Remind the player that for future deposits, proper proof submission can facilitate faster processing.

## Notes
- Always confirm the exact deposit method and details before proceeding.  
- For GCash deposits, actual processing times may vary; patience is advised during network delays.  
- Encourage players to keep clear screenshots of proofs of deposit and record screens for verification purposes.  
- Remind players that deposits via Maya and PayMaya offer benefits such as rebates and stability, and recommend these methods as alternative options during GCash network issues.

## Key points for communicating with players
- Confirm the deposit amount and method clearly.  
- Advise patience during delays, especially for GCash.  
- Collect and verify proof of deposit before escalating.  
- Suggest using alternative methods like Maya or PayMaya if delays persist.