# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Greet the player and obtain deposit details**  
   - Ask the player which deposit method they wish to use or have attempted (e.g., GCash, PayMaya, USDT, etc.).  
   - Confirm the deposit amount. Note: GCash deposits currently require a minimum of 500 PHP during technical issues.

2. **Verify the deposit method and check for service availability**  
   - Determine if the player selected GCash or an alternative method.  
   - If the player chose GCash, confirm if GCash deposit services are available.  
     - If GCash is unavailable due to technical issues, advise the player to use alternative methods.

3. **Instruct the player on the deposit process, if applicable**  
   - **For GCash QR deposits:**  
     - Guide the player to generate and save the GCash QR code by:  
       - Clicking Deposit on the homepage  
       - Selecting GCash QR and inputting the amount  
       - Clicking "Pay by Gcash" and entering GCash number  
       - Holding and saving the QR code to the album  
       - Opening GCash Wallet, selecting "Upload QR Code," and confirming transfer amount before clicking Send.  
   - **For other methods:**  
     - Provide the relevant instructions based on the chosen deposit method, if necessary.

4. **Request and analyze proof of deposit**  
   - Ask the player to provide a screenshot or proof of the transaction, especially if the deposit is delayed or not reflected.  
   - Confirm the transaction details such as amount and method.

5. **Check the deposit status in the back office/system**  
   - Look for the transaction record corresponding to the player's deposit.  
   - For GCash deposits:  
     - Allow 30-45 minutes for processing.  
     - If the deposit is delayed beyond this period, inform the player and suggest alternative deposit methods if needed.

6. **Resolve common deposit issues**  
   - **For delayed GCash deposits:**  
     - Advise the player to wait up to 45 minutes.  
     - Suggest alternative deposit methods like PayMaya (with 2% rebate), USDT, or Online Bank Transfer for smoother processing.  
   - **If the deposit is not found or still pending:**  
     - Verify if the player followed the correct procedure and provided valid proof.  
     - Escalate the issue to the appropriate department if unresolved.

7. **Confirm successful deposit and update records**  
   - Once confirmed, inform the player that their deposit has been successful and credited accordingly.  
   - Offer to provide a deposit record or screenshot if needed, guiding them on how to view or export their records (via Member area).

8. **Close the case**  
   - Summarize the resolution to the player.  
   - Ask if they have any further questions regarding deposits.  
   - Thank the player and end the interaction.

## Notes

- During technical issues, GCash deposits are only available with a minimum of 500 PHP. Advise players accordingly if they attempt smaller deposits.  
- Always verify the exact deposit method chosen and corresponding instructions, especially for QR code deposits.  
- If a deposit issue cannot be resolved through these steps, escalate the case following company procedures.

## Key points for communicating with players

- Be clear about expected processing times (30-45 minutes for GCash).  
- Recommend alternative deposit methods if delays occur or GCash is unavailable.  
- Remind players to provide proof of deposit/screenshots when issues arise.