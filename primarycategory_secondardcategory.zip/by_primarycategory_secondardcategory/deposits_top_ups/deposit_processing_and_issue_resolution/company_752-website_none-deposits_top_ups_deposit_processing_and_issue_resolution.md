# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Identify the player's deposit method and gather relevant information**
   - Ask the player which deposit method they used (e.g., GCash, PayMaya, USDT, Online Bank Transfer).
   - Confirm the deposit amount and the date/time of the transaction.
   - If applicable, request a screenshot of the deposit receipt or transaction confirmation.

2. **Check the deposit record in the system**
   - Access the player's deposit record:
     - Navigate to the 'Member' section from the homepage.
     - Select 'Deposit Record'.
   - Verify if the deposit transaction appears:
     - If the record is visible, confirm the amount and date match what the player provided.
     - If the record is not visible, inform the player that the system hasn't registered the deposit and advise them to wait or provide proof.

3. **Assess the status of GCash deposits**
   - Determine if the deposit was made via GCash:
     - If yes, check the recent deposit status.
     - If the deposit was initiated using GCash and shows as pending or delayed, proceed to Step 4.
   - Confirm if GCash is experiencing technical issues based on current site announcements or system updates.

4. **Handle GCash deposit issues**
   - If the player reports GCash is unavailable or experiencing delays:
     - Inform them that GCash deposits may be delayed due to network fluctuations.
     - Advise using alternative deposit methods such as:
       - Paymaya (which includes a 2% rebate)
       - USDT
       - Online Bank Transfer
     - Recommend waiting 30 to 45 minutes if the deposit was recently initiated.
     - Remind the player that their funds are secure and will be processed once the network stabilizes.

5. **Assist with deposits made through alternative methods if GCash is unavailable or delayed**
   - For PayMaya:
     - Confirm transaction success by asking for the receipt or confirmation screenshot.
     - Instruct the player on how to deposit:
       1. Click 'Deposit' on the homepage.
       2. Select the recharge channel.
       3. Input the recharge amount.
       4. Click 'Next' to proceed on E-wallet.
       5. Input the player's number and click 'Next'.
   - For USDT or online banking:
     - Ensure the player has completed the transaction successfully.
     - Wait for the system to update the deposit record if not yet reflected.

6. **Verify if the deposit has been processed**
   - Confirm that the deposit record shows the correct amount and date.
   - If the deposit record is visible but the funds have not yet credited:
     - Remind the player to allow some time for system processing.
   - If the record is missing after sufficient time:
     - Advise the player to retain proof of transaction and escalate the issue to the relevant department.

7. **Provide the deposit receipt if requested**
   - For GCash:
     - Instruct the player to log into their GCash account.
     - Select 'Inbox' to generate the invoice.
     - Take a screenshot of the deposit receipt.
   - For other methods:
     - Confirm if the player has a transaction confirmation or receipt; guide them accordingly.

8. **Address any unresolved issues or delays**
   - If the deposit remains delayed beyond expected time frames:
     - Inform the player that their funds are secure and being processed.
     - Suggest using the recommended alternative methods for faster transactions.
     - Advise the player to wait or provide proof for further assistance if needed.
   - If the deposit does not appear after a significant period or if there is a discrepancy:
     - Request the player to submit proof of the transaction.
     - Escalate to the finance or technical team for further investigation.

## Notes
- Always verify the deposit record before concluding a resolution.
- Remind players that GCash deposits may be delayed due to network conditions.
- Encourage using Maya for smoother transactions and to benefit from a 2% rebate.
- Ensure communication is clear, empathetic, and provides actionable advice.

## Key points for communicating with players
- Inform players about possible delays in GCash deposits due to network issues.
- Recommend alternative deposit methods with better stability and rebates.
- Remind players to retain transaction receipts or screenshots for proof.
- Let players know their funds are secure even if delays occur.