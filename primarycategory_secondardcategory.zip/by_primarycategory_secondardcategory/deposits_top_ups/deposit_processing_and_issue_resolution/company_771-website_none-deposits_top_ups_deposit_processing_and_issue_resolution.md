# Deposits & Top-ups - Deposit Processing and Issue Resolution

## Steps

1. **Gather information from the player**
   - Ask the player for details about the deposit attempt, including:
     - The payment method used (e.g., GCash or PayMaya).
     - The deposit amount.
     - The date and time of the transaction.
     - If available, request a screenshot of the transaction receipt or transaction history showing sender and recipient details.

2. **Verify the deposit details**
   - Check the player's account for the deposit:
     - Confirm if the deposit has been reflected in their account balance.
   - If the deposit is **not reflected**:
     - Request the player to provide the receipt or screenshot of the transaction showing mobile number, sender, and recipient information.
     - Advise the player that delays can occur due to network fluctuations, and suggest refreshing their account later.
   - If the player is using GCash:
     - Instruct them to submit the relevant receipt or transaction history.
   - If delays persist after refresh:
     - Suggest trying PayMaya as an alternative, noting it may offer a rebate.

3. **Investigate duplicate charges**
   - If the player reports being charged twice:
     - Ask for proof of payment (receipts) for each charge.
     - Verify the duplicate transactions in the back office systems.
     - If confirmed, proceed with the necessary correction and inform the player of the resolution.

4. **Check processing times and status**
   - Inform the player that deposit processing times may vary due to:
     - Network fluctuations.
     - High transaction volume.
     - System delays.
   - Advise the player to:
     - Refresh their account to check for updates.
     - Be patient while system verification completes.
   - Clarify that:
     - Deposits are processed as soon as verification and network stabilization occur.
     - Pending deposits will be credited once confirmed, or returned to the wallet if unsuccessful.

5. **Provide guidance based on deposit method and status**
   - If the deposit was successful after verification:
     - Confirm the credited amount in the player's account.
     - Thank the player and close the case.
   - If the deposit remains uncredited after a reasonable delay:
     - Escalate the issue to the relevant support team, attaching all collected evidence.
     - Inform the player that further investigation is ongoing.

## Notes
- Always request images or transaction receipts when deposits do not reflect in the account to facilitate verification.
- Remind players that using recommended platforms like GCash or Maya enhances stability and safety.
- Highlight that deposits via Maya include a 6% rebate on each recharge.

## Key points for communicating with players
- Keep players informed about potential delays and the importance of providing transaction proof.
- Encourage patience during network fluctuations and system processing times.
- Clearly explain that duplicate charges require proof to rectify and that they should submit receipts for verification.