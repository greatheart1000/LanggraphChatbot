# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Verify the player's inquiry and gather information**  
   - Ask the player to specify the nature of their question (e.g., game outcome, game operation, result guarantee).  
   - Confirm the game or betting involved, if relevant.

2. **Explain the general principles of game operation**  
   - Inform the player that all games are computer-generated and outcomes are produced by a random number generator (RNG).  
   - Clarify that outcomes cannot be manually programmed or manipulated by players or staff.  

3. **Check the specific query against the known facts**  
   - If the player questions outcome fairness or suspect manipulation, reassure them that outcomes are randomly generated and cannot be controlled or fixed.  
   - Confirm that the game system functions automatically; all wins and losses are recorded instantly and automatically added or deducted from their balance.

4. **Assess the information provided by the player**  
   - If the player reports winnings: verify that the winnings have been automatically credited to their balance.  
   - If the player reports losses or no winnings: explain that the game outcomes depend on RNG and winnings are not guaranteed—playing involves risk.

5. **Address concerns about game outcomes and system operation**  
   - Reiterate that outcomes are random and outcomes cannot be predicted or predetermined.  
   - Remind the player that the outcomes cannot be manually programmed or fixed, referencing the use of RNG as the core system mechanism.

6. **Handle specific system or outcome-related questions**  
   - If the player inquires about the timing of wins: explain that the system does not guarantee when winnings will occur, as outcomes are RNG-driven and unpredictable.  
   - If the player questions game stability during maintenance or updates: inform them that full transparency on system status is maintained, and outcomes are only generated when games are online and active.

7. **If needed, escalate or escalate suspension**  
   - If the issue involves suspected technical errors or outcomes that seem inconsistent with system operation, escalate to technical support or review the game logs.  
   - Do not offer promises of specific win times or fixed outcomes; uphold the transparency of RNG-based outcomes.

8. **Communicate key points clearly**  
   - Reinforce to the player that all wins and losses are automatically recorded and that the game outcomes are entirely determined by RNG and are not fixed or programmable.  
   - Clearly state that winnings are not guaranteed and depend on chance as per the system design.

## Notes

- Always confirm that the game is operational and not under maintenance when discussing outcomes.  
- Avoid providing any guarantees or promises regarding winnings or outcomes.  
- Keep responses aligned with the official policy that outcomes are generated randomly and cannot be controlled or predicted.  

## Key points for communicating with players

- Emphasize that games are computer-generated and outcomes are RNG-driven.  
- Explain that all winnings and losses are recorded automatically.  
- Clarify that outcomes cannot be manually programmed or manipulated and are unpredictable.  
- Remind players that gambling involves risk, and winnings are not guaranteed.