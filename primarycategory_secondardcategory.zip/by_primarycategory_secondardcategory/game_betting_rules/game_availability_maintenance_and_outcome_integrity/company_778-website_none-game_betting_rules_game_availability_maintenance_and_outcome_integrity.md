# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Receive the player's inquiry or report regarding game availability or outcomes.**  
   - Collect relevant information from the player, such as:
     - The specific game involved
     - The current status or any error messages
     - Details of recent activity, wins, or losses
     - Any screenshots or evidence if applicable

2. **Verify if the game is currently under maintenance.**  
   - Check the game status in the back office system.  
   - If the game (e.g., PG Game) is under maintenance:
     - Inform the player that the game is temporarily unavailable due to maintenance.
     - Explain that balances within the game are temporarily frozen during this period.
     - Assure the player that their funds remain secure.
     - Confirm that once maintenance ends, the balance will be automatically restored to their wallet.
     - Document the case accordingly.

3. **Assess the player's concerns regarding game outcomes and fairness.**  
   - Clarify to the player that:
     - All games are computer-generated with outcomes determined by RNG (random number generator).
     - Outcomes are random and cannot be manually influenced or patterned.
     - Winnings and losses are automatically recorded.
     - Outcomes are not predictable or guaranteed; players may win or lose.
   
   - If the issue involves a perceived outcome anomaly:
     - Confirm that the game outcomes are inherently random, fair, and system-determined.
     - Reiterate that outcomes cannot be manually programmed or influenced.
     - Reassure the player that the system ensures outcome integrity.

4. **Perform backend checks for the specific game and transaction records.**  
   - Review the game's system logs for:
     - Recent game results
     - Balance adjustments or freezes during maintenance
     - Player’s transaction history regarding wins/losses

5. **Determine resolution or explanation based on findings:**
   - If the game was under maintenance and balances were frozen:
     - Explain that the funds are secure and will be restored automatically after maintenance.
   
   - If the issue relates to game fairness or outcome predictability:
     - Reinforce that results are RNG-based, random, and cannot be predicted or influenced.
     - Confirm that outcomes are recorded automatically and fairly by the system.
   
   - If a discrepancy or technical issue is identified:
     - Escalate to technical or responsible department as per standard procedures.
   
   - If no issue is found and the player's concern is unfounded:
     - Politely clarify the game rules and system behavior.
     - Reiterate that outcomes are random, and wins are not guaranteed.

6. **Communicate the findings to the player.**  
   - Provide a clear, concise explanation aligned with the checks performed:  
     - Maintenance details, if applicable  
     - Explanation of outcome generation and fairness checks  
     - Assurance about the security of funds and system integrity

7. **Close the case once the explanation is provided and the player's concern is addressed.**  
   - Document the interaction and the outcome in the support system.  
   - Advise the player to reach out again if further issues arise.

## Notes

- Always verify if the game is under maintenance before addressing outcome concerns.
- Reinforce that game outcomes are RNG-based, random, and cannot be influenced.
- Maintain transparency regarding system operations, especially during maintenance periods.

## Key points for communicating with players

- Inform players that balances are temporarily frozen only during maintenance.
- Emphasize that game outcomes are computer-generated, random, and system-determined.
- Reassure players that winnings are automatically credited and losses are recorded fairly.
- Clarify that outcomes cannot be predicted or manually manipulated.