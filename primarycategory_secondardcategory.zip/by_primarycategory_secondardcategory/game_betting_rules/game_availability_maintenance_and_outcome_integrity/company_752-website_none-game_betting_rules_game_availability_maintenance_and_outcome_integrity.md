# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Verify the player’s query or concern.**  
   - Ask the player to specify their issue related to game availability, maintenance, or outcome fairness.  
   - Collect relevant details, such as the name of the game or specific incident if applicable.

2. **Check the game status in the back office/system.**  
   - Confirm whether the game in question is currently under scheduled or unscheduled maintenance.  
   - For ongoing maintenance, inform the player that their balance within the game will be temporarily frozen, and they will be automatically reimbursed once maintenance is complete.

3. **Explain the nature of the game system and outcomes.**  
   - Clarify that all games are computer-generated and cannot be manually programmed or manipulated.  
   - Emphasize that the results are determined by a random number generator, operated under a licensed gaming authority.  
   - Confirm that all winnings and losses are recorded automatically, and winnings are added automatically to the player’s balance.

4. **Assess the specific concern regarding fairness or potential manipulation.**  
   - Reiterate that game outcomes are random, not fixed or rigged, and the system is designed to ensure fairness under license regulations.  
   - Remind the player that claims of unfairness can be reported but must be based on genuine concerns, as the system’s results are consistent with responsible gaming policies.

5. **Resolve issues related to game outcomes or system faults.**  
   - If the player reports suspected unfair results or system errors, verify whether the game was affected by maintenance or technical issues.  
   - Confirm that during maintenance, the game balance is frozen and will be restored automatically.  
   - Advise the player that since outcomes are system-generated and cannot be manually manipulated, claims of rigging are unlikely unless verified by system logs.

6. **For inquiry about PHCASH games or other specific game types.**  
   - Affirm that PHCASH games are randomly generated, outcomes are not fixed or rigged, and winnings cannot be guaranteed at specific times.  
   - Explain that outcomes are determined by a random system and there are no guarantees of winnings.

7. **Document the interaction.**  
   - Record the player’s concern, the steps taken to verify the game status, and the explanation provided.  
   - Note whether the issue was due to maintenance, a system check, or a fairness concern.

8. **Close the case.**  
   - If the issue is resolved and there are no system errors or maintenance activities affecting gameplay, inform the player accordingly.  
   - Advise the player to contact support again if they experience further issues or suspect an unfair outcome.

## Notes

- All game outcomes are based on a random number generator and are operated by licensed authorities, ensuring fairness.  
- During game maintenance, the player’s balance within the game will be temporarily frozen; no funds are lost, and the balance will be restored post-maintenance.  
- Claims of unfair gameplay should be reported, but system results are based on results that are random and not manually controllable.  
- Always verify the current game status in the back office before providing explanations related to maintenance or system errors.

## Key points for communicating with players

- Clearly explain that all games are computer-generated and outcomes are random.  
- Reassure that all winnings are automatically added to the player's balance.  
- Emphasize that during maintenance, their game balance is temporarily frozen but will be restored automatically.  
- Encourage players to report genuine concerns and provide relevant details for proper investigation.