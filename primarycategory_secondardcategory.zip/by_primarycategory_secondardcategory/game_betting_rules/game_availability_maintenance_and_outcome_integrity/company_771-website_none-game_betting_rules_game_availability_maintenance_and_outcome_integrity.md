# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Receive the player's inquiry regarding game availability or results.**  
   - Ask the player to specify which game(s) or balance issue they are referring to.  
   - Collect relevant details such as game name, account ID, and the nature of their concern (e.g., game under maintenance, balance update, game outcome).

2. **Check the current status of the game in the back-end system.**  
   - Verify if the game is currently under maintenance.  
   - Confirm whether there are any system notices about ongoing maintenance or outages.

3. **If the game is under maintenance:**  
   - Inform the player that the game is temporarily unavailable due to scheduled or ongoing maintenance.  
   - Assure that all funds remain secure during this period.  
   - Explain that their balance within the game will be temporarily frozen and will automatically be restored once maintenance is completed.  
   - Advise the player to try again later or check for updates.

4. **Verify the player’s game balance and recent activity.**  
   - Check the balance in the game and overall wallet to compare with system records.  
   - Confirm that any winnings or losses are automatically recorded by the system.  
   - If the player reports a discrepancy (e.g., winnings not credited):  
     - Confirm if the game has concluded and whether the outcome is available.  
     - Verify whether the system shows winnings and losses accurately recorded after the game.

5. **Assess game outcome fairness and randomness.**  
   - Confirm that all games are computer-generated with outcomes that are random and cannot be manually manipulated.  
   - Reassure the player that the system ensures outcome integrity, and winnings/losses are automatically recorded.

6. **Investigate specific issues related to the outcome or balance updates:**  
   - If the player reports that winnings are not reflected:  
     - Check if the game outcome has been finalized and properly recorded.  
     - Confirm that winnings, if any, have been automatically credited to their balance.  
   - If no issues are found, explain that the system records winnings automatically and that balances update instantly based on game results.

7. **If there is a discrepancy or technical issue:**  
   - Document the issue and escalate to technical support or relevant department if needed.  
   - Advise the player that their funds are secure and that the issue will be investigated, providing an estimated timeframe for resolution if possible.

8. **Communicate clearly with the player:**  
   - Provide explanations supporting the automatic system processes, especially regarding game fairness, outcome generation, and balance updates.  
   - Reiterate that all results are generated randomly and cannot be manually influenced.

9. **Close the case once the issue is resolved or clarified:**  
   - Confirm with the player that they understand the system operations.  
   - Offer further assistance if necessary, or advise them to check back later if waiting for maintenance to complete.

## Notes

- Always verify the current game status and recorded outcomes in the back-end system before providing explanations.  
- Remind players that all game results are RNG-based and outcomes are generated automatically, ensuring fairness.  
- Reinforce that all winnings and losses are recorded automatically by the system, and balances are updated instantly after game results.  
- In case of any system maintenance, inform players about the temporary freeze on their game balance, which will be restored automatically once maintenance ends.  

## Key points for communicating with players

- Emphasize that all wins and losses are recorded automatically.  
- Clearly explain that game outcomes are RNG-generated and cannot be manipulated.  
- Reassure that their funds remain secure during maintenance and system issues.  
- Keep communication transparent and aligned with the current system status and official announcements.