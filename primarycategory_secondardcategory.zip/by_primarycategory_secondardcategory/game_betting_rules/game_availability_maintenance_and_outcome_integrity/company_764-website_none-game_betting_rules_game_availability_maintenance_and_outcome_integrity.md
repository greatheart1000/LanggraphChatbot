# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Gather Initial Information from the Player**
   - Confirm the specific game the player is referring to.
   - Ask if the player is experiencing issues with game outcomes, balance updates, or game availability.
   - Ensure to note whether the query involves winnings, losses, game outcomes, or system maintenance.

2. **Verify the Player’s Claims Regarding Game Outcomes and Balance Updates**
   - Clarify whether the player’s concern relates to whether their balance is being updated automatically after wins or losses.
   - If the player states their balance is not updating, instruct them to check if the game is correctly functioning or if there are ongoing system issues.

3. **Check the Game and System Status in the Back Office**
   - Confirm whether the game in question is currently available and operational.
   - Verify if there is planned or unplanned system maintenance affecting game availability.
   - Ensure that no system updates or technical issues are impacting game generation or payout processes.

4. **Explain to the Player How Game Outcomes Work**
   - Inform the player that all games are computer-generated using a random number generator (RNG).
   - Emphasize that outcomes are random and cannot be manually programmed or predicted.
   - Clarify that there is no guaranteed outcome or fixed schedule for wins ("Outcome outcomes are not fixed, and no guaranteed win time exists").
   - Reinforce that winnings are recorded automatically, and if the player wins, the amount will be added to their balance without delay.

5. **Assess the Validity of the Player’s Concern Based on System Data**
   - If the system shows no issues and the game is online and functioning properly, explain that:
     - All outcomes are random (RNG-based).
     - Winnings will automatically update in their balance.
   - If there is a discrepancy or system issue, escalate to technical support or report as per operational procedures.

6. **Address Player’s Specific Questions or Concerns**
   - If the player asks whether winnings can be predicted or outcomes guaranteed, reiterate that outcomes are random and cannot be manually programmed.
   - If the player requests information about guaranteed winnings, clarify that winnings are not guaranteed and are subject to the system’s random generation.

7. **Provide Guidance and Next Steps**
   - Advise the player to try restarting the game or clearing cache if their balance does not update after a win/loss.
   - If the issue persists or the game appears to be unavailable, inform the player about current maintenance or system issues, and advise to try again later or monitor official status updates.

8. **Close the Case**
   - Confirm the player understands the nature of game outcomes and balance updates.
   - Offer further assistance if needed.
   - Record the query and resolution in the customer support system, noting system status if relevant.

## Notes
- All games are generated randomly via RNG; outcomes are not manually programmed.
- Winnings and losses are automatically recorded and credited to the player’s balance when applicable.
- No fixed schedule or outcome guarantee exists; winnings are not predictable.
- Always verify system status before providing detailed explanations or solutions.
- Escalate system-related issues to technical support promptly if discrepancies are detected.

## Key points for communicating with players
- Emphasize that all outcomes are RNG-based and cannot be predicted or guaranteed.
- Confirm that balance updates are automatic after wins or losses.
- Explain that system maintenance or technical issues can temporarily affect game availability.
- Encourage players to restart their device or clear cache if balance updates are delayed but no system issue is apparent.