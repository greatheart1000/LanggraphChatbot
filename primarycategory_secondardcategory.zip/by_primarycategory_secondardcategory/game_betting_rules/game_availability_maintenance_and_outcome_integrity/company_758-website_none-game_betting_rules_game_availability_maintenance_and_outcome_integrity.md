# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Identify the player's inquiry**
   - Determine whether the question relates to game outcomes, winnings/losses, game fairness, or game outcome timing.
   - Collect relevant account information (player ID, game played, transaction details if applicable).

2. **Verify the game details and status**
   - Check if the game in question is currently available and not under maintenance.
   - Confirm that the game operates on a computer-generated, RNG-based system, as per the site's game rules.

3. **Explain how game outcomes are generated and recorded**
   - Clarify that all games are computer-generated and outcomes are random.
   - Emphasize that games cannot be manually programmed.
   - Confirm that all winnings and losses are recorded automatically by the system.
   - If the player’s concern involves winnings, explain that:
     - Winnings are added automatically to the balance when a win occurs.
     - Losses are recorded according to the RNG outcomes.

4. **Check the record of the player's game sessions**
   - Access the back office or system logs to verify the transaction history.
   - Ensure the recorded winnings/losses are consistent with the game outcomes.
   - Verify that winnings, if any, have been properly credited to the player's account.

5. **Address specific scenarios based on the player's question**
   - If the player questions the randomness or fairness:
     - Reiterate that outcomes are generated randomly by the system using RNG, and outcomes cannot be manually controlled.
   - If the player asks about the timing of winnings being awarded:
     - Inform that game outcomes are generated randomly, and there is no guaranteed time for winnings to be credited.
   - If the player claims issues with their winnings or losses not being reflected:
     - Double-check the transaction history and system records.
     - Confirm whether the game session is completed and results are processed.
     - If discrepancies are found, escalate the issue to the technical team for further investigation.

6. **Inform the player of the system's operation and limitations**
   - Reinforce that game outcomes are random and cannot be manually manipulated.
   - Clarify that winnings appear automatically in the account when the game result is a win.
   - Explain that the timing of winnings depends on system processing, with no guaranteed payout time.

7. **For unresolved concerns or discrepancies**
   - Advise escalation to technical support or senior team members for further investigation.
   - Do not attempt to manually adjust game outcomes or winnings.
   
8. **Close the case**
   - Summarize the findings for the player.
   - Confirm that the recorded results are consistent with system logs.
   - Inform the player that the game operates under the site’s rules for outcome generation and recording.
   - Provide reassurance regarding game fairness and system integrity.

## Notes
- All game outcomes are generated randomly and cannot be manually programmed.
- Winnings are automatically credited upon a win and are recorded in the system.
- There is no fixed timeframe for winnings to appear; they depend on system processing.
- Always verify the transaction record before concluding a case involving payout issues.

## Key points for communicating with players
- Emphasize that all outcomes are RNG-based and random.
- Confirm that the system records winnings and losses automatically.
- Clarify that winnings are credited automatically without manual intervention.
- Remind that outcome timing is unpredictable and not guaranteed.