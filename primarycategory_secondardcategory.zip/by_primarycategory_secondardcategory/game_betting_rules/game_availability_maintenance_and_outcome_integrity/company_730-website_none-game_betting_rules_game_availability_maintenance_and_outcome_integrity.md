# Game & Betting Rules - Game Availability, Maintenance, and Outcome Integrity

## Steps

1. **Receive the player's inquiry related to game outcomes or game fairness.**  
   - Collect relevant details about the specific game, bet amount, and any related concerns from the player.

2. **Explain that game outcomes are generated randomly by the system.**  
   - Clarify that outcomes cannot be manually programmed, predetermined, or influenced by agents or operators.  
   - Emphasize that the system uses RNG (Random Number Generation) ensuring fairness and compliance.  
   - Inform the player that no specific time or guarantee can be provided for winnings.

3. **Verify the player's account and game session status.**  
   - Check if the game is active, available, and not under maintenance.  
   - If the game is in maintenance, proceed to step 4; otherwise, continue.

4. **If the game is under maintenance:**
   - Notify the player that during PG game maintenance, their game balance is temporarily frozen.
   - Reassure the player that all funds are secure.
   - Inform that, once maintenance is complete, the balance will be automatically restored to the wallet.
   - Document the issue and advise the player to check back later or wait for system updates.

5. **If the outcome question relates to fairness or randomness:**
   - reassure the player that all game results are generated randomly and cannot be manually controlled or predetermined.  
   - Confirm that the system adheres to licensing regulations (e.g., PAGCOR) to ensure fairness and compliance.

6. **If the player questions about winnings at specific times or outcomes:**
   - Clarify that there is no guaranteed time to win or specific outcomes; results are entirely random.  
   - Explain that winnings are credited automatically when the system determines the outcome.

7. **In cases of technical or system issues affecting game results:**
   - Verify the game system status and ensure no ongoing maintenance or technical issues.  
   - If an issue is identified, escalate to technical support and inform the player that the issue is being investigated.

8. **Document all interactions and findings.**  
   - Record the details of the inquiry, system checks, and communications for future reference or escalation.

## Notes

- All game outcomes are random and cannot be manually programmed or predetermined.
- During maintenance, the game balance is temporarily frozen but remains secure.
- Winnings are automatically credited based on the system-generated results.

## Key points for communicating with players

- Always reinforce that the system uses RNG to ensure fairness and compliance.
- Make it clear that outcomes are unpredictable and no specific winning time can be guaranteed.
- Reassure players that their funds are secure during maintenance and that results are automatically processed.