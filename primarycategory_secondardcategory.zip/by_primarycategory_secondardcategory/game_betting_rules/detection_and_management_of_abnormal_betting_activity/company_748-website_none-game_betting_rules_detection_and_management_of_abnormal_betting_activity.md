# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. Receive the player's inquiry or report regarding abnormal betting activity.

2. Verify if the inquiry concerns abnormal or irregular betting activity detected by the system, or if the player claims possible violation.

3. Access the system logs and detection reports to confirm whether abnormal betting activity has been flagged:
   - Check for system notifications or alerts indicating abnormal or irregular betting.
   - Review the betting pattern for signs of abnormal profits or profits from violations.

4. Collect relevant information from the player:
   - Confirm the specific bet(s) they are concerned about.
   - Ask for details if needed to clarify whether they believe the activity was irregular or malicious.
   - Check if the player has engaged in any suspicious behavior, such as cheating or violating rules.

5. Assess whether abnormal or irregular betting activity is confirmed:
   - If confirmed, proceed to the resolution steps.
   - If not confirmed, explain that no abnormal activity has been detected and close the case.

6. If abnormal betting is confirmed:
   - Notify the player that the system has detected abnormal betting activity.
   - Inform them that any abnormal profits will be deducted from their account, including profits from malicious arbitrage-winning users who cheated or violated rules. Also, note that bonuses and profits from violations are subject to deduction.

7. In the back office/system:
   - Deduct the identified abnormal profits from the player's account.
   - Ensure that all winnings and losses from computer-generated games are automatically recorded and updated in the system.
   - Confirm that the player's total balance reflects the deduction.

8. Advise the player:
   - To bet normally in future.
   - To complete the added turnover or wagering requirements before attempting to withdraw any funds.

9. Close the case with appropriate documentation:
   - Record the detection details, actions taken, and any communication with the player.
   - Escalate per internal procedures if malicious activity or cheating is suspected beyond normal detection scope.

## Notes
- Games are computer-generated, and outcomes cannot be manually manipulated.
- All game results are automatically recorded; winnings will be credited automatically.
- Deductions are applied only when abnormal or irregular betting activity is confirmed by the system.

## Key points for communicating with players
- Clearly inform players that abnormal profits will be deducted if abnormal betting activity is detected.
- Emphasize that the system automatically detects irregular betting and records outcomes.
- Remind players to bet normally and complete any required turnover before withdrawal.