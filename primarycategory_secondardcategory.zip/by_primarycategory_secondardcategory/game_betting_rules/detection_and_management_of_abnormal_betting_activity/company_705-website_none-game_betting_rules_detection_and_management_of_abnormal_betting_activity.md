# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and assess the player's inquiry or report**
   - Gather detailed information from the player regarding the suspicious activity, including:
     - Description of the betting activity
     - Relevant dates and times
     - Amounts involved
     - Any supporting evidence (screenshots, transaction IDs, etc.)
   - Confirm whether the player reports abnormal betting activity or requires clarification on how winnings are determined.

2. **Verify the nature of the betting activity within the system**
   - Check the player's betting history for irregular activity:
     - Look for patterns that deviate from normal betting behavior
     - Confirm if the betting activity is flagged as abnormal by the system
   - Review the specific transactions associated with the activity:
     - Identify any profits gained from these activities

3. **Determine if abnormal betting activity is detected**
   - Confirm whether the system has flagged irregular or abnormal betting activity associated with the player's account
   - If the system detects irregular betting, it may also identify malicious arbitrage winnings and deduct illicit profits

4. **Assess the outcome of the betting activity**
   - Recognize that:
     - Games are generated randomly, and outcomes cannot be manually programmed
     - All winnings and losses are recorded automatically
     - Winnings, if any, are added automatically to the player's balance
   - Confirm that the game outcome is fair and not manipulated

5. **Decide on resolution based on detection results**
   - If abnormal betting activity is confirmed:
     - Inform the player that any profits gained from these activities are subject to deduction as per platform policy
   - If no abnormal activity is detected:
     - Advise the player that their betting activity is within normal parameters

6. **Actions if abnormal activity is identified**
   - Deduct any profits gained from abnormal betting activity from the player's account balance
   - If malicious arbitrage or illicit profit is identified, deduct all illicit profits
   - Notify the player about the detection, explaining that abnormal betting may result in restrictions or deductions
   - Escalate the case to the appropriate team if necessary, especially if further investigation or account restrictions are needed

7. **Document and close the case**
   - Record all findings, actions taken, and communications in the customer support system
   - Confirm that the player is informed of the deductions and the reasons behind them
   - Close the case once resolved and ensure all actions comply with platform policies and regulations

## Notes
- All detected abnormal betting activities may lead to restrictions or deductions on profits, in accordance with platform policy.
- The detection system may flag transactions as abnormal and take actions automatically.
- Play within normal betting behaviors; irregular betting activities can result in profit deductions or account restrictions.

## Key points for communicating with players
- Clearly explain that games are based on chance and outcomes cannot be manually manipulated.
- Inform players that any detected irregular betting activity can lead to deductions of profits gained from such activities.
- Advise players to bet normally and fulfill required turnover before withdrawal to avoid restrictions.