# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and record the player's report or inquiry regarding betting activity**  
   - Collect details about the suspected abnormal betting activity, including the time, amount, and nature of the bets if provided.  
   - If applicable, ask the player for screenshots or specific evidence of the activity.

2. **Access the player's betting history and account activity in the back office system**  
   - Review the betting patterns, focusing on activity associated with the player's account.  
   - Confirm all recorded winnings and losses, noting specific bets that may seem irregular or irregularly high.

3. **Check for abnormal betting signals**  
   - Determine if the activity qualifies as abnormal based on system detection – e.g., irregular betting patterns, unusually high bets, or profits that may be classified as illicit profits.  
   - Verify if the system has flagged any activity as irregular or abnormal.  
   - Remember, the system detects and will deduct profits gained from abnormal or irregular betting activity.

4. **Assess whether the detected activity involves abnormal profits or illicit winnings**  
   - If abnormal profits or illicit gains are identified, prepare to deduct these profits as per security measures.  
   - Confirm that the activity aligns with system detection of abnormal or irregular betting, which may include arbitrage or malicious activity.

5. **Determine the appropriate response based on findings**  
   - If abnormal betting activity is confirmed or detected:  
     - Proceed to deduct the abnormal profits gained from such activity in the system automatically.  
     - Inform the player that their activity has been flagged as abnormal and that profits obtained from such activity will be deducted in accordance with security measures.  
   - If the activity appears normal or insufficient evidence is available:  
     - Explain that the system continuously monitors activity and that flagged irregularities, if any, are handled automatically.

6. **Handle the player's account accordingly**  
   - Ensure that all winnings from detected abnormal activity are deducted in the back office system.  
   - Communicate transparently with the player regarding the detection and action taken, if necessary, clarifying that the system is designed to ensure fair gaming and prevent illicit profits.

7. **Advise the player on proper betting conduct**  
   - Remind them of the importance of normal betting behavior to avoid future detection of irregular activity.  
   - Recommend betting normally and avoiding patterns that could be identified as abnormal, in order to prevent further deductions.

8. **Document the case and actions taken**  
   - Record all observations, system detections, actions, and communications for audit purposes.  
   - Escalate to management if there is suspicion of malicious or intentional abuse of the system.

## Notes

- The system automatically detects abnormal betting and will deduct profits gained from such activity, including malicious arbitrage winnings.  
- All winnings and losses are recorded automatically for transparency and compliance purposes.  
- Ensure communication with players is clear but aligned with the company policy: indicate that the system’s security measures protect fair gaming and may deduct illicit gains.  
- Additional actions beyond profit deduction (such as account suspension or further investigation) are handled according to internal policies and escalation procedures, not specified in the FAQs.