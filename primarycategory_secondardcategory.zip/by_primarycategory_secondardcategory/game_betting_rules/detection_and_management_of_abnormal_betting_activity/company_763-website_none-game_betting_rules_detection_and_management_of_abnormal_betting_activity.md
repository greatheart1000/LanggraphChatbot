# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and review player report or concern about betting activity**  
   - Collect relevant information from the player, such as their account ID, betting history, and specific details about the suspected abnormal activity.

2. **Verify the player's identity and account security**  
   - Ensure the account is verified through physical ID verification if any online or xerox copies are used, as the platform does not accept online IDs.  
   - Confirm the account's current status and recent betting activity.

3. **Review system detection alerts and betting patterns**  
   - Check the system logs for detected abnormal betting activity or irregular betting patterns.  
   - Confirm if any abnormal profits or winnings have been automatically deducted, as per platform policy.

4. **Assess if abnormal betting activity is confirmed**  
   - Determine whether the system has flagged activity as abnormal based on betting behaviors.  
   - Review if profits from such activity have been deducted automatically.

5. **Explain the platform's policy to the player**  
   - Inform the player that if abnormal betting activity is detected, profits from those activities may be deducted as part of the platform’s risk controls or fair play policies.  
   - Clarify that this is an automatic security measure designed to protect fair play and the integrity of promotions.

6. **Check if additional information or evidence is required**  
   - Request any supporting screenshots or documentation if needed to clarify the betting activity, but note that automated system detection and deductions are standard procedures.  
   - If the player claims the betting activity was legitimate and there are no system alerts, advise them to continue playing responsibly and avoid irregular betting.

7. **Determine if further action is necessary**  
   - If abnormal profits have been deducted, record the action taken in the system.  
   - If the player disputes the detection, escalate the case for further review according to internal procedures, ensuring all relevant information is documented.

8. **Close the case**  
   - Confirm all actions have been properly recorded.  
   - Inform the player of any applicable information on automatic deductions and fair play policy.  
   - Reassure the player about the system's role in maintaining a fair gaming environment.

## Notes
- All automatic detections and deductions are performed by the platform’s system and are based on predefined betting pattern algorithms.
- Ensure quick verification of identity and betting activity; avoid unnecessary delays.
- Always communicate clearly that abnormal profits may be automatically deducted as part of platform policies.

## Key points for communicating with players
- Explain that the system detects abnormal betting, and profits from such activities may be deducted.
- Clarify that physical ID verification is required for account security.
- Emphasize the automatic nature of detections and deductions, and encourage playing responsibly.