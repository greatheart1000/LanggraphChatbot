# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and review the player's inquiry or report**
   - Collect relevant account details, including username and recent betting activity.
   - Ask the player if they have received any system notifications or warnings related to betting activity.

2. **Identify if the inquiry concerns abnormal betting activity or withdrawal issues due to suspected irregularity**
   - Confirm whether the player reports abnormal betting behavior or if the system has already flagged their account.

3. **Check for system detection of abnormal betting activity**
   - Verify if the system has identified irregular betting patterns associated with the player's account.
   - Confirm if any profits from these activities have been subject to deduction.
   - Determine if the system has frozen funds, or if withdrawal has been canceled due to abnormal activity.

4. **Evaluate the player's current betting status and profits**
   - Confirm whether the player has gained profits from abnormal betting activities.
   - Check if the player is required to complete turnover requirements before withdrawal, especially if their bets involved irregular activity.

5. **Advise the player on the consequences and required actions**
   - Inform the player that abnormal betting activity can result in profit deductions and fund freezing.
   - Explain that players must complete all ancillary requirements (e.g., turnover) before being able to withdraw.
   - Emphasize that if malicious arbitrage or illegal betting is detected, all illicit profits will be deducted.

6. **If abnormal betting activity is detected and the player has profits or withdrawal issues:**
   - Instruct the player to continue betting normally to complete the required turnover.
   - Confirm that they understand they must finish this turnover before initiating or successfully completing withdrawal.

7. **If the player claims to have made irregular bets but system detection is inconclusive:**
   - Explain the system's role in monitoring abnormal activity.
   - Advise to continue normal betting and complete any outstanding turnover obligations.
   - Inform that if irregular activity is confirmed by the system later, profits will be deducted accordingly.

8. **In case of further doubts or suspected malicious activity:**
   - Escalate the case to the relevant department following internal protocols.
   - Document all findings and communications with the player.

9. **Close the case after resolution:**
   - Confirm with the player once all requirements are met and their betting activity complies with the rules.
   - Advise on proper betting behavior to avoid future issues.
   - Ensure the player understands that any detected irregular betting activity will continue to be subject to review and possible deduction.

## Notes

- Always verify whether the system has flagged abnormal betting or profits before issuing explanations.
- Remind players that all profits from irregular activity are subject to deduction, including illicit profits from malicious arbitrage.
- Inform players that they must finish all relevant turnover requirements before being eligible for withdrawal if abnormal betting activity is involved.

## Key points for communicating with players

- Clearly explain the role of system detection and the potential consequences of abnormal betting activity.
- Emphasize the importance of completing turnover requirements to unlock withdrawal.
- Reassure the player that irregular activity is monitored automatically, and action is taken according to system findings.