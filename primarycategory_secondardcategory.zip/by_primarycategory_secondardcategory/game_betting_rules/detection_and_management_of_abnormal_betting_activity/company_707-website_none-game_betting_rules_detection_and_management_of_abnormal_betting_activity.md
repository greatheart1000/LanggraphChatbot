# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and review the player's inquiry or report**:
   - Collect any relevant information provided by the player regarding the betting activity.
   - Note the details of the suspected abnormal betting activity, including dates, amounts, and betting patterns if available.

2. **Access the system's detection alerts or monitoring tools**:
   - Check the system for any active alerts related to abnormal or irregular betting activities associated with the player's account.
   - Identify if the system has flagged any abnormal betting patterns or profits.

3. **Verify the existence of abnormal betting activity**:
   - Confirm whether the system has detected abnormal betting activity, such as irregular betting patterns or profits.
   - Recognize that the system may detect abnormal betting and automatically flag the activity for review.

4. **Assess the detected activity against policies**:
   - Determine if profits gained from the detected abnormal betting activity are present.
   - Understand that if abnormal betting is detected, the system may deduct the profits gained from such activities as part of anti-fraud measures.
   - Note that profits from irregular activities could be deducted, and the account may be suspended according to policy if applicable.

5. **Decide on handling based on verification results**:
   - **If abnormal betting activity is confirmed**:
     - Inform the relevant team or follow internal procedures for deducting abnormal profits.
     - Clearly communicate to the player that profits gained from abnormal betting activities may be removed.
     - If applicable, proceed with suspending the account according to standard procedures.
   - **If no abnormal activity is detected or information is insufficient**:
     - Advise on further investigation or inform the player that no abnormal activity has been found at this time.

6. **Document all findings and actions**:
   - Record the details of the detection, verification steps, and resolution.
   - Keep notes of any alerts, system reports, or communications with the player.

7. **Follow escalation procedures if necessary**:
   - If the situation involves a significant or confirmed breach, escalate to the relevant compliance or technical team.
   - Ensure any suspension or profit deduction actions are executed according to the company's policies.

## Notes

- Abnormal betting patterns are monitored through automated systems; manual detection should align with system alerts.
- Profits gained from detected irregular activities may be deducted from the player's account.
- Account suspension is possible if abnormal activity is confirmed.
- All actions should be documented thoroughly for compliance and review.

## Key points for communicating with players

- Clearly inform players that, if abnormal betting is detected, profits from such activities may be deducted.
- Ensure explanations are aligned with the system's detection capabilities and company policies.
- Maintain professionalism and transparency when discussing account activity or suspensions related to abnormal betting.