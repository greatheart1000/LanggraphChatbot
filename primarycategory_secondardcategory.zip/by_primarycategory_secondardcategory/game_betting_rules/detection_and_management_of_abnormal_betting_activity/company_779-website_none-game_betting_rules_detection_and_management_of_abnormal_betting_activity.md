# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and document the player's inquiry or report regarding betting activity.**  
   - *Note:* If the player reports suspected abnormal or irregular betting activity, record the details thoroughly.

2. **Verify if the inquiry is related to potential abnormal or irregular betting activity.**  
   - Check for any indications from the player's account or betting history suggesting irregular patterns.

3. **Assess the betting activity through the system's detection measures.**  
   - The system automatically monitors betting patterns for abnormal behavior or irregular activity.  
   - Be aware that the system flags abnormal betting activity and detects irregular betting patterns.

4. **Determine if abnormal or irregular betting activity has been detected.**  
   - **If no abnormal activity detected:**  
     - Explain to the player that their bets are in line with normal betting patterns, and no action is needed.  
   - **If abnormal or irregular activity is detected:**  
     - Proceed to the next step.

5. **Identify and document the specific nature of the abnormal or irregular activity.**  
   - Confirm that the activity falls under the system's detection triggers for abnormal or irregular betting, which may include patterns deviating from normal behavior.

6. **Decide on the appropriate action based on the detection:**
   - **For profits gained from abnormal or irregular betting activity:**  
     - Deduct those profits as penalties, in accordance with the platform's policy.  
   - **For winnings from normal bets:**  
     - Record winnings automatically; no deduction applies unless activity is flagged as irregular later.

7. **Advise the player on necessary conditions to maintain eligibility:**
   - Place bets normally and avoid irregular patterns.  
   - Complete the required turnover before attempting withdrawals, especially if profits are involved from flagged activity.

8. **Communicate clearly with the player:**
   - Explain that if abnormal betting activity is detected, profits may be deducted.  
   - Emphasize the importance of betting in compliance with platform policies to avoid penalties.

9. **Escalate the case if necessary:**
   - If there is suspicion of illegal activities such as arbitrage or account abuse, escalate according to internal protocols.

## Notes

- All outcomes and detections are handled automatically by the system; manual interventions are limited to cases where escalation is necessary.
- Winnings are automatically recorded, but profits from detected abnormal activity may be deducted.
- Handling irregular betting activity strictly follows the policy where profits gained from such activity are subject to deduction.
- The system's detection covers both abnormal and irregular betting activity, with a focus on maintaining fair play and policy compliance.

## Key points for communicating with players

- Explain that abnormal betting activity can result in profit deductions.
- Reinforce the importance of normal betting patterns and completing turnover requirements before withdrawal.
- Inform players that all bets and outcomes are automatically recorded, and irregular activity is monitored automatically.