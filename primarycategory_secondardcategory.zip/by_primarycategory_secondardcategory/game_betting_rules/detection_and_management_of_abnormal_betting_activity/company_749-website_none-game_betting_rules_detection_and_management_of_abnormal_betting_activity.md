# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and review the player's inquiry or report regarding betting activity.**
   - Determine if the player is reporting an issue or asking about their betting activity.

2. **Verify the player's account and obtain relevant information.**
   - Collect the player's account details.
   - Ask the player if they suspect irregular or abnormal betting activity, or if they have noticed any issues.

3. **Check for system detections of abnormal or irregular betting activity.**
   - Use the back office system to identify if any irregular betting activity has been flagged.
   - Confirm if the system has detected abnormal betting patterns associated with the player's account.

4. **Assess the detection outcome.**
   - If the system detects abnormal betting or irregular activity, proceed to Step 5.
   - If no detection or suspicion exists, explain the gameplay and betting process, emphasizing that:
     - Games are computer-generated and outcomes are determined by a random number generator (RNG).
     - All winnings and losses are recorded automatically.
     - Winnings are automatically added to the player's balance.

5. **Determine the scope of the detected abnormal activity.**
   - Confirm if the activity involves malicious arbitrage winning or other irregular betting that violates regulations.
   - Review the system's record to identify if illicit profits are involved.

6. **Communicate the detection results to the player.**
   - Inform the player that abnormal betting activity has been detected.
   - Explain that, in accordance with our policy, any abnormal or illicit profits gained from such activity will be deducted.
   - Clarify that if malicious arbitrage winning is identified, all illicit profits will be subject to deduction.

7. **Enforce the deduction of profits.**
   - Deduct the abnormal or illicit profits from the player's account according to the system's records.
   - If applicable, confirm this action with the player and provide a statement or evidence if required.

8. **Handle cases of repeated or severe violations.**
   - If malicious arbitrage or irregular activity persists or is severe, escalate the case following the company's internal procedures.
   - Consider account restrictions or further investigations if necessary.

9. **Document the case details.**
   - Record the detection, actions taken, and communication with the player in the system for future reference.

10. **Close the case and inform the player of the outcome.**
    - Confirm that the necessary actions have been taken.
    - Clearly communicate that the account is being monitored and recommend following fair play policies.

## Notes
- Always verify detection through the system before taking action.
- Adhere strictly to the policy that profits gained from abnormal or irregular activities are subject to deduction.
- Inform players that game outcomes are determined via RNG and cannot be manipulated.
- Escalate cases involving malicious arbitrage or illegal profits according to internal procedures.

## Key points for communicating with players
- Clearly explain that the system detects abnormal betting activity and deducts illicit profits.
- Emphasize fairness and the importance of maintaining the integrity of the game.
- Be transparent about the process and actions taken, ensuring players understand the rationale behind deductions.