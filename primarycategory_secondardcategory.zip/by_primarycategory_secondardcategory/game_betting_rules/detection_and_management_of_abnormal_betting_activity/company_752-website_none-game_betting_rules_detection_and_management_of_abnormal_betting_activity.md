# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and log the player's report or query about abnormal betting activity.**
   - Collect relevant account information, including account ID, recent betting history, and any specific details the player provides about the activity in question.

2. **Check the system for abnormal betting activity associated with the player's account.**
   - Review system alerts or flags indicating irregular betting patterns, as detected by the platform’s automatic detection system.

3. **Verify the nature of the betting activity.**
   - Determine if the activity is classified as abnormal betting or irregular betting based on the system’s identification.
   - Recognize that suspected activities may include unauthorized arbitrage or other patterns violating platform rules.

4. **If abnormal or irregular betting activity is confirmed:**
   - Inform the player that:
     - The system has detected abnormal betting activity.
     - Any profits gained from such activities will be subject to deduction.
     - The player must complete the required turnover (e.g., by betting normally and finishing the added turnover) before initiating any withdrawal.
   
5. **Advise the player to continue normal betting to complete the turnover.**
   - Instruct the player to play fish or slot games, or continue betting in accordance with the platform's policies, until the necessary turnover is met.

6. **Monitor the account to ensure the turnover requirement is fulfilled.**
   - Confirm that the player has completed the minimum betting turnover before allowing withdrawal requests.

7. **If the player attempts to withdraw before completing the turnover:**
   - Inform them that withdrawals are only permitted after completing the required wagering.
   - Remind the player that profits from abnormal betting will be deducted if detected after withdrawal.

8. **Explain the consequence of abnormal betting detection:**
   - Clearly state that all profits gained from abnormal or irregular betting will be deducted according to the platform's policies.
   - Emphasize that irregular betting activities violate platform terms, and detection will lead to profit deduction as part of maintaining fair gaming.

9. **If the player disputes the detection or has questions:**
   - Verify whether there is a need for additional evidence or clarification based on the account activity.
   - Escalate the case to the relevant department if suspicious activity persists or cannot be resolved through standard explanation.

10. **Close the case after the player has fulfilled the turnover requirement or as per the resolution outcome.**
    - Document all actions taken, including the communication with the player and the verification process.
    - Ensure the player's account is flagged for abnormal betting activity if applicable, in accordance with platform policies.

## Notes
- All game outcomes are determined by a computer-generated RNG, and profits are automatically recorded.
- The detection of abnormal betting is based on the platform’s automated system, which may flag patterns consistent with unauthorized arbitrage or other irregular behaviors.
- Players are encouraged to follow normal betting practices; irregular activities are subject to profit deduction.
- No additional business rules or numeric thresholds are specified beyond what is provided in the FAQs. Follow site configuration and official detection criteria.

## Key points for communicating with players
- Clearly inform players that abnormal betting activities will lead to profit deductions.
- Emphasize the necessity of completing the required turnover before withdrawal.
- Remind players that all game results are RNG-based, and outcomes cannot be influenced.
- Approach queries about detection with transparency, explaining that the system is designed to maintain fair gaming practices.