# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and Document Player Inquiry or Report**
   - Collect relevant information from the player, including account details and specific concerns about betting activity.
   - Record the nature of the issue and any relevant timestamps or screenshots if provided.

2. **Check for System-Flagged Irregular or Abnormal Betting Activity**
   - Log into the back office system and review the player's recent betting history.
   - Determine if the system has flagged any irregular or abnormal betting activity on the account.
   - Confirm if the activity matches the criteria for irregular betting or abnormal betting as defined internally.

3. **Assess the Detected Activity**
   - Verify if the activity corresponds to any of the following conditions:
     - Irregular betting activity that may lead to profits being deducted.
     - Abnormal betting activity that could trigger winnings deduction as part of anti-fraud safeguards.
   - Determine if the flagged activity is consistent with the platform’s policy on detecting irregular or abnormal betting.

4. **Explain the Findings and Possible Outcomes to the Player**
   - Inform the player that if irregular or abnormal betting activity is detected, the system may deduct profits gained from such activity.
   - Clarify that all winnings and losses are automatically recorded, and that the platform reserves the right to take appropriate action if irregular activity is identified.
   - Emphasize that winnings from such activity may be deducted as part of anti-fraud measures.

5. **Decide on Appropriate Action Based on Detection**
   - If irregular or abnormal activity is confirmed:
     - Notify the player that profits from those activities may be deducted.
     - Advise the player that further review or investigation may be necessary.
     - If applicable, escalate the case to a supervisor or specialized fraud management team for further action.
   - If no irregular activity is confirmed:
     - Reassure the player that their betting behavior appears normal and that no action is needed.

6. **Document the Case and Action Taken**
   - Record all findings, communications, and system alerts related to the case.
   - Update the player’s support ticket with details of the review and any conclusions or next steps.

7. **Follow Up with the Player**
   - If the player has questions or disputes the detection, provide clear explanations based on the system findings.
   - Offer guidance on how to maintain compliant betting behavior to avoid future issues.

8. **Close or Escalate the Support Ticket**
   - Close the case once resolution is communicated and any necessary actions are completed.
   - Escalate if required, following internal protocols, for cases involving potential fraud or account suspension.

## Notes
- Always verify if the system has flagged activity before issuing any warnings or deductions.
- Be aware that winnings are automatically credited if no irregular activity is detected.
- In case of suspected irregular activity, profits gained may be deducted as per platform policies.
- Ensure that communication with the player is clear about why actions are being taken.

## Key points for communicating with players
- Inform players that the system automatically records all game results and wagering behavior.
- Clarify that profits from abnormal betting activity may be deducted according to the platform’s anti-fraud safeguards.
- Reassure players that standard winnings are credited automatically if no irregular activity is found.
- Emphasize that further investigation may be required if irregular activity is detected.