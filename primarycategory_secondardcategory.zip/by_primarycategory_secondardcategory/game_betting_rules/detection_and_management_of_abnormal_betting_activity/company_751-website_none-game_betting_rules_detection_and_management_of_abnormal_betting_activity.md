# Game & Betting Rules - Detection and Management of Abnormal Betting Activity

## Steps

1. **Receive and review the player's inquiry or report**  
   - Determine if the concern relates to abnormal betting activity or profit deductions due to irregular gambling behavior.

2. **Collect relevant information from the player**  
   - Confirm details about their betting activity, including the specific bets involved and amounts wagered.  
   - Ask if they are aware of any abnormal betting detection or profit deductions.

3. **Check for system detection of abnormal betting**  
   - Access the back office or system logs to verify if abnormal betting activity was detected for the player’s account.  
   - Confirm if any profits have been deducted automatically as a result of the system’s detection.

4. **Review the nature of betting activity**  
   - Determine whether the activity is flagged as abnormal by the system.  
   - Understand that abnormal betting is identified automatically and that profits gained from such activity will be deducted as part of security measures to ensure fair gaming.

5. **Verify if profit deduction has occurred**  
   - Check the player's current balance and transaction history to see if profits gained from abnormal betting have been deducted.  
   - Confirm that deductions are part of an automated process triggered by the system detection.

6. **Explain the system’s automated detection and deduction process to the player**  
   - Inform the player that abnormal betting activity is detected by the system and that any abnormal profits are automatically deducted to maintain fair gameplay.  
   - Clarify that this process is part of our security measures to protect both the player and the platform.

7. **Address questions related to betting limits or game outcomes**  
   - If the inquiry involves maximum betting amounts or game outcomes, clarify that:  
     - Bet limits vary depending on the selection (e.g., a maximum of ₱779.80 for some selections).  
     - Games are RNG-generated, with outcomes determined randomly and automatically recorded; they cannot be manually programmed or guaranteed.

8. **Advise the player on withdrawal restrictions if abnormal betting is detected**  
   - Inform them that if abnormal betting is detected, they must bet normally and complete the required turnover before initiating a withdrawal.  
   - State that withdrawals may be restricted until the turnover requirements are met.

9. **Confirm the player’s understanding and accuracy of their betting activity**  
   - If the player claims their betting activity was legitimate, request supporting evidence or details.  
   - If the activity appears consistent with system detection, proceed with the deduction process and inform the player accordingly.

10. **Escalate the case if necessary**  
   - If there are disputes or unclear information that cannot be resolved by the agent, escalate to the appropriate team or supervisor for further review.

## Notes
- The detection of abnormal betting and deduction of profits is automated and standard across the platform.
- The system’s detection criteria are not always transparent; the process relies on automatic system alerts.
- Always communicate to players that game outcomes are RNG-driven and can't be manually controlled or guaranteed.
- Ensure players are aware that they must meet turnover requirements before withdrawal if abnormal betting is detected.

## Key points for communicating with players
- Emphasize that abnormal betting detection and profit deductions are automatic security measures.
- Clearly explain that game outcomes are randomly generated and cannot be manually manipulated.
- Inform players of the requirement to bet normally and meet turnover requirements before withdrawal if irregular activity is flagged.