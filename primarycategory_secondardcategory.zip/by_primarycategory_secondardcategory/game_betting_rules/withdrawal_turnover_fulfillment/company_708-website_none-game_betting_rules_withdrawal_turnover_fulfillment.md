# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's withdrawal request and review their account status.**
   - Confirm that the player has initiated a withdrawal and that their account is in good standing.
   - Check for any alerts or flags related to irregular betting activity in the system.

2. **Inquire about the player's current wagering activity.**
   - Ask the player if they have fulfilled the turnover requirement associated with their current promotion or bonus.
   - Clarify whether the player is aware of the specific turnover amount they need to meet (if applicable).

3. **Check the system for the player's current turnover status.**
   - Access the player's account or back office system to verify if the turnover requirement has been met.
   - Confirm that all wagers were placed on eligible games (e.g., slots or fish games) as specified by the promotion rules.

4. **Assess for irregular or suspicious betting activity.**
   - Review recent betting patterns for signs of abnormal or irregular activity.
   - If irregular betting is detected, inform the player that profits from such activities may be deducted, as per site policy.

5. **Determine if the turnover requirement has been fulfilled.**
   - If the total wagered amount on eligible games meets or exceeds the required turnover, proceed to the next step.
   - If not, advise the player to continue playing on eligible games to meet the requirement before requesting withdrawal.

6. **Confirm the completion of turnover fulfillment.**
   - Once the system confirms that the player has met the turnover requirement, inform the player that they are eligible to proceed with withdrawal.
   - If the system flags any irregular or abnormal activity, instruct the player to normalise their betting pattern and complete the turnover before attempting withdrawal again.

7. **Proceed with the withdrawal process.**
   - Ensure all conditions are met: turnover requirement is fulfilled, no suspicious activity flags are active, and the account is eligible.
   - Approve the withdrawal request and process it according to standard procedures.

8. **If the player has not met the turnover requirement.**
   - Explain that they need to continue playing on designated games (slots, fish, etc.) until the required turnover is met.
   - Remind the player that no withdrawal can be processed until the turnover requirement is fulfilled.

## Notes
- Turnover requirements must be met before withdrawals are processed.
- Profits from irregular or suspicious betting activity may be deducted.
- Repeated deposits or bets from the same IP address, bank card, or phone number can trigger review or further investigation.
- Always verify the specific turnover amount based on the current promotion or bonus, and check that wagers are placed on eligible games.

## Key points for communicating with players
- Clearly explain that they must meet the turnover requirement before withdrawal.
- Advise players to play on designated games to fulfill the turnover.
- Inform players about potential deductions if irregular betting activity is detected.
- Encourage normal betting patterns to avoid flags and potential confiscation of rewards or profits.