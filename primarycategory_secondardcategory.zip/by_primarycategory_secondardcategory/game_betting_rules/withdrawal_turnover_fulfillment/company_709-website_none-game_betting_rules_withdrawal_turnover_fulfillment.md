# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's request and gather necessary information**
   - Confirm that the player is requesting a withdrawal.
   - Ask the player if they have completed the required turnover, specifically playing Slot or Fish games.
   - If applicable, check if the player has claimed any bonuses or made deposits that are subject to turnover requirements.

2. **Check the player's account for fulfillment of the turnover requirement**
   - Access the system back office or participant account dashboard.
   - Review the player's gameplay history related to Slot or Fish games.
   - Confirm whether the total amount wagered in these eligible games meets the required turnover, calculated as (cash in + bonus) multiplied by the promotion's specific multiplier.
   - Verify that all bets resulted in either a win or loss, ensuring they are valid bets counting toward turnover.

3. **Identify reasons for incomplete turnover or withdrawal restriction**
   - If the system indicates that the turnover requirement is not yet fulfilled, inform the player that they must continue playing Slot or Fish games.
   - Check for signs of abnormal betting activity or irregular behavior, as these may prevent withdrawal.
   - Confirm that only bets on Slot or Fish games have been placed to fulfill the requirement; bets on other game types do not count.

4. **Instruct the player on steps to fulfill the turnover requirement if incomplete**
   - Advise the player to continue playing eligible games (slots or fish games) until the total wagered amount reaches the required turnover.
   - Clarify that bets must result in wins or losses, not draws or other outcomes.

5. **Once the system confirms the turnover requirement has been met**
   - Notify the player that they have fulfilled the turnover condition.
   - Confirm that all conditions for withdrawal, including turnover fulfillment, are satisfied.

6. **Proceed with the withdrawal process**
   - Confirm the player's withdrawal request.
   - Verify that there are no other restrictions or issues (e.g., bonus deductions or abnormal activity).
   - Approve the withdrawal and process it according to the standard procedures.

7. **If the player still cannot withdraw after meeting the requirements**
   - Double-check that the player has indeed completed the turnover with valid bets on Slot or Fish games.
   - If doubts persist, escalate the case with detailed account activity logs for further review.
   - Inform the player that the system is reviewing their account for compliance and that the withdrawal will be processed once cleared.

## Notes

- Turnover must be completed on Slot or Fish games only; bets on other game types are not counted.
- All bets should result in either a win or a loss; bets resulting in other outcomes do not count toward turnover.
- Abnormal betting patterns, repeated account registration for bonus claims, or irregular activities may lead to deductions or delays.
- Fulfillment of the turnover requirement is a prerequisite before initiating withdrawal, and players should continue playing until the condition is met.

## Key points for communicating with players

- Clearly explain that they need to play Slot or Fish games to meet the turnover requirement.
- Remind players that bets must be either wins or losses; other outcomes do not count.
- Inform players that the system monitors for abnormal activity, which may affect withdrawal eligibility.
- Keep the communication transparent, emphasizing that the process is to ensure fair play and compliance.