# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather player information and assess withdrawal request**
   - Confirm the player's identity and verify the account details.
   - Ask the player if they have completed the required turnover for withdrawal.
   - Determine the amount the player wishes to withdraw and whether it matches their deposited funds or total balance.

2. **Check system flags for irregular betting activity**
   - Access the back office or system logs to check for any alerts or flags related to abnormal or illegal betting activity.
   - If irregular activity is detected, inform the player that profits may be deducted and additional steps may be required.

3. **Verify the turnover completion**
   - Confirm with the system whether the player has fulfilled the required turnover.
   - Ensure that the player has continued to play permitted games (such as slots or fishing games) to meet the turnover requirement.
   - If the turnover is incomplete:
     - Explain to the player that they need to continue playing eligible games (e.g., slots or fishing) until the required wagering amount is fulfilled.
     - Advise the player on their current progress and the remaining turnover needed, if system data is available.
   
4. **Address irregular betting or illegal activity (if any)**
   - If the system detects irregular activity, clarify to the player that profits may be deducted.
   - Advise the player to adjust their betting activity to comply with site rules and to play allowed games to complete the turnover.

5. **Confirm turnover fulfillment before processing withdrawal**
   - Once the system confirms that turnover requirements are met:
     - Instruct the player they may now submit a withdrawal request.
     - Proceed with processing the withdrawal in accordance with standard procedures.
   - If turnover is not yet completed:
     - Inform the player of the remaining steps and encourage them to continue playing permissible games.
     - Do not process the withdrawal until the turnover requirement is fulfilled.

6. **Finalize the withdrawal process**
   - After confirming that all conditions are met and no flags are active:
     - Approve and execute the withdrawal request.
   - If any issues arise during processing, escalate according to internal protocol.

## Notes

- Withdrawals are only permissible once the respective turnover requirements are fulfilled.
- Profits may be deducted if irregular betting activity or illegal betting is detected.
- Continue playing permitted games (e.g., slots or fishing) to meet the turnover.
- Monitor for flags indicating abnormal or illegal betting activity and handle accordingly.

## Key points for communicating with players

- Clearly explain that withdrawal is subject to completing the required turnover.
- Inform the player that they need to continue playing eligible games to fulfill this requirement.
- Advise the player that profits may be deducted if irregular activities are identified.
- Keep the player updated on their progress toward meeting the turnover requirement.