# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's withdrawal request and gather necessary information:**
   - Confirm the amount the player wishes to withdraw.
   - Check if the request includes funds associated with bonuses or promotional offers.
   - Ask the player if they are aware of the current turnover requirement (if known or applicable).

2. **Check the player's account for turnover progress:**
   - Access the player's account in the back office system.
   - Review the current turnover (wagering) progress towards the required threshold for withdrawal.
   - Determine whether the turnover requirement has been fully satisfied.

3. **Assess if the turnover requirement has been completed:**
   - If **YES**:
     - Proceed with the withdrawal process.
     - Inform the player that the withdrawal is eligible because the turnover requirement has been fulfilled.
   - If **NO**:
     - Explain to the player that they need to meet the specific turnover requirement by playing eligible games (e.g., slots or fish games).
     - Advise the player to continue wagering until the progress bar or indicator shows full completion of the requirement.

4. **Instruct the player on how to meet the turnover requirement (if not completed):**
   - Play eligible games such as slots or fish games in accordance with the current promotion rules.
   - Wager the required amount multiple times based on the specific turnover requirement.
   - Check the account periodically or instruct the player to refresh and review their account to monitor progress.

5. **Reassess after continued gameplay:**
   - Once the player reports or the system reflects that the turnover has been completed:
     - Verify again in the account system that the turnover threshold is now met.
     - Confirm that the progress indicator shows full completion.

6. **Proceed with withdrawal if the requirement is satisfied:**
   - Process the player's withdrawal request in the system.
   - Notify the player that the withdrawal is now processed because the turnover requirement has been completed.

7. **Handle cases where the turnover requirement is not met or there are issues:**
   - If the required progress is not achieved after reasonable gameplay or recent activity:
     - Clarify that the withdrawal cannot be processed until the turnover condition is fully satisfied.
     - Offer guidance on how to meet the requirement or suggest playing more eligible games.
   - Escalate any system discrepancies or unresolved issues according to the escalation policy.

## Notes

- Players must meet the exact turnover requirement before withdrawals can be processed; unfulfilled requirements will prevent withdrawal approval.
- Turnover is calculated based on the amount deposited or bonus amount multiplied by the promotion-specific turnover factor.
- Only eligible games such as slots or fish are counted towards fulfilling the turnover.
- Players can check their current progress on the account dashboard or profile page.

## Key points for communicating with players

- Clearly explain that the turnover is the wagering requirement that must be completed before withdrawal.
- Inform players that they need to play eligible games until the progress bar or indicator shows full completion.
- Remind players that withdrawal is only possible after meeting the specific turnover amount.
- Emphasize to the player to monitor their account for their current turnover progress before attempting to withdraw.