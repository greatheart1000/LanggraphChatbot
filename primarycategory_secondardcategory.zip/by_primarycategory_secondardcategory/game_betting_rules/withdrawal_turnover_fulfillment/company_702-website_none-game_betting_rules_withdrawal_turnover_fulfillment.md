# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's withdrawal request and account status**
   - Confirm that the player has submitted a withdrawal request.
   - Check whether the player has any ongoing turnover requirements related to their deposit, bonus, or promotion.
   
2. **Collect necessary information from the player**
   - Ask if the player has completed the required turnover for their deposit or bonus.
   - Confirm if they are aware that they need to fulfill the turnover requirement before their withdrawal can be processed.

3. **Check the player's current turnover progress in the system**
   - Access the player's account information and review the turnover status.
   - Determine if the turnover requirement (e.g., wagering requirement) has been fully met.

4. **Assess if the player has fulfilled the turnover requirement**
   - If the turnover is fully met:
     - Proceed to process the withdrawal request.
   - If the turnover is not met:
     - Inform the player that they need to continue playing qualifying games to fulfill the requirement.
     - Specify that only FISH or SLOT JILI GAMES count toward the turnover requirement.
     - Advise the player to continue playing slots or fishing games until the required volume is wagered.

5. **Guide the player on how to fulfill the turnover requirement**
   - Explain that they should continue playing eligible games (slots or fish) to reach the needed wagering volume.
   - Remind them that they cannot process a withdrawal until the turnover requirement is met.

6. **Confirm the completion of turnover fulfillment**
   - Once the player reports or the system shows the requirement has been satisfied:
     - Verify that the turnover requirement has been recorded as completed.
     - Proceed with processing the withdrawal request.

7. **Process the withdrawal**
   - Approve and initiate the withdrawal once turnover is fulfilled.
   - Inform the player of the successful withdrawal process initiation.

8. **Handle cases where turnover cannot be completed**
   - If the player is unable or chooses not to fulfill the turnover:
     - Clearly inform them that withdrawal cannot proceed until the requirement is met.
     - Advise on further gameplay or review their account status if applicable.

## Notes
- The turnover requirements apply to all deposits, bonuses, or promotions as stipulated.
- Only specific game types (FISH or SLOT JILI GAMES) count toward fulfilling the turnover requirement.
- The process must be followed precisely as per site rules; no extra steps for non-specified conditions.
- Screenshots or verification may be required if there are disputes or system discrepancies.

## Key points for communicating with players
- Clearly explain that ongoing gameplay in specified games is necessary to fulfill the requirement.
- Reinforce that no withdrawals can be processed until the turnover is fully met.
- Always confirm the current turnover status before proceeding with the withdrawal.