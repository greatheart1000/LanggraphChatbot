# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Identify the player's withdrawal request and confirm the withdrawal reason**  
   - Check if the player is attempting to withdraw funds from a bonus, promotion, or regular balance.  
   - Confirm if the withdrawal involves any bonuses or promotional winnings that are subject to turnover requirements.

2. **Request and review the player's account details related to turnover**  
   - Ask the player if they have any active bonuses or promotions that might require wagering (e.g., first deposit bonus, VIP weekly salary).  
   - Verify the amount of bonus funds or promotional winnings involved.  

3. **Check the player's current wagering status in the system**  
   - Access the back office or relevant system interface to determine if there are any ongoing wagering or turnover requirements.  
   - Confirm the specific turnover or wagering amount needed for the promotion or bonus involved, based on site configuration.  

4. **Assess if the player has completed the necessary turnover**  
   - Review the player's game history to assess if the total wagering (playing eligible games like Fish or Slot JILI) has met the required multiple (e.g., the player has played enough to fulfill the set turnover requirement).  
   - Ensure the customer's wagering amount corresponds with the minimum amount or multiple specified by the current promotion rules.  

5. **If the player has not met the turnover requirement**  
   - Inform the player that the withdrawal cannot be processed until the turnover requirement is fulfilled.  
   - Advise the player to continue playing eligible games to reach the required wagering amount.  

6. **If the player has met the turnover requirement**  
   - Confirm from the system that the wagering requirement is fully satisfied.  
   - Proceed to process the withdrawal through the standard withdrawal procedure.  

7. **Additional considerations and restrictions**  
   - For bonuses like the first deposit bonus, ensure the minimum deposit (e.g., 100 PHP) has been made if applicable, and the bonus cap (e.g., up to 10,999 PHP) has been observed before withdrawal.  
   - Be aware of any restrictions such as limits if promotional abuse is suspected, or if specific promotions have unique conditions.  

8. **Complete the withdrawal**  
   - Once confirmed that turnover is fulfilled, process the withdrawal request according to standard procedures.  
   - Notify the player of successful processing or any additional verification if needed.  

## Notes

- Turnover is a wagering requirement attached to bonuses and promotional funds, which must be completed before withdrawal.  
- The exact amount of wagering needed depends on the specific promotion or bonus, and players are advised to play eligible games to fulfill this.  
- Failure to meet the turnover requirement results in blocked withdrawal from promotional funds or winnings until requirements are fulfilled.  

## Key points for communicating with players

- Clearly explain that they must play eligible games until they meet the specified turnover requirement before they can withdraw.  
- Confirm the exact amount or ratio of wagering needed, based on the current promotion or bonus terms.  
- Remind the player that once the turnover requirement is met, they can proceed with their withdrawal request.