# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather player information regarding withdrawal request**
   - Confirm the player's identity and account status.
   - Ask the player if they have met the turnover requirement before requesting withdrawal.
   - Inquire about any irregular or abnormal betting activities recently detected on the account.

2. **Check the player's current account status in the back office/system**
   - Verify if a withdrawal request has been submitted.
   - Confirm whether the account has met the required turnover, specifically the 15x turnover if applicable.
   - Review the transaction history for any flagged irregular or abnormal betting activities.
   - Determine if any profits from irregular activities are subject to deduction or if restrictions are in place.

3. **Evaluate if the turnover requirement is satisfied**
   - Ensure the player has played the eligible games (e.g., slots, fish) sufficient to meet the 15x turnover requirement.
   - Confirm that all bonus-related turnover conditions, if applicable, are fulfilled.
   - Check if the account's recent betting activity has been flagged for irregularity or abnormality.

4. **If the player has met the turnover requirement and no irregularities are flagged**
   - Inform the player that they are eligible for withdrawal.
   - Proceed to approve the withdrawal request.
   - Process the withdrawal via the system.
   - Notify the player that the withdrawal has been approved and is being processed.

5. **If the turnover requirement is not met**
   - Clearly explain to the player that a 15x turnover must be completed before withdrawal can be approved.
   - Advise the player to continue playing eligible games (such as slots or fish) to fulfill the remaining turnover.
   - Confirm whether the player is willing to continue playing to complete the requirement.
   - Do not process the withdrawal until the turnover condition is satisfied.

6. **If irregular or abnormal betting activity is detected**
   - Inform the player that their account activity has been flagged for irregularity.
   - Explain that profits from such activities may be deducted.
   - Clarify that the withdrawal may be restricted until the issue is resolved or additional verification is completed.
   - Hold the withdrawal request and escalate to the relevant verification team if necessary.

7. **Follow up on any flagged activities or incomplete turnover**
   - Remind the player to meet all specified turnover requirements, including those related to bonuses.
   - If the player continues playing, monitor the account until the turnover is fulfilled.
   - Once the turnover is completed, revisit the account to verify no new irregular activities have been flagged.
   - Proceed with the withdrawal approval process once all criteria are met.

8. **Close the case**
   - Provide the player with the final status of their withdrawal request.
   - Confirm if the withdrawal has been processed or if any additional action is required.
   - Offer guidance for further questions or account issues if necessary.

## Notes
- The 15x turnover requirement applies before any withdrawal can be requested.
- Turnover is typically completed by playing eligible games such as slots or fish.
- Profits from irregular betting activity can be deducted, and withdrawals may be restricted until verification.
- During system maintenance, balances may be temporarily frozen; account activity should be reviewed accordingly.

## Key points for communicating with players
- Clearly explain the need to meet the specific turnover requirement before withdrawal.
- Advise on how to fulfill the turnover by playing eligible games.
- Inform about possible deductions or restrictions if irregular activities are detected.
- Always verify account status and flagged activities in the back office before proceeding.