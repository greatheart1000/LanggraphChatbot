# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify Player's Inquiry and Gather Information**
   - Confirm the player's account details.
   - Ask the player if they are aware of the turnover requirement for withdrawal.
   - Check if the player has attempted withdrawal and if they received any specific message about turnover obligations.

2. **Check the Player’s Current Turnover Status**
   - Access the player's account system to review the current turnover status.
   - Determine if the turnover requirement has been met:
     - If the turnover is not yet fulfilled, proceed to the next step.
     - If the turnover is already fulfilled, explain that withdrawal is possible and guide them on the process.

3. **Review the Player’s Betting History**
   - Confirm if the player has placed bets on the allowed game types to fulfill turnover:
     - Specifically, bets on Fish games or Slot/Jili games (as per FAQ guidance).
   - Verify the total betting amount on these game types.  
   - Ensure that the bets are placed on the eligible games, as only these count towards turnover fulfillment.

4. **Explain Turnover Calculation and Requirements**
   - Inform the player that turnover is calculated as: (Cash In + Bonus) multiplied by the turnover requirement.
   - Clarify that only bets on Fish or Slot/Jili games contribute to decreasing turnover.
   - Remind the player that completing the required turnover is necessary before they can withdraw funds.

5. **Check for Minimum Deposit or Other Conditions**
   - Confirm if any minimum deposit conditions or other requirements are specified and met.
   - Ensure that the player has met all prerequisites for withdrawal aside from fulfilling the turnover.

6. **Instruct the Player on How to Fulfill Turnover (if not yet met)**
   - Advise the player to continue playing on Fish or Slot/Jili games.
   - Clearly state that they need to place bets on these game types until the turnover requirement is fully completed.

7. **If Turnover is Fulfilled, Proceed with Withdrawal Process**
   - Confirm with the player that the turnover is now complete.
   - Explain that they can now initiate a withdrawal request.
   - Assist with the withdrawal process if necessary.

8. **If Turnover is Not Increasing as Expected**
   - Verify if the player is only betting on permitted game types.
   - Advise them to focus their bets exclusively on Fish or Slot/Jili games.
   - Escalate the case if technical issues are suspected or if the system does not reflect the bets correctly.

## Notes

- Only bets on Fish and Slot/Jili games count towards turnover fulfillment.
- Turnover is based on total cash in plus bonus, multiplied by the required turnover multiple.
- Ensure players understand that completing the turnover is mandatory before withdrawal.
- Review system updates or promotional rules that may affect turnover calculations or requirements.

## Key points for communicating with players

- Clearly explain that only bets on Fish or Slot/Jili games count toward turnover.
- Emphasize that the total turnover is (Cash In + Bonus) times the required multiple.
- Remind the player to continue betting on the allowed game types to fulfill the requirement.
- Confirm that all other conditions, such as minimum deposits, are met before processing withdrawal.