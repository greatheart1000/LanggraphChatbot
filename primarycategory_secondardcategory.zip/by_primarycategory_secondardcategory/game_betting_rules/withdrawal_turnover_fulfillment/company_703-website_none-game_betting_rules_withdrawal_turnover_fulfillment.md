# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's account and withdrawal request**
   - Confirm the identity of the player and the amount they wish to withdraw.
   - Check if the withdrawal has been initiated and is pending due to turnover requirements.

2. **Check the player's current wagering (turnover) status**
   - Access the back-office system to review the wagering (turnover) progress for the player's account.
   - Determine whether the required turnover amount has been fully completed.
   - Confirm the specific turnover requirement, which involves playing on FISH or SLOT JILI GAMES, until the specified amount has been wagered.

3. **Inform the player if the turnover requirement is incomplete**
   - Advise the player that they must continue playing eligible games (FISH or SLOT JILI GAMES) to fulfill the turnover requirement.
   - Emphasize that they need to wager until the system registers that the turnover target is met.
   - Explain that only after completing the turnover will their withdrawal request be processed.

4. **Guide the player on completing turnover if necessary**
   - Instruct the player to continue playing on eligible games—specifically, Fish or Slot JILI Games—until the system shows the turnover requirement as fulfilled.
   - Clarify that irregular betting activity may trigger system detection of abnormal betting, which can delay or block withdrawals. They should bet normally and meet the requirements.

5. **Recheck the player's wagering progress after further play**
   - Once the player indicates they've played sufficiently, verify the updated turnover status in the system.
   - Confirm that the total wagered amount on eligible games has met or exceeded the required turnover threshold.

6. **Process the withdrawal after turnover completion**
   - If the turnover requirement is fulfilled:
     - Approve the withdrawal request.
     - Proceed with the standard withdrawal process.
   - If the turnover requirement is not yet met:
     - Inform the player of the remaining wagering amount needed.
     - Advise continued play on eligible games until the requirement is satisfied.

7. **Address any irregular betting or system alerts**
   - If system detects abnormal betting activity, advise the player to bet normally and complete the turnover before withdrawal.
   - Any profits gained during suspicious betting may be deducted, according to site rules.

8. **Finalize and document the process**
   - Record the verification steps, player communication, and system checks.
   - Close the case once the turnover is verified as complete and the withdrawal is processed.

## Notes
- Turnover must be completed by playing FISH or SLOT JILI GAMES.
- Once turnover is fulfilled, players can withdraw at any time.
- Abnormal betting detected by the system may cause delay or blocking of withdrawals; players should bet normally to complete the requirement.
- The requirement is strictly based on wagering the specified amount; other activities do not count toward fulfillment.

## Key points for communicating with players
- Clearly explain the need to play specific games (Fish or Slot JILI) to meet the wagering requirement.
- Emphasize that only after completing the required turnover can withdrawal requests be processed.
- Advise players to bet normally if irregular activity is suspected.
- Keep them updated on their progress and what steps to take next.