# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's request and initial account status**
   - Confirm the player's identity and gather details about their withdrawal request.
   - Check if the player has made any deposits or claims of bonuses/promotions.
   - Note the total deposit amount, bonus claims, and current account balance.

2. **Inform the player about the turnover requirement**
   - Explain that to proceed with the withdrawal, they must fulfill the turnover requirement.
   - Clarify that this involves playing certain eligible games (e.g., slots and fish games) until the required wagering amount is met.

3. **Determine if the player has already fulfilled the turnover requirement**
   - Access the system to check the player's current wagering status related to the specific deposit or bonus.
   - If the system indicates the turnover requirement is already met, proceed to step 5.
   - If not, proceed to step 4.

4. **Assist the player in fulfilling the turnover requirement**
   - Advise the player to continue playing eligible games, such as slots or fish games, to meet the remaining turnover.
   - Monitor the player's gameplay activities and ensure they are wagering on eligible game types.
   - Confirm that the total wagering matches the required turnover amount before proceeding.

5. **Verify the completion of the turnover requirement**
   - Check the back office or system to confirm that the player has completed the required turnover (e.g., 10x turnover).
   - Confirm that the player has not engaged in abnormal betting activity; if detected, advise placing normal bets and completing turnover again.

6. **Check for any restrictions or limitations**
   - If the player has not made any deposits, ensure the maximum withdrawal limit is 100 PHP.
   - Ensure no system blocks or restrictions are preventing the withdrawal, such as abnormal betting detection or other compliance issues.

7. **Authorize the withdrawal or provide next steps**
   - If all conditions are met (turnover fulfilled, limits observed, no restrictions), approve the withdrawal request.
   - If the turnover has not been met, inform the player of the remaining wagering needed and advise continuing gameplay.
   - If the player's activity is flagged for abnormal betting, instruct them to place normal bets and complete the turnover before proceeding.

## Notes
- Players must complete the turnover requirement by playing eligible games (slots and fish) until the corresponding wagering amount is achieved.
- For users who have not deposited, the maximum withdrawal amount is capped at 100 PHP.
- If abnormal betting activity is detected, the withdrawal will be blocked until normal betting resumes and the turnover is fulfilled.

## Key points for communicating with players
- Clearly explain that withdrawals depend on fulfilling the specific turnover requirement.
- Emphasize the importance of playing eligible games until the requirement is met.
- If the player has not deposited, remind them of the maximum withdrawal limit of 100 PHP.
- Advise patience and adherence to normal betting behavior if system flags are raised.