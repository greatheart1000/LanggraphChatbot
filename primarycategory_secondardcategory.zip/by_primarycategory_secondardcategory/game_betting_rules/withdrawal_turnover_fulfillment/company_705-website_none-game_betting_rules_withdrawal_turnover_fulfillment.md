# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather player information and understand the context**
   - Confirm the player's inquiry relates to withdrawal and turnover requirements.
   - If applicable, verify the specific bonus or promotion involved that requires turnover fulfillment.
   - Determine if the player has met the necessary requirements or if there are any abnormal betting activities.

2. **Check the player's current status and system data**
   - Access the player's account in the back office.
   - Review the player's betting history, focusing on gameplay on slots or fish games, which are the eligible games to fulfill the turnover.
   - Verify the amount of turnover already completed against the required turnover for withdrawal, as per the current promotion or bonus terms.
   - Check for any indicators of abnormal bets or suspicious activity, which could lead to system deductions or restrictions.

3. **Assess whether the turnover requirement has been met**
   - Confirm if the total wagering on eligible games (slots and fish games) has fulfilled the turnover requirement.
   - If the turnover is not yet completed:
     - Inform the player that they need to continue playing on eligible games (slots or fish games) until the required turnover is met.
     - Advise the player to bet normally; abnormal betting may be detected and could affect the withdrawal process.
   - If the turnover is fulfilled:
     - Proceed to the next step.

4. **Verify the absence of abnormal betting activity**
   - Check for any abnormal bets or activities that might have been flagged by the system.
   - If abnormal betting is detected:
     - Explain to the player that abnormal bets have been detected, and any abnormal profits may be deducted.
     - Advise the player to continue betting normally and complete additional turnover if needed.
     - Only proceed once the system confirms normal betting behavior and the turnover is properly completed.

5. **Initiate the withdrawal process**
   - Once the player has met the turnover requirement and no abnormal activities are detected:
     - Confirm that all conditions for withdrawal are satisfied.
     - Process the withdrawal request according to standard procedures.
     - Inform the player that they can proceed with their withdrawal now that conditions are met.

6. **Follow-up and resolution**
   - Ensure the withdrawal is successfully completed.
   - If issues persist (e.g., system flags or additional verification needed), escalate according to company protocol.

## Notes
- Turnover must be fulfilled on eligible games such as slots and fish games.
- Abnormal betting may be detected by the system, and profits from such bets may be deducted.
- Players can only withdraw after successfully completing the turnover requirement.

## Key points for communicating with players
- Clearly explain that turnover refers to the wagering requirement they need to meet before withdrawal.
- Emphasize the importance of betting normally on slots or fish games to fulfill the requirement.
- Inform players that abnormal betting can be flagged and may impact their withdrawal eligibility.
- Advise patience and ongoing gameplay until the system confirms the completion of the turnover.