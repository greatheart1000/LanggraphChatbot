# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's identity and account status.**  
   Ensure the player is verified and their account is active to proceed with withdrawal requests.

2. **Request the player to confirm their withdrawal request.**  
   Gather the details of the requested withdrawal amount and verify the player's intended action.

3. **Check if the player's account has any pending withdrawal or bonus activity that may affect turnover requirements.**  
   Review the account for any ongoing bonuses or restrictions that might influence the process.

4. **Determine if the player has met the turnover requirement for withdrawal.**  
   - Access the system to verify the player's current wagering on eligible games (e.g., Fish or Slot games)<br>
   - Confirm that the accumulated wagering (turnover) meets the required multiple (e.g., 5x of bonus/deposit).  
   - If the required turnover is not yet met, inform the player that they must continue playing eligible games to fulfill it.

5. **Guide the player on how to fulfill the turnover requirement.**  
   - Advise that they should continue wagering on eligible games such as Fish or Slot until the turnover requirement is completed.  
   - Clarify that only eligible games contribute to the turnover requirement.

6. **Re-verify the turnover status after the player reports additional wagering or after a reasonable period.**  
   - Check again if the accumulated wagering now meets or exceeds the required turnover.  
   - If not, repeat the guidance until the requirement is fulfilled.

7. **Once the turnover requirement is met, process the withdrawal request.**  
   - Inform the player that they are now eligible to withdraw their winnings.  
   - Initiate the withdrawal in the system; ensure it complies with applicable limits and rules.

8. **Monitor for any system flags or unusual activity during the process.**  
   - Be alert to system alerts regarding betting activity; if flagged, review activity thoroughly before proceeding.

9. **Provide the player with confirmation of the successful withdrawal or next steps if additional verification is required.**  
   - Confirm the completion of the process and advise on expected processing times.

## Notes

- Turnover must be fulfilled by playing eligible games such as Fish or Slot games.  
- Withdrawals cannot be processed until the turnover requirement is explicitly met.  
- Continue wagering on eligible games until the required turnover (e.g., defined by bonus/deposit terms) is achieved.  
- If the system flags unusual betting activity, review the account carefully before authorizing withdrawal.

## Key points for communicating with players

- Clearly explain that a turnover requirement must be met before withdrawal is allowed.  
- Guide players on which games count towards fulfilling this requirement.  
- Remind players to continue playing eligible games (Fish or Slot) to complete the wagering threshold.  
- Confirm when the turnover has been completed and the withdrawal can proceed.