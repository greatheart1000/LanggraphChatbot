# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather player information**
   - Confirm the player's identity and verify account details.
   - Ask the player if they are requesting a withdrawal and inquire about the current status of their wagering requirements.
   - Determine which promotion or bonus (if any) the player used, to identify applicable turnover requirements.

2. **Check the player's account for unmet turnover requirements**
   - Access the player's account in the back office or system.
   - Verify whether the player has completed the required wagering (turnover) based on the applicable promotion or bonus.
   - Confirm which games are eligible for fulfilling turnover (e.g., slots, fish games).

3. **Verify deposit activity**
   - Confirm any recent deposits with proof of payment, such as a screenshot of the transaction confirmation.
   - Ensure deposits are verified and credited properly before proceeding.

4. **Assess betting activity and game play**
   - Review the player's recent game history to determine if they have played eligible games sufficiently to meet the turnover requirement.
   - Check if the total wagering amount matches or exceeds the required turnover (the specific multiple, such as 9x or 20x, depends on the promotion).

5. **Determine if turnover requirement is fulfilled**
   - If the player has completed the designated wagering amount through eligible games:
     - Proceed to process the withdrawal.
     - Inform the player that the turnover requirement has been met, and they can now submit a withdrawal request.
   - If the player has not yet met the requirement:
     - Inform the player of the remaining wagering amount needed.
     - Advise them to continue playing eligible games to fulfill the turnover requirement.
     - Wait until the required conditions are fulfilled before attempting withdrawal.

6. **Handle withdrawal request**
   - Confirm that the account has no irregular betting activity or unresolved issues.
   - Verify that all applicable rules, including turnover requirements, are satisfied.
   - Process the withdrawal request through the system.
   - Communicate to the player that the withdrawal has been approved once the conditions are met.

7. **Post-fulfillment follow-up**
   - Once the turnover requirement is confirmed as fulfilled and the withdrawal is processed, inform the player of the successful transaction.
   - If a withdrawal cannot be processed due to unmet requirements or other issues, explain clearly and politely.

## Notes
- Withdrawals require completion of the designated turnover (playthrough) amount before they can be processed.
- Only eligible games such as slots or fish games contribute to fulfilling the turnover requirement.
- Bonus and winnings are subject to system rules, with automatic calculation and crediting once conditions are met.
- Deposit proofs (screenshots or transaction confirmation) are necessary for verification of deposits.
- Variations in turnover requirements (e.g., 9x or 20x) depend on the current promotion or bonus terms.

## Key points for communicating with players
- Clearly explain the concept of turnover (wagering) and its importance for withdrawal eligibility.
- Inform players of their remaining wagering amount if they have not yet fulfilled it.
- Remind players to only play eligible games for fulfilling turnover.
- Always verify deposit proof and account activity before proceeding with withdrawal requests.
- Be polite and instructive, guiding players on how to fulfill requirements if they haven't yet done so.