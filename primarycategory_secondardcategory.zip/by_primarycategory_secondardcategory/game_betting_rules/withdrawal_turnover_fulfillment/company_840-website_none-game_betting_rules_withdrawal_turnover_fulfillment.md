# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather information from the player**:
   - Confirm the player's account details.
   - Ask if they are requesting a withdrawal related to bonus funds or winnings.
   - Determine if the player has any ongoing bonuses or promotions that may require turnover fulfillment.

2. **Check the player's current wagering situation**:
   - Access the player's account system and review their bonus and winnings status.
   - Verify if the player has any active wagering requirements that are yet to be fulfilled.

3. **Determine the applicable turnover requirement**:
   - Identify the specific turnover (wagering) requirement for the player's promotion or bonus, as per the current promotional terms (e.g., 15x turnover for first-deposit bonus).
   - Recognize that the requirement involves playing eligible games such as slots or fish, according to site rules.

4. **Assess whether the turnover requirement has been met**:
   - Review the player's game history to see if the total wagers on eligible games meet or exceed the required turnover amount.
   - If the requirement is not met:
     - Inform the player of the remaining wagering amount needed.
     - Advise them to continue playing eligible games (slots or fish) until the requirement is fulfilled.

5. **Determine if the turnover requirement has been fulfilled**:
   - If the total wagers on eligible games meet or exceed the required amount:
     - Confirm in the system that the turnover requirement is complete.
   - If not:
     - Clearly communicate the remaining amount needed.
     - Do not proceed with the withdrawal until the requirement is fully met.

6. **Proceed with the withdrawal process**:
   - Once the system shows the turnover requirement is fully completed:
     - Verify that the withdrawal request complies with all other withdrawal rules.
     - Approve the withdrawal request.
   - If the requirement is not fulfilled:
     - Politely inform the player that they must meet all wagering requirements before withdrawal approval.

7. **Handle any discrepancies or edge cases**:
   - If the system indicates the requirement has been met but the player claims otherwise:
     - Double-check the game wagers and system records.
     - Escalate for further review if needed.

## Notes
- Turnover generally includes playing on eligible games such as slots or fish games; other game types typically do not contribute unless explicitly specified.
- The exact turnover amount and conditions depend on the current promotion or bonus terms; always verify these specifics in the current promotion rules.
- Only process withdrawal requests once the recognized wagering requirement has been fulfilled.
- Inform players that failure to meet the requirement may prevent withdrawal of bonus funds or winnings associated with the bonus.

## Key points for communicating with players
- Clearly explain what turnover means and how to fulfill it.
- Remind players that continuing to play eligible games (slots or fish) is necessary to meet the wagering requirement.
- Keep players informed of their remaining wagering amount if they have not yet met the requirement.
- Be transparent that withdrawals can only be processed after complete fulfillment of the wagering conditions.