# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's withdrawal request**  
   - Check if the player has initiated a withdrawal and identify the requested amount.  
   - Confirm whether the player's current account status indicates that any turnover requirement is outstanding.

2. **Request clarification on turnover fulfillment**  
   - Ask the player if they have completed the required turnover for withdrawal.  
   - If they state that they have not yet completed it, proceed with the following checks.

3. **Review the player's activity and system status**  
   - Access the back-end system to verify the player's total turnover against the requirement.  
   - Confirm that the player has played FISH or SLOT JILI GAMES, as only these games count toward the turnover requirement.  
   - Check whether the turnover amount has changed or increased after their recent activity.

4. **Assess whether the player has fulfilled the turnover requirement**  
   - If the turnover requirement is not met:  
     - Inform the player that they cannot proceed with withdrawal until the required turnover is completed.  
   - If the turnover amount is not changing or appears insufficient:  
     - Advise the player to continue playing eligible games (FISH or SLOT JILI GAMES) until the requirement is met.

5. **Guide the player on completing the turnover**  
   - Remind the player that playing FISH or SLOT JILI GAMES is necessary to fulfill the requirement.  
   - Specify that once the turnover is met, they will be eligible to withdraw at any time.

6. **Confirm completion of the turnover**  
   - After the player reports that they have completed sufficient play, verify in the system if the turnover requirement has been met.  
   - If confirmed, explain that they can now proceed with the withdrawal request.

7. **Proceed with withdrawal**  
   - If turnover requirements are fulfilled, process the withdrawal per standard procedure.  
   - If not, reinforce that additional play on eligible games is needed.

## Notes

- Only FISH and SLOT JILI GAMES count toward completing the turnover requirement; playing other games will not advance this requirement.  
- The system detects whether the player is qualified for withdrawal based on the game activity and turnover completion status.  
- Ensure to communicate clearly that players can withdraw at any time once the turnover requirement is met.

## Key points for communicating with players

- Emphasize that completing the turnover by playing designated games is mandatory before withdrawal.  
- Clarify that if the turnover amount is not changing, they need to continue playing FISH or SLOT JILI GAMES.  
- Remind players that once the turnover requirement is fulfilled, they are free to withdraw at any time.