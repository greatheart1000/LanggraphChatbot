# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Verify the player's withdrawal request and account details.**  
   - Collect the player's account number and details of the withdrawal request.  
   - Check if the player has any ongoing restrictions or account issues.

2. **Check the player's turnover status for the current withdrawal.**  
   - Access the player's account to verify if the turnover requirement has been fully met.  
   - Confirm whether the account shows the status of the current wager or turnover progress.

3. **Determine if the turnover requirement has been completed.**  
   - If the turnover requirement **is not yet fulfilled**, inform the player that they cannot proceed with withdrawal until they complete the wagering requirements.  
   - Advise the player to continue playing **eligible games** (specifically, FISH or SLOT JILI GAMES) to fulfill the requirement.

4. **Confirm game activity and compliance.**  
   - Validate that the player's gameplay involved only eligible games (slots or fish games).  
   - Check that the betting activities align with the system's policies and are within allowed limits.

5. **Explain the process and requirements clearly to the player.**  
   - Inform them that:  
     - Turnover is calculated as the sum of (Cash in + Bonus = Amount) multiplied by the required turnover number (as per promotion or game rules).  
     - They must complete this wagering before any withdrawal can be processed.

6. **Advise the player on how to complete the turnover requirement.**  
   - Instruct them to keep playing the eligible games (slots or fish) until the system indicates that the turnover target is reached.  
   - Remind them they can check their turnover progress within their account.

7. **Once the turnover is fulfilled, review withdrawal eligibility.**  
   - Ensure that the player’s betting activity has met the required turnover total.  
   - Confirm that all other account or system checks (such as transaction verification and compliance) are completed.

8. **Proceed with the withdrawal process.**  
   - If the turnover requirement and other checks are satisfied, process the withdrawal request according to the standard system policies.  
   - If the player attempted to withdraw before fulfilling the turnover, inform them to continue playing until they meet the requirement.

9. **Address any edge cases or additional restrictions.**  
   - If the player’s bets are abnormal or activity is flagged, explain that withdrawals may be prevented until the turnover is met.  
   - Clarify any limits related to withdrawal amounts and associated procedures in line with system policies.

10. **Record and finalize the case.**  
    - Document the steps taken, questions answered, and confirmation of the turnover status.  
    - Close the case once the withdrawal process is successfully initiated or if further action or clarification is required.

## Notes

- Turnover requirements vary depending on the promotion or specific game rules; always verify relevant details in the player's current promotion terms.  
- Players cannot withdraw until the total turnover (calculated as per their activity and the required multiple) is completed.  
- Continuous monitoring of betting activities is essential to ensure compliance before withdrawal approval.

## Key points for communicating with players

- Clearly inform players that they must play **eligible games** until their turnover goal is reached.  
- Explain that turnover is based on the total of their cash and bonus amount multiplied by the required wager multiple.  
- Remind them they can check their current progress in their account.  
- Emphasize that withdrawals are only processed after the turnover requirement is fully met and all system checks are passed.