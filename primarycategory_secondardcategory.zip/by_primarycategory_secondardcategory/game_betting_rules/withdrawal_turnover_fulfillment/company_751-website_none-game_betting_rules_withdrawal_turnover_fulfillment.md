# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Identify the player's request regarding withdrawal**:
   - Confirm if the player is attempting to withdraw their winnings.
   - Determine if the player's withdrawal is being blocked or if they are inquiring about withdrawal eligibility.

2. **Verify if the player has completed the necessary turnover requirement**:
   - Check the player's account for the current turnover status.
   - Inform the player that they need to play FISH or SLOT JILI GAMES to fulfill the turnover requirement.
   - Confirm if the player has already completed the turnover:
     - If **not completed**:
       - Advise the player to continue playing SLOT or FISH GAMES.
       - Remind that every deposit and bonus claim has a turnover requirement that must be met before withdrawal.
     - If **completed**:
       - Proceed to the next step.

3. **Check specific conditions for withdrawal**:
   - Confirm that the player has fulfilled the turnover requirement for their current bonus or deposit.
   - Inform that only bets on FISH or SLOT JILI GAMES count towards this requirement.
   - Ascertain if the player has met all bonus-specific turnover conditions (if applicable).

4. **Verify the player's eligibility to withdraw**:
   - Ensure the player's turnover requirement is fulfilled.
   - Confirm that no other withdrawal restrictions are in place (e.g., bonus rules, time limits).

5. **If the player’s turnover requirement is unmet**:
   - Explain that they must continue playing FISH or SLOT JILI GAMES until the requirement is met.
   - Reiterate that after completing the turnover, they can try to withdraw again.

6. **If the turnover requirement is met**:
   - Guide the player to proceed with the withdrawal request.
   - Confirm that the system allows withdrawal at this point.
   - Provide instructions for withdrawal if needed or escalate as per standard procedure.

7. **In case of any issues or discrepancies**:
   - Check for any potential system errors or special restrictions.
   - Escalate to appropriate back-office support if necessary.

## Notes
- Only bets placed on FISH or SLOT JILI GAMES count towards fulfilling the turnover requirement.
- The turnover requirement must be fulfilled **before** any withdrawal can be processed.
- For bonuses, additional specific turnover conditions may apply, and failure to meet them can prevent withdrawal of bonus funds.

## Key points for communicating with players
- Clearly inform players that they need to play either Fish or Slot JILI Games to fulfill their turnover.
- Emphasize that only bets on these game types count towards the requirement.
- Remind players that the turnover requirement must be met before they can withdraw winnings or bonuses.
- Keep the explanation simple, emphasizing ongoing play until the requirement is completed.