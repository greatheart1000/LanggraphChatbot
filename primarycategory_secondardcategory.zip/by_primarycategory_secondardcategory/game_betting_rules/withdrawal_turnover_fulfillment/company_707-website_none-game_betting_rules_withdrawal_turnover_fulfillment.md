# Game & Betting Rules - Withdrawal Turnover Fulfillment

## Steps

1. **Gather player information regarding the withdrawal request.**  
   - Confirm the player's intention to withdraw funds.  
   - Verify if the player has recently initiated a withdrawal.

2. **Check the player's account for turnover requirements.**  
   - Access the player's account or back-office system.  
   - Identify the applicable turnover requirement based on the current promotion or account type.  
   - Confirm if the account has met the required turnover before allowing withdrawal.

3. **Determine the current status of turnover fulfillment.**  
   - Check whether the player has completed the necessary bets or activity on eligible games (e.g., slots, fish).  
   - Confirm if the total betting volume on eligible games has reached the stipulated turnover target.  
   - If the turnover is not met, proceed to inform the player accordingly.

4. **Communicate with the player about the turnover status.**  
   - If the turnover requirement has been fully met, explain that they are eligible to proceed with withdrawal.  
   - If the turnover requirement has not been met, advise that they must continue playing eligible games (slots or fish) until the required wagering is fulfilled.  

5. **If turnover is complete, verify the eligibility and readiness for withdrawal.**  
   - Ensure all other withdrawal conditions (such as deposit verification, account standing, and any security checks) are satisfied.  
   - Confirm if the withdrawal request is valid and can be processed according to platform rules.

6. **Process the withdrawal request.**  
   - Approve the withdrawal in the system once all conditions are met.  
   - Notify the player that their withdrawal has been successfully processed or is approved for processing.

7. **If conditions for withdrawal are not met, do not process the withdrawal.**  
   - Clearly communicate to the player that the turnover requirement is not yet fulfilled.  
   - Provide guidance on how to complete the remaining wagering (continue playing on eligible games until target is met).  
   - Reiterate that withdrawals can only be processed after full turnover fulfillment.

## Notes
- The turnover requirement must be met before any withdrawal can be processed; this includes bets on designated games such as slots or fish.
- Verify that all bets placed have contributed towards the turnover target.
- Make sure to check the current site configuration or official promotion details for specific requirement values, as these may vary.

## Key points for communicating with players
- Clearly explain that "turnover" means the wagering requirement based on deposits and bonuses, and it must be completed before withdrawal.
- Remind players that only bets on eligible games count toward turnover.
- Inform players that they cannot make a withdrawal until the turnover requirement has been fully met.
- Encourage players to continue playing eligible games if the requirement is incomplete.