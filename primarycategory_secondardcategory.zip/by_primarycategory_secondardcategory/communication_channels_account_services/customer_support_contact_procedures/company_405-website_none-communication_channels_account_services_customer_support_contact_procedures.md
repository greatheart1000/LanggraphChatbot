# Communication Channels & Account Services - Customer Support Contact Procedures

## Steps

1. **Identify the player's support inquiry and verify that it pertains to account services or communication channels.**

2. **Inform the player that Lodibet's official support channel is LiveChat.**  
   - Clearly explain that Lodibet does not initiate phone calls to request personal information.  
   - Emphasize that for security reasons, all support and verification should be conducted via LiveChat or official channels.

3. **Advise the player to access LiveChat for support:**  
   - Direct the player to use the LiveChat feature on the Lodibet website or app.  
   - If the link is not functioning, provide instructions to use the official backup domains listed on the website for accessing LiveChat.

4. **Open a support session with LiveChat:**  
   - Engage with the player in real-time through the chat window.  
   - Confirm the player's identity by requesting their username and verifying any known account details if necessary.

5. **Gather necessary information for account services requests (e.g., changing bound contact details):**  
   - Ask for the player's current username.  
   - Request the new phone number or email they wish to bind to their account.

6. **Explain the identity verification process:**  
   - Inform the player they will need to fill out an identity verification form with their username, new contact information, and typically their date of birth and withdrawer name.  
   - Clarify that the change is processed only after verification.

7. **Request required supporting documents:**  
   - Ask the player to submit the necessary documents as instructed, such as two valid IDs, a selfie, and additional supporting account information.  
   - Make sure the player understands the importance of submitting clear, valid documents to avoid delays.

8. **Review submitted documents and information:**  
   - Verify the documents and details in the back office or system.  
   - Ensure that all information is consistent and meets security standards before processing changes.

9. **Process the change request:**  
   - Approve the update of contact details (phone number/email) once verification is successful.  
   - Confirm to the player that their request has been processed and inform them of the updated account details.

10. **Handle security-related inquiries or reports of unsolicited contact:**  
    - Reinforce that Lodibet will not contact players to solicit personal information via phone or messages.  
    - If the player reports receiving unsolicited calls or messages claiming to be from Lodibet, advise them not to share any information and to report the incident via LiveChat.

11. **Close the support session:**  
    - Summarize the actions taken.  
    - Remind the player to always use official channels like LiveChat for security and support.  
    - Provide any additional instructions if necessary.

## Notes

- Always prioritize verifying the player's identity through official forms and documents before making any account changes.  
- Do not accept or process sensitive information over phone calls or unofficial messages; all communications involving account details must happen via LiveChat.  
- Use the official backup domains if the primary links are unavailable, as listed on the Lodibet site.  
- Clearly communicate the security policies to players, emphasizing that Lodibet will never request personal information via unsolicited calls or messages.  

## Key points for communicating with players

- Reinforce that LiveChat is the only official support channel.  
- Never share personal or account information outside of verified LiveChat interactions.  
- Inform players about the importance of submitting valid identity verification documents for account updates.  
- Be diligent in confirming player identity before processing sensitive account changes.