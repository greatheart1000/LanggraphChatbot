# Communication Channels & Account Services - Referral Program and Agent Management

## Steps

1. **Identify the player's request or inquiry**
   - Determine whether the player wants to understand the referral program, become an agent, claim referral rewards, check income, or update linked account details.
   - Ask for the player's full name, username, and specific details about their request.

2. **For players asking about the Referral Program**
   - Explain the key requirements:
     - Deposit at least 200 PHP.
     - Link their withdrawal account.
     - Share their referral link on social media platforms like Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.
   - Inform them that referral rewards are automatically credited when the referred member deposits the minimum required amount.
   - Guide them to visit the Invite Friends or Reward Center section to verify their earnings.
   - Clarify that referral activity must meet all conditions (deposit amount, activity source) to be considered valid.

3. **For players interested in becoming an agent**
   - Instruct them to click the "Agent" link on the homepage.
   - Prompt them to copy their unique Referral Link.
   - Advise sharing the referral link via social media platforms such as Facebook, Messenger, YouTube, Instagram, Tiktok, Twitter, Viber, WhatsApp, etc.
   - Inform them of agent benefits:
     - ₱200 PHP for every valid invite.
     - 1.00% commission on downline deposits.
     - 0.63% commission on downline bets.
     - Up to ₱188,888 PHP per tier.
     - Potential to earn up to ₱1 million weekly through 4-tier commissions.

4. **For players requesting to unbind or update linked personal details (e-wallet or phone number)**
   - Instruct them to submit a formal request with the following information:
     - Full name
     - Username
     - The number or account to delete or update
     - The reason for the change
     - Clear images of their ID or selfie for verification
   - Confirm that the request will be processed once verified.
   - Inform them that changes are typically confirmed within a few minutes to hours depending on system processing.

5. **For players asking about claiming referral rewards or checking referral/commission status**
   - Verify that the player has made the required deposit (at least 200 PHP) if claiming a bonus.
   - Guide them to visit the Invite Friends or Reward Center section.
   - Help them locate their referral earnings or income statements.
   - Clarify that earnings are credited automatically upon meeting the conditions.

6. **Perform necessary checks and operations in the back office/system**
   - Review referral activity to ensure deposit, sharing, and activity conditions are met.
   - Confirm the validity of the referral link sharing.
   - Verify the deposit amount and source for each referral.
   - Confirm whether the user is eligible for a bonus or commission based on the activity and the specified thresholds.

7. **Resolve and communicate with the player based on the findings**
   - If all conditions are met:
     - Confirm the rewards/commissions are credited or will be credited shortly.
   - If conditions are not met:
     - Explain clearly the reason (e.g., deposit below minimum, share link not evident, invalid activity).
     - Advise on what the player needs to do to qualify (e.g., deposit more, share again).

## Notes
- When requesting account updates from players, ensure all required details and identification are provided for quick verification.
- Referral rewards are credited automatically once the referral deposit reaches the minimum threshold.
- Always verify that shared links are on permitted platforms and activities meet the program’s rules.

## Key points for communicating with players
- Remind players that referral rewards are automatically credited.
- Clarify the minimum deposit requirement (200 PHP) for earning bonuses.
- Emphasize sharing their referral link on social media platforms to maximize earning potential.
- Inform players that updates to personal details typically take a few minutes to hours, depending on verification.