# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report related to inappropriate language or conduct during support chat.**

2. **Verify the player's account details and chat history**:
   - Ensure the contact is from an active account.
   - Review chat logs for any use of inappropriate, abusive, or profane language.
   
3. **Determine the nature of the language or conduct violation**:
   - Check if the language used is inappropriate or abusive as per platform policies.
   - Confirm whether the behavior qualifies as harassment or includes profane language.
   
4. **Communicate with the player if applicable**:
   - Remind the player to keep language respectful.
   - Inform the player that inappropriate language is not permitted and may lead to suspension or termination of accounts.
   
5. **If inappropriate language or conduct is detected**:
   - Initiate a warning or take action according to the policy:
     - Inform the player that their behavior violates platform rules.
     - Notify the player that continued violations may result in account suspension or termination.
   
6. **Record the incident in the case log or ticket system**:
   - Attach relevant chat screenshots if required.
   - Document the nature of the violation and actions taken.
   
7. **Apply account action if necessary**:
   - If violations are severe or repeated, escalate for possible account suspension or termination, following the platform's enforcement policies.
   - Support staff will intervene in the conversation if inappropriate language is present.
   
8. **Follow-up steps**:
   - Inform the player about the outcome (warning issued, account action, etc.).
   - Advise the player on maintaining respectful communication in the future.
   - Close the case once resolution is confirmed.

## Notes

- Inappropriate, abusive, or profane language is strictly prohibited in support chats.
- The platform reserves the right to suspend or terminate accounts violating these policies.
- Support staff are authorized to intervene in conversations containing inappropriate language.
- Always follow the verification procedures and document violations properly.

## Key points for communicating with players

- Emphasize respectful communication as a condition of platform use.
- Clearly inform players of the consequences of violating chat policies.
- Use neutral language and avoid escalating conflicts during the conversation.