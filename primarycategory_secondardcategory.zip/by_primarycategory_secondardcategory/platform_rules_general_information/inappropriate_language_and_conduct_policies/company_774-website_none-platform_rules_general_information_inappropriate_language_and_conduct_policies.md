# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and read the player's inquiry or report regarding conduct or language issues.**  
   - Determine if the concern refers to inappropriate language, profanity, or abusive behavior.

2. **Ask the player to clarify or specify the incident if necessary.**  
   - Collect details such as the context, platform (chat, in-game, etc.), and any relevant screenshots or evidence if available.

3. **Verify if the player’s report concerns inappropriate language or abusive behavior.**  
   - Confirm whether the language used violates the platform's conduct policy as outlined in the FAQs:  
     - Inappropriate language and abusive behavior are not permitted.  
     - Profanity in chats is not allowed.  
     - PHJOIN reserves the right to suspend or terminate accounts for violations.

4. **Check back-office or system records for any prior violations or evidence.**  
   - Review chat logs or incident reports if available.  
   - Confirm if the account has a history of similar violations.

5. **Determine if the reported behavior violates the conduct policy.**  
   - If violation is confirmed, proceed to enforce appropriate action.  
   - If not confirmed or insufficient evidence, inform the player that no policy violation was identified or that further evidence is needed.

6. **Implement enforcement actions based on the company's policy.**  
   - If the violation is verified, suspend or terminate the account accordingly.  
   - Clearly communicate to the player the reason for the action, emphasizing the policy on inappropriate language and conduct.  
   - Remind the player of the platform's conduct policies and the importance of respectful communication.

7. **Document the case fully in the case management system.**  
   - Include details of the report, evidence reviewed, and actions taken.

8. **Follow up with the player if required or if there are additional concerns.**  
   - Offer further assistance or guidance on conduct policies and responsible communication.

## Notes

- PHJOIN explicitly reserves the right to suspend or terminate accounts that violate the conduct policies related to inappropriate language and abusive behavior.  
- Communication with players should be respectful, informative, and aligned with the policies.  
- Do not offer lending services or cash advances, as this is outside the scope of conduct issues but is part of the general policies.

## Key points for communicating with players

- Clearly explain that inappropriate language and abusive behavior are not permitted on the platform.  
- Reiterate that violations can lead to suspension or termination of accounts.  
- Encourage respectful communication and remind players to adhere to the platform’s conduct policies.