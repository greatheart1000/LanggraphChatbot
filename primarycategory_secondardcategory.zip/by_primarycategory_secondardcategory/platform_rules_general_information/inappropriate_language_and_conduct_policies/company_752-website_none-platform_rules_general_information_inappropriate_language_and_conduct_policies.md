# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and review the player's inquiry or report regarding inappropriate language or conduct**.  
   - Determine if the concern pertains to the player’s own behavior, chat discussions, customer service interactions, or other communication channels.

2. **Gather necessary information from the player** if relevant.  
   - Confirm the details of the incident, such as the context of the inappropriate language, the specific communication (chat, live chat, conversation transcript), and any screenshots if available.  
   - For chat-related issues, request or review chat transcripts or logs to verify the use of inappropriate language.

3. **Check the player's account history and communication logs** in the back office or system to verify if inappropriate language was used.  
   - Confirm if the language violates the platform policy as specified: "Inappropriate language or engaging in conversations that contain inappropriate language is not permitted."

4. **Assess the situation against policies**:  
   - **If inappropriate language or conduct is confirmed in chat or communication logs**:  
     - Determine whether the language or conduct is in violation of the platform’s rules, noting the policy that "using inappropriate language is not permitted" and that such violations "may result in suspension or termination of the account."  
   - **If no evidence or the issue is unclear**:  
     - Inform the player that the review is ongoing or that additional information is needed before making a final decision.

5. **Decide on the appropriate action based on the severity and policy violation**:  
   - **For confirmed violations**:  
     - Proceed with suspending or terminating the account as per platform policy.  
     - Clearly communicate to the player that inappropriate language violates the rules and that their account has been suspended or terminated accordingly.  
   - **For unverified or minor issues**:  
     - Remain on hold or inform the player that further review is needed before any action.

6. **Document the case thoroughly**:  
   - Save chat transcripts, screenshots, or communication logs that support the decision.  
   - Record the actions taken, including suspension or termination details if applicable.

7. **If the violation involves funds or betting activity, review for irregular betting activity**:  
   - **If identified**: Note that profits from irregular betting activities will be subject to deduction, and explain this to the player if applicable.  
   - **If no irregular activity is detected**: Proceed with the communication regarding conduct violations only.

8. **Communicate the resolution clearly to the player**:  
   - Explain the reason for any action taken regarding inappropriate language, referencing the platform rules.  
   - Remind the player of the policies regarding conduct and language, including consequences such as suspension or termination.

9. **Follow escalation procedures if necessary**:  
   - If the situation involves repeated violations or complex cases, escalate to senior support or compliance teams as per internal guidelines.

## Notes
- Always rely on concrete evidence such as chat logs, screenshots, or transcripts before taking disciplinary action.
- Inappropriate language includes profanity and offensive conversations in chats or other communication channels.
- The platform reserves the right to suspend or terminate accounts for violations.

## Key points for communicating with players
- Be clear and professional when explaining rules and violations.
- Reference specific policies: "Using inappropriate language is not permitted," and "PHCASH reserves the right to suspend or terminate your account if this policy is violated."
- Ensure players understand that actions are based on verified evidence and in accordance with site rules.