# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report regarding language or conduct issues**  
   - Confirm the concern relates to inappropriate language or abusive behavior in support chats or on the platform.

2. **Gather necessary information from the player**  
   - Request details about the incident, including specific messages, date/time, and involved parties if applicable.  
   - If applicable, ask the player to provide screenshots evidencing the inappropriate language or behavior.

3. **Verify the account status and recent activity**  
   - Check the player's account for any prior violations regarding language or conduct.  
   - Review recent chat history and activity logs in the back office systems.

4. **Assess the language or conduct level against platform policies**  
   - Confirm whether the language used is profane, abusive, or violates the platform's conduct policies.  
   - Note that inappropriate language and abusive behavior are not permitted and may lead to suspension or termination.

5. **Check for repeated violations**  
   - Determine if the player has previous instances of inappropriate language or behavior.  
   - Multiple violations may result in chat closure, account suspension, or termination.

6. **Decide on appropriate action based on findings**  
   - If the violation is superficial or first-time, inform the player politely about policy expectations.  
   - If the language is severe or if repeated violations are evident, escalate to account suspension or termination as per guidelines.

7. **Explain the platform's conduct policies to the player**  
   - Clearly communicate that inappropriate language is not permitted and that violations can result in account actions.  
   - Emphasize that support agents are there to assist politely and that abuse will not be tolerated.

8. **Address the player's concern about irregular betting activity or profits**  
   - If the report concerns irregular betting activity, check the system for irregular betting detection.  
   - Inform the player that profits from irregular activities may be deducted according to policy.  
   - If profits are deducted, clarify that this is to maintain fair play and compliance.  
   - If the system detects irregular activity, advise the player that the profits may be deducted and that withdrawal may require meeting standard turnover requirements.

9. **Take the necessary action if misconduct is confirmed**  
   - For confirmed violations, suspend or terminate the player's account in accordance with the platform's rules.  
   - Close the support chat if abusive language persists, to protect staff and other users.  
   - Document the incident thoroughly in case of escalation or future reference.

10. **Communicate the resolution to the player**  
    - Provide a clear explanation of the action taken and the reasons based on platform policies.  
    - Remind the player of acceptable conduct standards going forward.

11. **Close the support ticket** after the issue resolution is communicated or escalated, ensuring all relevant details are documented.

## Notes

- Always verify if the violations involve repeated instances, as this may trigger stricter actions such as chat closure or account suspension.  
- If evidence is not sufficient, inform the player that the investigation will continue or that further evidence is required.  
- Remember to maintain respectful polite communication throughout and emphasize the importance of respectful language and conduct on the platform.

## Key points for communicating with players

- Clearly state that inappropriate or abusive language is not allowed.  
- Explain that violations may lead to chat closure, suspension, or account termination.  
- If applicable, inform about possible deductions of profits based on irregular betting activity.  
- Reinforce that support staff are there to help respectfully and that maintaining respectful communication is mandatory.