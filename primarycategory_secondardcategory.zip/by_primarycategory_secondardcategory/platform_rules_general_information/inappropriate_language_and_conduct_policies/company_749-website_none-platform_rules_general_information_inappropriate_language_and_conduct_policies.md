# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and review the player's inquiry or report regarding inappropriate language or conduct.**
   - Determine whether the issue involves the player's own behavior, another user's behavior, or concerns raised during interaction with customer service.
   
2. **If the player reports or demonstrates inappropriate language or behavior, collect relevant information:**
   - Player's account details (username, account ID).
   - Details of the incident (date, time, platform used).
   - Exact quotes or descriptions of inappropriate language or conduct.
   - Screenshots or recordings if provided (ensure proper documentation if necessary).
   - Confirm if multiple accounts are involved, especially if referred through a referral link or if multiple accounts are suspected of violating site policies.

3. **Check the player's account status and activity in the back office/system:**
   - Verify if the account has been flagged for violations previously.
   - Review betting activity for irregular or suspicious behavior, particularly irregular betting activity that could indicate fraudulent conduct.  
   - For violations involving fraud, inappropriate language, or abuse, confirm if the account has been flagged or if there are previous warnings.

4. **Assess if the account or activity violates the policies:**
   - Use the following criteria based on the FAQs:
     - Use of inappropriate language or engaging in conversations containing inappropriate language.
     - Abusive or inappropriate language directed toward staff or other players.
     - Fraudulent behavior or conduct against platform rules.
     - Multiple accounts created using a referral link (if applicable).
     - Irregular betting activity leading to potential deductions or confiscation of rewards.

5. **Decide on the appropriate resolution based on the violation detected:**
   - For inappropriate language or conduct:
     - Confirm violation of the policy that "abusive or inappropriate language is not permitted."
     - Note that PHLOVE reserves the right to suspend or terminate accounts if policies are violated.
   - For fraudulent conduct or suspected fraud:
     - Prepare to escalate or escalate following internal procedures.
   - For multiple account violations:
     - Deduct commissions earned from referred accounts if policies are violated.
   - For irregular betting activity:
     - Follow policies regarding deduction of profits or confiscation of rewards.

6. **Communicate the outcome to the player:**
   - If violation is confirmed:
     - Inform the player that their account has been suspended or terminated based on policies regarding inappropriate language or conduct.
     - Explain that using inappropriate or abusive language is grounds for suspension or termination.
     - If applicable, mention that multiple accounts or irregular betting activities can result in deductions or account restrictions.
   - If clarification or further action is needed:
     - Escalate to relevant departments or management per internal protocols.

7. **Document the case and actions taken:**
   - Record all findings, communications, and resolutions in the case file or CRM system.
   - Attach relevant screenshots or evidence if collected.

## Notes
- Always verify the exact nature of the language or conduct to determine if it violates the policy.
- PHLOVE reserves the right to suspend or terminate accounts upon policy violations without prior notice.
- Handling cases involving fraud or multiple accounts may require further escalation according to internal procedures.

## Key points for communicating with players
- Clearly explain the platform’s policy on inappropriate language and conduct: abusive or inappropriate language is not permitted.
- Inform players that violations can lead to account suspension or termination.
- Be professional and neutral, avoiding confrontation.
- Escalate cases involving complex violations, suspected fraud, or repeated offenses as needed.