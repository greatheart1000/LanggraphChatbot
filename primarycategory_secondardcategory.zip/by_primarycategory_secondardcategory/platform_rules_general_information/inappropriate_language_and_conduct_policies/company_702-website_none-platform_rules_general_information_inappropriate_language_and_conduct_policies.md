# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report** regarding inappropriate language, conduct, or related policy issues.  
   - Collect relevant details from the player, such as the nature of the concern, any specific messages or conversations, and account details if applicable.

2. **Verify the player's reported concern or inquiry**:  
   - Check the chat or communication logs for evidence of inappropriate language or conduct.  
   - Review any flagged or suspicious activity related to betting behavior, especially if irregular betting activity or illicit profits are involved, according to platform security protocols.

3. **Assess the player's activity according to platform rules**:  
   - Confirm if inappropriate language or conduct is present.  
   - Determine if there are signs of irregular betting activity, illicit betting, or arbitrage, based on system detection.  
   - Be aware that profits from irregular betting or illicit activities may be subject to deduction.

4. **Decide on the appropriate action based on findings**:

   - **If inappropriate language is detected**:  
     - Use internal moderation tools to disable chat for the user if bad words are used.  
     - Inform the player that using inappropriate language is not permitted and may result in account suspension or termination.  
     - Clearly explain that WOWPH reserves the right to suspend or close the account for violations.

   - **If irregular betting activity, illicit profits, or arbitrage are flagged**:  
     - Explain to the player that detected irregular activities may lead to the deduction of profits and other actions according to platform rules.  
     - Document the findings for internal review.

5. **Determine whether additional actions are required**:

   - **For violations involving inappropriate language**:  
     - Disable chat functions if applicable.  
     - Consider suspending or terminating the account if the violation is severe or repeated.

   - **For betting irregularities or illicit activities**:  
     - Initiate internal investigations if necessary.  
     - Follow platform procedures for deductions or further actions, as dictated by system detections and policies.

6. **Communicate clearly and professionally with the player**:  
   - Describe the reasons for any actions taken, referencing platform policies.  
   - Assure the player that their e-wallet services (e.g., GCash, Maya) remain active unless otherwise specified, and that removals of links by BSP do not affect their account security.

7. **Log all actions and findings**:  
   - Record the incident details, evidence, and steps taken in the case management system for future audit and review.

8. **Close the case** once the issue is addressed or escalated according to the severity, ensuring the player has received a clear explanation of actions taken.

## Notes

- Inappropriate language policies explicitly prohibit conversations containing bad words; violators may be disabled from chatting or face account suspension/termination.
- The platform reserves the right to suspend or terminate accounts if violations are detected.
- Profits from irregular betting activities or illicit profit generation may be deducted, and further actions may be taken per platform rules.
- System detections are automatically monitored; agents should corroborate such findings with logs and evidence before taking action.

## Key points for communicating with players

- Explain platform policies clearly regarding inappropriate language and betting irregularities.
- Reassure players that their e-wallet services are safe and remain active unless explicitly affected.
- Be professional, firm, and polite when responding to violations, providing specific references to policies where applicable.