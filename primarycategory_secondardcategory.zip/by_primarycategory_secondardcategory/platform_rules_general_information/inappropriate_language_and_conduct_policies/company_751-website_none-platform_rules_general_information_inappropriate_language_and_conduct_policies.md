# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and Review the Inquiry or Report**
   - Determine if the player has reported a violation or whether the front-line agent has identified inappropriate language or conduct.
   - Collect relevant account information: player ID, username, and details of the incident (e.g., chat logs, screenshots).
   - Confirm if the issue pertains to inappropriate language or irregular betting activity, or both.

2. **Verify the Instance of Inappropriate Language or Conduct**
   - Check the conversation logs, chat transcripts, or any other evidence provided by the player.
   - Confirm whether the language used is inappropriate according to platform policies.
   - If related to betting activity, verify if the system detected irregular betting activity associated with the account and note any flagged profits.

3. **Evaluate the System Detection of Irregular Betting Activity**
   - Access the back-end system to see if any irregular betting activities are identified for the account.
   - If irregular activity is detected, confirm whether profits gained from such activities have been deducted as per policy.

4. **Determine the Appropriate Action**
   - For inappropriate language or conduct:
     - Communicate to the player that using inappropriate language is not permitted.
     - Inform the player that PHJOY reserves the right to suspend or terminate the account if violations are confirmed.
     - Clarify that account deactivation is not available; the player can choose not to log in if they wish to stop playing.
   - For irregular betting activity:
     - Explain that profits gained from such activities may be subject to deduction.
     - Confirm whether the system has flagged any abnormal betting activities and if profits have been deducted.
     - Advise the player that additional actions may be taken to maintain fair play if necessary.

5. **Record and Document the Incident**
   - Log the details of the violation, including date, type (inappropriate language or irregular betting activity), and the evidence reviewed.
   - Note whether any account suspension was applied or if any profits were deducted.
   - Save relevant logs, screenshots, or chat transcripts for future reference.

6. **Escalate if Necessary**
   - If a severe violation or a pattern of misconduct is detected, escalate the issue to a supervisor or compliance team, especially if further disciplinary actions are warranted.

7. **Close the Ticket**
   - Summarize the action taken and reinforce platform policies regarding appropriate language and conduct.
   - Inform the player if further steps will be taken or if no further action is necessary.
   - Advise the player to communicate respectfully moving forward.

## Notes

- PHJOY reserves the right to suspend or terminate accounts that violate inappropriate language policies.
- Account deactivation is not available; players can choose to stop logging in if they wish.
- Profits from irregular betting activity identified by the system may be deducted, and additional actions to maintain fair play may be taken.
- E-wallet linking policies are unrelated to this scenario but remain subject to the current site rules.

## Key points for communicating with players

- Clearly inform players that inappropriate language is not permitted and violations may result in suspension or termination.
- Emphasize that account deactivation is not possible, and suggest they simply stop logging in if they wish to cease playing.
- Explain that irregular betting activity can lead to profits being deducted and that the system may automatically detect and act upon such activities.
- Maintain a respectful and professional tone when addressing violations and policy enforcement.