# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report regarding inappropriate language or conduct**  
   - Gather relevant details, including the nature of the issue (e.g., inappropriate language in chat, general conduct concerns).  
   - Confirm the specific communication channel involved (e.g., chat, comments).

2. **Verify the presence of inappropriate language or conduct**  
   - Check the incident, chat logs, or conversation history for use of inappropriate language or behavior.  
   - Confirm if the language or conduct violates PLUSPH's policy, which explicitly states that inappropriate language is not permitted and may result in a suspension or termination of the account.

3. **Assess the severity and context**  
   - Determine if the language or conduct is clearly inappropriate and violates policies as described in the FAQs.  
   - If the language involves inappropriate language or conversations, confirm that this is a policy violation, as per the FAQs.

4. **Take corrective action based on the violation**  
   - If inappropriate language or conduct is confirmed, inform the player of the violation and that their account may be suspended or terminated according to PLUSPH policies.  
   - Remind the player that inappropriate language or conversation is not permitted and that further violations could lead to account suspension or termination.  
   - If applicable, document the incident with screenshots or logs for record-keeping.

5. **If a system detection of irregular betting activity is involved**:  
   - Confirm whether irregular or illegal betting activity was detected.  
   - If detected, notify the player that any profits gained from these activities will be subject to deduction, per the policy.  
   - Document the findings and take necessary system actions, including potential deduction of profits, according to the site rules.

6. **Determine if account action is necessary**  
   - Based on the severity and recurrence of violations, decide whether to suspend or terminate the account.  
   - Remember, account deactivation is only feasible if there's clear evidence of malicious activity; otherwise, advise creating a new account if the player wishes to continue.

7. **Communicate the resolution to the player**  
   - Clearly explain the reason for any account suspension, termination, or other actions taken based on the violation of language or conduct policies.  
   - Emphasize the importance of adhering to the site's rules regarding appropriate language and behavior, referencing the policies summarized above.  
   - Warn that further violations may result in stricter sanctions.

8. **Close the case and update records**  
   - Finalize the support case with all relevant details: incident description, actions taken, system checks, and communications.  
   - Ensure documentation is complete for future reference or escalations if necessary.

## Notes

- Inappropriate language or conduct includes conversations that contain inappropriate language, which is explicitly prohibited according to PLUSPH's policies.  
- The platform reserves the right to suspend or terminate accounts that violate these policies.  
- When irregular betting activity is detected, profits earned from such activity may be deducted, based on the system alerts and policies.

## Key points for communicating with players

- Clearly inform players that inappropriate language or conduct violates platform policies and can lead to account suspension or termination.  
- When applicable, explain system detections related to irregular betting or illegal activity and the consequent deductive actions.  
- Maintain a professional tone, emphasizing adherence to site rules rather than accusations.  
- Document all communications and actions thoroughly to ensure transparency and compliance.