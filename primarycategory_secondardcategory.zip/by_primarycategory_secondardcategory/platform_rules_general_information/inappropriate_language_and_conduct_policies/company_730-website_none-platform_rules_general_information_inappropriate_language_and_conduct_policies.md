# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and review the player's inquiry or report concerning inappropriate language or conduct.**  
   - Collect relevant details: player account ID, nature of the issue, specific examples of inappropriate language if provided, and any relevant chat transcripts or screenshots.

2. **Verify the report or conversation for inappropriate language.**  
   - Check in the system or chat logs for evidence of inappropriate, abusive, or profane language.  
   - Confirm whether the language violates ACEPH's policy, which strictly prohibits inappropriate language in support chats and player interactions.

3. **Determine the severity and continuity of inappropriate language.**  
   - If the player used inappropriate language or engaged in offensive conversations, proceed with policy enforcement steps.  
   - If profanity persists or escalates during the current interaction, support agents may close the chat to prevent further violations.

4. **Assess previous violations or warnings (if applicable).**  
   - Check the player's account for prior violations related to language or misconduct.  
   - If prior infractions exist, consider the potential for account suspension or termination based on the ongoing violation and ACEPH's policy.

5. **Communicate the policy to the player (if applicable during chat).**  
   - Politely inform the player that inappropriate language is not permitted and could lead to suspension or termination of their account.  
   - Emphasize the importance of respectful communication to receive proper support and continue the interaction.

6. **Decide on the appropriate action based on the violation severity:**
   - **If inappropriate language is confirmed and continues:**  
     - Support agents may close the chat if profanity persists to prevent further violations.  
     - Escalate to a supervisor if the violation is severe or if it involves ongoing abusive behavior.  
     - Document the incident in the player's account record.

   - **If there is only a minor or first-time offense:**  
     - Issue a warning on the conversation, reminding the player of ACEPH’s language policy.  
     - Observe the chat for further violations before taking stronger action.

7. **Apply sanctions if necessary:**  
   - Based on the violation or recurrence, implement disciplinary measures such as account suspension or termination, following ACEPH policies.  
   - When system detection of irregular betting activity occurs, the system will deduct profits gained illegally; this is separate from language violations but should be documented if relevant.

8. **Close the case once the appropriate action has been taken.**  
   - Ensure all steps taken are documented clearly in the support case.  
   - Offer the player guidance on acceptable behavior if applicable, and inform them of any further consequences if violations continue.

## Notes
- Inappropriate language includes any abusive, profane, or offensive words in chat or conversations with support agents.  
- Support agents should maintain respectful communication, even when addressing violations.  
- Use the system logs and chat transcripts to verify and substantiate violations.

## Key points for communicating with players
- Clearly inform players that ACEPH prohibits inappropriate language, including profane or offensive words.  
- Explain that continued violations may result in account suspension or termination.  
- If closing the chat due to profanity, notify the player courteously and document the incident.