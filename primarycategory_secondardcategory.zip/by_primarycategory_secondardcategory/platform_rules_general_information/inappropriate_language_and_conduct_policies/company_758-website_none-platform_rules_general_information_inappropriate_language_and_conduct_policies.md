# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report regarding language or conduct issue.**  
   - Identify if the concern is about inappropriate language, abusive behavior, or conduct during support interactions.

2. **Gather relevant information from the player.**  
   - Collect details such as player’s full name, username, and the nature of the incident or concern.  
   - If applicable, request screenshots that illustrate the inappropriate language or conduct.  
   - Remind the player that the maximum file size for attachments is 20MB.

3. **Assess the player's communication to determine if the policy has been violated.**  
   - Check if the message contains inappropriate or abusive language.  
   - Confirm whether the conduct during support chat was disrespectful or offensive.  
   - Review any submitted screenshots for evidence of violations.

4. **Verify the nature of the conduct against the policies.**  
   - Use your system or support guidelines to verify if the language or behavior meets the criteria for violations, based on the FAQs:  
     - Use of inappropriate language or engaging in conversations with inappropriate language is not permitted. (FAQs)  
     - Offensive or abusive language is not permitted, and policies apply during support chats. (FAQs)  
     - Repeated violations may result in suspension or termination of the account.

5. **Decide on the appropriate resolution based on the evidence and policy.**  
   - If the violation is confirmed:  
     - Inform the player that their language or conduct violates platform policies.  
     - Clearly state that SUPERPH maintains a zero-tolerance policy for inappropriate language and abusive behavior.  
     - Explain that the account may be suspended or terminated for violations, especially in cases of repeated offenses.  
   - If the evidence is insufficient:  
     - Request additional information or clarification from the player.  
     - Advise the player to communicate respectfully to ensure effective support.

6. **Take corrective action as per policy.**  
   - For confirmed violations:  
     - Initiate an account review or suspension as per the platform’s disciplinary procedures.  
     - Document the violation details in the case notes.  
   - For non-violations or insufficient evidence:  
     - Close the case with a note advising on respectful communication in future interactions.

7. **Communicate the resolution clearly to the player.**  
   - Reinforce that the platform emphasizes respectful language and behavior.  
   - If applicable, inform the player about potential account suspension or termination due to violations.  
   - Encourage respectful communication to avoid future issues.

8. **Escalate or follow up if necessary.**  
   - If violations are severe or recurrent, escalate to the relevant support or disciplinary team.  
   - Monitor for repeated violations; persistent issues may lead to account suspension or termination.

## Notes

- The platform maintains a zero-tolerance policy for abusive or offensive language during all interactions, including support chats.  
- Repeated violations may lead to account suspension or termination, at SUPERPH’s discretion.  
- Always verify evidence such as messages or screenshots before taking disciplinary action.  
- Clearly inform players about the policy’s stance on inappropriate language and conduct, emphasizing respectful communication.

## Key points for communicating with players

- Be respectful and professional; inform players of policy violations politely.  
- Remind players that offensive language is not permitted and may result in account sanctions.  
- If requesting screenshots, ensure the player understands file size limits.  
- Document all interactions and evidence to support any disciplinary actions taken.