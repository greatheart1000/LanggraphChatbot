# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and review the player's inquiry or report** related to inappropriate language, conduct, or chat behavior.
   
2. **Identify the nature of the issue**:
   - If the player reports inappropriate language in chat or with customer support, proceed with conversation clarification.
   - If the system or staff detects irregular betting activity, follow the related procedures (though this is outside the scope of inappropriate language policies).
   - If the player mentions participation in casino games or other activities, verify if any conduct violations are involved, but focus remains on language and conduct policies.
   
3. **Collect necessary information from the player**:
   - Confirm details of the incident (e.g., chat transcript, description of behavior).
   - Ensure the player’s account details are available for review.
   - Ask for any relevant screenshots if applicable, to verify the nature of the inappropriate language or conduct.

4. **Perform system and account checks**:
   - Review the chat logs or communications for evidence of inappropriate language or offensive content.
   - Check the account activity for any signs of irregular betting activity if relevant, and review for penalties related to such (e.g., profits from irregular activity may be deducted; note that this is separate from language conduct but may be related to overall conduct review).
   - Verify if the account has any previous warnings or violations related to conduct or language.

5. **Determine the appropriate action**:
   - If inappropriate language or offensive content is confirmed during chat review:
     - Remind the player of the etiquette policy: inappropriate language is not permitted.
     - Inform the player that violations may result in account suspension or termination.
     - If violations are severe, proceed with suspending or terminating the account according to company policy.
   - If the language violation is borderline or unclear, document findings and escalate if needed according to local escalation procedures.

6. **Communicate the decision to the player**:
   - Clearly explain that inappropriate language or conduct is against platform policies.
   - Emphasize the importance of respectful communication.
   - Inform the player of potential consequences, such as account suspension or termination if violations recur.

7. **Document the case**:
   - Record the incident details, evidence, and actions taken in the internal system.
   - Attach chat transcripts or screenshots if available.
   - Note any warnings issued or sanctions applied.

8. **Follow up or escalate if necessary**:
   - If the case involves repeated violations, escalate to the relevant department or management.
   - Ensure that any suspension or termination is carried out in accordance with company policies.

9. **Close the case**:
   - Confirm that all actions and communications are documented.
   - Inform the player about the closure of the case if appropriate.
   - Offer guidance or contact points for further assistance, maintaining respectful communication.

## Notes

- Inappropriate language, including profanity, is strictly prohibited in chats and customer interactions.
- The platform reserves the right to suspend or terminate an account if violations occur.
- Always verify the evidence before advising sanctions or restrictions.
- When in doubt, escalate the case according to internal procedures.

## Key points for communicating with players

- Maintain a respectful tone when addressing violations.
- Clearly state that inappropriate language is not tolerated.
- Explain potential consequences calmly and professionally.
- Emphasize the importance of respectful communication to receive support or assistance.