# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps
1. **Receive the player's inquiry or report regarding inappropriate language or conduct**  
   - Review the message for any mention of abusive language, profanity, harassment, threats, or disrespectful comments.  

2. **Verify the nature of the concern**  
   - Check if the issue relates to the player's own behavior or if it's a report about another user's conduct.  
   - Confirm whether the language used is inappropriate as per PHPARK's policies.  

3. **Gather necessary information from the player**  
   - If applicable, request relevant details such as screenshots of the chat, conversation logs, or specific examples of the inappropriate language to assess the situation accurately.  
   - Document the call, chat transcript, or report details accordingly.  

4. **Perform internal checks**  
   - Access the player's account in the system to review chat logs or support interaction records if available.  
   - Confirm whether the user has previously violated the policy by reviewing their account activity history, if accessible.  

5. **Assess the violation based on collected evidence and policies**  
   - Determine if there is clear evidence of inappropriate language or abusive behavior.  
   - Note that PHPARK reserves the right to suspend or terminate accounts violating the policy.  

6. **Decide on the appropriate resolution**  
   - If violation is confirmed:  
     - Inform the player that inappropriate language or abusive behavior is strictly prohibited and can lead to account suspension or termination.  
     - Clearly explain that the policy requires respectful communication, and reiterate the rules against harassment and threats in chats.  
     - Proceed with the suspension or account termination in line with system procedures if the violation warrants it.  
   - If evidence is insufficient:  
     - Advise the player to maintain respectful language in future interactions.  
     - Offer guidance on acceptable conduct policies and remind about the importance of respectful support experience.  

7. **Escalate or document if needed**  
   - For serious violations, escalate to the appropriate team or manager as per internal policies.  
   - Save records of the incident and action taken for compliance and future reference.  

8. **Close the case and inform the player**  
   - Summarize the actions taken and remind the player of the platform’s conduct policies.  
   - Confirm they understand the importance of respectful communication and that violations may result in account suspension or termination.  

## Notes
- Always handle reports of inappropriate language promptly and professionally.  
- Collect concrete evidence (screenshots, logs) when possible, as PHPARK reserves the right to suspend or terminate accounts that violate policies.  
- Be transparent about policies but encourage respectful communication to maintain a positive community environment.

## Key points for communicating with players
- Emphasize the importance of respectful language and behavior in all interactions.  
- Clearly state that inappropriate language can lead to account suspension or termination.  
- Support players in addressing their concerns while reinforcing the platform’s conduct policies.