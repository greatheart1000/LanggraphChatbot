# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player inquiry or report regarding inappropriate language or conduct**  
   - Collect relevant details including the player's username, description of the behavior, and any supporting evidence such as chat screenshots if available.  

2. **Review the player's communication history and recent activity**  
   - Check for any previous violations related to inappropriate language or conduct in the player's account.  
   - Verify recent betting activity to identify any irregular or suspicious wagering behaviors, as profits gained from irregular betting activity may be deducted in accordance with platform rules.

3. **Assess the violation based on the available evidence**  
   - Determine whether the communication includes inappropriate language or abusive behavior, which is explicitly prohibited.  
   - Confirm if the reported or detected conduct violates the platform’s policies on respectful communication and conduct.  
   - If chat records are involved, ensure they contain inappropriate content; communicate that inappropriate language or abusive behavior is not permitted, and the platform reserves the right to suspend or terminate the account for violations.

4. **Decide on the appropriate resolution or action**  
   - If violations are confirmed, inform the player of the platform’s policies:  
     - Inappropriate language is not permitted.  
     - The platform reserves the right to suspend or terminate accounts for violations.  
   - If there is evidence of irregular betting activity, explain that any profits gained from such activity will be deducted according to platform rules.  
   - For repeated violations, mention that persistent inappropriate behavior can lead to suspension or termination of the account.  

5. **Implement the necessary account action**  
   - If violations are severe or repeated, escalate the case as per internal procedures for suspension or termination.  
   - For minor or first-time violations, document the incident and notify the player of the breach, emphasizing the importance of respectful communication.  

6. **Communicate the resolution clearly to the player**  
   - Provide an explanation aligned with the platform policies and findings from the review.  
   - Remind the player of the conduct rules and consequences of violations.  
   - Encourage respectful communication in future interactions to prevent further violations.  

7. **Close the case**  
   - Record all actions taken and the rationale in the internal system.  
   - Follow up if necessary, especially if further monitoring is required for recurring misconduct or irregular betting activity.

## Notes

- When communicating with players about violations, emphasize the prohibition of inappropriate language and abusive behavior, along with the potential for account suspension or termination for violations.  
- For cases involving irregular betting activity, clarify that profits from such activity will be deducted in accordance with the platform’s rules.  
- Always ensure supporting evidence such as chat screenshots or activity logs are available before proceeding with account-related actions.

## Key points for communicating with players

- Be clear and respectful; inform players about the platform’s policies on inappropriate language and conduct.  
- Explain that the platform reserves the right to suspend or terminate accounts for violations.  
- In cases of irregular betting activity, notify that profits gained from such activity will be deducted.  
- Reiterate the importance of respectful behavior and adherence to conduct rules to prevent account suspension or termination.