# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive and Review the Player Inquiry or Report**
   - Determine if the query relates to inappropriate language or conduct, such as offensive language in chat or conversations containing inappropriate language.
   - Confirm if the player is requesting clarification or reporting an incident.

2. **Gather Relevant Information from the Player**
   - Request details about the specific incident or language used.
   - If applicable, ask for screenshots or evidence of the inappropriate language or conduct.
   - Verify the player's account details to ensure correct handling and record-keeping.

3. **Check for System or Previous Reports**
   - Review the player's chat logs, chat history, or previous reports related to inappropriate language or conduct.
   - Confirm if there are existing violations or warnings associated with the account.

4. **Evaluate if Violations are Confirmed**
   - Confirm whether the report or evidence indicates the use of inappropriate language or conduct.
   - Check if the violation breaches the platform's policy, which explicitly prohibits inappropriate or abusive language.
   - Take note that using inappropriate language or engaging in conversations with inappropriate language is not permitted and can lead to suspension or termination of the account.

5. **Decide on the Appropriate Action Based on Findings**
   - **If violation is confirmed:**
     - Inform the player that misuse of inappropriate or abusive language violates platform policies.
     - Clarify that the platform reserves the right to suspend or terminate accounts in case of violations.
     - Document the violation in the player's record.
     - If the platform's policy or system detects irregular betting activity or other violations, mention that profits from such activity may be deducted.
     - Escalate to the relevant department if further action is required (e.g., account suspension or termination).
      
   - **If insufficient evidence or no violation is found:**
     - Explain that no breach of platform rules is detected based on current evidence.
     - Remind the player of the policies against inappropriate language to encourage adherence.

6. **Communicate Clearly and Professionally**
   - Use straightforward language to explain the platform's rules regarding inappropriate language.
   - Emphasize that inappropriate language or abusive conduct is not tolerated.
   - Avoid unnecessary details; focus on the violation status and possible consequences.

7. **Close the Inquiry**
   - Confirm the player understands the platform policies.
   - Advise the player to adhere to community standards and conduct respectful interactions.
   - Save a record of the interaction and decision.
   - If the case involved a violation, ensure the account's violation history is updated accordingly.

## Notes
- SLOTSGO reserves the right to suspend or terminate accounts if inappropriate language or abusive conduct is detected.
- Incidents involving abusive language or inappropriate conduct can lead to account suspension or termination, even if the incident was a one-time occurrence.
- Profits from irregular betting activity may be deducted if system detects such activity, as per platform policy.
- Always verify evidence before taking action; escalate cases involving complex or unclear violations to the appropriate department.

## Key points for communicating with players
- Be clear and direct about the platform's policy against inappropriate language.
- Use professional, non-confrontational language.
- Ensure the player understands that violations can result in account suspension or termination.
- Maintain a record of all interactions for accountability.