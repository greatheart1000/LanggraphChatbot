# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player inquiry or report regarding conduct or language violation.**

2. **Verify the player's account details and history:**
   - Check for previous violations related to inappropriate language or conduct.
   - Review recent chat interactions, if applicable.
   - Examine betting activities for irregular betting following the incident, noting that profits from irregular betting may be deducted.

3. **Assess the nature of the issue based on the player's report or system detection:**
   - Determine if the violation concerns inappropriate language, abusive language, or disrespectful behavior.
   - Confirm if the conduct involved was in chat or support interactions.
   - Check if the activity involved irregular betting or behavior that might trigger deductions.

4. **Collect evidence if needed:**
   - Request or review screenshots of chat conversations showing inappropriate language if available.
   - Note any system alerts or logs related to irregular betting activity.

5. **Explain the platform policy to the player:**
   - Emphasize that inappropriate language, abusive language, or disrespectful conduct is not permitted.
   - Clearly state that repeated violations can lead to account suspension or termination.
   - Inform that any profits from irregular betting activity may be deducted as part of the platform's security policies.

6. **Determine the appropriate action based on the severity and repetition of the violation:**
   - For a first-time or minor infraction, issue a warning about the conduct violations.
   - For repeated violations or severe misconduct, escalate to suspending or terminating the player's account.

7. **Implement the resolution:**
   - Issue warnings for minor violations.
   - Suspend or terminate accounts for repeated or serious violations, in accordance with platform policies.
   - Document the action taken in the case record.

8. **If the violation involves irregular betting activity:**
   - Confirm that the system detected irregular betting.
   - Inform the player that profits gained from these activities may be deducted.
   - Follow the platform's audit procedures for such cases.

9. **Inform the player of the outcome and next steps:**
   - Summarize the action taken (warning, suspension, termination).
   - Remind the player of conduct policies.
   - Encourage future respectful behavior and adherence to platform rules.

10. **Close the case once all actions are completed and documented.**

## Notes
- Always communicate with respect and professionalism, regardless of the situation.
- If evidence or policy application is unclear, escalate to supervisory support.
- Ensure documentation of all interactions and actions for future reference.

## Key points for communicating with players
- Clearly explain the platform's rules on language and conduct.
- Emphasize that repeated violations or severe misconduct can lead to account suspension or termination.
- Confirm that profits from irregular betting activity are subject to deduction as per platform security policies.
- Maintain respectful and professional language at all times.