# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Identify the nature of the issue**
   - Determine if the player's inquiry or report concerns inappropriate language or conduct, specifically in chats or conversations with support representatives.
   - Check if the player has used inappropriate language or engaged in harassment, or if they have questioned policies related to language and conduct.

2. **Verify the player’s account and interaction details**
   - Confirm the player's identity and account status.
   - Review chat transcripts, messages, or reported interactions for evidence of inappropriate language or conduct.
   - Note the specific instances or warnings of policy violation.

3. **Assess the violation based on system detection or observed behavior**
   - If the system has flagged irregular betting activity, record that profits gained from such activity will be subject to deduction (refer to FAQs on irregular betting activity).
   - If the platform has identified inappropriate language or conduct:
     - Confirm if this is evidenced by system alerts, chat logs, or reports.

4. **Determine the appropriate action based on the violation type and severity**
   - For inappropriate language or conduct in chats or other communication channels:
     - Inform the player that inappropriate language is not permitted on the platform, and violations can lead to suspension or termination of the account.
     - Emphasize the platform's policy: using inappropriate language or engaging in harassment cannot be tolerated.
     - Explain that persistent violations will result in consequences, including possible account suspension or termination.
   - For irregular betting activity:
     - Notify the player that any profits from such activity may be subject to deduction, as per the platform policy.

5. **Apply corrective action and document the case**
   - If violations are confirmed:
     - Issue a warning or suspension based on the platform’s severity guidelines.
     - Record the incident and actions taken in the system notes.
   - If no violation is confirmed, inform the player that their behavior did not breach platform policies but remind them to adhere to community standards.

6. **Escalate or further assist if needed**
   - For repeated violations or serious misconduct, escalate the issue to senior support or compliance teams.
   - If the player disputes the violation, review chat logs or account activity again before finalizing the decision.

7. **Communicate the resolution to the player**
   - Provide a clear explanation of the outcome and any actions taken.
   - Reinforce the importance of following platform rules regarding language and conduct.
   - Offer guidance if the player has further questions, ensuring to maintain a respectful tone.

## Notes
- Inappropriate language or harassment in support chats or other communication channels is explicitly prohibited.
- The platform reserves the right to suspend or terminate accounts for policy violations.
- When dealing with irregular betting activity, inform the player that profits gained from such activity are subject to deduction.
- Always verify evidence thoroughly before taking disciplinary action.

## Key points for communicating with players
- Be clear and polite when explaining policy violations.
- Remind players of the platform’s rules against inappropriate language and conduct.
- Maintain objectivity and document all interactions for compliance purposes.
- Emphasize that repeated violations lead to stricter penalties, including account suspension or termination.