# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Greet the player and address their concern or inquiry about language or conduct.**

2. **Gather relevant information from the player:**
   - Ask if they have used inappropriate or offensive language in chat.
   - Confirm whether the concern relates to their own behavior or if they reported another player.
   - If applicable, request details about the specific messages or behavior in question.

3. **Assess the situation based on the player's input:**
   - If the player admits to using inappropriate language, proceed to check the account history.
   - If the concern is about another player's conduct, verify the reported messages or behavior.

4. **Verify the violation in the system:**
   - Review chat logs or message history to confirm the use of profanity or offensive language.
   - Check if the account has previously violated the policies related to inappropriate language or conduct (note: this may depend on available account history).

5. **Determine appropriate action based on policy:**
   - **If a violation is confirmed:**
     - Inform the player that inappropriate language or offensive conduct is not permitted.
     - Explain that NICEPH reserves the right to suspend or terminate accounts for policy violations.
     - Clarify that repeated violations may lead to chat session closure to assist other players.
     - If necessary, escalate the case to review for account suspension or termination.
   - **If no violation is confirmed or evidence is insufficient:**
     - Advise the player that no policy violation has been detected.
     - Remind the player of the importance of maintaining respectful communication.
     - Close the case if no further action is required.

6. **Handle the case based on the outcome:**
   - If initiating a suspension or termination, follow the internal procedures to flag and process the account accordingly.
   - If closing the chat session due to repeated profanity, notify the player politely and end the chat.

7. **Document the interaction:**
   - Record details of the conversation, including the nature of the concern, findings, and any actions taken in the system.

## Notes

- Usage of inappropriate language or abusive conduct is strictly against NICEPH policies.
- NICEPH reserves the right to suspend or terminate accounts that violate the policies.
- Repeated profanity usage may result in chat being closed to other players to maintain a respectful environment.

## Key points for communicating with players

- Always remind players to maintain respectful and appropriate communication.
- Clearly explain that violations can lead to account suspension or termination.
- If evidence is insufficient, politely inform the player and encourage respectful behavior.
- Be professional and polite regardless of the situation, even if the player shows frustration.