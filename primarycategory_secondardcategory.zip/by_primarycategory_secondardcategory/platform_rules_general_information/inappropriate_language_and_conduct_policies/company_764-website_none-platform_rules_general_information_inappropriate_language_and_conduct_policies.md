# Platform Rules & General Information - Inappropriate Language and Conduct Policies

## Steps

1. **Receive the player's inquiry or report regarding inappropriate language or conduct**  
   - Examine the message or ticket contents to identify concerns related to offensive language or misconduct during support chats or account activities.

2. **Verify the nature of the complaint or issue**  
   - Check if the player reports inappropriate language used in live chat or support communication.
   - Determine if the concern involves irregular betting activity related to inappropriate conduct, harassment, or suspicion of rule violation.

3. **If the issue pertains to inappropriate language in support chats:**  
   - Confirm whether the player’s message contains profanity or abusive language.  
   - Remind the player that:  
     - Profane or abusive language is not permitted.  
     - DREAMJILI reserves the right to suspend or terminate the account if this policy is violated.  
     - Communication should be respectful to receive assistance.  
   - If the player has used inappropriate language:  
     - Clearly inform the player that their language violates site rules.  
     - Mention the risk of chat being closed or account suspension if violations continue.

4. **If the complaint involves irregular betting activity:**  
   - Access the player’s account details through the back-office or system.  
   - Check if irregular betting activity has been detected (e.g., unusual or suspicious betting patterns).  
   - If irregular betting activity is identified:  
     - Note that: profits gained from these activities may be deducted.  
     - Verify if the system has identified activity or if a manual review is required.  
     - Notify the player of the detection and inform them that any profits from these activities may be deducted as per policy.

5. **Collect and document relevant information:**  
   - Record the details of the complaint, including any screenshots or chat logs if applicable.  
   - For inquiries about language, note the specific messages used by the player.  
   - For betting activity, document the suspicion of irregularity and relevant account details.

6. **Based on the findings, determine the appropriate course of action:**  
   - For inappropriate language:  
     - Advise the player about the policy and enforce consequences if necessary (e.g., chat closure, account suspension).  
   - For irregular betting activity:  
     - Inform the player that profits may be deducted if irregular activity is confirmed.  
     - Proceed with system review or escalate to the relevant department if required.  
   - If insufficient evidence is available or the issue cannot be confirmed, explain that no violations are detected but remind the player to communicate respectfully.

7. **Communicate the resolution to the player clearly:**  
   - Explain the site’s policies on language and conduct.  
   - Clarify any actions taken (e.g., chat closure, account review).  
   - If applicable, instruct the player on expected follow-up steps or appeals process.

8. **Follow up if needed:**  
   - For ongoing cases, monitor the account or chat for further violations.  
   - Escalate to management or compliance teams if violations are severe or repeated.

9. **Close the case:**  
   - Ensure all relevant documentation is recorded in the system.  
   - Confirm that the player understands the outcome and any consequences.

## Notes
- Profanity or abusive language in support chats is strictly prohibited; repeated violations may lead to chat closure or account suspension.
- Irregular betting activity may cause profits to be deducted and trigger account review.
- Always verify and document all findings thoroughly before taking corrective action.
- Maintain respectful communication with players, emphasizing policies and consequences clearly.

## Key points for communicating with players
- Clearly inform players about the prohibition of inappropriate language and abusive conduct.
- Remind players about the potential consequences for violations, including account suspension.
- Explain that profits from irregular betting activity may be deducted if irregularity is confirmed.
- Emphasize respectful and constructive communication to ensure effective support.