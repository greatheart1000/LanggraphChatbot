# Platform Rules & General Information - Detection and Handling of Irregular Betting Activities

## Steps

1. Receive and review the player's inquiry or report regarding betting concerns or account issues related to irregular activity.  
   - Confirm the specific details provided by the player, and if necessary, request additional information to clarify the situation.

2. Check the system for suspicious activity associated with the player's account.  
   - Verify if the system has detected irregular betting activity or malicious arbitrage winnings.
   - Review if the account shows signs of malicious arbitrage behavior or abnormal profits.

3. Assess whether the activity violates fair use policies or terms and conditions.  
   - If malicious arbitrage winnings or irregular betting activity are detected, proceed to the next step.

4. Determine the legitimacy of the profits gained from the suspicious activity.  
   - Identify if illicit profits exist and quantify the amount of gains involved.
   - Confirm if the profits are deemed illicit according to system detection and policies.

5. Take appropriate resolution actions based on detection outcomes:  
   - Deduct all illicit profits from the player's account if malicious arbitrage, irregular betting, or abnormal profits are confirmed.  
   - Make a note of the deduction and inform the player about the reason, referencing detected irregular activity.

6. Request additional documents or information from the player if needed for further investigation or clarification, especially in cases of balance deduction due to abnormal betting activities.  
   - Clearly communicate the reason for the request and the importance of providing accurate documentation.

7. If no suspicious activity is confirmed or the provided information is insufficient for action:  
   - Explain to the player that no irregular activity was detected or that further evidence is required before taking any action.  
   - Offer guidance on any steps the player may take or how to appeal if applicable.

8. Document all actions, checks, and communications in the case record for audit purposes and future reference.  
   - Record detection results, player explanations, documents received, and actions taken.

## Notes

- The system automatically detects malicious arbitrage winnings and irregular betting activities.  
- All illicit profits derived from such activities will be deducted according to the platform's terms and conditions.  
- Only accounts associated with suspicious fraudulent activity can be deactivated or deleted; otherwise, accounts remain active unless further flagged.

## Key points for communicating with players

- Clearly explain that detected irregular betting activity or arbitrage winnings lead to profit deductions.  
- Inform players about the need for additional documentation if balance deductions occur due to abnormal betting behavior.  
- Provide reassurance that all actions are compliant with the platform's policies and are driven by system detection results.