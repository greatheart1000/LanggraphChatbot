# Platform Rules & General Information - Detection and Handling of Irregular Betting Activities

## Steps

1. **Receive the player's inquiry or report regarding suspected irregular betting activity.**  
   - Collect relevant account information: player ID, username, involved bets, dates, and any supporting screenshots or evidence the player can provide.

2. **Access the back office/system to review the account and betting activity.**  
   - Check for detected irregular betting activity, suspicious patterns, or illicit profits flagged by the system.
   - Confirm whether the system has flagged or suspended the account for such activity.

3. **Identify if illicit or irregular activity is suspected or confirmed based on system alerts.**  
   - Look for indications of malicious arbitrage winnings or irregular betting behavior.
   - Verify if profits gained from such activity are flagged by the system.

4. **Determine the scope of the detected activity and potential illicit profits.**
   - Ascertain if profits or bonuses are involved.
   - Check if multiple accounts from the same IP have been used, especially if it leads to violations (e.g., account suspensions or deductions).

5. **Communicate clearly with the player regarding the detection.**  
   - Explain that the system monitors betting behaviors and that if irregular activity is confirmed, profits earned from those activities may be deducted.
   - Emphasize the policy that illicit or malicious arbitrage winnings will lead to deductions from the account.

6. **Decide on the appropriate resolution based on the detection outcome.**  
   - If irregular betting activity or illicit profits are confirmed:
     - Inform the player that all illicit profits and bonuses associated with the violation will be deducted.
     - Note that profits earned from irregular activity may be deducted according to platform policy.
     - If applicable, notify about account suspension or flagging in accordance with the policy.
   - If the evidence is insufficient or unclear:
     - Advise the player that further monitoring is ongoing, and advise playing within the rules to avoid potential deductions or account actions.

7. **Implement necessary actions in the system.**  
   - Deduct illicit profits and bonuses where confirmed.
   - Flag or suspend the account if malicious arbitrage or illicit profits are detected, in line with the platform’s policy.

8. **Document all findings, actions taken, and communication with the player in the case record.**  
   - Include details of detected activity, evidence reviewed, and resolution steps.

## Notes

- Deductions are made when irregular, suspicious, or malicious arbitrage betting activity is detected, in accordance with platform policies.
- The system may flag or suspend accounts involved in illicit activities, or where multiple accounts/IPs are used in violation.
- Always verify whether the evidence is sufficient before proceeding with deductions or account suspensions.
- Policies specify that all illicit profits stemming from malicious arbitrage will be deducted from the account.

## Key points for communicating with players

- Clearly explain that the system monitors betting behavior to prevent abuse.
- Inform that profits gained from irregular or illicit activity may be deducted.
- Emphasize the importance of playing within the rules and policies to avoid deductions or account sanctions.
- When necessary, explain that further investigation is ongoing if evidence is insufficient.