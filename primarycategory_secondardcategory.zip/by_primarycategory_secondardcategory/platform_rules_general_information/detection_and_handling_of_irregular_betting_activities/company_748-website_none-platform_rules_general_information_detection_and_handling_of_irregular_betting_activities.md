# Platform Rules & General Information - Detection and Handling of Irregular Betting Activities

## Steps

1. **Receive and Log the Player Inquiry or Report**
   - Note if the player reports irregular betting activity or if the inquiry relates to account restrictions.
   - Gather initial information: player’s account ID, nature of activity suspected, and any relevant details provided by the player.

2. **Check System Alerts for Irregular Activity**
   - Verify if the system has flagged the account for irregular betting activity (e.g., malicious arbitrage betting).
   - Confirm whether the system has identified irregular or malicious arbitrage betting activity associated with the account.

3. **Assess Player Account for Irregular Betting Activity**
   - Determine if the account has engaged in betting behaviors associated with irregular activity, such as arbitrage.
   - Confirm if winnings have been gained from such activities.

4. **Evaluate the Impact on Player Winnings and Profits**
   - If irregular betting activity is detected:
     - Deduct any illicit profits from the player's account, as profits gained from irregular activities will be subject to deduction.
     - Withhold winnings until any turnover or wagering requirements are met.
     - Check if the account withdrawal activity is flagged as irregular:
       - If flagged, restrict withdrawal options until the issue is resolved.

5. **Address the Player's Request and Provide Explanation**
   - Inform the player that the system has identified irregular betting activity, and accordingly:
     - Any profits gained will be deducted.
     - Winnings may be withheld or deducted until requirements are met.
     - Withdrawals may be restricted until compliance.

6. **If the Player’s Account Is Under Restriction or Deduction**
   - Clarify that account deletion or deactivation is not permitted except in cases of malicious activity.
   - Advise the player on the current status and next steps:
     - Instruct on any required actions (if applicable, e.g., meeting turnover requirements).
     - Explain that restrictions remain until the system detects compliant activity or until further investigation concludes.

7. **Escalate or Follow Up if Necessary**
   - If the detection involves complex or malicious activity, escalate to the relevant team according to internal policies.
   - Record all actions taken, including system flags, deductions, and communication with the player.

## Notes
- Do not attempt to delete or deactivate the account unless there is malicious activity explicitly confirmed.
- Profits gained from irregular activity will be deducted from the account, and winnings may be withheld until turnover requirements are fulfilled.
- Always communicate the situation clearly to the player, referencing system detection and site policies.

## Key points for communicating with players
- Clearly explain that irregular betting activity has been detected and that profits or winnings may be deducted or withheld.
- Emphasize that account deletion or deactivation is not permitted unless malicious activity is confirmed.
- Provide guidance on next steps or requirements to lift restrictions, if applicable.