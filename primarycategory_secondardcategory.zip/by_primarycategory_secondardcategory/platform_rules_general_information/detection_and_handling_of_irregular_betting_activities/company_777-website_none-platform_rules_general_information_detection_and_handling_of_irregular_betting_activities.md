# Platform Rules & General Information - Detection and Handling of Irregular Betting Activities

## Steps

1. **Receive and Review the Player’s Report or Alert**
   - If a player contacts support regarding irregular betting activity or suspicious profits, record their concern and account details.
   - If an internal system alert is triggered for abnormal or suspicious betting activity, note the detection details.

2. **Gather Relevant Account and Transaction Information**
   - Request the player to provide a screenshot of the deposit receipt, including sender and recipient information (e.g., GCash/PayMaya details), if applicable, to verify deposits.
   - Review the account’s betting history, recent activity, and any relevant transaction logs.

3. **Conduct System-based Checks for Irregular or Abnormal Activity**
   - Verify if the system has detected irregular betting or illicit profits in the account.
   - Confirm whether abnormal betting or profits were identified by the system and if profits have been automatically deducted as per policy.

4. **Evaluate the Findings Against Platform Policy**
   - Determine if the activity involved irregular betting, arbitrage, or illicit gains.
   - Recall that profits gained from irregular or abnormal betting activities, including arbitrage, may be deducted according to the platform policy.
   - Check if the detected activity aligns with the rules for illicit or suspicious activity as per the internal review.

5. **Inform and Communicate with the Player**
   - If applicable, explain that the system has detected irregular or abnormal betting activity and that profits from such activities may be deducted.
   - Emphasize that the platform reserves the right to review accounts and adjust profits for security reasons.
   - If requesting additional information or clarifications, ensure the player provides all necessary documentation promptly.

6. **Take Administrative and System Actions**
   - If irregular or suspicious activity is confirmed and profits are detected, process deductions of illicit or abnormal profits as per platform policy.
   - Keep detailed records of the detection, review, and actions taken for future reference and audits.
   
7. **Escalation and Further Review**
   - If the system detects activity that warrants further investigation or if there is any ambiguity, escalate the case to the compliance or security team for unified assessment.
   - Follow internal guidelines for escalation based on detected activity severity.

8. **Close the Case**
   - Communicate the resolution to the player, clarifying any deductions or account restrictions applied.
   - Confirm the player understands the platform’s stance on irregular betting and the measures applied.
   - Log all actions taken, correspondence, and outcomes in the case record.

## Notes
- Always verify deposit receipts with clear sender and recipient information when handling deposit-related inquiries.
- Profits gained from irregular betting or arbitrage, if detected, will be deducted according to the platform policy.
- The system automatically detects abnormal betting and can deduct profits associated with such activity.
- Maintain respectful and clear communication with players about detected irregular activity and related policies.

## Key points for communicating with players
- Clearly explain that the platform monitors betting activity for irregularities to maintain security.
- Inform players that detected irregular or abnormal activity may result in the deduction of profits.
- Emphasize the platform’s right to review and adjust accounts if suspicious or illicit activity is confirmed.