# Platform Rules & General Information - Reward Claiming and Redemption Procedures

## Steps

1. **Identify the specific reward the player is inquiring about**, such as the Every 3rd Monthly Rewards, VIP Weekly Salary, or Sunday Weekly Gifts.  
   - Clearly determine the reward type to proceed correctly.

2. **Request the player’s account details**, including login information, to verify their identity and access their Rewards Center.

3. **Check the current date and time in GMT+8 timezone**.  
   - Confirm whether the player is eligible to claim the reward based on the designated claim window:
     - For **Every 3rd Monthly Rewards**: between 22:00 - 23:59 on the 3rd of the month.
     - For **VIP Weekly Salary**: every Wednesday between 22:00 - 23:59.
     - For **Sunday Weekly Gifts**: every Sunday between 22:00 - 23:59.

4. **Verify the player's qualification criteria for the specific reward**:
   - For **Every 3rd Monthly Rewards**: ensure the player logs in and claims during the correct date and time window; only one claim per player is allowed.
   - For **VIP Weekly Salary**:
     - Confirm the player has completed at least one valid bet on slot or fish games within the current week.
     - Check that the player has made a minimum deposit of 100 PHP during the week to qualify for the VIP Weekly Salary.
   - For **Sunday Weekly Gifts**:
     - Confirm the claim is made on Sunday within the time window.
     - Verify the claim has not been made previously this week.
     - Note that rewards are random and can be up to 699,999 PHP.

5. **Check for repeated claims involving the same IP address, bank card, or phone number**:
   - If a repeated claim is detected:
     - Inform the player that both the rewards and profits for the claim will be confiscated.
     - Escalate to the relevant department if needed.

6. **Instruct the player to log into the Rewards Center**:
   - Guide them on how to navigate to the Rewards Center.
   - Confirm if the reward is available for claiming.

7. **Assist the player in claiming the reward**:
   - For **Monthly Rewards and Sunday Gifts**: click the claim button during the specified time window.
   - For **VIP Weekly Salary**: verify the reward has been credited automatically every Wednesday.

8. **Verify the success of the claim**:
   - Ensure the reward appears in the Rewards Center.
   - Confirm the player received the reward amount.

9. **Advise the player**:
   - That rewards are only claimable once per eligible period.
   - Repeated claims from the same IP, bank card, or phone number will lead to confiscation.

10. **If the player reports not receiving the reward or claims an issue**:
    - Check the system logs to verify eligibility, claim timing, and whether the reward was successfully credited.
    - Inform the player if they did not meet the criteria (e.g., no valid bet for VIP Salary, claiming outside valid window).
    - Escalate the case if there appears to be a system error.

## Notes

- Rewards are only available for claiming during the specified time frames.
- Repeated claims from the same IP address, bank card, or phone number are strictly monitored and will result in confiscation of rewards and profits.
- For VIP Weekly Salary, the player must complete at least one valid bet within the week to qualify; failing to do so means they did not meet the criteria.
- Rewards can be random (up to 699,999 PHP for Sunday Gifts), but eligibility and claim timing are strictly enforced.

## Key points for communicating with players

- Clearly specify claim times and restrictions.
- Remind players they can only claim once per period.
- Warn about the consequences of repeated claims from the same IP, bank card, or phone number.
- Confirm player qualification criteria before processing claims.
- Escalate queries about unsuccessful claims or technical issues according to the escalation procedures.