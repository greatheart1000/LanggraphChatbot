# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Identify the player's inquiry or issue**  
   - Determine if the player is asking about account access, profile management, or policy violations.  
   - Clarify the specific concern or question.

2. **Check if the player requests account deletion**  
   - Inform the player that accounts cannot be deleted.  
   - Advise creating a new account if necessary.  
   - End the case if this is their request.

3. **Verify player's account details**  
   - Collect necessary information such as username, email, or registered phone number for identification.  
   - Confirm the player's identity as per standard verification procedures.

4. **Assess the nature of the inquiry**  
   - If the player inquires about account access issues (e.g., login problems):  
     - Check if the player has the correct login credentials and the account status in the system.  
     - Advise on resetting login details if applicable, following the site's standard process.  
   - If the player reports policy violations or suspicious activity:  
     - Gather detailed information about the incident or behavior.  
     - Document the report for further review.

5. **Address file upload or attachment issues**  
   - If the player mentions difficulty with attachments:  
     - Verify that the file size does not exceed 10MB.  
     - Advise the player to reduce file size if necessary.

6. **Determine if any actions are required based on the account status**  
   - For account access issues:  
     - Confirm account details and guide the player on next steps (e.g., password reset).  
   - For policy violations:  
     - Follow internal procedures for reviewing and handling policy breaches.  
   - If player asks about transferring balance or deleting:  
     - Clearly inform them that fund transfers between accounts are not permitted and accounts cannot be deleted.  

7. **Provide guidance on app usage and promotions**  
   - If the player asks about accessing promotions or bonuses:  
     - Inform them that promotions and bonuses may require downloading the PHLOVE Official App.  
     - Encourage downloading the app to stay updated.

8. **Escalate or close the case**  
   - If further investigation is needed, escalate according to company protocols.  
   - If issue is resolved, confirm the resolution with the player and close the case.

## Notes
- Always verify the specific details and conditions according to the player's account information.  
- Remind players that account deletion is not possible; creating a new account is the alternative.

## Key points for communicating with players
- Clarify that accounts cannot be deleted.  
- Emphasize the importance of security and confirmation of account details before proceeding with any actions.  
- Make players aware of file size restrictions (10MB for attachments).  
- Highlight that fund transfers between accounts are not allowed.  
- Inform players about the app requirement for accessing certain promotions and bonuses.