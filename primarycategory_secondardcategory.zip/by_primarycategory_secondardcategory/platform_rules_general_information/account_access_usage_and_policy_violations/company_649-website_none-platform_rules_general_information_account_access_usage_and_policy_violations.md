# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Receive the player’s inquiry or report regarding account access, restrictions, or violations.**
   - Ask the player to provide their full account details, including username and registered email address.
   - Inquire if the player has created multiple accounts or used multiple accounts from the same IP address, if relevant.

2. **Verify the account status and check system restrictions.**
   - Search for the account in the back office system.
   - Check if the account has been automatically blocked or restricted due to policy violations, such as multiple accounts from the same IP address or multiple accounts under the same name.
   - Determine if the account has been flagged for policy violations related to account creation rules.

3. **Assess account deletion eligibility (if requested by the player).**
   - Confirm if the account has had any deposits made in the past two months.
   - If no deposits were made within this period, the account will be automatically deleted; inform the player accordingly.
   - If deposits exist within the last two months, explain that account deletion cannot be processed.

4. **Review for multiple accounts or account creation from the same IP.**
   - Check if multiple accounts exist under the same name; if so, inform the player that only one account per person is permitted and any duplicates will be blocked.
   - Check if multiple accounts have been created from the same IP address; if so, inform the player that the system may have automatically blocked or restricted these accounts to prevent multiple accounts, per policy.
   - If accounts are blocked due to these reasons, clarify that blocked accounts cannot be reopened and advise on proper account management.

5. **Provide resolution or further instructions based on the findings.**
   - If a player’s account has been blocked or restricted for policy reasons, explain that the system enforces rules such as one account per person and restrictions on multiple accounts from the same IP.
   - If the account qualifies for deletion due to inactivity and no recent deposits, confirm that the deletion will be processed automatically.
   - If the player’s issue involves multiple accounts or IP-related restrictions, advise them to use a single account from a single device/IP to avoid further restrictions.
   - For account-related concerns not covered here, recommend contacting support with detailed information for further investigation.

6. **Document all steps and communications in the case ticket.**

## Notes

- Accounts may be automatically blocked if multiple accounts are detected from the same IP or under the same name.
- Accounts cannot be deleted if there have been deposits in the past two months; otherwise, they are automatically deleted after two months of inactivity.
- Use a single account per user to adhere to the policy.
- Blocked accounts cannot be reopened; players should be advised to use only one account from a single device/IP.

## Key points for communicating with players

- Clearly explain that policy prohibits multiple accounts from the same IP address and under the same name.
- Inform players about the automatic system restrictions and potential account blocks.
- Emphasize that accounts with recent deposits cannot be deleted.
- Encourage players to comply with the single account policy to avoid restrictions.