# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Receive and review the player's inquiry or report regarding account access or policy violations.**  
   - Identify whether the player is reporting an issue (e.g., account suspension, suspected arbitrage) or requesting account deletion or transfer.

2. **Verify the player's identity and account details.**  
   - Collect the player's registered username, email, and any relevant account identifiers.
   - Confirm the current account status in the system.

3. **Determine if the issue is related to policy violations or suspicious activities.**  
   - Check if the account has been suspended or banned:  
     - Recall that PHWIN reserves the right to suspend or terminate accounts for policy violations.  
   - Look for signs of malicious arbitrage or irregular betting activities:  
     - Illicit arbitrage detection may lead to deductions of illicit profits and account restrictions or suspension.

4. **If the player reports an account transfer or migration:**
   - Confirm whether their account was transferred from BARAHA.VIP to PHWIN.  
   - Ensure the player has registered a new PHWIN account via official links.  
   - Advise the player to contact PHWIN customer service for assistance with migrating VIP levels, balances, or other details.

5. **Check for multiple accounts from the same IP address if applicable:**  
   - Be aware that creating multiple accounts from a single IP address is monitored.  
   - If multiple accounts are detected, inform the player that commissions earned from those referrals may be deducted in accordance with policy.

6. **Clarify policies regarding account deletion or closure:**  
   - Confirm that account deletion is not permitted; players cannot delete their accounts.  
   - If the player wishes to stop using their account, advise them to simply refrain from logging in, as deletion is not supported.

7. **If the player's account shows suspicious or illicit activity:**
   - Explain that accounts involved in malicious arbitrage or irregular betting activities may have illicit profits deducted, and funds may be forfeited.  
   - Reiterate that all winnings and losses are automatically recorded by the system.

8. **Based on the above findings, determine the appropriate resolution:**
   - If a policy violation or suspicious activity is confirmed:  
     - Inform the player of the suspension or restriction, and explain that further investigation is ongoing or that the account is subject to penalties per site policy.  
   - If the issue is a technical or account access problem without violation evidence:  
     - Provide troubleshooting steps or advise on next suitable action.
   - If the player requests account deletion or transfer outside official procedures:  
     - Clarify that deletion is not allowed and guide according to policy.

9. **Document the case thoroughly in the support system, including:**
   - Player's details
   - Nature of inquiry or violation
   - Actions taken and explanations provided
   - Any evidence or screenshots provided by the player (if applicable)

10. **Close the case with appropriate follow-up instructions or escalation if needed.**  
    - For cases requiring further investigation, escalate to the relevant department.
    - For resolved cases, confirm closure with the player and advise on future compliance with platform rules.

## Notes

- Do not attempt to delete or unblock accounts if prohibited; inform players accordingly.
- Be cautious when discussing specific penalties; always base explanations on official policies.
- Remind players that all activity, winnings, and losses are automatically monitored and recorded by the system.
- Encourage players to adhere to platform policies to prevent account restrictions.

## Key points for communicating with players

- Clearly explain that PHWIN reserves the right to suspend or ban accounts for policy violations.
- Emphasize that account deletion is not allowed; players may only stop using their accounts.
- In cases of detected arbitrage or malicious activity, inform players of deductions and possible restrictions as per policy.
- Provide guidance on proper migration procedures from BARAHA.VIP to PHWIN if relevant, and direct players to customer support for assistance.
- Maintain professionalism and transparency, ensuring players understand the reasons behind account restrictions or actions taken.