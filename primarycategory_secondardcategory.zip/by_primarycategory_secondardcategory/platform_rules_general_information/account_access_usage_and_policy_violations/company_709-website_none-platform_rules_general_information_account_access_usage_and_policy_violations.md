# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Gather player information**  
   - Confirm the player's account details (username, email, or user ID).  
   - Verify the specific issue or question regarding account access, usage, or policy violation.

2. **Identify access issues or violations**  
   - If the player reports difficulty accessing the website, inform them of alternative URLs:  
     - https://5jollyph.com  
     - https://6jollyph.com  
     - https://7jollyph.com  
     - https://8jollyph.com  
     - https://9jollyph.com  
     - https://1jollyph.com  
   - If the player references policy violations related to account behavior or multiple accounts, proceed to the relevant checks.

3. **Check for multiple accounts or referral-based violations**  
   - Review the system for multiple accounts originating from the same IP address linked to the player's referral link.  
   - Confirm if multiple accounts or suspicious activity are detected.  
   - Note: Policy states that creating multiple accounts from the same IP address using the referral link results in deduction of earned commissions, and rewards/profits may be confiscated.

4. **Assess account status and behavior policies**  
   - Verify whether the account has been suspended or terminated, especially if related to inappropriate language or behavior.  
   - Inform the player that accounts cannot be deleted, only created anew if they no longer wish to use the service.

5. **Explain website access options**  
   - If the player cannot access the main site, advise using any of the alternative URLs listed above.  
   - Confirm whether the player can now access the platform.

6. **Clarify policy on account behavior**  
   - Inform the player that inappropriate language or conduct that violates the platform’s policies may lead to account suspension or termination.  
   - Reinforce that the platform reserves the right to take such actions.

7. **Document the case and next steps**  
   - Record findings, especially if access is restored via alternative URLs or if violations are confirmed.  
   - If further escalation is needed, follow the internal escalation procedures as per the company's protocol.

## Notes

- Accounts cannot be deleted; players must create a new account if they wish to stop using the service.  
- Multiple account detection from the same IP can lead to confiscation of commissions and rewards.  
- Always confirm the latest official URLs if players report access issues, as they may change according to site updates.

## Key points for communicating with players

- Clearly state the available alternative URLs for website access.  
- Explain the policy regarding multiple accounts and referral link violations concisely.  
- Remind players that accounts cannot be deleted, only created anew if they wish to cease using the service.  
- Be transparent about possible consequences for violating platform rules, especially related to inappropriate language and multiple accounts.