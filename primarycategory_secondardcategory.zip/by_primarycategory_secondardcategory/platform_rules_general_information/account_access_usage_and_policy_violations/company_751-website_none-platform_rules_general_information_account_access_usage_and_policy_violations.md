# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Receive the player's inquiry or report** related to account access, usage, or policy violations.

2. **Gather necessary information from the player**, including:
   - Whether they are asking about account creation, deletion, deactivation, or access issues.
   - If they suspect multiple accounts, ask if they or the referring party have created multiple accounts.
   - Confirm the player's current location or device details, especially if they are outside the Philippines.
   - Request any relevant screenshots, especially if access issues are reported.

3. **Check if the player’s concern involves account creation or management**:
   - If the player asks about deleting or deactivating their account, inform them that **account deletion/deactivation is not possible** to prevent fraudulent activities.
   - Advise them that they may choose not to log in, which will prevent further access.

4. **Verify account activity and registration details**:
   - Check for multiple accounts associated with the player's details and IP addresses from the back office system.
   - Confirm if multiple accounts have been created from the same IP address using referral links; **this violates site policy**.
     - If so, inform the player that commissions earned from those referrals will be deducted as per policy.
     - No further action is needed if this is the case; explain the policy clearly.

5. **For players outside the Philippines seeking access to PHJOY**:
   - Confirm if they are located outside the Philippines.
   - If yes, instruct them to use a **VPN** connecting to a server in the Philippines to access the game.
   - Verify if they are using the official URLs or the provided alternative URLs:
     - Alternative URLs include: phjoy11.com, phjoy22.com, phjoy33.com, phjoy44.com.
   - Advise them to switch to one of these URLs if they encounter access difficulties.

6. **Handle access issues**:
   - If the player cannot access the website, recommend trying the alternative URLs.
   - If the problem persists, verify if their IP address or network could be blocking access.
   - Suggest using a VPN if outside the Philippines when needed.

7. **Address policy violations or misconduct**:
   - Inform the player that inappropriate or abusive language on the platform can result in **account suspension or termination**.
   - Clarify that violations of the platform rules may lead to penalties according to site policy.

8. **Document all findings and actions**:
   - Record the player's details, issue specifics, any system checks performed, and advice given.
   - Escalate to relevant departments if the inquiry involves technical or account security issues.

9. **Close the case**:
   - Confirm the player understands any policies or actions taken.
   - Offer further assistance if needed.
   - Encourage the player to reach out again if issues persist.

## Notes

- Accounts cannot currently be deleted; users must simply cease logging in if they want to stop using the service.
- Multiple accounts from the same IP using referral links are against policy; commissions will be deducted accordingly.
- Use a VPN for players outside the Philippines seeking access to PHJOY.
- Inappropriate behavior may lead to account suspension or outright termination.

## Key points for communicating with players

- Clearly explain that account deletion/deactivation is not available.
- Emphasize that creating multiple accounts from the same IP using referral links violates policies.
- Guide players on using official URLs or alternative links if they encounter access problems.
- Advise on using VPN if outside the Philippines to access the platform.
- Remain professional and transparent regarding policy violations and consequences.