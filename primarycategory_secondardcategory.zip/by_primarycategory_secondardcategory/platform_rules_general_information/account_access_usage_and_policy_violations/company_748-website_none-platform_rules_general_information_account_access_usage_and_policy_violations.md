# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Receive the player's inquiry or report regarding account access, usage, or policy violations.**  
   - Collect the player's identifiable information (username, email, phone number if applicable).  
   - Note the specific concern or question raised by the player.

2. **Verify the player's account status and activity.**  
   - Access the back-office system to locate the player’s account details.  
   - Check for any recent account activity that may indicate multiple accounts.

3. **Determine if the concern relates to account creation from the same IP address or multiple accounts.**  
   - Check if the player has created multiple accounts from the same IP address.  
   - Cross-reference if multiple accounts are using the same referral link, bank card, or phone number, as these are also indicators of violations.

4. **Assess whether any policy violation applies based on the account data.**  
   - If multiple accounts are found created from the same IP address with the same referral link, bank card, or phone number, recognize this as a violation of site policy.  
   - Confirm that no other legitimate reasons justify the account activity.

5. **Inform the player of the findings and policy consequences.**  
   - Clearly explain that creating multiple accounts from the same IP address using referral links or payment details violates the platform’s policy.  
   - Advise that commissions earned from such referrals will be deducted as per site policy.

6. **If policy violation is confirmed, proceed with appropriate actions.**  
   - Deduct commissions earned from the referral activities associated with the violation.  
   - Take any necessary internal steps to prevent further policy breaches, such as flagging the accounts or restricting access if required.

7. **If the player reports difficulty accessing the platform and requests alternative URLs:**  
   - Provide approved alternative URLs: 7phspin.com, 9phspin.com, 1phspin.com, 2phspin.com.

8. **For cases involving inappropriate language or conduct:**  
   - Inform the player that using inappropriate language violates the platform rules.  
   - Confirm that the account may be suspended or terminated if violations persist, following the platform’s policy.

9. **Record all findings and actions taken in the case file and escalate if necessary.**  
   - Document the nature of the violation, steps taken, and communication with the player.

## Notes

- Creating multiple accounts from the same IP address using referral links, bank cards, or phone numbers is explicitly considered a policy violation, with deductions made from earned commissions.  
- Always verify details against system records before taking punitive or corrective actions.  
- Providing alternative website URLs is permitted if the player faces access issues.

## Key points for communicating with players

- Clearly explain the violation concerning multiple accounts from the same IP or linked payment methods.  
- Reiterate that commissions from such referrals will be deducted per policy.  
- Offer alternative URLs if access issues are reported.  
- Emphasize that use of inappropriate language may result in account suspension or termination, following site rules.