# Platform Rules & General Information - Account Access, Usage, and Policy Violations

## Steps

1. **Identify the player's concern related to account access or policy violations.**  
   - Determine whether the issue relates to site access, account suspension, suspected policy violation, or other account-related problems.

2. **If the player cannot access LOVEJILI or the site is blocked:**
   - Ask the player which URLs they have tried.
   - Recommend trying alternative URLs: 9lovejili.com, 1lovejili.com, 2lovejili.com, 3lovejili.com.
   - Advise the player to check their network settings, firewall, or VPN connection if access remains blocked.
   - If access issues persist after trying alternative URLs and network troubleshooting, instruct the player to contact support with details of the problem.  
   *Note: Do not attempt to unblock or override system restrictions.*

3. **If the account has been flagged or suspected of a policy violation (e.g., arbitrage or cheating):**
   - Inform the player that bonuses and profits tied to the violation may be deducted by the system.
   - Clarify that engaging in malicious arbitrage or cheating will lead to deductions and potential suspension or termination.
   - Explain that the platform reserves the right to suspend or terminate accounts for policy violations, including inappropriate conduct or fraudulent behavior.

4. **If the player has multiple accounts or creates multiple accounts from the same IP or using their referral link:**
   - Check the system for detection of multiple accounts linked to the same referral, IP, or originating from the same device.
   - Inform the player that if multiple accounts are detected using their referral link or from the same IP, commissions earned may be deducted.
   - Advise the player to use unique and accurate information for each account and link them properly to avoid penalties.

5. **If the player’s account is suspected of violating policies (e.g., through inappropriate language or fraudulent conduct):**
   - Verify the nature of the conduct and determine if it breaches platform policies.
   - If the conduct is inappropriate or fraudulent, inform the player that their account may be suspended or terminated according to platform rules.
   - If evidence of cheating, arbitrage, or malicious behavior is found, notify the player that bonuses and profits from such behavior may be deducted, and the account may be suspended or terminated.

6. **Conclude the interaction by advising the player on next steps:**
   - For access issues: suggest network troubleshooting or alternative URLs.
   - For violations or suspected policy breaches: inform the player about potential deductions and possible account actions.
   - If needed, escalate the issue to a supervisor or the system for further investigation, especially in cases of suspected policy violations or complex access problems.

## Notes

- Always verify the URL and network status before suggesting further action.
- Clear communication about policy breach consequences helps prevent misunderstandings.
- Maintain professionalism when discussing potential penalties or account suspensions.

## Key points for communicating with players

- Emphasize understanding and clarify that access issues are often network-related.
- Explain that violations like arbitrage, cheating, or inappropriate conduct may lead to deductions, suspension, or termination.
- Reinforce the importance of using unique account information to avoid detection and penalties.
- When in doubt, escalate or seek approval from a supervisor.