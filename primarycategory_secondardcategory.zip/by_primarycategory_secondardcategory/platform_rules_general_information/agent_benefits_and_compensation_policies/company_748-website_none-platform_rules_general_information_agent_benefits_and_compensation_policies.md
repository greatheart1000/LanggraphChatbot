# Platform Rules & General Information - Agent Benefits and Compensation Policies

## Steps

1. **Identify the nature of the inquiry**  
   - Determine whether the customer is asking about becoming an agent/partner, commission structure, claiming credits, or communication policies.

2. **If the player enquires about becoming an agent/partner**  
   - Inform them to:  
     a) Click on the "Agent" link/button on the homepage.  
     b) Copy their referral link.  
     c) Share the referral link across social media platforms such as Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.  
   - Clarify the commission structure:  
     - 208 PHP for every valid invite  
     - 0.80% of each downline’s deposit  
     - 0.38% of each downline’s bet  
     - Up to 8,800,000 PHP for tier reach  
   - Confirm that a referral is considered valid only after the downline deposits a minimum of 200 PHP.  
   - Advise that commission can be claimed every day at 00:30 AM (GMT+8) after the downline has deposited and betted.

3. **If the customer inquires about the partner program commission structure**  
   - Reiterate the same details:  
     - Each valid invite earns 208 PHP.  
     - Downline deposit earns 0.80%.  
     - Downline bet earns 0.38%.  
     - Tier reach can accumulate up to 8,800,000 PHP.  
   - Emphasize the condition that the referral must deposit at least 200 PHP to be valid.  
   - Explain how and when to claim commissions: in the Bonus Center, typically after deposits/bets, around 00:30 AM GMT+8.

4. **If the inquiry relates to claiming credits or bonuses**  
   - Confirm that free credits are automatically credited to the player's account once the system verifies eligibility.  
   - No manual claiming process is necessary.

5. **If the customer has questions about policies on communication or conduct**  
   - Advise them that respectful and professional communication is required.  
   - Make them aware that inappropriate language or disrespect may lead to suspension or termination of their account.

6. **Perform necessary checks based on the system and FAQ guidelines**  
   - For commission-related inquiries, verify if the referral has deposited at least 200 PHP.  
   - Check the deposit and betting history of the downline to confirm eligibility.  
   - Evaluate if the commission period (around 00:30 AM GMT+8) has passed for the current day to process pending earnings.  
   - For credits, confirm eligibility and system status; no further action should be needed.

7. **Provide the appropriate resolution**  
   - Confirm eligibility and inform the customer of their current standing.  
   - For commission claims, instruct them to view their earnings in the Bonus Center and advise on the usual claim time.  
   - For ineligible referrals or transactions, explain the specific reason based on the deposit threshold or system status.

8. **If escalation or further action is needed**  
   - Advise the customer to contact support with relevant details or screenshots if issues persist.

## Notes

- Always verify if the referral deposit reaches the minimum of 200 PHP for validity.  
- Commission can only be claimed in the Bonus Center after the downline has deposited and bet.  
- The typical payout timestamp for commissions is around 00:30 AM GMT+8 following the deposit/bet activity.  
- Respectful communication with support is mandatory; violations may result in account suspension or termination.

## Key points for communicating with players

- Remind players that free credits are automatically credited once system eligibility is confirmed.  
- Reinforce the importance of the minimum deposit (200 PHP) for referral validation.  
- Clarify the timing and conditions for commission claims.  
- Encourage respectful dialogue and professionalism when discussing policies or resolving issues.