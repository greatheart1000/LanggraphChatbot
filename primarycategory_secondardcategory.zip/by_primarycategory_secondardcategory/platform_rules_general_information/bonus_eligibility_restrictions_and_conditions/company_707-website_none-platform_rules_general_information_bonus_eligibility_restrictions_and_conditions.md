# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry or report about bonus issues.**  
   - Collect relevant account information, especially the account ID or username.

2. **Verify the player's account details and eligibility:**
   - Ensure the account is legitimate and operating under a legitimate license (e.g., PAGCOR license in the Philippines).
   - Confirm the account has linked a valid mobile phone number.
   
3. **Check for common reasons why a player might not receive a bonus:**
   - Ask if the player has used the same bank card across multiple accounts.
   - Confirm whether the player has linked a mobile phone number to their account.
   - Verify if the player has used the same or multiple phone numbers on different accounts.
   
4. **Investigate account activity and system data:**
   - Review account registration details and linked contact information.
   - Check for multiple accounts from the same IP address.
   - Ensure the same bank card and phone number are not used across multiple accounts.
   
5. **Determine player eligibility based on the collected information:**
   - If the account has no issues with linked phone number or bank card, proceed to verify bonus-specific conditions.
   - If multiple accounts are linked via the same bank card or phone number, or multiple accounts have the same IP address, inform the player that bonus eligibility may be affected and cannot be granted in these cases.
   - Confirm that referral accounts (if applicable) have reached a total deposit of 200 PHP and comply with conditions such as no multiple registrations, binding of the same bank card, or using the same phone number/IP address.
   
6. **For players participating in the Weekly Thursday Gifts:**
   - Confirm the player logs in between 22:00 and 23:59 GMT+8 on a Thursday.
   - Verify the player has downloaded the official app.
   - Note that rewards can be up to 188,888 PHP.
   - Inform the player that repeated use from the same IP, bank card, or phone number may result in confiscation of the reward.

7. **Explain the outcome to the player:**
   - If the player's account meets all conditions but still does not receive the bonus, inform them that system detections (e.g., identical IP, bank card, or phone number) may restrict bonus eligibility.
   - If any issues are detected (e.g., same bank card or phone number used across multiple accounts), clearly communicate that these conditions may prevent bonus assignment due to security and anti-fraud measures.

8. **If necessary, advise the player on corrective actions:**
   - If the issue involves account setup (e.g., multiple accounts linked with the same bank card or phone number), inform the player that resolving these issues is necessary for future bonus eligibility.
   - No bonus can be issued if system rules are violated; encourage adherence to the platform’s policies for eligibility.

9. **Escalate if needed:**
   - If the case involves potential eligibility disputes, suspicious activity, or requires further verification, escalate following internal protocols.

## Notes
- Bonuses are not offered for birthdays.
- System is designed to detect and possibly confiscate rewards if repeated use from the same IP, bank card, or phone number is identified.
- All verification must comply with site-specific and legal standards, especially regarding legitimate licensing and responsible gaming.

## Key points for communicating with players
- Clearly explain that bonus eligibility depends on account details, including linked phone number, bank card, IP address, and deposit activity.
- Emphasize the importance of using unique contact information and avoiding multiple accounts with the same details.
- Remind players that system detections may restrict bonus claims, and that eligibility rules are strictly enforced to ensure fair play.