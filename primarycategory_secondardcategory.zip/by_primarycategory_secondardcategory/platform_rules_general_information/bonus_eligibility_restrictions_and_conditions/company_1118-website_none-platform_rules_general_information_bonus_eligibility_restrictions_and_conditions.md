# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry regarding bonus eligibility**  
   - Determine which bonus the player is referring to (e.g., First Deposit Bonus, Rescue Fund, or other).  
   - Clarify if the player is inquiring about the First Deposit Bonus or another promotion based on their situation.

2. **Verify player's account information and history**  
   - Check if the player is requesting the First Deposit Bonus.  
   - Confirm whether the account has already claimed a first deposit bonus or if it is their initial deposit.

3. **Check IP address and device restrictions for bonus eligibility**  
   - Review the system to see if the player's IP address or device has previously claimed the bonus.  
   - Remember that the First Deposit Bonus can only be claimed once per IP address and device.  
   - If the account shares the same IP or device with another account that has claimed the bonus, the player is ineligible.

4. **Determine player's verification status, especially for the First Deposit Bonus**  
   - Confirm if the player has verified their mobile number before making their first deposit.  
   - If the player deposited before verifying their mobile number, inform them they may not be eligible for the bonus.  

5. **Assess bonus-specific eligibility criteria**  
   - For the First Deposit Bonus:  
     - Ensure the player has verified their mobile number prior to deposit.  
     - Confirm that the deposit is the player's first one, and not from a shared IP/device.  
   - For the Rescue Fund:  
     - Verify that the player has deposited ₱2,500 or more and has lost ₱2,500 or more to meet the eligibility.  
     - Confirm that the loss occurred the day before they request the Fund.

6. **Identify why the bonus box might not be visible to the player**  
   - If the bonus box is not visible, check for potential IP or device restrictions, as the same IP or device may only be eligible once.  
   - Clarify whether the player is attempting a deposit from an unverified account or a different device/IP.

7. **Explain the applicable restrictions and conditions to the player**  
   - If ineligible due to sharing IP/device, explain that the bonus can only be claimed once per IP address or device.  
   - If the player deposited before verifying their mobile number, inform them of their ineligibility for the First Deposit Bonus.  
   - Clarify that the birthday bonus is not offered on the site, if asked.

8. **If the player is eligible, guide them to claim the bonus**  
   - Advise the player to verify their mobile number if not done already, before making their deposit.  
   - Ensure the deposit is their first, from a unique IP and device, and that all verification requirements are met.

9. **If the player is ineligible, communicate the reason clearly and politely**  
   - Explain restrictions related to IP or device sharing.  
   - Mention if the deposit was made prior to mobile verification or if other eligibility criteria are not met.

10. **Offer further assistance or escalate if necessary**  
    - If system issues or discrepancies are found, escalate to technical support as per internal procedures.  
    - Provide additional guidance or alternative promotions if applicable and available, noting that specific bonuses (e.g., birthday bonus) are not offered.

## Notes

- Bonus eligibility is tightly restricted by IP address, device, and verification status.  
- The First Deposit Bonus can only be claimed once per IP address and device, and only if mobile verification is completed before deposit.  
- The Rescue Fund requires a deposit of ₱2,500 or more and a loss of ₱2,500 or more, claimable the day after the loss.

## Key points for communicating with players

- Clearly explain that the same IP address or device can only be used to claim the bonus once.  
- Remind players to verify their mobile number before making their initial deposit to qualify for the first deposit bonus.  
- Inform players that no birthday bonus is available on the site.  
- Always verify the timing of deposit and loss for Rescue Fund eligibility.