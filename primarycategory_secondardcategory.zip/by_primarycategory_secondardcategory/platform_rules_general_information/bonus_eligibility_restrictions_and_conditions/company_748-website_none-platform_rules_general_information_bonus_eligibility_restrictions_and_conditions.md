# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Identify the specific bonus the player inquires about** (e.g., Birthday Bonus, Rank Upgrade Bonus, Referral/Invite Bonus).

2. **Gather necessary information from the player based on the bonus type:**
   - For Birthday Bonus:
     - Player's username.
     - Two valid IDs showing the player's birthdate.
     - A selfie of the player holding both IDs, ensuring ID details are clearly visible.
   - For Rank Upgrade Bonus:
     - Player's current VIP level.
     - Details of recent play activity and total bets if verification is needed.
   - For Referral/Invite Bonus:
     - Downline's total deposit amount.
     - Whether the downline's IP address differs from the referrer.
     - Confirmation that the downline has placed bets.
     - The system automatically checks for multiple account registration, same bank card, phone number, or multiple IP addresses.

3. **Perform system checks and verification:**
   - Confirm the player's VIP level; ensure VIP4 or above for Birthday Bonus.
   - Verify the provided IDs and selfie for the Birthday Bonus claim.
   - Check the player's rank requirements and bet history for upgrade bonuses.
   - Verify that the downline's deposit meets the minimum requirement (e.g., 200 PHP) and that IP addresses differ.
   - For referral bonuses, confirm that the deposit and betting activity have been completed, and that no prohibited activity (e.g., same IPs, multiple accounts) is detected.

4. **Determine bonus eligibility:**
   - For the Birthday Bonus:
     - Confirm user meets VIP4 status and has submitted valid documentation.
   - For Rank Upgrade Bonuses:
     - Ensure the required rank requirements are achieved; if not, advise user to continue playing to meet criteria.
   - For Referral/Invite Bonuses:
     - Ensure deposit amount meets minimum, IP address restrictions are observed, and no disqualifying activity is detected.
   - For eligible cases, proceed to manual review or system approval as applicable.

5. **Communicate the outcome to the player:**
   - If eligible, instruct the player on how to claim the bonus (e.g., via Reward Center) or inform them that the bonus has been granted.
   - If ineligible:
     - Explain the specific reason based on the verification results (e.g., VIP level too low, missing documentation, deposit amount insufficient, IP address mismatch, or system detection of prohibited activity).
     - Clarify that bonuses are only available under certain conditions as per the site's rules.

6. **Assist with additional actions if necessary:**
   - Guide the player through submitting required documents.
   - Advise on how to achieve VIP4 status or meet other bonus requirements.
   - Escalate cases with suspicious activity or unclear eligibility issues to the appropriate department for further review.

7. **Close the case once the resolution has been communicated** and any required follow-up instructions are provided.

## Notes

- Always verify player identity and eligibility based on the provided documentation for birthdays.
- Bonus eligibility depends strictly on VIP level, deposit amounts, activity, and system checks for prohibited activities.
- The referral bonus requires a minimum deposit of 200 PHP, differing IP addresses, and no signs of multiple account abuse.

## Key points for communicating with players

- Clearly explain the specific eligibility criteria for each bonus.
- Inform players about required documentation for birthday bonuses.
- Notify players of deposit and activity requirements for referral bonuses.
- Remind players that bonuses are subject to system checks and may be disqualified if prohibited activities are detected.