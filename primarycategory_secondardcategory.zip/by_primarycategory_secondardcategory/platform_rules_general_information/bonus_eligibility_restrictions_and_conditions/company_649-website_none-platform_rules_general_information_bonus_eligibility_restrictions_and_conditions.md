# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Gather player information regarding bonus eligibility:**
   - Confirm if the player is requesting the app download bonus or the 28P Bonus code treat.
   - For app download bonus:
     - Verify if the player registered within the last 7 days.
     - Ask if the bonus is being claimed within 7 days of activation or registration.
   - For 28P Bonus code treat:
     - Ensure the player is aware the bonus is available via GamePH channels at 7 PM on designated days.
   
2. **Check the timing and registration details:**
   - For the app download bonus:
     - Confirm whether the player has completed the 7-day rejection period.
     - Determine if the bonus is being claimed within 7 days of registration.
   - For the 28P Bonus code treat:
     - Verify if the player is redeeming the bonus code during the redemption window.
   
3. **Verify bonus-specific requirements:**
   - For the app download bonus:
     - Confirm that the player has not completed the 7-day rejection period, as completing it makes them ineligible.
     - Check if the bonus has been used within 7 days of activation.
     - Confirm no deposit is required to claim this bonus.
   - For the 28P Bonus code treat:
     - Check if the player’s account is KYC-verified.
     - Confirm a minimum deposit of ₱100.
     - Ensure the mobile number is linked.
   
4. **Perform system and account checks:**
   - Verify the player’s registration date and registration state in the system.
   - For the 28P Bonus code treat, confirm the number of redemptions done by the individual player (limit of 1,500).
   - Confirm the player's eligibility status (e.g., not expired, within the eligibility period).
   
5. **Determine the bonus eligibility outcome:**
   - If the player is eligible based on registration, timing, and specific requirements:
     - Proceed with the bonus process, informing the player of the next steps (e.g., how to claim or redeem).
   - If the player is not eligible:
     - Explain the relevant restrictions clearly, referencing the specific rules:
       - Too late to claim (after 7 days of registration/activation)
       - Completing the rejection period
       - Not meeting KYC, deposit, or other requirements
     - Advise on what they can do to become eligible in future promotions.
   
6. **Guide the player on bonus claiming process:**
   - For the app download bonus:
     - Remind the player to claim within the 7-day window.
     - Confirm that no deposit is necessary.
   - For the 28P Bonus code treat:
     - Instruct the player to redeem the gift code in-app during the specified time.
     - Emphasize that the bonus must be wagered 5x on eligible slots before withdrawal.
   
7. **Close the interaction:**
   - Communicate any additional instructions or restrictions based on system checks.
   - Offer to assist further if needed (e.g., troubleshooting redemption, verifying account details).
   
## Notes
- The app download bonus must be used within 7 days of activation; if the 7-day rejection period is completed, the player is no longer eligible.
- The app download bonus is exclusively for new players who registered within the last 7 days and must be claimed within this period.
- No deposit is required for the download bonus.
- The 28P Bonus code treat is limited to the first 1,500 redemptions per user, available via GamePH channels at 7 PM on designated days.
- Players must meet specific requirements for the 28P Bonus code treat: KYC-verified account, minimum deposit of ₱100, and a linked mobile number.
- All bonuses are subject to standard GamePH terms and conditions.

## Key points for communicating with players
- Clearly ask about registration date and timing of bonus claims.
- Explain restrictions based on the completed rejection period or expiration limits.
- Verify account details diligently before confirming eligibility.
- Reinforce the deadline-sensitive nature of bonus claims (7 days for app download bonus; redemption periods for codes).