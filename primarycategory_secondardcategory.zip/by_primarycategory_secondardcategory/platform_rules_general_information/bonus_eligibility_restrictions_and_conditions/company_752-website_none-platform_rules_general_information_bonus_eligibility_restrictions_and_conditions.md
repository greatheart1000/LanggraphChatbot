# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry regarding bonus eligibility or issues with bonus receipt**.  
   - Collect necessary details such as the player's username, email, and any relevant account information.

2. **Verify the player's account details and registration information**.  
   - Confirm the player's username and registration status.
   - Check if the account is registered under the player's name.

3. **Determine the specific bonus in question** (e.g., first deposit bonus, birthday bonus, referral bonus).  
   - For birthday bonus, verify if the customer is VIP3 level or above.  
   - For referral bonus, confirm if the referred player has deposited at least 200 PHP.

4. **Check the player's eligibility for the bonus based on the following criteria and FAQ conditions**:

   a. **For the birthday bonus**:
   - Confirm if today is the player's exact birthday.  
   - Ensure the player has provided two valid IDs and a selfie holding those IDs, with their name clearly visible and taken from a reasonable distance.  
   - Verify that the player's account is registered under their name.

   b. **For deposit-related bonuses**:
   - Confirm if the account has no violations of bonus rules (e.g., not registered with multiple accounts, same IP address as other accounts, same bank card or phone number used elsewhere).  
   - Check if the player has met the deposit criteria (if applicable) and has not previously received or been disqualified from this bonus.
   - Verify if the bonus distribution system has processed the bonus within the expected timeframe (usually within 12 hours).

   c. **For referral bonuses**:
   - Ensure the referred player has deposited at least 200 PHP.
   - Confirm that the referrer has not created multiple accounts, nor used the same IP address, phone number, or bank card as other accounts involved.

5. **Check for any restriction or activity that invalidates bonus eligibility**, based on the FAQs:
   - Multiple account registrations linked to the same person.
   - Use of the same bank card, phone number, or IP address as other accounts.
   - Referral activity that doesn't meet deposit or other criteria.

6. **Perform system checks**:
   - Access the back office or automatic systems to validate the eligibility.
   - Confirm bonus status and whether the bonus has already been awarded or is pending.

7. **Based on the verification results, determine the appropriate resolution**:

   - **If the player is eligible**:
     - Confirm the bonus should be credited per system processing.
     - Inform the player that their bonus will be credited within the specified timeframe.
     - No further action needed; document the case.

   - **If the player is not eligible due to bonus restrictions**:
     - Clearly explain the reason, referencing specific FAQ conditions:
       - Multiple accounts, identical IP, bank card, or phone number issues.
       - Not meeting deposit thresholds for referral bonuses.
       - Not being VIP3 or above for the birthday bonus.
       - Not following bonus rules (e.g., bet only on slot and fish games for certain bonuses).
     - Request additional proof if necessary (e.g., ID or selfie) if reporting eligibility issues.
     - Advise on the requirement to meet the conditions for future eligibility.

8. **Provide instructions or next steps to the player**:
   - If eligible, reassure that the bonus is being processed and will appear shortly.
   - If ineligible, explain the specific reason politely and suggest corrective actions or future eligibility criteria.

9. **Document the interaction**:
   - Record all relevant details, including player inputs, verification steps, and final outcome.
   - Save any submitted documents, screenshots, or correspondence.

## Notes

- Always verify the eligibility of the bonus based on the exact conditions listed in the FAQs.
- Ensure the player provides all required identification documents for birthday bonus claims.
- Remember that bonuses are only applicable for gambling on slot and fish games; adherence to this rule is necessary.
- Be aware that bonuses may be automatically distributed within 12 hours for deposit-related bonuses if conditions are met.
- Handling referral bonuses requires confirming deposit amount and ensuring no violation of multiple account rules.

## Key points for communicating with players

- Clearly state the specific reason for ineligibility based on the documented rules.
- Politely inform players that only eligible players will receive the bonus.
- Emphasize the importance of adhering to rules such as no multiple accounts, same IP, and correct ID submission for special bonuses like birthday bonuses.
- Encourage players to contact support again after resolving any issues or meeting the requirements.