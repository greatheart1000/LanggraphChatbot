# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry about bonus eligibility or reward status.**  
   - Gather relevant player details: account information, current VIP level, and specific bonus or reward in question.

2. **Verify the player's eligibility for the specific bonus or reward.**  
   - Check the distribution schedule and eligibility rules:
     - For the 14th monthly rewards, verify if the reward was issued on the 14th and if the player qualifies based on system rules.  
     - For weekly or monthly salaries, confirm if the player has met the minimum deposit and betting requirements within the designated period.

3. **Confirm the player's activity and deposit status for bonuses like VIP Salaries.**  
   - Check if the player has placed a valid bet and deposited at least 100 PHP (or the minimum amount specified) within the relevant period.  
   - Ensure that the player’s activity aligns with the bonus eligibility criteria.

4. **For bonuses with claiming periods (e.g., VIP Monthly Salary):**  
   - Verify whether the claiming period is still open.  
   - If the period has ended, inform the player they need to log in during the next available period to claim the bonus.

5. **Determine if the bonus or reward should have been credited automatically.**  
   - Check the Rewards Center or equivalent system to see if the bonus or salary appears there.  
   - If not received, confirm whether the player meets all the eligibility criteria, including activity and deposit requirements.

6. **If the reward is not credited and the player is eligible, advise the player accordingly:**  
   - Confirm whether they have met all requirements, such as placing qualifying bets and deposits within the specified periods.  
   - If all conditions are met but the reward is still missing, escalate the issue to technical support or system team for further investigation.

7. **If the player is not eligible or conditions are unmet:**  
   - Clearly explain the specific reasons for ineligibility based on the recorded activity or system rules, such as unmet deposit/bet thresholds or missed claiming windows.

8. **Document the case and provide any necessary follow-up instructions:**  
   - Suggest checking the Rewards Center periodically during open claiming periods.  
   - Advise the player to ensure their deposits and bets meet the minimum required amounts within the designated period.

## Notes

- The 14th monthly rewards are issued on the 14th of each month; failure to receive them may indicate ineligibility according to the system's rules.
- VIP Monthly and Weekly Salaries are automatically credited if the player has met all required activity, such as placing valid bets and deposits of at least 100 PHP within the period.
- The VIP Birthday Bonus is only available on the player's exact birthdate.
- Regular checks are necessary to confirm whether bonuses have been credited or not, especially around scheduled payout dates.

## Key points for communicating with players

- Always verify and clearly explain the criteria (deposit, betting, timing) that affect bonus eligibility.
- Remind players about specific claiming periods for bonuses like the VIP Monthly Salary.
- When bonuses are not received, check for unmet requirements before suggesting further investigations.
- Keep communication clear, factual, and aligned with the official rules to avoid misunderstandings.