# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Gather Player Information and Clarify the Issue**
   - Ask the player to provide detailed information about their concern related to bonus eligibility or restrictions.
   - If relevant, request additional documentation such as valid IDs, a selfie holding their ID, or other supporting proof if the issue involves verification (e.g., Birthday Bonus claim).

2. **Verify Player Identity and Eligibility Conditions**
   - Confirm the player's VIP level for bonuses tied to VIP tiers (e.g., Birthday Bonus requires VIP4 or higher).
   - For referral-related issues, verify the player's referral status and ensure they meet referral conditions:
     - Referred user has deposited at least 200 PHP.
     - No multiple accounts registered for the player.
     - Check for absence of duplicate banking details, phone numbers, or IP addresses linked to multiple accounts.
   - For bonus claims like Birthday Bonus, confirm the player has provided the necessary validation documents and the correct birth date.

3. **Check for Account Violations or Illicit Activities**
   - Review system alerts and logs for illicit activity or arbitrage attempts.
   - Determine if the account has engaged in multiple account registration, sharing bank cards, phone numbers, or IP addresses with others.
   - Remove any illicit profits as per policy if such activities are detected.
   - Escalate to compliance or relevant department if suspicions or violations are confirmed.

4. **Assess Bonus and Referral Eligibility**
   - Confirm that the player's activity meets required conditions:
     - For referral bonuses, validate deposit amount (e.g., minimum 200 PHP) and check for multiple account or shared details across accounts.
     - For weekly salaries or bonuses, verify deposit and turnover requirements have been fulfilled; bonuses are automatically sent every Sunday between 22:00 and 23:59 GMT+8.
     - For special bonuses like Birthday Bonus, ensure the player is VIP4 or higher, and that appropriate documentation has been provided before their birthday.

5. **Determine the Appropriate Resolution**
   - If all conditions are met and the bonus or payout is qualified:
     - Inform the player that the bonus or payout will be processed as per schedule.
   - If eligibility conditions are not met (e.g., multiple accounts, missing documentation, or account violations):
     - Clearly communicate which criteria are not satisfied.
     - Explain that the bonus cannot be granted due to these restrictions.
     - Advise the player on necessary steps to qualify in the future, if applicable.

6. **Record and Escalate if Necessary**
   - Log the case details, including the player's account information, the reason for denial or restriction, and any identified violations.
   - If the case involves suspicious activity or potential fraud, escalate to the appropriate senior team or compliance department following internal procedures.

7. **Close the Case**
   - Confirm the resolution with the player.
   - Provide clear instructions or guidance if further action is necessary.
   - Document the interaction for future reference.

## Notes
- Bonus eligibility can be affected by multiple account registrations, shared bank cards, phone numbers, or IP addresses.
- Weekly bonuses are distributed automatically on Sundays if requirements are met.
- For special bonuses such as the Birthday Bonus, player must be VIP4 or higher and provide valid identification with a selfie.
- Any detected illicit activity or arbitrage will result in profits being deducted and possible further action.

## Key points for communicating with players
- Be clear and polite, explaining specific reasons related to eligibility restrictions.
- Refer to the current site policies and official conditions for bonus and referral rules.
- Ensure the player understands their status and any actions needed to qualify in future instances.