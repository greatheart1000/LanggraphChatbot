# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry or request related to bonus eligibility or restrictions.**

2. **Collect necessary information from the player:**
   - Verify the player's account details, including account registration details.
   - Confirm whether the player has multiple account registrations.
   - Ask if the player has bound the same bank card to multiple accounts.
   - Inquire if the player has a mobile phone number registered.
   - Check if the player is using the same or multiple IP addresses.
   - For bonus-specific cases such as the Birthday Bonus, confirm if the player has achieved VIP4 status.
   - For DawnLoud app bonus, verify if the player has registered on the official website and downloaded the app.

3. **Perform account system checks based on the provided information:**
   - Review account registration and linking data for multiple accounts and bank card bindings.
   - Check system logs for IP addresses and device information to detect potentially linked accounts.
   - Determine if the account’s activity has been flagged as malicious arbitrage or irregular betting.
   - For Birthday Bonus eligibility, verify VIP4 status and review submitted identification.

4. **Assess bonus eligibility based on the collected information:**
   - If multiple accounts, linked bank cards, missing mobile number, or using the same or multiple IP addresses are detected, clearly inform the player that they may be ineligible for bonuses.
   - If the player is requesting the Monthly Pay-day Bonus, clarify that it is credited automatically every 15th of the month between 22:00 and 23:59 GMT+8, and that logging in on that day is required to receive it.
   - For Birthday Bonus, confirm if the player meets the VIP4 requirement and has submitted the necessary IDs and selfie with valid ID, and inform about the documentation process.
   - For DawnLoud app bonus, confirm registration, app download, and inform the player it will be sent to the Rewards Center within about 2 hours, which they can claim by clicking "Claim."
   - For any detected malicious arbitrage, explain that profits may be deducted and account restrictions may be applied according to system detection.

5. **Determine the appropriate resolution or explanation based on the checks:**
   - If the player is eligible, process the bonus or inform them of the upcoming automatic credit (such as the monthly bonus or DawnLoud bonus) or necessary steps to claim (e.g., Rewards Center).
   - If the player is ineligible, clearly explain which rules or restrictions apply (e.g., multiple accounts, binding the same bank card, IP address issues) based on the detected violations, referencing the applicable FAQ.
   - If documentation or further verification is needed (like for Birthday Bonus), instruct the player on how to submit the required ID documents.

6. **Advise the player on next steps or actions:**
   - For eligible players awaiting bonus credit, inform them about the timing (e.g., 15th of the month for the Monthly Pay-day Bonus, about 2 hours for DawnLoud bonus).
   - For players submitting documents, guide them on how and where to upload the required IDs.
   - For ineligible players, reinforce the reasons and suggest compliance to meet future eligibility criteria.

7. **Record the case and any findings in the system for future reference and follow-up.**

## Notes
- The Pay-day Monthly Bonus is credited automatically every 15th between 22:00 and 23:59 GMT+8; players need to log in on that day to receive the reward.
- Bonus eligibility may be affected by multiple accounts, linked bank cards, missing mobile numbers, or use of the same/multiple IP addresses.
- For the Birthday Bonus, players must be VIP4 and submit two valid IDs plus a selfie holding a valid ID.
- Profits from malicious arbitrage detected through automated systems may be deducted, and the account may face restrictions.
- The DawnLoud app bonus is sent automatically to the Rewards Center within about 2 hours after registration and app download, and players must claim within the Rewards Center.

## Key points for communicating with players
- Clearly state the basis for bonus eligibility or ineligibility according to site policies.
- Confirm the timing and method of bonus delivery.
- Guide players on required documentation and how to submit it.
- Be transparent about system detections of irregular activity and consequences.
- Ensure players are aware of the need to log in or complete app downloads to receive bonuses.