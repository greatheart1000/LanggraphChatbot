# Platform Rules & General Information - Bonus Eligibility Restrictions and Conditions

## Steps

1. **Receive the player's inquiry about bonus eligibility.**
   - Collect the player's account details, including:
     - Bank card information
     - Phone number
     - IP address
   - Ask if they have recently received specific bonuses (e.g., referral, first deposit, birthday) or if they are inquiring about general bonus eligibility.

2. **Verify the player's identity and account status in the system.**
   - Check if the account is active and properly registered.
   - Confirm the VIP level if relevant (e.g., for birthday bonus eligibility, only VIP3 players qualify).

3. **Assess potential violations of bonus eligibility conditions based on provided information.**
   - Check for multiple account registrations under the same phone number or bank card.
   - Determine if the same bank card is bound to multiple accounts.
   - Verify if the same phone number is used across accounts.
   - Examine IP address consistency:
     - Confirm whether the same or multiple IP addresses have been used for account creation or activity.

4. **Evaluate specific bonus eligibility conditions:**
   - For **Referral Bonus**:
     - Confirm that the referee's total deposits have reached 200 PHP.
     - Ensure there are no violations such as multiple accounts, same bank card binding, same phone number, or IP address issues.
   - For **Weekly Thursday Rewards**:
     - Confirm whether the player attempted to claim the reward during the specified timeframe (22:00 to 23:59 GMT+8).
     - Check if the reward has already been issued to the player.
   - For **First Deposit Bonus**:
     - Verify the absence of violations:
       - Same bank card across accounts
       - Use of the same or no mobile phone number
       - Same or multiple IP addresses
   - For **Birthday Bonus**:
     - Confirm the player's VIP level as VIP3.
     - Check if the bonus was claimed within the player's birthday period.

5. **Determine eligibility based on the above checks:**
   - If the account passes all the relevant checks and there are no violations, inform the player that they are eligible for the bonus.
   - If violations are detected, explain that the bonus eligibility has been blocked due to the violation(s).

6. **If eligibility cannot be confirmed due to insufficient or unclear information:**
   - Request the player to provide additional details or documentation if necessary.
   - Advise the player that eligibility cannot be confirmed at this stage and that further review is required.

7. **Communicate the outcome to the player:**
   - Clearly state whether they are eligible or ineligible, citing the reasons supported by the system checks.
   - For ineligible cases, explain which condition(s) failed according to the rules.
   - If eligible, explain the next steps or how they can access their bonus.

8. **Escalate if needed:**
   - If the case involves complex violations, system errors, or requires special handling, escalate to the relevant department with detailed notes.

## Notes
- Bonus distribution is automatic by the system, but manual checks are necessary when violations are suspected.
- Violations such as binding the same bank card, using the same phone number, or multiple IP addresses may result in ineligibility.
- The BSP e-wallet icon removal does not affect bonus eligibility directly; it pertains to online gambling icons from BSP directives.
- The birthday bonus is only available to VIP3 players and within their birthday period.

## Key points for communicating with players
- Clearly state the specific reason if a bonus is ineligible.
- Emphasize the importance of adhering to account binding and registration rules.
- Reassure players that violations are detected to maintain fairness and security.
- Advise players to ensure their account details are accurate and to avoid violating conditions for future eligibility.