# Platform Rules & General Information - Withdrawal and Bonus Eligibility Requirements

## Steps

1. **Receive player's inquiry regarding withdrawal or bonus eligibility requirements.**  
   - Record the player's account details and the specific issue or question.

2. **Verify if the player is requesting information about withdrawal timing or limits.**  
   - If yes, inform that there is a daily pause in withdrawal services at 12:00 AM [GMT+8].  
   - Advise the player to refresh the page and try again after this time.  

3. **Check the player's account status and recent activity.**  
   - Confirm if the player has completed the necessary verification, if applicable, and review their deposit/withdrawal history.

4. **Assess if the player's inquiry involves withdrawal limits.**  
   - For non-deposit users, inform that the maximum withdrawal amount is 100 PHP.  
   - For other users, clarify that deposit and withdrawal limits are subject to company policies and may vary depending on account type and verification status.

5. **If the player inquires about referral bonuses, collect referral details.**  
   - Ask whether the referral has deposited at least 200 PHP.  
   - Confirm if the referral used multiple accounts, same bank card, same phone number, or multiple IP addresses, which could invalidate the referral.  
   - Inform that the agent commission is automatically credited once the referral's deposit and betting conditions are met, provided no policy violations are detected.

6. **Perform back-office checks to validate the referral status or withdrawal eligibility.**  
   - Verify deposit amounts, activity, and account linkage.  
   - Check for policy violations like multiple accounts, same bank card, same IP address, or using the same phone number.

7. **Determine if the player's request can be satisfied based on the checks.**  
   - If the withdrawal is temporarily paused due to the daily timing, explain the daily pause at 12:00 AM [GMT+8] and advise to retry after this time.  
   - If limits apply (e.g., non-deposit accounts), inform the player accordingly.  
   - If referral criteria are not met, explain the specific violations and remind about the requirements (deposit of 200 PHP, no policy violations).

8. **Communicate the outcome to the player:**
   - If eligible, confirm the correct amount and processing time.  
   - If ineligible, explain the specific reason and possible remedies or steps needed to qualify.  
   - If the issue is due to a system pause or limits, clearly inform and advise the player on when and how to retry or proceed.

9. **Escalate or document any unresolved issues or suspected violations as per company procedures.**  
   - If the player's request cannot be resolved on the spot, record the case for further review.  
   - Advise the player of any next steps or expected follow-up.

10. **Close the interaction after confirming the resolution or providing necessary guidance.**


## Notes

- Always inform players about the daily withdrawal pause at 12:00 AM [GMT+8] and advise them to retry after this time.  
- For referral bonuses, ensure players understand that deposits of at least 200 PHP are required for referral validity, and policy violations such as multiple accounts or shared details can invalidate referrals.  
- Deposit and withdrawal limits depend on account verification and type; non-deposit users can only withdraw up to 100 PHP.  
- All checks must be performed according to the current site configuration and official policies; avoid making assumptions beyond the provided rules.