# Platform Rules & General Information - Withdrawal and Bonus Eligibility Requirements

## Steps
1. **Identify the player's inquiry or claim related to withdrawals or bonuses.**
   - Determine whether the question concerns the turnover requirements, bonus eligibility, or withdrawal restrictions.

2. **Gather relevant player information and verify eligibility:**
   - Confirm the player's identity and account status.
   - Check if the player has claimed any active bonuses, especially the first deposit bonus or birthday bonus.
   - Verify the current promotions or bonuses linked to their account, including specific bonus details and requirements.

3. **Check if the player has met the turnover (wagering) requirements:**
   - Review the account’s wagering or turnover status in the system.
   - Confirm whether the player has fulfilled the specific turnover requirements applicable to their bonus:
     - For the first deposit bonus: 15x turnover.
     - For the register bonus: 20x turnover.
   - If the player has not met the required turnover, inform them that they need to fulfill this requirement before withdrawal.

4. **Assess the bonus rules specific to the promotion:**
   - Verify if the bonus has the correct status (e.g., credited, active, not expired).
   - Check if the player is within the required timeframe to use bonus features—such as the 12-hour window to log into the Reward Center after earning the bonus.
   - Confirm that no policy violations or suspicious activity (e.g., multiple accounts, use of the same IP address, bank cards, or phone numbers) are detected, as such violations may lead to confiscation of bonuses and profits.

5. **For bonus claims such as the Birthday Bonus:**
   - Confirm that the player’s date of birth matches the current date.
   - Request the player to submit the following:
     - Two valid IDs displaying their birthday.
     - A selfie holding the IDs.
   - Verify the submitted documents for authenticity and matching information.

6. **Review system and account restrictions:**
   - Ensure the account is not under any restrictions that prevent withdrawals or bonus conversions.
   - Check if the withdrawal amount complies with any maximum or minimum limits (if applicable), and verify the balance after the bonus and wagering requirements are met.

7. **Determine the resolution based on findings:**
   - If all requirements are met, approve the withdrawal, noting that the turnover requirement of 20x must have been fulfilled.
   - If the turnover requirement is not met, explain that they need to wager the required amount before withdrawal.
   - If bonus or eligibility rules are violated, state that the bonus or profits may be confiscated per policy.
   - If documentation for bonus claims (e.g., birthday bonus) is missing or invalid, request the player to re-submit or clarify accordingly.

8. **Communicate clearly and inform the player of next steps:**
   - Provide reasons for approval or denial based on compliance with the rules.
   - Guide the player on how to meet requirements if they are not yet fulfilled.
   - Escalate the issue if suspicious activity is detected or if documentation validation fails.

## Notes
- Turnover requirements vary per promotion; always check the specific promotion details in the Rewards Center or Promotion page.
- Bonuses are issued automatically by the system and are subject to Wagering/Turnover requirements before withdrawal.
- Repeated use from the same IP, bank card, or phone number may lead to confiscation of rewards and profits.
- The Birthday Bonus is only applicable on your exact birthday and requires ID and selfie confirmation.

## Key points for communicating with players
- Clearly explain that turnover requirements (e.g., 20x) must be fulfilled before withdrawals.
- Emphasize that bonuses are subject to specific rules and time frames.
- Remind players that policy violations such as suspicious activity can lead to confiscation of rewards and profits.
- For documentation requests, specify what is needed and ensure that submitted IDs are clear and valid.
- Always keep the tone professional, transparent, and supportive to maintain trust and clarity.