# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern related to platform licensing, legitimacy, or regulatory compliance.**  
   - Determine if the player is asking about the platform's legitimacy, licensing status, or what happens if irregular betting activity is detected.

2. **Gather relevant information from the player.**  
   - Ask the player for their account details (e.g., username or account ID).  
   - Clarify the specific question or concern the player has regarding licensing or irregular activity.

3. **Verify the platform's licensing status in the back office/system.**  
   - Confirm that SUPERPH operates under a Philippine gaming license issued by PAGCOR, as per official records.  
   - Ensure the license is valid and active.  
   - Note: SuperPH's licensing information can be confirmed through the company's official licensing confirmation, which states that the platform complies with legal protections for players and responsible gaming standards.

4. **Communicate the platform’s licensing and legitimacy status to the player.**  
   - Clearly state that SUPERPH is licensed and operating under the PAGCOR license in the Philippines.  
   - Emphasize that this license ensures adherence to responsible gaming practices, player protection, and game fairness under regulated oversight.

5. **Address player questions about irregular betting activity, if applicable.**  
   - Ask if the player's query involves irregular betting activity or detected irregular activity.  
   - If the question relates to detected irregular betting activity, inform the player that:  
     - If the system identifies irregular betting activity associated with the account, any profits gained from these activities will be subject to deduction.  
     - This measure is applied to protect the integrity of the platform and its players.

6. **Perform system checks for irregular betting activity.**  
   - Review the player's account for any flagged irregular betting activity by the internal monitoring system.  
   - If irregular activity is detected, proceed to warn the player about potential profit deductions.

7. **Provide explanations and resolutions based on findings:**  
   - If the license is confirmed and the account shows no irregular activity, reassure the player that the platform is legitimate and compliant with licensing standards.  
   - If irregular activity is confirmed, inform the player of the deduction policy and the importance of fair play, following regulatory rules.  

8. **Document the interaction and findings.**  
   - Record the player's details, the nature of the query, verification steps performed, and any actions taken in the case notes.

9. **Close the case or escalate if necessary.**  
   - If the inquiry is fully resolved (e.g., licensing confirmation or clarification about irregular betting activity), close the case.  
   - If the issue involves complex licensing or compliance concerns beyond standard verification, escalate to a supervisor.

## Notes

- Always verify licensing information directly through official records and confirm that the license is from PAGCOR, issued by the Philippines government.  
- Remind players that SUPERPH operates under strict regulations which ensure fair gaming and player protection by law.  
- For questions about chat access or customer support features, inform players that some features (like the gaming chat) require placing a bet first.

## Key points for communicating with players

- Confirm SUPERPH operates under a PAGCOR license in the Philippines.  
- Assure players that their protection, responsible gaming, and game fairness are guaranteed under this license.  
- Notify players that if irregular betting activity is detected, profits from such activity may be deducted to safeguard game integrity.