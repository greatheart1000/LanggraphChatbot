# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive and review the player's inquiry related to licensing, regulation, or irregular betting activity.**  
   - Collect the player's account details and nature of the question or concern.  
   - Determine if the inquiry pertains to licensing status, legitimacy, or irregular betting activity (e.g., cheating, arbitrage, irregular betting patterns).

2. **Verify the player's account for irregular betting activity or cheating/arbitrage detection.**  
   - Check the system for any alerts or flags indicating irregular betting activity, cheating, or arbitrage, as these are specifically monitored.  
   - Confirm whether profits gained from these activities are subject to deduction, per the system protocols.

3. **Assess the licensing and legitimacy status of JOLLYPH for the player’s jurisdiction.**  
   - Confirm that JOLLYPH operates under a PAGCOR gaming license issued by the Philippines.  
   - Verify that the license ensures compliance with local laws, player protection, and responsible gaming practices, as confirmed by provided documentation or system data.  
   - Note that all references confirm JOLLYPH is licensed, legitimate, and regulated under PAGCOR, which provides player protection.

4. **Based on the player's query, determine the appropriate response:**

   - **If the inquiry is about licensing, legitimacy, or safety:**  
     - Inform the player that JOLLYPH operates under a PAGCOR license, ensuring legitimacy and regulatory oversight.  
     - Emphasize that the license ensures adherence to strict player protection, responsible gaming practices, and secure handling of funds.

   - **If the inquiry is about irregular betting, cheating, arbitrage, or related activities:**  
     - Explain that if irregular betting activity, cheating, or arbitrage is detected by the system, any profits gained from these activities will be subject to deduction.  
     - Clarify that if irregular betting activity is identified on the account, profits from such activities will be deducted as per the system’s protocols.

5. **If the system detects irregular betting, cheating, or arbitrage:**
   
   - Document the detection and action taken, such as profit deduction or bonus withholding, following internal procedures.  
   - Advise the player that the activity has been flagged appropriately and that profits gained from such activities will be subject to deduction.

6. **If the player provides insufficient information or the inquiry cannot be verified immediately:**  
   
   - Explain that further investigation is necessary.  
   - Inform the player that account inspections or system checks are required to confirm any irregular activities and license status.  
   - Escalate the case to relevant department if needed, following internal escalation procedures.

7. **Conclude the conversation, ensuring the player understands the licensing and regulatory safeguards, or the implications of irregular betting activities.**  
   - Provide clear explanations consistent with the above points, without revealing sensitive system details.  
   - Offer to update the player once investigations are complete or if further information becomes available.

## Notes
- Always confirm and communicate that JOLLYPH operates under a PAGCOR license, which supports player protection and responsible gaming.  
- Be cautious to only relay information supported by official data and system alerts—avoid speculation or unconfirmed claims.  
- In cases of detected irregular activity, clearly explain that profits gained from such activities will be subject to deduction, and any bonuses may also be affected.

## Key points for communicating with players
- Emphasize that JOLLYPH is licensed by PAGCOR, ensuring legality and regulation.
- Clearly state that irregular betting, cheating, and arbitrage activities, if detected by the system, lead to profit deductions.
- Maintain transparency about the investigation process and provide reassurance regarding compliance and player protection.