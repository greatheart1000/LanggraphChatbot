# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify and understand the player's query**:
   - Determine if the player is asking about the platform's licensing, legitimacy, or regulatory status.
   - Typical questions include inquiries about license existence, licensing authority, or regulatory compliance.

2. **Verify the player's specific query content**:
   - Confirm if the question relates to whether VIPPH Casino is licensed, legitimate, or regulated.
   - Check if the question concerns the licensing authority or the compliance standards the platform adheres to.

3. **Gather relevant information from the FAQs**:
   - Confirm that VIPPH Casino operates under the Philippines PAGCOR license.
   - Note that the license ensures adherence to laws, player protection, and responsible gaming.
   - Understand that VIPPH's license indicates compliance with strict standards set by PAGCOR.

4. **Explain the licensing status to the player**:
   - Clearly state that VIPPH Casino is licensed and legitimate.
   - Mention that the platform holds a PAGCOR license issued by the Philippines Amusement and Gaming Corporation.
   - Emphasize that this license confirms compliance with national regulations, responsible gaming standards, and player protection laws.

5. **Assess if the player asks for additional licensing or regulatory details**:
   - Confirm that VIPPH operates under a PAGCOR license, which is a recognized and regulated authority.
   - Advise that the license provides assurance of the platform's legality and safety for players.

6. **If the player questions about the platform's safety or legitimacy**:
   - Reiterate that operating under the PAGCOR license means VIPPH follows strict standards, ensuring the platform's legitimacy.

7. **Document the conversation**:
   - Record that the player received accurate information about VIPPH's licensing and regulatory compliance.
   - Make note of the player's concerns to ensure future follow-up or clarification if needed.

8. **Close the case**:
   - Confirm the player has no further questions regarding licensing or legality.
   - Offer additional assistance if required, but ensure the key information about PAGCOR licensing is communicated clearly.

## Notes
- Do not provide any unverified or external licensing details not supported by the FAQs.
- The licensing status (PAGCOR) and its significance should be the main focus of the explanation.
- Emphasize that VIPPH's licensing means the platform complies with legal standards and prioritizes player protection.

## Key points for communicating with players
- Always mention the specific regulatory authority, which in this case is PAGCOR.
- Reinforce that the license ensures adherence to local laws, responsible gaming practices, and player protection.
- Keep explanations clear, concise, and based solely on the licensing information confirmed by the FAQs.