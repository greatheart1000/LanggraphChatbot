# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern related to platform licensing or regulation.**  
   - Collect relevant details from the player about their question or issue, e.g., the specific information they seek about licensing or compliance.

2. **Verify the player's account status and relevant details.**  
   - Check if the account is active, and if applicable, note any recent policy violations or behavior that could lead to suspension or termination, following the condition that accounts may be suspended for policy violations or inappropriate behavior or language.

3. **Confirm the platform’s licensing status.**  
   - Inform the player that LoveJILI operates under the Philippine PAGCOR license, which is issued by the Philippine gaming regulator.
   - Reinforce that the platform is licensed and regulated under the PAGCOR framework, ensuring regulatory compliance and protection for players.

4. **Explain the regulatory framework and protections.**  
   - Clarify that the license from PAGCOR supports compliance with gambling laws, promotes responsible gaming, and offers legal protection for players.
   - Emphasize that all games are computer-generated and winnings/losses are recorded automatically, ensuring transparency and fairness.

5. **Determine if the question involves account suspension or termination conditions.**  
   - If the inquiry relates to account status or violations, explain that accounts may be suspended or terminated due to policy violations or inappropriate conduct.

6. **Address specific player concerns or questions.**  
   - Provide clear, accurate responses based on the verified licensing information.
   - If the question involves licensing legitimacy, reassure the player that LoveJILI operates under a valid license from PAGCOR, confirming its legitimacy and legal status.

7. **Record the interaction and resolution.**  
   - Document the player's concern, the information provided, and any follow-up actions needed.

## Notes

- Always confirm the platform's license status as per the FAQs: LoveJILI operates under the PAGCOR license issued by the Philippine gaming regulator.
- When discussing protections, highlight that licensing ensures compliance with player protection and responsible gaming laws.
- Do not invent new rules; base your responses solely on the current licensing framework and official information provided in the FAQs.

## Key points for communicating with players

- Clearly state that LoveJILI is licensed and regulated by PAGCOR.
- Emphasize the benefits of licensing, such as legal compliance, player protection, and responsible gaming.
- Be transparent about account suspension or termination policies, especially if related to policy violations or inappropriate behavior.