# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry or report about irregular betting activity or licensing/legitimacy concerns.**

2. **Gather necessary information from the player:**
   - Confirm the player's identity details if required.
   - Ask for specific details about the activity or issue (e.g., nature of betting activity, account details, concerns about licensing).

3. **Check system alerts for irregular betting activity:**
   - Access the back-office or relevant system to identify if the account has been flagged for irregular betting activity.
   - Verify if any profits have been gained from the activity.

4. **Determine the appropriate response based on system findings:**
   - If irregular betting activity is detected:
     - Inform the player that any profits gained from such activity are subject to deduction, in accordance with platform policy.
     - Note that the system may automatically flag such activity, and profits will be deducted accordingly.
   
   - If the inquiry relates to licensing or legitimacy:
     - Confirm that WOWPH operates under a PAGCOR gaming license issued in the Philippines.
     - Explain that the license ensures player protection, responsible gaming standards, and compliance with local regulations.

5. **Provide clear explanations to the player:**
   - If irregular activity is found, clarify that profits from irregular betting activities are subject to deduction.
   - If licensing concerns are raised, assure the player of the licensure details and the regulatory standards WOWPH adheres to under PAGCOR.
   
6. **Escalate or document the case as necessary:**
   - If the player’s issue is complex or requires further investigation, escalate to the relevant department following internal procedures.
   - Record the case details, including any evidence of irregular betting activity or licensing inquiries.

7. **Close the case with communication and instructions:**
   - Confirm that the player understands the platform rules regarding irregular betting activity and licensing.
   - Advise the player to follow responsible gaming practices and contact support if further questions arise.

## Notes

- Profits resulting from irregular betting activities will always be subject to deduction.
- WOWPH’s license from PAGCOR ensures compliance with gaming laws and player protection standards.
- Be transparent and provide accurate license information when discussing legitimacy issues.

## Key points for communicating with players

- Clearly explain that any profits from irregular betting activity are subject to deduction.
- Emphasize that WOWPH is licensed by PAGCOR, which regulates and oversees the platform.
- Handle licensing and irregular activity inquiries with factual, license-based reassurance and clarity.
- Escalate cases that require further investigation or legal clarification according to internal protocols.