# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's concern or query related to platform rules or licensing.**  
   - Confirm if the player is asking about account status, licensing, regulation, or related operational policies.

2. **Gather necessary information from the player.**  
   - Ask for their account details (e.g., username) if not already known.  
   - Clarify the specific question or issue regarding licensing, regulation, or platform rules.

3. **Verify the player's account status.**  
   - Check for any potential irregular activity, especially related to betting patterns.  
   - If irregular betting activity is detected, inform the player that any profits may be subject to deduction as per platform policy.

4. **Provide information about platform licensing and regulation.**  
   - Confirm that PHSPIN operates under a gaming license issued by PAGCOR in the Philippines.  
   - Explain that this licensing ensures adherence to high standards of player protection and responsible gaming.  
   - Emphasize that PHSPIN is licensed, regulated, and compliant with local laws which safeguard players.

5. **Address questions about account deletion.**  
   - Inform the player that their current account cannot be deleted.  
   - Advise that creating a new account is recommended if they wish to start fresh.

6. **Respond to questions regarding licensing legitimacy and safety.**  
   - Reinforce that PHSPIN operates under a PAGCOR license and follows strict regulations, making it a legitimate and safe platform to play.

7. **Explain platform rules related to inappropriate language or conduct.**  
   - Clearly state that inappropriate language or conduct is not permitted.  
   - Warn that violating this policy may result in account suspension or termination.

8. **Handle app download inquiries.**  
   - Instruct the player to tap “App Download,” choose their device OS (Android or iOS), and follow the download procedure to ensure app safety and updated promotions.

9. **Note any additional informational points.**  
   - Clarify that account issues, licensing, or regulation details are based on the current site configuration and official licensing authorities.  
   - If players have further questions or require escalation, advise contacting support directly with detailed account information.

10. **Close the interaction by summarizing key points if necessary.**  
    - Reiterate that PHSPIN is licensed by PAGCOR, operates under strict regulations, and adheres to responsible gaming policies.  
    - Remind players of platform rules regarding language and conduct.

## Notes

- Always verify the player's account details before sharing sensitive information.  
- If any suspicion arises regarding irregular betting activity, follow internal procedures for review and adjustment of winnings if applicable.  
- Provide clear, factual information about licensing and regulation, emphasizing the legitimate and regulated status of PHSPIN in accordance with PAGCOR standards.

## Key points for communicating with players

- Emphasize that PHSPIN is licensed by PAGCOR, ensuring it is a safe and legitimate platform.  
- Explain that account deletion is not possible; creating a new account is the alternative.  
- Clarify policies regarding inappropriate language and the consequences for violations.  
- Always support licensing and regulatory claims with the facts from the official site and regulatory authority (PAGCOR).