# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry regarding platform licensing and regulation**.  
   - Ask the player what specific information they need or any concerns they have about licensing and compliance.

2. **Gather necessary information from the player** to understand their specific question or concern.  
   - Determine if they are asking about licensing legitimacy, regulation, or protection measures.

3. **Verify the player's account for irregular betting activity**, if relevant to the inquiry:  
   - Check the back office or system logs for irregular betting activity on the player's account.  
   - Be aware that if irregular betting activity is identified, any profits gained from those activities will be subject to deduction.

4. **Provide a clear answer based on the platform's licensing and regulation status**:  
   - Confirm that PHPGAMES operates under a Philippines gaming license issued by PAGCOR.  
   - Emphasize that PHPGAMES complies with local gaming regulations, ensuring regulatory compliance and player protection by law.  
   - Clearly state that PHPGAMES is legitimate, licensed, and regulated by PAGCOR.

5. **Explain the protections offered to players**:  
   - Highlight that operating under a PAGCOR license indicates compliance with the Philippines gaming regulations.  
   - State that the platform adheres to high standards of player protection and responsible gaming practices.

6. **If the player raises concerns about irregular betting activity or account issues**:  
   - Inform them that if irregular activity is detected, profits obtained from such activity may be deducted as per platform policy.  
   - Advise the player they may need to follow any additional verification or review procedures if irregular activity is suspected.

7. **Document the interaction and any specific issues discussed**:  
   - Note whether the player’s questions were fully addressed or if further investigation/regulation compliance checks are required.

8. **Close the case with a summary of the licensing and regulation compliance status**:  
   - Reinforce that PHPGAMES operates under a PAGCOR license, ensuring both entity legitimacy and player protection.

## Notes
- Always confirm the platform's licensing and regulation status as stated in the FAQs: PHPGAMES operates under a Philippines gaming license issued by PAGCOR.
- Be aware that any detection of irregular betting activity may lead to deduction of profits gained from such activity, according to platform policies.
- Maintain transparency by clearly communicating the protections and compliance standards associated with the PAGCOR license.

## Key points for communicating with players
- Emphasize that PHPGAMES is licensed and regulated by PAGCOR, which safeguards player interests and ensures regulatory compliance.
- Clarify that irregular betting activity, if detected, results in consequences such as profit deduction.