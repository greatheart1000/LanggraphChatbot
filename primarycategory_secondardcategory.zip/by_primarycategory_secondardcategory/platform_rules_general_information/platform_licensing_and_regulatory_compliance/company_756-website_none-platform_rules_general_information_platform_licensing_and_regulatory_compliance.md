# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry regarding platform licensing, regulation, or safety.**  
   - Ask the player if they have specific questions about whether PHDREAM Casino is licensed or regulated.  
   - If the player raises concerns about platform legitimacy or safety, proceed to verify the licensing status.

2. **Verify the player's account details and identify the player.**  
   - Gather necessary account information to locate the player's account in the system.  
   - Confirm the player's identity to ensure accuracy in addressing their inquiry.

3. **Check the licensing status of PHDREAM Casino in the back office/system.**  
   - Confirm that PHDREAM Casino operates under a PAGCOR license issued by the Philippine gaming authority.  
   - Verify that the platform is licensed and compliant with applicable laws to assure the player of its legitimacy and safety.

4. **Provide information to the player based on verification:**

   - If the license status is confirmed as PAGCOR-licensed:  
     - Inform the player that PHDREAM Casino is licensed and regulated by PAGCOR, ensuring player protection, adherence to responsible gaming, and legal safeguards.

   - If the licensing status is not clear or the license is not verified:  
     - Advise the player to check official PAGCOR resources or official licensing details, as agents cannot provide unverified licensing information.
  
5. **Address concerns about risks of online casino gaming.**  
   - Explain that online casino games involve risk; outcomes can be wins or losses.  
   - Emphasize that the platform promotes responsible gaming as part of its licensed operations.

6. **Clarify any restrictions or notices related to online gambling links through e-wallets.**  
   - Inform the player that BSP has directed e-wallet providers (such as GCash and Maya) to remove icons and links of online gambling platforms within 48 hours.  
   - Reassure the player that this removal does not require unlinking their e-wallet account and does not affect the safety of their e-wallet for other transactions.

7. **Explain what happens in cases of irregular betting activity.**  
   - Inform the player that if irregular betting activity is detected, profits earned from such activities may be deducted, following the platform's policies.

8. **If the player has additional licensing or regulatory questions, escalate to specialized support or verify through official sources.**

## Notes

- Ensure all information provided is aligned with the latest official licensing status from PAGCOR.  
- Always verify the player's identity before sharing licensing or regulatory details.  
- Emphasize responsible gaming practices and legal safeguards associated with licensed operation.

## Key points for communicating with players

- Clearly state that PHDREAM operates under a PAGCOR license, ensuring legitimacy and compliance.  
- Explain the platform's commitment to responsible gaming and legal safeguards.  
- Clarify the BSP directive regarding online gambling links and e-wallets, noting it does not affect overall e-wallet safety or account linkage.  
- Be transparent about actions taken in cases of irregular betting activity, such as profit deductions.