# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the player's inquiry about licensing or legitimacy**  
   - Ask the player to specify their concern (e.g., platform legitimacy, licensing details, player protection).  
   - Confirm whether they are asking about licensing, legitimacy, or regulatory compliance.

2. **Inform the player about the licensing status**  
   - Clearly state that SLOTSGO operates under a Philippines PAGCOR license.  
   - Emphasize that this license is issued by PAGCOR and indicates compliance with Philippine gaming laws.  
   - Mention that the platform follows rigorous practices for player protection and responsible gaming.  
   - Reinforce that players are protected by law due to this licensing.

3. **Address questions regarding legitimacy and player protection**  
   - Confirm that SLOTSGO is a legitimate platform licensed by PAGCOR.  
   - Explain that adherence to the PAGCOR license ensures compliance with strict player protection standards and responsible gaming practices.

4. **Explain regulatory implications for players**  
   - Clarify that because SLOTSGO is licensed under PAGCOR, the site is regulated by Philippine law.  
   - Highlight that this regulation supports fair play, responsible gaming, and legal protection for players.

5. **If the player raises concerns about suspicious activity or irregular betting**  
   - Check for signs of irregular betting activity associated with their account.  
   - Inform the player that if irregular betting activity is detected, profits gained from such activities may be subject to deduction, according to system rules.

6. **Verify player identity and account details if needed**  
   - Collect relevant account information, such as account ID, registration details, IP addresses, phone number, and bank card used (if relevant).  
   - Cross-check these details against system records to identify potential multiple accounts, same bank card, same phone number, or IP addresses.

7. **Identify any potential rule violations or irregularities**  
   - If irregular activity or multiple account issues are detected, explain that rewards, bonuses, or profits may be confiscated or invalidated in accordance with system rules.  
   - Inform the player about restrictions on referral rewards if applicable (e.g., multiple accounts, same bank card, same phone number, IP address).

8. **If the inquiry involves bonuses or promotional rewards**  
   - Confirm that Angpao (red envelope) bonuses are offered on a first-come, first-served basis hourly, and each player can claim only once.  
   - Warn the player that rewards or profits may be confiscated if the system detects repeated claims from the same IP address, bank card, or phone number.

9. **Provide clarification or escalate if needed**  
   - If the player requests further clarification about licensing standards or regulatory practices, reiterate the points above.  
   - For complex issues or suspected breaches, escalate to the compliance or technical team as per internal procedures.

10. **Close the conversation with reassurance and documentation**  
    - Reaffirm that SLOTSGO is a licensed and legitimate platform operating under the Philippine PAGCOR license.  
    - Assure the player of adherence to strict regulations for their safety.  
    - Document the interaction and any relevant details for internal records.

## Notes
- Always base responses on the officially stated licensing information: SLOTSGO operates under a PAGCOR license issued in the Philippines.
- Ensure transparency in explaining the implications of licensing for player protection and regulation.
- Be cautious when discussing irregular activities; inform players about the possibility of penalties or deduction of profits if irregular betting or multiple account violations are detected.
- Follow internal escalation protocols for complex or unresolved licensing or compliance questions.

## Key points for communicating with players
- Reassure players about the legitimacy by confirming the PAGCOR license.
- Emphasize that the license guarantees adherence to law, responsible gaming, and player protection.
- Clarify that any irregular betting activity can lead to deductions.
- Mention the restrictions on rewards for prohibited activities (multiple accounts, same IP, same bank card).