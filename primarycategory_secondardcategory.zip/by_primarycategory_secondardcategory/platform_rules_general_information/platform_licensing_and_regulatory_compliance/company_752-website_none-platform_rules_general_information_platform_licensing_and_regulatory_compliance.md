# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern related to platform legitimacy, licensing, or regulatory status.**  
   - Confirm the nature of the question whether it pertains to licensing, safety, legitimacy, or regulatory compliance.

2. **Verify the player's request or claim regarding legitimacy or licensing.**  
   - If the player asks if PHCASH is legitimate, licensed, safe, or operates under a valid license, proceed to the relevant checks.

3. **Inform the player about PHCASH's licensing status.**  
   - Clearly state that PHCASH operates under the Philippines gaming license issued by PAGCOR.  
   - Emphasize that this licensing indicates adherence to rigorous practices for player protection and responsible gaming, and that players are protected by law.  
   - Example phrasing: "PHCASH is licensed and operates under the Philippines gaming license issued by PAGCOR, meaning we follow strict standards for player protection and responsible gaming."

4. **If further details are requested about licensing or legality:**
   - Reinforce that PHCASH's licensing status complies with applicable laws and standards, ensuring player safety and confidentiality of client information.  
   - Confirm that PHCASH is licensed, legitimate, and compliant with regulatory requirements specific to the Philippines.

5. **If the inquiry involves system detection or irregular activity:**
   - Explain that if the system detects irregular betting activity, any profits from such activity may be deducted, and players may need to complete turnover requirements before withdrawal, as per system rules.

6. **Record the interaction and document that the player was informed of PHCASH’s licensing and regulatory compliance.**  
   - Ensure the information provided aligns with official site policies and FAQs.

7. **If the player raises concerns about online gambling platform regulations, e.g., related to news about GCash and Maya:**
   - Clarify that the Bangko Sentral ng Pilipinas (BSP) has directed e-wallet providers to remove icons and links of online gambling platforms within 48 hours.  
   - Transparency note: this action does not impact the safety or activity of existing e-wallet accounts; they remain active for other transactions.  
   - Advise the player accordingly, but reassure safety and compliance.

8. **Escalate or refer to the relevant department if the inquiry involves legal or regulatory disputes beyond standard responses.**  
   - Follow internal escalation protocols if required.

## Notes
- Always base responses on the fact that PHCASH holds a PAGCOR license issued by the Philippines, ensuring adherence to rigorous standards for player protection and responsible gaming.
- Use clear, consistent language to communicate licensing status and regulatory compliance.
- Remember that specific numeric values, amounts, or detailed process steps are not applicable unless explicitly provided in the FAQs.

## Key points for communicating with players
- Reinforce that PHCASH's license from PAGCOR guarantees it operates under strict legal and safety standards.
- Confirm that players are protected by law under the current licensing.
- Clarify that any system detection of irregular betting can result in profits being deducted and the need to fulfill turnover requirements before withdrawal.
- Reassure that e-wallet issues prompted by BSP directives do not affect the safety of existing accounts or the platform's legitimacy.