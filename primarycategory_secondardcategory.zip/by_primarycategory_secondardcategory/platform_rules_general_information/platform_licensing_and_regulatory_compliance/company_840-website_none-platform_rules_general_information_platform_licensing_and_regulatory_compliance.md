# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's query** regarding licensing, regulation, or protections associated with 639JL Casino.

2. **Verify the player's provided information**:
   - Ask for any relevant account details or identifiers to locate the user's records.
   - Confirm whether the query relates to licensing, regulatory compliance, security, or player protection.

3. **Access the back-office / system information**:
   - Check the licensing status of 639JL Casino.
   - Confirm that the platform operates under a PAGCOR license in the Philippines.
   - Ensure the license is active and current.

4. **Review licensing and regulation details**:
   - Confirm that the license is issued by PAGCOR (Philippine Amusement and Gaming Corporation).
   - Check that the platform adheres to local gaming laws.
   - Verify that the platform complies with responsible gaming and player protection standards.

5. **Assess the player's concerns**:
   - If the player inquires about protections, explain that the PAGCOR license ensures adherence to regulations that protect players and promote responsible gaming.
   - If the player requests confirmation of legitimacy, inform that the platform is licensed by PAGCOR, confirming legal operation and regulatory compliance.

6. **Provide explanations based on the inquiry**:
   - For licensing questions: Clearly state that 639JL Casino operates under the PAGCOR license in the Philippines.
   - For protection or fairness questions: Explain that games are computer-generated and winnings/losses are automatically recorded, ensuring fairness.
   - For other regulatory concerns: Reiterate that the license indicates compliance with local laws and standards.

7. **Record the interaction**:
   - Log the player's question and the information provided about licensing and protections.
   - Attach evidence or screenshots of the current license status if available or requested, ensuring compliance with internal procedures.

8. **If the license status cannot be verified or there is an issue**:
   - Advise the player accordingly.
   - Escalate the case following internal escalation procedures if necessary.

9. **Close the case**:
   - Confirm the player has received the required information.
   - Ensure all relevant details are documented for future reference.

## Notes

- Always verify current license status via official PAGCOR sources if possible.
- Reinforce that the license confirms adherence to regulations, responsible gaming, and player protection.
- If the player raises further concerns, direct them to official licensing authorities or official platform communications.

## Key points for communicating with players

- Clearly state that 639JL Casino operates under a PAGCOR license issued in the Philippines.
- Emphasize that this license indicates compliance with all local laws and responsible gaming practices.
- Explain that the gameplay is fair and transparent, with computer-generated games and automatic record keeping.
- Ensure players understand that their protection is supported by the licensing and regulation framework.