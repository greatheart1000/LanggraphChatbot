# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Greet the player and clarify the player's inquiry**  
   - Determine if the player’s question pertains to account registration, betting activity, or licensing/legitimacy.  
   - Ask for necessary details such as the player's account ID or username if not already available.

2. **Gather relevant account information**  
   - Confirm the player's account status, including registration history, recent activity, and any suspicious or irregular betting behavior.  
   - Document any complaints or concerns expressed by the player regarding account issues or legitimacy.

3. **Check for repeated account registration concerns**  
   - Verify if the player’s account is flagged for repeated registration in violation of bonus regulations.  
   - If detected, explain that the system detects repeated account registration for bonuses and inform the player they must meet the turnover requirements again before withdrawal.

4. **Review recent betting activity for irregularities**  
   - Use the back-office system to identify any irregular betting activity linked to the account.  
   - If irregular activity is identified, inform the player that profits gained from such activity will be subject to deduction.  
   - Note: For malicious arbitrage activity, all illicit profits will be permanently deducted and will not be returned.

5. **Verify licensing and legitimacy**  
   - Confirm the company's licensing status by referencing the existing license issued by PAGCOR under the Philippines gaming license.  
   - Counsel the player that SLOTSPH operates under PAGCOR, follows strict player protection and responsible gaming practices, and is 100% legitimate and licensed.

6. **Explain consequences of irregular betting detection**  
   - If irregular betting activity is confirmed, inform the player that profits from these activities will be deducted.  
   - Mention that repeated irregular activity could lead to further account actions in accordance with company policy.

7. **Communicate the company's licensing and regulatory compliance**  
   - Reinforce that SLOTSPH is licensed by PAGCOR, which ensures compliance with strict regulations and provides legal protections to players.

8. **Address player concerns about legitimacy and protections**  
   - Assure the player that SLOTSPH's licensing under PAGCOR guarantees adherence to player protection and responsible gaming standards, and that their bankroll is protected by law.

9. **Provide further guidance or escalate if necessary**  
   - If the inquiry is beyond the agent’s authority or requires further investigation, escalate to a supervisor or relevant department.  
   - Document the case details and the actions taken.

## Notes
- Always verify the player's account details before providing explanations.  
- Clearly communicate that profits gained from irregular or malicious arbitrage activities are subject to deduction and may result in further actions for repeated violations.  
- Emphasize the licensing status to reassure players about SLOTSPH's legitimacy and legal standing.

## Key points for communicating with players
- Inform players that the system detects repeated registration and irregular betting activities.  
- Explain that profits from irregular betting activities, including malicious arbitrage, will be deducted.  
- Confirm that SLOTSPH operates under PAGCOR’s license, ensuring compliance with strict regulations and player protections.