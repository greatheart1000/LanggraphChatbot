# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry regarding licensing or regulation status.**
   - Ask the player for specific concerns or questions related to the platform's legitimacy, licensing, safety, or regulation.

2. **Verify the player's account and identify the context of the inquiry.**
   - Confirm the player's account details and recent activity if relevant to the discussion.
   - Note any claims of irregular betting activity or winnings to address separately.

3. **Confirm the platform's licensing status.**
   - Inform the player that DREAMJILI operates under the Philippine gaming license issued by PAGCOR.
   - Emphasize that the platform is licensed, legitimate, and presented as safe to use.

4. **Explain the implications of PAGCOR licensing.**
   - Clarify that PAGCOR licensing means DREAMJILI adheres to regulatory standards for player protection and responsible gaming.
   - Mention that the platform complies with applicable laws, and players are protected by law.

5. **Address questions about safety and legitimacy.**
   - Reiterate that DREAMJILI is licensed by PAGCOR and follows strict practices, making it a legitimate platform.

6. **In case of concerns about irregular activity or winnings:**
   - Explain that if irregular betting activity is detected, profits gained from such activity may be deducted according to DREAMJILI's policy.
   - Clarify that the platform does not guarantee winnings in cases of irregular betting activity.

7. **If additional clarification is required on licensing or regulation:**
   - Reiterate that DREAMJILI operates under the official PAGCOR license issued in the Philippines.
   - Reinforce that this licensing supports player protection, responsible gaming standards, and regulatory compliance.

8. **Document the interaction and any relevant details in the system.**
   - Make notes of the player's concerns, the information provided, and any follow-up actions needed.

9. **Close the interaction.**
   - Confirm with the player that their questions have been addressed.
   - Offer assistance with any other concerns related to platform compliance or safety.

## Notes

- Always ensure communication is confident and transparent about the platform's licensing status.
- Be prepared to explain the significance of PAGCOR licensing in terms of player protection and responsible gaming if asked.
- Do not provide legal advice beyond what is supported by the FAQs; stick to the facts specified.

## Key points for communicating with players

- DREAMJILI operates under a PAGCOR license from the Philippines.
- The license confirms the platform's adherence to local laws and responsible gaming practices.
- Profits may be deducted if irregular betting activity is detected, and winnings are not guaranteed in such cases.
- Emphasize the platform's legitimacy, safety, and compliance explicitly to reassure players.