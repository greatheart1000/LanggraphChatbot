# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern regarding platform licensing or legitimacy.**  
   - This may include questions about whether NICEPH is a licensed, regulated, or legitimate casino, or specific questions about the company's gaming license.

2. **Verify the player's account details.**  
   - Collect their username, account ID, or any other relevant identifier to locate their account in the system.

3. **Assess the nature of the inquiry:**
   - If the player questions the platform’s legitimacy or licensing status:
     - Confirm that NICEPH operates under the Philippines gaming license issued by PAGCOR.
     - Inform the player that NICEPH is licensed by PAGCOR, which ensures adherence to strict regulations for player protection and responsible gaming.
     - Emphasize that NICEPH is 100% legitimate and fully compliant with relevant laws.
   - If the player asks about license details:
     - Clearly state that NICEPH has a gaming license issued by PAGCOR (Philippine Amusement and Gaming Corporation).

4. **If the player asks about operational or regulatory compliance:**
   - Explain that NICEPH follows rigorous practices for player protection and responsible gaming as mandated by PAGCOR.
   - Confirm that the platform is licensed, regulated, and adheres to the standards set by PAGCOR.

5. **For questions regarding deposits, withdrawals, or account activity related to licensing:**
   - Clarify that deposits are non-refundable and non-cancellable; this policy is standard and outlined in the terms of service.

6. **Handle any questions about irregular betting activity or potential misconduct:**
   - If irregular betting activity is suspected or detected:
     - Notify the player that profits from irregular betting activities may be subject to deduction, as per system detection protocols.
     - Document the issue and escalate to relevant back-office teams if necessary.

7. **For questions related to downloading or accessing the platform:**
   - If relevant to licensing or platform legitimacy, confirm that the platform is officially licensed and recommend downloading the app via official channels.
   - Provide the steps: 
     - Tap "App Download"
     - Choose between Android or iOS
     - Install the app

8. **Document the conversation and any verification performed.**  
   - Log the query, steps taken, and resolution in the support system.
   - If the inquiry involves sensitive or complex licensing issues, escalate to a supervisor or compliance specialist.

9. **Close the ticket or support case once the information has been provided and confirmed.**  
   - Ensure the player acknowledges understanding their platform's licensing status and any relevant policies.

## Notes
- Always verify the player's account details before providing licensing information.
- Emphasize that NICEPH operates under the Philippines PAGCOR license, ensuring compliance and player protection.
- Do not speculate or provide unverified information about licensing.
- Clearly state deposit policies and handling of irregular activity if relevant to the inquiry.

## Key points for communicating with players
- Confirm NICEPH’s license with PAGCOR to reassure legitimacy.
- Clearly explain that deposits are non-refundable.
- Inform about the company’s commitment to responsible gaming and adherence to regulations.
- Escalate complex licensing or compliance concerns to appropriate teams for further handling.