# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern regarding licensing or platform legitimacy**  
   - Record the player's question or issue related to platform rules, licensing status, or regulatory compliance.

2. **Verify the player's location and regional restrictions**  
   - Check if the player is outside the Philippines.  
   - Inform the player that regional restrictions may apply.  
   - If the player is outside the Philippines and wishes to access the platform, advise them that they can use a VPN to connect via a server in the Philippines, as per current site policies.

3. **Confirm the platform’s licensing status**  
   - Explain that JILICROWN operates under a PAGCOR license issued by the Philippines, which ensures regulatory compliance and a safe, legal environment for players.  
   - Emphasize that the platform follows strict responsible gaming practices.

4. **Address e-wallet related concerns (if applicable)**  
   - Inform the player that the BSP has directed e-wallet providers to remove icons and links to online gambling sites within 48 hours.  
   - Clarify that this does not prevent them from using their e-wallet for other transactions or unlinking their account.

5. **Check for additional verification (if necessary)**  
   - If the player reports issues with access or restrictions, verify whether their account might have been suspended or terminated for policy violations, such as inappropriate conduct.  
   - Inform the player that account suspension or termination can occur for violations of platform policies.

6. **Explain the platform’s commitment to legitimacy and responsible gaming**  
   - Reiterate that JILICROWN is a licensed and regulated platform under PAGCOR, committed to player protection and responsible gaming standards.

7. **Document the case and, if applicable, clarify next steps or escalations**  
   - Record all relevant information, including player location, concerns, and any detected issues.  
   - If the player’s concern involves access restrictions or technical issues, suggest using a VPN (if appropriate and compliant with site policies).  
   - For unresolved licensing or regulatory questions, escalate to the compliance or management team as per internal procedures.

## Notes
- Always verify the player’s specific concern, whether about licensing, access, or account status.
- Communicate clearly that the platform is licensed and operated under Philippine regulations.
- Remind players that regional restrictions are in place according to BSP directives.
- When sharing information about the license, specify that JILICROWN operates under the PAGCOR license issued by the Philippines.

## Key points for communicating with players
- Emphasize the legitimate and regulated status of JILICROWN under PAGCOR licensing.
- Clarify regional restrictions and the use of VPNs only if appropriate and compliant.
- Reassure players about their protections and responsible gaming commitments.
- Maintain a professional tone when discussing account suspensions or violations.