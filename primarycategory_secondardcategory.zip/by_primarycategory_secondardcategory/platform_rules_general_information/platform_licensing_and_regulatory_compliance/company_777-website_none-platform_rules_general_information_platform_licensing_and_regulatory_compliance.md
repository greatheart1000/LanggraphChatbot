# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's query or concern related to licensing or regulatory compliance.**  
   - Example topics include legitimacy, licensing, player protection, or responsible gaming.  
   - Confirm whether the inquiry is about site legitimacy, licensing status, or regulatory standards.

2. **Verify the player's identity and gather relevant account information, if necessary.**  
   - Ensure the account is active and the player is verified, following standard procedures.

3. **Check the licensing status of MERRYPH.**  
   - Confirm that MERRYPH operates under the PAGCOR license (Philippines gaming license).  
   - This information is consistent across FAQs: MERRYPH is licensed by PAGCOR, which ensures legality, player protection, and compliance.

4. **Explain the licensing and regulation to the player.**  
   - Inform that MERRYPH is a legitimate and licensed site under PAGCOR.  
   - Emphasize that licensing ensures player protection, responsible gaming, and adherence to applicable laws.  
   - Use language aligned with the FAQs, e.g., "MERRYPH is licensed under the Philippines PAGCOR license, which ensures compliance with local laws and provides safeguards for players."

5. **Confirm the platform's commitment to player protection and responsible gaming.**  
   - Reiterate that strict player protection practices are followed, such as recording winnings and losses automatically for fairness and accountability.  
   - Emphasize the platform's compliance with local regulations through PAGCOR licensing.

6. **Address privacy and confidentiality guarantees if asked.**  
   - Assure the player that all personal information is kept strictly confidential, never shared or leaked, and privacy is a top priority.

7. **If the player questions the legitimacy or safety of the platform, reinforce the license information.**  
   - Reiterate that operating under the PAGCOR license means the platform is regulated by the Philippines government, following strict rules for responsible gaming and player protection.

8. **If any additional verification or documentation is required by the player, advise accordingly.**  
   - Refer to the company's existing information on licensing and regulations.  
   - Do not need to verify license details beyond confirming the PAGCOR license status.

9. **Close the interaction once the player's questions are fully addressed.**  
   - Offer further assistance if needed and thank the player for their inquiry about platform compliance and licensing.

## Notes

- Always provide factual and consistent information verified by the site’s licensing details.  
- Do not modify or invent licensing details; rely solely on the fact that MERRYPH operates under a PAGCOR license.  
- Emphasize the connection between licensing and player protection, responsible gaming, and regulatory compliance, as supported by the FAQs.

## Key points for communicating with players

- Confirm MERRYPH’s license status under PAGCOR, highlighting that it is a legitimate, regulated site.  
- Reinforce that license ensures compliance with legal and responsible gaming standards.  
- Assure players of data privacy and confidentiality as standard practice.  
- Disclose that winnings and losses are automatically recorded to uphold fairness and accountability.