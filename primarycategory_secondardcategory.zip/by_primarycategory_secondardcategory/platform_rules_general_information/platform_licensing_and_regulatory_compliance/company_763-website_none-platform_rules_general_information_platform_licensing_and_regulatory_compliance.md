# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry regarding platform licensing, legitimacy, or regulatory compliance.**  
   - Ask for specific details about their concern or question to understand if they are inquiring about license validity, legitimacy, or compliance measures.

2. **Verify the player's concern with the company's licensing information in the back office or official resources.**  
   - Confirm that DAILYJILI operates under a PAGCOR license issued by the Philippines gaming authority.  
   - Ensure that the information matches the official licensing details, which establish the platform's legitimacy and compliance, providing player protection and responsible gaming standards.

3. **Determine the nature of the inquiry based on the player's question (e.g., license legitimacy, safety assurance, compliance policies).**  
   - If the player asks about licensing and legitimacy: explain that DAILYJILI is licensed and regulated by PAGCOR (Philippine Amusement and Gaming Corporation), which guarantees compliance with local laws and player protection.  
   - If the inquiry involves safety, responsible gaming, or legal protection: inform that the platform operates under this license, ensuring strict adherence to regulatory standards.

4. **Clarify the platform's licensing scope and the benefits for players.**  
   - Emphasize that the license from PAGCOR ensures the platform's operations are compliant with legal requirements and that players are protected under Philippine law.  
   - Mention that dailyJILI follows responsible gaming practices as part of the licensing obligations.

5. **If the player questions the platform's authenticity or legitimacy, provide reassurance based on licensing status.**  
   - State explicitly that DAILYJILI's operation under PAGCOR licensing confirms it is a legitimate and safe platform for players.

6. **If the player asks for specific actions or documentation related to licensing, inform them that:**
   - The licensing information is publicly available via official PAGCOR channels or the company's official website.
   - No additional documentation or verification steps are necessary from the player's side for licensing confirmation.

7. **In case the player provides additional details or displays suspicion about the platform's licensing:**
   - Cross-verify with the current official licensing details on the PAGCOR database or official communications.
   - Escalate to a supervisor if discrepancies are suspected or if further validation is required.

8. **Conclude the interaction by summarizing key points:**
   - Reiterate that DAILYJILI is licensed and regulated by PAGCOR.
   - Confirm that such licensing guarantees compliance with regulatory standards, protection, and responsible gaming.

9. **Close the case according to the company's standard procedures, ensuring no further licensing inquiries remain unresolved.**

## Notes
- Always rely on the information that DAILYJILI operates under a PAGCOR license, ensuring compliance and player safety.
- Do not attempt to provide unverified or unofficial licensing information.
- Be clear and transparent about the licensing confirmation process and direct players to official sources if requested.

## Key points for communicating with players
- Emphasize that DAILYJILI is licensed by PAGCOR, which guarantees compliance with strict gaming laws.
- Reinforce that operating under this license provides player protection and enforces responsible gaming practices.
- Provide reassurance that the platform is legitimate and safe based on its licensed status.