# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry about licensing, legitimacy, or safety of PHPARK.**  
   - Determine if the player is asking whether PHPARK is licensed, regulated, legitimate, or safe to use.

2. **Provide the appropriate response based on the inquiry:**
   - Confirm that PHPARK operates under a PAGCOR license in the Philippines, which ensures compliance with laws related to player protection and responsible gaming.
   - Emphasize that this licensing supports responsible gaming practices and that the platform adheres to regulatory standards.
   - Clarify that PHPARK is considered legitimate and safe, with funds and data protected by law, as a result of its PAGCOR licensing.
   
3. **If the player asks for verification of their deposit transaction:**
   - Request the player to submit a clear screenshot or proof of payment.
     - The proof must include:
       - Payment account details (e.g., GCash or PayMaya).
       - Transaction confirmation message.
       - Transaction date and amount.
     - Advise the player to ensure all these details are visible to facilitate quick processing.

4. **Review the submitted proof of deposit:**
   - Check if the screenshot clearly shows all required details as per above.
   - Verify that the transaction details match the player's account information.

5. **If the proof of deposit is complete and correct:**
   - Confirm the deposit verification with the player.
   - Proceed to credit the player's account according to the platform's process.
   
6. **If the proof of deposit is insufficient or incomplete:**
   - Inform the player that the submission is unclear or missing information.
   - Request a new, clear screenshot showing:
     - Transaction date.
     - Transaction amount.
     - Payment account details.
   - Advise the player to resubmit following these instructions.

7. **Escalate or handle edge cases as needed:**
   - If the transaction cannot be verified despite correct submission, escalate the issue to the relevant department following internal procedures.
   
8. **Document all interactions and proofs properly in the system.**  
   - Ensure that all relevant details are recorded for future reference and compliance checks.

## Notes
- PHPARK is licensed and regulated by PAGCOR, the Philippine gaming regulator, ensuring compliance with standards for player protection and responsible gaming.
- This license assures players that their funds and data are protected legally.
- When discussing licensing or safety, always refer to PHPARK's PAGCOR license and its implications for legitimacy and security.
- For deposit verification, clear and complete proof submission is crucial for processing.

## Key points for communicating with players
- Emphasize that PHPARK is licensed under PAGCOR, a reputable regulator.
- Clarify that this licensing ensures adherence to laws for player protection and responsible gaming.
- Request clear screenshots showing all necessary transaction details for deposit verification.
- Keep records of all submitted proofs and correspondence for compliance.