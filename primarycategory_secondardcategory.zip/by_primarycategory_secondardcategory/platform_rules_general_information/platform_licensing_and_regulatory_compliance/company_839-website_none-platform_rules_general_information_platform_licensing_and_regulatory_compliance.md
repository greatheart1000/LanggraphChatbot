# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player's inquiry regarding platform legitimacy or licensing status.**  
   - Collect the player's account information and specific question.

2. **Verify the player's account status and history if applicable.**  
   - Check for any irregular betting activity or account issues if relevant to the inquiry.

3. **Provide the player with accurate information about the licensing status of KINGJL.**  
   - Inform the player that KINGJL operates under a PAGCOR gaming license issued by the Philippines gaming authority.
   - Confirm that the license ensures compliance with legal requirements, player protection, and responsible gaming policies.
   - Clarify that KINGJL is a legitimate platform licensed in the Philippines and adheres to strict regulations enforced by PAGCOR.

4. **If the player questions operational legality outside the Philippines or mentions restrictions:**
   - Inform the player that KINGJL is licensed exclusively by PAGCOR in the Philippines and may not be authorized to operate in other jurisdictions.
   - Advise the player to verify local laws before using the platform if they are outside the licensed territory.

5. **Address questions about platform features or bonuses in relation to licensing:**
   - Clarify that KINGJL currently does not offer birthday bonuses, if applicable.
   - Emphasize that all platform operations comply with the licensed regulations, and any promotions follow site policies.

6. **If the player reports suspicious activity or irregular betting:**
   - Inform the player that if irregular betting activity is detected, profits gained from such activities may be deducted in accordance with system checks.
   - Explain the importance of responsible gaming and that the system monitors for irregular activity as part of site compliance.

7. **Ensure the player receives consistent and accurate information:**
   - Reinforce that KINGJL is licensed and regulated under PAGCOR, which enforces strict standards to ensure player protection and responsible gaming.

8. **Document the interaction and any relevant details in the support case.**

9. **Close the case with a summary of the provided information and reassurance regarding licensing and compliance.**

## Notes

- Always confirm that the information provided aligns with the latest official licensing and regulatory status.
- If the player asks about downloading the app or account access, refer to specific procedures for app download and login.

## Key points for communicating with players

- Emphasize that KINGJL operates under a PAGCOR license in the Philippines.
- Confirm the license ensures compliance with legal standards and player protection.
- Clarify that current promotions, such as birthday bonuses, are not offered.
- Stress the importance of responsible gaming and adherence to site rules, especially regarding irregular betting activity.
- Be transparent and consistent in relaying the licensing information to maintain trust.