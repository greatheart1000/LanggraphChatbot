# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the licensing and legitimacy of the platform.**  
   - Confirm that the player's inquiry pertains to PLUSPH, which operates under a PAGCOR gaming license issued in the Philippines, ensuring compliance with regulatory standards.  
   - Clearly communicate that PLUSPH is 100% legitimate with proper licensing, following rigorous player protection and responsible gaming practices (based on FAQs confirming legitimacy and licensing).

2. **Identify and document the player's access issues (if applicable).**  
   - Ask the player if they are unable to access the main site.  
   - If the player cannot access the site, provide the list of alternative URLs: 7plusph.com, 9plusph.com, 2plusph.com, 3plusph.com.

3. **Explain the platform’s regulatory status.**  
   - Inform the player that PLUSPH operates under the PAGCOR license issued in the Philippines, which ensures regulatory compliance and player protection.  
   - Emphasize that the platform follows responsible gaming practices and adheres to laws in the jurisdiction.

4. **Address specific inquiries regarding rewards and bonuses.**  
   - If the query concerns the Friday Rewards schedule:  
     - Explain that Rewards are automatically sent to the Rewards Center every Friday between 22:00 - 23:59 (GMT+8).  
     - Clarify that rewards include random rewards up to 699,999 PHP.  
     - Warn that if the system detects repetition involving the same IP address, bank card, or phone number, rewards and profits will be confiscated (based on FAQ about Friday Rewards and reward confiscation rules).

5. **Perform system checks related to betting activities.**  
   - Review the player's account activity for irregular betting behavior.  
   - If irregular activities are detected:  
     - Inform the player that profits from such activities will be subject to deduction.  
   - Clarify that if irregular betting activity is identified, any profits gained from these activities could be deducted (supported by FAQs about irregular betting activity).

6. **Document all findings and actions taken.**  
   - Record details of the licensing confirmation, access issues, rewards information provided, and any irregular activity alerts.  
   - If necessary, escalate cases involving suspicious activity or system issues according to internal protocols.

7. **Close the interaction.**  
   - Summarize the key points for the player: that PLUSPH is licensed by PAGCOR, operates legally and responsibly, and explain the specific process or reward schedule if relevant.  
   - Provide further assistance contacts if needed or advise on accessing the site via alternative URLs.

## Notes

- Always confirm the player's identity and account details before providing specific information about account activity or rewards.  
- The platform's licensing under PAGCOR is a key point to communicate for assurance of legitimacy and regulatory compliance.  
- Be vigilant about possible signs of irregular betting; investigate and escalate any suspicious activity as per company protocol.  

## Key points for communicating with players

- Reassure the player about PLUSPH’s legitimacy, licensed by PAGCOR.  
- Clearly explain reward schedules and potential confiscation rules related to repeated activity involving identical IP, bank card, or phone number.  
- Use the provided alternative URLs if the player reports access issues.  
- Address concerns about irregular activities with transparency regarding possible deductions.