# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the player's inquiry related to platform licensing or regulatory compliance.**
   - Confirm whether the player is asking about the site's license, safety, legitimacy, or related topics.
   - If the question pertains to licensing or safety, proceed; otherwise, handle according to standard protocols for other inquiries.

2. **Provide the relevant licensing and regulatory information.**   
   - Inform the player that PHJOIN operates under a PAGCOR license issued by the Philippines gaming authority.
   - Emphasize that PHJOIN adheres to strict player protection and responsible gaming practices, and players are protected by law.
   - Clearly state that PHJOIN operates under the compliance of the Philippines PAGCOR gaming license, ensuring legal safeguarding for players.

3. **Confirm and document the licensing details.**
   - Record that the platform is licensed and regulated by PAGCOR.
   - Verify that the player understands the licensing information by asking if they need further clarification.

4. **Address any specific concerns about safety or legitimacy.**
   - If the player queries whether PHJOIN is safe, specify that the PAGCOR license provides player protection and responsible gaming measures.
   - Confirm that PHJOIN is a legitimate platform licensed under Philippine law, reassuring the player of its legal status.

5. **If the player asks about download or access.**
   - Inform them that they can download the PHJOIN app by tapping the App Download option, then install it on Android or iOS devices.
   - Advise to open the app, log in or register, and start playing.

6. **Handle any follow-up questions or doubts related to licensing.**
   - Reiterate that PHJOIN's licensing by PAGCOR ensures compliance with regulatory standards and protects player rights.
   - If the player expresses concerns about legitimacy, explain that the license guarantees adherence to Philippine gaming laws and responsible gaming policies.

7. **Escalate or refer to further support if necessary.**
   - If the player presents issues that cannot be resolved through licensing information alone, escalate to the relevant department or supervisor for further assistance.

## Notes

- The SOP strictly reflects that PHJOIN operates under a PAGCOR license, providing legal and player protection.
- Do not invent or imply additional licensing details not explicitly stated in the FAQs.
- Ensure clarity and reassurance when explaining the licensing and regulatory status to maintain transparency with players.

## Key points for communicating with players

- Emphasize that PHJOIN operates under a PAGCOR license issued by the Philippines gaming authority.
- Confirm the platform’s compliance with strict legal and responsible gaming practices.
- Reassure players of their legal protection and the platform’s legitimacy based on official licensing.