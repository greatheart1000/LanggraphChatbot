# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Gather Player Inquiry or Concern**
   - Identify if the player is asking about platform licensing, regulation, or compliance.
   - Record the player's account details and nature of the question.

2. **Verify Licensing and Regulation Status**
   - Inform the player that ACESUPER operates under a gaming license issued by PAGCOR in the Philippines.
   - Confirm that the platform is licensed under PAGCOR, which ensures compliance with gaming regulations and player protection.
   - Emphasize that ACESUPER is licensed and regulated by PAGCOR, providing legitimacy, responsible gaming measures, and legal safeguards.

3. **Check for Specific Licensing Information or Claims**
   - If the player questions license validity, clarify that:
     - ACESUPER holds a PAGCOR gaming license.
     - The license guarantees adherence to player protection standards and responsible gaming obligations.
     - The platform is fully licensed, legal, and compliant with Philippine gaming laws.

4. **Assess Any Concern About Irregular Betting Activity**
   - If the player reports or questions irregular betting activity, review system alerts.
   - Explain that:
     - The platform monitors betting activity to detect anomalies.
     - Profits from irregular betting might be deducted as per policy.
     - Continue normal activity and contact support if the player believes there is a misunderstanding or if further review is needed.

5. **Address Technical or System-related Licensing Queries**
   - If the inquiry pertains to system maintenance or downtime:
     - Inform that scheduled maintenance windows (e.g., 10:00 AM to 12:00 PM GMT+8) may temporarily freeze in-game balances.
     - Confirm that balances are restored automatically after maintenance, with funds remaining secure.

6. **Provide Guidance on Accessing Promotions and Official Resources**
   - If the player asks about accessing the platform’s app or promotions:
     - Advise downloading the official ACESUPER app by tapping "App Download."
     - Follow instructions to install the Android app, then log in to access promotions.

7. **Explain Player Protections and Responsible Gaming Standards**
   - Reiterate that:
     - All player activities are protected by the PAGCOR license.
     - The license ensures compliance with high standards of responsible gaming and player safety.
  
8. **Close the Inquiry**
   - Summarize that ACESUPER is fully licensed and regulated by PAGCOR, which safeguards player rights and ensures legal compliance.
   - Offer further assistance if needed, or close the case if the player’s questions are fully addressed.

## Notes
- Always refer to the specific PAGCOR licensing in responses to confirm legitimacy.
- Emphasize compliance, responsible gaming, and legal safeguards when communicating with players.
- Do not provide legal opinions or unverified claims about the license or regulation.

## Key points for communicating with players
- Confirm the license status: ACESUPER operates under a PAGCOR license in the Philippines.
- Stress the importance of the PAGCOR license in providing player protection and responsible gaming.
- Clarify that the platform's licensed status ensures adherence to local laws and regulations.
- When discussing technical or operational downtimes, refer to scheduled maintenance windows and reassure on funds security.