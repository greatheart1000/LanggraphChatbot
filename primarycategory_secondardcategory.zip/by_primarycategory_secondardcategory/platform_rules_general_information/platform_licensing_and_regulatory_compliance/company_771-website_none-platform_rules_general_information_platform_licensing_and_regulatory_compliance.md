# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the player's inquiry or concern regarding licensing or regulatory compliance.**
   - Collect the details of the player's question to understand whether they are asking about platform legitimacy, licensing status, or protections in place.
   
2. **Inform the player of the licensing status and regulatory compliance of WINPH Casino.**
   - Clearly state that WINPH operates under a PAGCOR license issued by the Philippine Amusement and Gaming Corporation.
   - Emphasize that this license ensures the platform follows strict player-protection and responsible gaming practices, and that players are protected by law.
   - Confirm that WINPH Casino is licensed, regulated, and operates in accordance with Philippine law.

3. **If the player asks about protections and legitimacy:**
   - Explain that license under PAGCOR means adherence to regulatory standards, including rigorous player protection measures.
   - Clarify that the platform's operation under this license guarantees compliance with local gaming laws and responsible gaming practices.

4. **If the player inquiries about platform safety or legitimacy explicitly:**
   - Reiterate that WINPH's licensing under PAGCOR ensures the platform’s legitimacy and safety for use.
   - Confirm that the license ensures compliance with applicable gaming laws and standards.

5. **In cases where the player questions about the platform's authority or regulation:**
   - Confirm that WINPH Casino operates under a Philippine PAGCOR gaming license, ensuring compliance with the relevant regulatory authority.
   
6. **Do not provide additional business information not specified in the FAQs.**
   - Reinforce that WINPH does not offer loans or capital funding, if the question pertains to financial products.
   
7. **If the player asks for operational instructions or access to features related to licensing or compliance:**
   - Proceed with standard guidance for app download or other relevant functionalities, as detailed below.

8. **If the player’s question relates to irregular betting activity or account restrictions:**
   - Explain that if irregular betting activity is detected, the system may deduct illicit profits, and accounts may be suspended or restricted accordingly.

9. **For questions about accessing promotions or bonuses via the WINPH app:**
   - Guide the player to download the official app by:
     - Tapping "App Download",
     - Selecting Android or iOS,
     - Installing and opening the app.
   - Advise them to proceed to the promotions/bonuses section within the app for further details.

10. **In the case of becoming an agent or sharing referral links:**
    - Instruct the player to:
      - Click "Agent" on the homepage,
      - Copy their referral link,
      - Share it via social media platforms such as Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.

11. **If the player asks about downloading the app:**
    - Follow the steps:
      - Tap "App Download",
      - Choose Android or iOS,
      - Install and open the app.

12. **For any concerns not explicitly covered by the above steps, educate the player to refer to the platform's terms and conditions or official communications for more detailed information regarding licensing, regulation, and player protections.**

## Notes

- Always confirm the licensing information explicitly: WINPH operates under a PAGCOR license issued by the Philippine government.
- Reinforce that compliance with PAGCOR standards provides legal protection for players.
- Maintain transparency and be clear that the licensing ensures regulatory oversight, especially concerning responsible gaming and player protection.

## Key points for communicating with players

- Emphasize that WINPH is licensed by PAGCOR, which enforces strict standards.
- Assure players that their rights are protected under Philippine law.
- Reinforce that the license signifies compliance with local gaming laws and responsible gaming practices.
- Avoid providing unsupported or speculative information; stick to the facts from the FAQs.