# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's query or concern related to platform rules, licensing, or regulations.**
   
2. **Verify the player's account details and the context of their inquiry:**
   - Confirm their identity if necessary.
   - Determine if the question pertains to legitimacy, licensing, download procedures, or account activity.

3. **Address questions about platform legitimacy or licensing:**
   - Inform the player that PHJOY is 100% legitimate and operates under a PAGCOR license issued by the Philippines government.
   - Emphasize that the platform follows rigorous practices for player protection and responsible gaming, with legal protection in place.

4. **Assist with downloading or accessing the platform:**
   - For app download:
     - Guide the player to go to the official website.
     - Instruct to tap 'Download' and follow prompts.
     - For Android:
       - Tap the 'DOWNLOAD' icon on the homepage.
       - Select 'Install Android App' and proceed with installation.
       - If encountering Google Play Protect warnings, advise to tap 'More details' and select 'Install anyway'.
     - For iOS:
       - Follow official instructions specific to iOS devices (if provided in the current official guide).
   - For alternative website access:
     - Provide the alternative URLs: phjoy11.com, phjoy22.com, phjoy33.com, phjoy44.com.
     - Advise to save these URLs for future access.

5. **Assist with accessing promotions and bonuses:**
   - Explain that access is via the official app.
   - Confirm the player has downloaded and logged into the app.
   - Clarify that promotions and bonuses appear within the app environment.

6. **Verify the player's inquiry about account security or irregular activity:**
   - Check for system alerts or system logs indicating irregular betting activity or malicious arbitrage.
   - Inform the player that:
     - If irregular betting activity is detected, any illicit profits will be deducted.
     - Accounts involved in such activity may face restrictions.
   
7. **Investigate and handle account-related questions regarding licensing or regulatory compliance:**
   - Reiterate that PHJOY operates under a PAGCOR license, ensuring adherence to legal and regulatory standards.
   
8. **Confirm that the player’s question does not involve financial services outside of gaming:**
   - Clarify that PHJOY does not provide financial lending services.
   - Focus on resolving issues related to the gaming platform only.

9. **Help with game discovery:**
   - Guide the player to go to the Home page, click 'See All,' and browse available games.

10. **Provide guidance on becoming an agent (if applicable):**
    - Instruct to click 'Agent' on the homepage.
    - Copy their Referral Link.
    - Share the link on social media platforms like Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, or WhatsApp.

11. **Gather the necessary information if a player reports a referral issue:**
    - Check for reasons like multiple accounts, shared bank cards, same phone number, or same IP address.
    - Explain that if such are detected, the referral may not qualify for rewards.

12. **Escalate or direct the case if beyond standard troubleshooting or if system detection alerts are present.**

## Notes
- Always confirm the player’s account is verified when discussing sensitive topics like activity detection or licensing.
- Reinforce that all actions regarding account restrictions or deductions are based on system detections of irregular activities.
- When providing download instructions, follow current site configurations and official guidelines.

## Key points for communicating with players
- Emphasize the legitimacy and licensing status of PHJOY under PAGCOR.
- Keep explanations clear about the purpose and scope of the licensing—focused on player protection and responsible gaming.
- Use official URLs and steps to guide players smoothly through downloads and access.
- Clarify that the platform does not offer financial lending services.
- Be transparent about system detection of irregular betting leading to deductions or restrictions.