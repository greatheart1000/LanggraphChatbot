# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the player's inquiry or concern** to determine if it relates to licensing, legitimacy, or regulatory compliance of PHLOVE.

2. **Gather essential information from the player**, including:
   - Player’s account details (username, registration date, transaction history if applicable)
   - Nature of the question or issue (e.g., about legitimacy, licensing, downloads, or transaction confidentiality)

3. **Confirm the player’s specific concern**:
   - Is it about the legitimacy and licensing of PHLOVE?
   - Is it regarding downloading the app?
   - Is its about transaction confidentiality?
   - Or other related questions on user protection and compliance?

4. **Check the back office / system records**:
   - Confirm that PHLOVE operates under the PAGCOR license issued by the Philippine Amusement and Gaming Corporation (PAGCOR).
   - Verify that the account’s recent activity or registration details do not violate bonus rules (e.g., repeated registration for bonuses), ensuring the account is compliant.

5. **Address licensing and legitimacy questions**:
   - Inform the player that PHLOVE operates under a PAGCOR license, which ensures regulatory compliance, player protection, and adherence to Philippine laws.
   - Emphasize that PHLOVE is a legitimate platform with strict responsible gaming practices.
   - Reinforce that players are protected by law and that their transaction details are confidential and not disclosed to third parties.

6. **Handle app download inquiries**:
   - Explain the process to download the PHLOVE app:
     - Tap the “App Download” button.
     - Choose between Android or iOS.
     - Proceed with installing the app.
   - Clarify that downloading the app is necessary to access promotions and bonuses if they ask about that.

7. **Verify and reassure about transaction confidentiality**:
   - Confirm that transaction details are kept private, and the platform does not disclose customer information to third parties.

8. **If the player asks about other licensing or legal protections**:
   - Reiterate that PHLOVE is licensed by PAGCOR and operates under strict legal standards for player protection and responsible gaming.

9. **For questions about bonus or account restrictions**:
   - Check if the account has violated bonus regulations e.g., repeated registration to obtain bonuses.
   - If so, explain that the player must meet the:
     - Required turnover requirements again before withdrawal.
   - Inform that account access or withdrawal may be temporarily restricted if violations are detected.

10. **If the inquiry involves any suspected violation or account issues**:
    - Escalate the case according to standard procedures.
    - Inform the player that the matter is under review and ensure confidentiality.

11. **Close the interaction**:
    - Summarize the key point that PHLOVE is licensed by PAGCOR and follows strict practices for safety and compliance.
    - Reiterate that their information and transactions are protected.
    - Offer further assistance if needed.

## Notes

- Always verify license status by checking the system or official records confirming the PAGCOR license.
- Emphasize the legitimacy and safety of PHLOVE based on its license and compliance.
- Do not disclose sensitive transaction details or internal security procedures to players.
- When handling questions about bonuses, ensure the player understands they may need to meet turnover requirements before withdrawal if violations occurred.

## Key points for communicating with players

- Clearly state that PHLOVE is licensed under PAGCOR.
- Explain that the platform adheres to strict regulatory standards, ensuring player protection.
- Confirm that transaction details are confidential and protected by law.
- Guide players through download steps if they ask about accessing the app.
- If violations are suspected (e.g., bonus abuse), inform about the need to meet requirements before withdrawal and escalate if necessary.