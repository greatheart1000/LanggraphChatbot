# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Greet the player and clarify their inquiry**  
   - Determine if the player is asking about licensing, legitimacy, or regulatory compliance of PHFUN Casino.  
   - Ask for details if necessary to understand their specific concern or question.

2. **Verify the player's account and the nature of the query**  
   - Confirm if the player’s question relates to platform rules, licensing, legitimacy, or any account-specific issue.  
   - If the inquiry is about promotions, bonuses, or app download, proceed accordingly based on the relevant steps (see steps 4 and 5).

3. **Inform the player of licensing and legitimacy**  
   - Clearly state that PHFUN Casino operates under a Philippine gaming license issued by PAGCOR, ensuring compliance with player protection and responsible gaming standards.  
   - Emphasize that PHFUN is licensed and regulated under PAGCOR, which guarantees lawful operation and player protection, based on FAQs stating that the platform “operates under a Philippine gaming license issued by PAGCOR” and “is licensed and regulated.”

4. **Address questions about platform legitimacy and regulation**  
   - Reiterate that PHFUN Casino is licensed and protected by law through PAGCOR licensing.  
   - Confirm: PHFUN does not offer financial lending or credit services, only gaming and account support.  
   - Clarify that the site does not provide financial lending services as per the FAQ.

5. **If the player asks about app download or access to promotions/bonuses**  
   - Advise to download the official app to access promotions and bonuses.  
   - Provide steps:  
     - Tap "App Download" on the platform.  
     - Select Android or iOS.  
     - Proceed with the installation or open the app after installation.  
     - Note: the app offers faster access to promotions and bonuses as per FAQs.

6. **Address concerns about responsible gaming and account security**  
   - Remind the player that the platform complies with official gaming regulations and aims to ensure secure and responsible gaming practices, based on licensing info.

7. **Handle inquiries about bonus claiming periods**  
   - Inform the player that the Weekly Salary Bonus has a designated claiming period.  
   - If the claiming period has ended, advise waiting until the next period, or recommend contacting customer service for eligibility questions.

8. **Educate on platform policies**  
   - Inform that inappropriate language in chats with support is not permitted and may lead to account suspension or termination, as stated in the FAQs.

9. **If any verification or escalation is required**  
   - Collect necessary account information and details of the query.  
   - Escalate to specialized support if:  
     - The query involves licensing confirmation beyond standard info, or  
     - There are account security or legal compliance issues.  
   - Document all relevant information before escalation.

10. **Close the interaction appropriately**  
   - Summarize the key points relevant to the player's query.  
   - Offer further assistance if needed.  
   - Thank the player for their inquiry.

## Notes

- Always confirm that the information provided aligns with the latest official licensing and regulatory statements from PHFUN and PAGCOR.  
- Do not provide legal advice or speculative information beyond what is explicitly stated in the FAQs.  
- Focus on transparency about licensing, responsible gaming, and platform compliance.  

## Key points for communicating with players

- Emphasize that PHFUN operates under a PAGCOR license, ensuring legitimacy and protection.  
- Clarify that the platform does not offer financial services.  
- Encourage app download for faster access to promotions and bonuses.  
- Remind about chat conduct policies and the importance of respectful communication.