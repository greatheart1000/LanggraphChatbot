# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or concern related to platform licensing or compliance.**  
   - Collect relevant details about the player's question or specific issue.

2. **Verify the platform's licensing and regulatory status.**  
   - Confirm that the platform operates under a PAGCOR (Philippines gaming license), which indicates compliance with local gaming regulations.  
   - If the inquiry is about JILIPARK or the platform in general, acknowledge that it is licensed and regulated under PAGCOR standards.

3. **Check the specific platform or app involved.**  
   - If the player mentions the JILIPARK app, confirm that the app can be downloaded by tapping the App Download option, then choose Android or iOS, and follow the on-screen prompts to complete the installation.  
   - If the inquiry involves another platform, verify its licensing status in accordance with the same rules.

4. **Address questions about legitimacy and safety.**  
   - Reassure the player that JILIPARK is licensed by PAGCOR, ensuring adherence to legal and player protection standards.  
   - Emphasize that operating under this license helps support responsible gaming and legal safeguards for players.

5. **Clarify the implications of BSP directives for e-wallet services like GCash or Maya.**  
   - Explain that following the BSP directive, icons and links of online gambling platforms have been removed from these e-wallet apps within 48 hours.  
   - Clarify that this does not require unlinking the e-wallet account and that the services remain safe and available for other transactions.

6. **Assess the player’s account and system checks if needed.**  
   - If the player reports issues related to licensing or regulation, verify their account status and recent activity to ensure compliance and security.

7. **Provide a clear explanation or resolution based on the inquiry.**  
   - Confirm that the platform/license is valid, ensuring players understand the legitimacy and regulated status.  
   - If the player expresses concerns about safety, responsibility, or compliance, reiterate the platform’s PAGCOR licensing and regulation.

8. **Document the interaction and update any relevant records.**  
   - Record the player’s questions, clarifications provided, and the verification steps taken for future reference.

9. **If the inquiry reveals incomplete information or requires escalation, inform the player.**  
   - Advise that further investigation or higher-level support may be necessary and inform them of next steps or timeframes.

## Notes

- Always remember that the platform must operate under a PAGCOR license; no unlicensed or unregulated platforms should be considered compliant.  
- The removal of online gambling icons from GCash and Maya is a regulatory requirement, not an indication of platform illegitimacy.  
- Clear communication about the regulatory environment helps maintain player trust and understanding.  

## Key points for communicating with players

- Confirm licensing status via PAGCOR for JILIPARK or the platform involved.  
- Explain that the removal of gambling icons from GCash or Maya does not mean their accounts or services are unsafe; it’s a regulatory measure.  
- Emphasize that JILIPARK operates under a strict PAGCOR license, which ensures compliance with local laws and responsible gaming standards.