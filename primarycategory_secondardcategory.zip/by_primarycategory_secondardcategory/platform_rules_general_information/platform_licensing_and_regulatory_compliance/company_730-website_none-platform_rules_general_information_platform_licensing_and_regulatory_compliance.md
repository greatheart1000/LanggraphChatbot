# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry**:
   - Determine if the question relates to licensing, regulation, or legitimacy of ACEPH.
   - Common keywords include "licensed," "regulated," " legitimacy," or "law."

2. **Verify the player's concern**:
   - If the player questions the legitimacy or licensing of ACEPH:
     - Confirm that ACEPH operates under a PAGCOR gaming license issued in the Philippines.
     - Inform the player that ACEPH adheres to high standards of player protection and responsible gaming under PAGCOR regulation.

3. **Explain license and regulation details**:
   - Clearly state: "ACEPH is licensed and regulated by PAGCOR, the Philippines gaming regulator."
   - Emphasize that this licensing ensures compliance with laws and regulations, safeguarding players' rights.

4. **Address questions about the platform's legitimacy**:
   - If asked whether ACEPH is a legitimate platform:
     - Reiterate: "ACEPH operates under a PAGCOR gaming license, ensuring adherence to legal standards."

5. **Provide information on platform accessibility and features**:
   - If the player asks about accessing promotions and bonuses:
     - Advise downloading the official ACEPH app.
     - Guide the player through:
       - Tap "App Download"
       - Install the Android or iOS app
       - Log in to view and claim current promotions and bonuses

6. **Handle inquiries about becoming an Agent**:
   - If relevant:
     - Explain that to become an Agent:
       - Click 'Agent' on the homepage
       - Copy the referral link
       - Share the link on social media platforms like Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.

7. **Address conduct and chat policies**:
   - Reinforce rules: Profanity or abusive language is prohibited.
   - Advise that violations may result in account suspension, termination, or chat closure.

8. **Escalate or document if necessary**:
   - If the question involves specific legal or licensing concerns beyond standard explanations, escalate to a supervisor or compliance team.
   - Document the interaction as per company policy for future reference.

## Notes

- Always base explanations on the fact that ACEPH is licensed under PAGCOR.
- Do not invent or assume additional legal or regulatory details beyond those explicitly confirmed.
- Focus on conveying the licensing status and adherence to responsible gaming standards clearly and accurately.

## Key points for communicating with players

- Emphasize that ACEPH is licensed and regulated by PAGCOR.
- Assure players of adherence to high standards of player protection and responsible gaming.
- Use straightforward language, avoiding technical jargon unless necessary.
- Confirm the source of the licensing information if challenged.