# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Identify the player's inquiry or issue related to platform rules, licensing, or compliance.**
   - Confirm if the player is asking about refunds, deposits, withdrawals, or game outcomes.
   - Determine if they inquire about platform licensing, regulatory compliance, or related policies.

2. **Gather necessary information from the player.**
   - For refund-related questions:
     - Clarify that **no refunds** are given for deposits, withdrawals, bets, or game outcomes.
   - For licensing or regulatory questions:
     - Confirm that the platform operates under a **PAGCOR license**, ensuring compliance with Philippine gaming regulations.
   - For deposit inquiries:
     - Ask for the deposit amount if relevant.
   
3. **Verify the player's deposit or transaction details (if applicable).**
   - Request the relevant document:
     - **Deposit Slip**: if the player mentions a deposit transaction.
     - **Deposit Receipt**: to confirm funds have been credited.
     - **Receiving Slip**: if the player claims funds were sent via GCash.
   - Ensure the correct document is used for verification:
     - Do not confuse a receiving slip with a deposit slip.

4. **Check the player's account status and transaction history in the system.**
   - Confirm if the deposit has been credited or if the withdrawal has been processed.
   - For deposit:
     - Verify that the amount meets the **minimum deposit amount of 100 PHP**.
   - For funds during game maintenance:
     - Inform that **funds remain safe** during maintenance and are automatically returned after the game is back up.

5. **Address the player's inquiry based on the verified information:**
   - If the question pertains to refunds or disputes:
     - Clearly inform that **no refunds** are provided for any deposits, withdrawals, bets, or game results.
   - If the inquiry is about licensing:
     - Confirm that the platform is **licensed and compliant** under PAGCOR, ensuring adherence to local regulations.
   - If the issue relates to fund safety during maintenance:
     - Reassure that funds are secure and will be returned automatically after maintenance ends.

6. **If the information provided is insufficient or unclear:**
   - Request additional details or documents from the player.
   - Escalate the case to higher support or relevant department if necessary, especially if further investigation is required.

7. **Close the interaction with a clear summary of the key points:**
   - Reinforce that no refunds are available.
   - Confirm the licensing status and compliance details as applicable.
   - Advise on the next steps if needed (e.g., waiting for maintenance to end).

8. **Document the case and actions taken in the system, including any provided documents or clarifications.**

## Notes
- Always verify transaction documents carefully; using the correct document (deposit slip, deposit receipt, receiving slip) is essential.
- Remind players that the platform operates under PAGCOR license, indicating compliance with Philippine regulations.
- Clarify to players that during game maintenance, funds are safe and will be automatically returned; no action is necessary from their side regarding fund security.

## Key points for communicating with players
- Emphasize that **no refunds** are available for any transactions or outcomes.
- Confirm the platform's **licensing with PAGCOR** to reassure compliance.
- Ensure players know their funds are safe during maintenance and will be automatically restored afterward.