# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Verify the player's inquiry related to licensing and regulation**  
   Ask the player to specify their concern about platform licensing or regulatory compliance. If the player asks if PHWIN is licensed, regulated, or safe, proceed to the next step.

2. **Confirm licensing status**  
   - Inform the player that PHWIN operates under a legitimate license issued by the Philippine Amusement and Gaming Corporation (PAGCOR).  
   - Explain that this license ensures compliance with local gaming regulations, supports player protection, and promotes responsible gaming.  
   - Use official confirmation from the FAQs: "PHWIN is licensed and regulated by PAGCOR."

3. **Provide contact and official channel information**  
   - Share the official Telegram channel: https://t.me/PHWIN_OfficialPage.  
   - Emphasize that players should use official channels for updates and support.

4. **Address queries about online-gambling icons and links in e-wallet apps**  
   - If the player inquires about using GCash or Maya for PHWIN after the BSP directive, explain:  
     - The BSP required e-wallet providers to remove online-gambling icons/links within 48 hours.  
     - Players do not need to unlink their e-wallet accounts; services remain safe and active for other transactions.  
     - Icons/links to PHWIN will no longer be visible in the apps.

5. **Handle questions about protections and player rights**  
   - Confirm that PHWIN's PAGCOR license ensures all operations are regulated under Philippine law, providing legal protections for players.  
   - Reiterate that the platform implements practices for responsible gaming and player protection.

6. **Check for any account irregularities related to licensing and regulation**  
   - If the player reports suspicious activity or concerns about violations, clarify that irregular betting activity may result in profit deductions, as per standard platform practice.  
   - Explain that the platform's operations are overseen by PAGCOR, safeguarding players under the law.

7. **Provide additional verification if requested**  
   - If a player asks for further proof of licensing, refer to the official PAGCOR licensing authority and advise to contact PHWIN directly via their official channels for confirmation.

## Notes
- Always emphasize that PHWIN's license from PAGCOR supports compliance, player protection, and responsible gaming.  
- Clearly communicate that the removal of online gambling icons/links in e-wallet apps was mandated by the BSP and does not affect the safety or continued use of the e-wallet services.

## Key points for communicating with players
- PHWIN is licensed and regulated by PAGCOR, ensuring a legitimate and compliant operation.  
- The license supports player protections and responsible gaming practices.  
- The BSP directive required removing online-gambling icons/links from e-wallet apps within 48 hours, but e-wallet services remain active and safe for other transactions.  
- Use official channels like https://t.me/PHWIN_OfficialPage for updates and support.