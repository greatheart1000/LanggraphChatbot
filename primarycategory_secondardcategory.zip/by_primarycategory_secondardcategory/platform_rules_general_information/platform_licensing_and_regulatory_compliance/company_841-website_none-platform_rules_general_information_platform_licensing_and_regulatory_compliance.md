# Platform Rules & General Information - Platform Licensing and Regulatory Compliance

## Steps

1. **Receive the player inquiry regarding licensing or regulation status**.  
   - Record the player's question accurately to determine if they are asking about licensing, regulation, fairness, or irregular betting activity.

2. **Verify licensing and regulatory status in the back office/system based on the inquiry**.  
   - Confirm that 639CLUB operates under a PAGCOR gaming license issued in the Philippines, ensuring compliance with local regulations and protections for players.  
   - Check if the platform explicitly states it is licensed and regulated by a gaming authority (PAGCOR).

3. **Assess the specific nature of the player's query**.  
   - If the player asks about whether the platform is licensed and regulated:  
     - Inform them that 639CLUB is licensed under PAGCOR, which means the site operates legally under Philippine law and is subject to regulatory standards that protect players and promote responsible gaming.  
   - If the player asks about the fairness of games or platform regulation:  
     - Confirm that games are computer-generated and cannot be manually programmed, with winnings and losses automatically recorded.  
     - Reinforce that the platform's PAGCOR license ensures regulatory compliance and player protections.

4. **Address inquiries about irregular betting activity**.  
   - Inform the player that if irregular betting activity is detected, profits gained from such activity may be deducted as part of the platform’s risk controls.

5. **If the player’s question involves additional clarification or suspicion of unlicensed operation**:  
   - Reaffirm that 639CLUB operates under a legitimate PAGCOR license, providing official confirmation of legal status and regulation.

6. **If the required information is available and aligns with the FAQs**:  
   - Provide the player with accurate details based on the confirmed license and regulation status.  

7. **Document the interaction, including the player’s question, the information provided, and any decisions made**.  
   - Escalate to management if any discrepancies or suspicions arise, or if further validation is needed.

## Notes

- Always rely on official licensing confirmation that 639CLUB operates under PAGCOR, as explicitly stated in the FAQs.  
- Clearly communicate that the license ensures adherence to regulatory standards for fair play, responsible gaming, and player protection.  
- Transparently explain that in case of irregular betting activity, profits from such activity may be deducted, in line with risk control policies.

## Key points for communicating with players

- Emphasize that 639CLUB is licensed under PAGCOR, meaning it is legally regulated in the Philippines.  
- Highlight that the platform adheres to standards for fair gaming and responsible gaming.  
- Clarify that irregular betting activity may result in the deduction of profits, if detected.