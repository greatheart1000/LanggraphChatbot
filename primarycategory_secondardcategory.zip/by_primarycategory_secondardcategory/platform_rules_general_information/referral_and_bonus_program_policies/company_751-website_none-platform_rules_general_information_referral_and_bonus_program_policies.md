# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding referral or bonus program policies.**
   - Clarify if the player is asking about referral eligibility, commissions, bonus claiming, or specific events like Invite and Earn Red Envelope.

2. **Verify the player's account details and registration information.**
   - Ensure the player is logged into their account.
   - Confirm the registration details such as phone number, bank card, and IP address.

3. **Request information about the referred players (if applicable).**
   - Ask for the details of each referral, including:
     - Player's phone number or username.
     - Deposit amount made by the referral.
     - Confirmation that the referral has reached the minimum deposit of 200 PHP.
     - Confirmation that turnover of 1200 PHP has been completed (if required for the specific promotion).
   - Note: The player must have invited at least 20 players to be eligible for a 488 PHP bonus, or 50 players for the 888 PHP bonus.

4. **Check the validity of the referral(s).**
   - Review whether the referral:
     - Reached a total deposit of 200 PHP.
     - Completed the required turnover of 1200 PHP.
     - Has no multiple account registration associated with the player.
     - Is not using the same bank card, phone number, or IP address as the referrer or other known invalid patterns.
   - **If the referral does not meet these conditions:**
     - Inform the player that the referral is invalid and cannot qualify for commissions or bonuses.
     - Document the case for further review if necessary.

5. **Verify the deposit and betting activity for valid referrals.**
   - Confirm whether the referred player has deposited at least 200 PHP.
   - Confirm whether the referred player has completed the required turnover of 1200 PHP.
   - Check the deposit and bet activity to ensure compliance with the rules.

6. **Check the system for earned commissions and bonuses.**
   - Confirm via the Rewards Center or back-office system:
     - Whether the referral bonus of 128 PHP is available for manual claim.
     - Whether the deposit commission (0.88%) and bet commission (0.64%) are tracked and ready for payout.
     - Ensure commissions are only paid after the referral's activity is validated and no violations are found.

7. **Explain to the player the process for claiming bonuses and commissions.**
   - If conditions are met, inform the player they can manually claim the ₱128 referral bonus via the Rewards Center.
   - Clarify that commissions on deposits and bets are automatically sent after the referral's activity is verified.

8. **Address any violations or suspicious activity reports.**
   - If multiple accounts, similar IPs, bank cards, or phone numbers are detected, inform the player that the referral may be disqualified.
   - Note that commissions from invalid referrals may be deducted per policy.

9. **Provide guidance on earning maximum bonuses.**
   - Inform the player they can earn up to 8,888,888 PHP by reaching higher tiers through successful invites.
   - Mention the incentive to invite more players (20 players for 488 PHP bonus, 50 for 888 PHP bonus, up to the maximum tier).

10. **Conclude the case with a summary of actions taken and next steps.**
    - Confirm whether the referral qualifies for bonuses or commissions.
    - Advise on manual bonus claim or automatic processing as appropriate.
    - Escalate any unresolved issues to the relevant department if required.

## Notes
- Ensure all checks align with the specific requirements: minimum deposit of 200 PHP and turnover of 1200 PHP per referral.
- Be aware that commissions can be deducted if policy violations are identified.
- Remind players to maintain their account details consistent and avoid using multiple accounts or the same bank cards, phone numbers, or IPs for valid referrals.

## Key points for communicating with players
- Clearly explain the qualification criteria for valid referrals.
- Advise players to invite genuine users who will meet the deposit and turnover conditions.
- Remind them that bonuses and commissions require manual or system processing, and verification may take some time.
- Reinforce that violations such as multiple accounts or identical details can disqualify referrals or lead to deduction of commissions.