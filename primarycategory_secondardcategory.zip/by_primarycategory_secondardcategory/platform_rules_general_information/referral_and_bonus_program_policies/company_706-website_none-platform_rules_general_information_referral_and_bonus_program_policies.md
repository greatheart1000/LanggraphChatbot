# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry or request related to the referral or bonus program.**

2. **Verify the player's identity and account status.**
   - Confirm that the player is using the account under their primary details.
   - Check for any multiple account registrations from the same IP address, phone number, or binding the same bank card, as these violations may invalidate their referral or bonus eligibility (FAQs: "What are the referral program requirements," "Why might my referral not be qualified").

3. **Explain the basic structure of the referral program to the player.**
   - Mention that they can earn 89 PHP per invited player, 0.89% on each downline deposit, and 0.70% on downline bets.
   - Inform them about tier-based rewards: e.g., up to 8,800,000 PHP for reaching higher tiers.
   - Clarify that a referral is valid only if the referred player reaches a total deposit of at least 200 PHP.

4. **Ask the player for details about their current referral setup and the referred players.**
   - Confirm if they have shared their referral link.
   - Check if the referred players have deposited at least 200 PHP in total.
   - Verify if the referrals fulfill the conditions, such as no multiple accounts, same bank card, phone number, or IP address.

5. **Check the referral activity and qualification status in the system.**
   - Access the Bonus Center or relevant system dashboard.
   - Verify whether the referred players have deposited at least 200 PHP.
   - Confirm if the players' bets and deposits meet the program requirements for commissions to be credited.
   - For multi-level tiers, verify if downline deposits and bets are properly tracked across levels (up to 3 levels).

6. **Determine if the referral qualifies for commissions based on system data.**
   - If the referral has deposited at least 200 PHP and met the required actions (bets, deposits), proceed.
   - If not, inform the player of the reasons (e.g., referral did not reach the deposit threshold, multiple accounts, or policy violations).

7. **Explain to the player how commissions are paid.**
   - Clarify they will receive commissions automatically after the downline's deposits and bets are processed.
   - Instruct them to check the Bonus Center or Rewards Section for view and claim options.

8. **Address potential issues or violations if applicable.**
   - If referrals are disqualified due to policy violations (e.g., multiple account registration, same bank card/IP), inform the player that the referral is invalid and no commissions will be credited.
   - Remind the player that commissions are only valid for qualified referrals according to the policies.

9. **Advise the player on how to secure future referral success.**
   - Share best practices: avoid creating multiple accounts, do not bind the same bank card or phone number to multiple accounts, and promote referrals over legitimate, compliant means.
   - Emphasize the importance of reaching the deposit threshold of 200 PHP for each referral.

10. **If applicable, assist the player in sharing their referral link.**
    - Guide them to find their Referral Link by clicking on “Agent” on the homepage.
    - Instruct them to share this link through their preferred social platforms.

11. **Conclude the interaction by confirming understanding and offering further assistance.**
    - Reiterate the key points of the referral and bonus policy.
    - Offer further help if they have any other questions.

## Notes
- All commissions are paid automatically once qualifying actions are completed.
- Multiple account violations (same IP, bank card, phone number) will invalidate referrals and forfeit commissions.
- A referral remains valid only if the total deposit by the referred player reaches 200 PHP.
- Tiered rewards can be reached by inviting more players, with specific bonus tiers (e.g., 5 players = 100 bonus, 20 players = 400 bonus, etc.).
- Check the Bonus Center regularly for commission status and claims.

## Key points for communicating with players
- Clearly explain the requirement of at least 200 PHP deposit for a referral to be valid.
- Warn about disqualifications due to policy violations (multiple accounts, same bank card, etc.).
- Remind that commissions are automatically paid and can be viewed or claimed in the Bonus Center.
- Encourage compliance with the referral program rules to maximize rewards.