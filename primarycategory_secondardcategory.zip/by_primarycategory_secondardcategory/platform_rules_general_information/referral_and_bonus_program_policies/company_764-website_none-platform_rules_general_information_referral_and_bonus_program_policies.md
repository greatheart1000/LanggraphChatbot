# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Collect player query details and verify the specific concern.**  
   - Identify if the player is asking about referral rewards, bonus redemption, or issues with bonus credits.

2. **Determine the player's eligibility status for referral or bonus rewards.**  
   - Request the player's account details, including registered phone number, bank card information, and IP address if applicable.

3. **Check if the player has received or entered a valid gift code for redeeming promo or gift rewards.**  
   - Ask the player to enter the gift code into the gift box within the game.  
   - Confirm whether the gift code is valid and has been received.  
   - If no gift code was received, inform the player they are ineligible for the promo reward.

4. **Review the player's referral activity and status.**  
   - Confirm if the player has shared their referral link or code properly.  
   - Request details about the referred friends, such as account creation, deposit amount, and deposit date, if known.

5. **Verify the referral eligibility for the referred user.**  
   - Confirm whether the referred user has created a new account and made a deposit of at least 200 PHP.  
   - Check for signs of multiple registrations, same bank card, same phone number, or same IP address linked to the referral.  
   - If any disqualifying factors are detected, inform the player that the referral may be invalidated and bonus eligibility is affected.

6. **Check the statuses of deposited amounts and bets for the referred users.**  
   - Confirm if the referred user has deposited ≥200 PHP.  
   - Verify whether deposits and bets by the referred user have been properly registered in the system.

7. **Identify if the referral bonuses or commissions have been credited.**  
   - Check the player's account bonus or commission history for reward credits.  
   - If rewards are missing, verify if the referral qualifies, based on deposit and activity criteria.

8. **Explain the specific reward calculation and conditions to the player.**  
   - Inform them that:  
     - They earn ₱200 per successful invite  
     - They earn 0.77% on the deposit amount of the invitee  
     - They earn 0.55% on bets placed by the invitee  
     - They can earn bonuses on each tier with multi-level commissions  
     - Rewards are automatically granted once the invited user deposits and/or bets

9. **Advise the player on possible reasons for missing bonuses or commissions.**  
   - Highlight common causes:  
     - Multiple account registrations  
     - Binding the same bank card or phone number to multiple accounts  
     - Sharing the same IP address with the referral  
     - The referred user not reaching a deposit of 200 PHP or not engaging further in activity

10. **If the conditions for earning rewards are met but bonuses are still not credited, escalate as needed.**  
    - Suggest the player check their account history again.  
    - If confirmed that all conditions are met and rewards are still missing, escalate to technical support or back office review.

11. **Provide guidance to the player on the Maya 6% rebate program or other specific promotions if applicable.**  
    - Explain that deposits via Maya e-wallet earn a 6% rebate, credited automatically upon deposit, with no limits on deposit or withdrawal amounts when using Maya.

## Notes

- Always confirm the exact deposit amount (≥200 PHP) and activity status of the referred user before attributing rewards.
- Remember that multiple accounts, same bank card, same phone number, or same IP address can disqualify a referral.
- Referral rewards are only valid once the specified conditions are satisfied, and automatic reward granting depends on system detection of deposit and betting activities.
- When in doubt, escalate to the appropriate back-office team for further verification.

## Key points for communicating with players

- Clearly explain the eligibility requirements for referrals: deposit of at least 200 PHP, unique account details, and no shared IP or device info.
- Inform players that bonuses are awarded automatically after conditions are met and verified.
- Emphasize the importance of using correct and unique account details when referring friends.
- Remind players that incomplete activity or violations of rules may result in disqualification or non-credit of rewards.