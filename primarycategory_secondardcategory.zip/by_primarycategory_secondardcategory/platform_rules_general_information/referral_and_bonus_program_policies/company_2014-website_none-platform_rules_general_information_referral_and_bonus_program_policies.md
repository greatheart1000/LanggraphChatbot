# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry or report regarding referral or bonus program**  
   - Identify if the issue pertains to eligibility, commissions, bonuses, or registration.

2. **Verify the player's account information and details**  
   - Confirm the player's identity and account status.  
   - Ask the player for their account details, including registered phone number, bank card used, IP address, and referral link used (if applicable).

3. **Determine if the referral qualifies as valid**  
   - Check if the referred player has deposited at least PHP 200.  
   - Confirm the referred player's activity includes fulfilling the required turnover (e.g., PHP 1,000 in bets).  
   - Verify the referral did not involve any violations such as multiple accounts, duplicate registration details, same IP addresses, bank cards, or phone numbers that could invalidate the referral.

4. **Confirm deposit and betting activity**  
   - Verify in the system whether the referred player has deposited PHP 200 or more.  
   - Check if the deposit and bets meet the conditions for commission crediting, including the turnover requirement (specifically PHP 1,000).  
   - Ensure the deposit and betting are legitimate, confirmed, and not flagged for violation.

5. **Check for bonus eligibility and automatic crediting**  
   - Confirm that the referral or agent bonuses are valid based on the system policies:  
     - Referral bonuses are awarded when the referred user deposits at least PHP 200 and completes the required turnover.  
     - Commissions are automatically credited once deposit and betting thresholds are met.  
   - If the referral is invalid (e.g., multiple registrations, same IP, etc.), inform the player that bonuses and commissions will not be awarded.

6. **Resolve of eligible referrals or deposits**  
   - If all conditions are met:  
     - Inform the player that their referral or bonus has been qualified and that the system will automatically credit the bonus/commission via the Reward Center.  
     - No manual intervention is needed unless there is a discrepancy or system error—document the case accordingly.

7. **Handle cases of ineligibility**  
   - If the referral or deposit does not meet the minimum conditions:  
     - Explain clearly that bonuses or commissions are invalid due to the failure in meeting deposit amount, turnover, or due to violations like multiple accounts or reused details.  
     - Advise the player on the specific condition not met, providing guidance on what is required for eligibility if they wish to attempt again.

8. **Escalation and documentation**  
   - If there is a system error or suspicious activity, escalate to the relevant department as per internal protocol.  
   - Document all findings, checks performed, and the outcome in the system case notes.

## Notes

- Always verify the deposit amount (PHP 200 minimum) and turnover (PHP 1,000) for eligibility.  
- Commissions and bonuses are automatically credited once all requirements are satisfied, and no manual payout is typically necessary.  
- Violations such as multiple accounts, duplicate registrations, same IP, bank card, or phone number can invalidate the referral or bonus.  
- Ensure transparent communication: inform players clearly about the reasons for invalidation if applicable.

## Key points for communicating with players

- Clearly explain the conditions for valid referrals: minimum PHP 200 deposit, PHP 1,000 turnover, and no violations.  
- Emphasize that bonuses are credited automatically after meeting all criteria.  
- If invalid, specify the violated rule (e.g., multiple accounts or insufficient deposit).  
- Always maintain professionalism and provide precise information based on system verification.