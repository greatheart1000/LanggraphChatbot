# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding the referral or bonus program.**  
   - Clarify the specifics of their question (e.g., referral process, rewards, commissions, eligibility, or claiming process).

2. **Verify player identity and access to relevant account information.**  
   - Ensure the player is logged into their account and has access to their member area.

3. **Collect necessary information from the player if applicable.**  
   - Ask for their referral link or ID.
   - Confirm if they have referred players before and the number of referrals.
   - Inquire about the deposit amounts and bet activity of referred players (if needed to explain or troubleshoot).

4. **Check the player's referral program eligibility and referral activity in the system.**  
   - Navigate to **Member > Invite Friends > Records** to view current referrals and deposit/betting history of downlines.
   - Confirm that each referral has deposited at least 200 PHP to qualify.
   - Verify that the referral does not use the same IP address, bank card, or phone number as the referrer, to ensure compliance with policies.

5. **Assess whether any policy violations exist.**  
   - Review if multiple accounts were created from the same IP address using a referral link.
   - Check for violations such as multiple accounts, same bank card, phone number, or IP address used for the referral.
   - Determine if there is any evidence of violating the policy, which could lead to invalidation of commissions or disqualification of referrals.

6. **Explain the referral program structure and rules to the player.**  
   - Clarify that:
     - They earn ₱200 for each successful referral whose deposit reaches 200 PHP.
     - They earn 0.68% on each deposit made by their downline.
     - They earn 0.74% on each bet placed by the downline.
   - Mention that bonuses can be distributed as additional tier rewards.
   - Emphasize that commissions are automatically paid after the downline deposits and bets.

7. **Guide the player on how to view and claim their commissions and rewards.**  
   - Instruct them to go to **Member > Rewards Center**.
   - To view referral records, go to **Invite Friends > Records**.
   - To claim rewards, click **Claim** in the Rewards Center.

8. **Inform the player about the weekly rewards program (if applicable).**  
   - Mention that it runs every Thursday.
   - They must log in during the rewards window and visit the Rewards Center to claim.
   - The rewards may include random bonuses up to a cap (e.g., 888,888 PHP).

9. **Warn about policy compliance and possible disqualifications.**  
   - Advise that creating multiple accounts using the same referral link or from the same IP address, binding the same bank card, or using the same phone number can disqualify the referral.
   - State that violations may lead to deduction or invalidation of earned commissions.

10. **Provide troubleshooting or additional guidance if the player’s referral or reward status appears irregular or if commissions are not received.**  
    - Confirm whether the referral deposit or betting activity has been completed.
    - Verify that all policies have been adhered to and review any flagged account activity.
    - Advise that commissions are only paid after qualifying deposit and betting activity.

11. **If necessary, escalate issues that cannot be resolved by the current information or system checks.**  
    - Gather and document all relevant details.
    - Forward to the appropriate support or compliance team based on your process.

## Notes

- Ensure all communication emphasizes adherence to policies preventing multiple accounts, same bank card, phone number, or IP address from being used for multiple registrations.
- Remember that all referrals must deposit at least 200 PHP to qualify for commissions.
- Commissions are automatically paid; manual intervention is only required if there is a discrepancy or dispute.