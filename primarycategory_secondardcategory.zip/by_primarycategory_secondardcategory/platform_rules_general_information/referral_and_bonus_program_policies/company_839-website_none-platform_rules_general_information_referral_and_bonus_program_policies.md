# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry about the referral or bonus program.**
   - Clarify if the player is requesting information about earning commissions, bonuses, or eligibility criteria.

2. **Verify whether the player is asking about a specific referral or bonus activity.**
   - If yes, proceed to gather detailed information.
   - If no, provide a general overview of the program based on the FAQs.

3. **Collect necessary information from the player:**
   - Player's registered phone number, bank card details, IP address, and system account details (if applicable).
   - Details about the referred players' activities, such as deposit amount and betting activity.

4. **Check the referral activity details against system logs:**
   - Confirm if the referred player has deposited at least **200 PHP**.
   - Verify that the referral does not involve multiple accounts, duplicate bank cards, same phone number, or same/multiple IP addresses as the referrer.
   - Ensure the deposit and betting activities are completed and conform to the rules for earning commissions and bonuses.

5. **Determine if the referral is valid:**
   - If the downline has deposited **200 PHP or more** and all disqualifying conditions (multiple accounts, same IP/phone/bank card) are absent, the referral is valid.
   - If the referral does **not** meet these criteria, inform the player that the referral is invalid or ineligible.

6. **If the referral is valid and has completed deposit and betting activities:**
   - Confirm that the total deposit amount is **at least 200 PHP**.
   - Check if the referred user has placed bets and if the account activity qualifies for commission distribution.

7. **Verify if the commissions or bonuses have been automatically credited:**
   - Confirm in the backend systems if the referral bonus of **208 PHP** has been credited automatically after deposit and betting.
   - Check the Reward Center for any pending claims.

8. **If commissions or bonuses are not credited yet:**
   - Instruct the player to visit the Reward Center.
   - Guide them to click the **'Claim'** button to receive their commissions or bonuses.

9. **Address any suspected fraudulent activity or policy violations:**
   - If the system detects suspicious activity (e.g., multiple registrations, same IPs, duplicate bank cards), inform the player that the referral or bonus is disqualified.
   - Escalate the case to the relevant department if fraud suspicion is confirmed.

10. **Communicate the results to the player clearly:**
    - Confirm whether the referral activity is eligible and whether the commissions/bonuses are credited.
    - Explain the automatic credit process and the requirement to claim manually if necessary.
    - Remind players that suspicious or disqualifying activities will lead to non-qualification.

11. **If the player asks about ongoing or future bonuses, promotions, or events (like the Refer A Friend / Angpao Event):**
    - Tell them they can participate by completing the required tasks (e.g., inviting friends, accumulating scores through activities).
    - Explain that rewards are sent automatically after task completion and that only one active Ticket can be used at a time.

12. **Document the interaction and any evidence (screenshots, activity logs) in the player’s case record.**

## Notes
- Referral commissions are credited automatically after the referred player deposits **200 PHP** and places bets.
- Bonuses and commissions may be disqualified if the referral involves multiple accounts, duplicate bank cards, same IP address, or same phone number.
- The 'Claim' button in the Reward Center must be used to manually claim commissions that are not auto-credited.
- Always ensure that the referral activity complies with the rules; suspicious activities such as multiple registrations or shared IPs can lead to disqualification.

## Key points for communicating with players
- Emphasize that referral bonuses are only awarded if the downline deposits **at least 200 PHP**.
- Confirm that no disqualifying factors (shared IP, duplicate bank card or phone number, multiple accounts) are present.
- Clarify that commissions will be automatically credited after deposit and betting, but players can manually claim in the Reward Center.
- Remind players that activities deemed suspicious will result in disqualification of the referral or bonus.
- Advise on completing any pending steps in the Reward Center if commissions are not yet visible.