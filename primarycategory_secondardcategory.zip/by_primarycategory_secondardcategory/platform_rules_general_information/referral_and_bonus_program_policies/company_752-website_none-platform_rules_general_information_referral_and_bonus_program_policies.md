# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry about the referral or bonus program.**  
   - Determine whether the player is asking about the referral program, agent program, or related bonuses.

2. **Verify the player's eligibility for the referral or agent program.**  
   - Ensure the player intends to participate as a referrer or agent.
   - Confirm they have created an account and are willing to share their referral link.

3. **Explain how to become a valid referrer or agent.**  
   - Instruct the player to:  
     - Click on the "Agent" section on the homepage or relevant link.  
     - Copy their unique referral link.  
     - Share this link on social media platforms or with potential referees.

4. **Inform the player of the referral and agent commission structure.**  
   - Clarify that:  
     - Each invited player who deposits at least 200 PHP qualifies the referrer or agent for commissions.  
     - The referrer earns 129 PHP per valid invited player.  
     - They receive 0.89% on each invite deposit.  
     - They earn 0.64% (or 0.64%) on each invite bet (whether win or lose).  
     - They can reach higher tiers for rewards up to 3,999,999 PHP.  
     - Top agents can earn up to 1,000,000 PHP per valid player.

5. **Identify potential causes for referral disqualification.**  
   - Check if the player’s referral activities involve the following, which would disqualify the referral:  
     - Multiple account registrations.  
     - Binding the same bank card.  
     - Using the same phone number.  
     - Using the same or multiple IP addresses.  
   - If any of these apply, explain that the referral will not be qualified.

6. **Verify that the referred player meets the qualification requirements.**  
   - Confirm the referred player has deposited a minimum of 200 PHP.  
   - Confirm the referred player has completed a turnover of at least 1500 (based on overall play activity).  
   - Ensure the player's deposit and betting activity are recognized by the system.

7. **Check system records for automatic commission payments.**  
   - Confirm that:  
     - The system has credited commissions automatically after the downline deposit and bets.  
     - The player’s deposit and betting activity are properly recorded.

8. **If the referral is disqualified due to reasons in step 5,**  
   - Communicate clearly with the player, listing the specific disqualifying activity.  
   - Advise adherence to proper registration and activity rules to qualify future referrals.

9. **If the referral qualifies, inform the player about reward collection.**  
   - Direct the player to visit the Rewards Center for viewing and claiming earned commissions or bonuses.

10. **For inquiries about ongoing promotions or special bonuses (e.g., TEMU points referral event, weekly cash prizes):**  
    - Provide details of relevant rules, such as:  
      - The TEMU points event: invite friends, complete tasks, and reach a score target (e.g., 7777) to receive matching bonuses.  
      - Weekly Sunday Cash Prizes: log in between 22:00–23:59 PM (GMT+8) to claim random rewards up to 488,888 PHP.

11. **Document the interaction and update the system if needed.**  
    - Record the referral activity, disqualifications, or rewards issued, following internal procedures.

## Notes

- Ensure to clarify that commissions are automatically credited once the conditions (deposit of 200 PHP and activity) are met, with no manual intervention required.  
- Emphasize to players that activities such as multiple account creation, shared bank details, or IP addresses could disqualify their referral.  
- Remind players that rewards and tiers are based on verified deposit and betting activity, according to the current site configuration.

## Key points for communicating with players

- Clearly explain the qualification criteria for referral bonuses and tiers.  
- Warn against common disqualifying behaviors like multiple registration or sharing account details.  
- Guide players on where to view and claim their earned rewards.  
- Reiterate that commissions are credited automatically after activity verification.