# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive and understand the player's inquiry or issue related to the referral or bonus program.**  
   - Determine if the player is asking about referral commissions, bonus eligibility, or the referral process.

2. **Collect necessary information from the player:**
   - Player’s registered account details and username.
   - Whether the player is a current agent or wants to become one.
   - Details of the referred user (if applicable), including their deposit amount and betting activity.
   - The referral link or invitation code used.
   - Any relevant timestamps, such as deposit or betting dates.

3. **Verify the referral’s validity:**
   - Check if the referred user has made a minimum total deposit of **₱200** (as per the rules).
   - Confirm that the referral was made through the player’s unique referral link or code.

4. **Assess potential reasons for referral disqualification:**
   - Confirm that there are no violations such as:
     - Multiple account registrations using the same IP, phone number, or bank card.
     - Binding the same bank card to multiple accounts.
     - Use of the same or multiple IP addresses to register or deposit.
   - Determine if the total deposit threshold has been reached.

5. **Check if the referral qualifies for commission:**
   - Verify that the referred user’s deposit and betting activities meet the minimum deposit requirement.
   - Confirm that no disqualifying activity (e.g., multi-account registration, card binding, IP issues) has occurred.

6. **Confirm bonus or commission eligibility:**
   - For successful referrals:
     - Ensure commission payments are triggered automatically once the referred user deposits and starts betting.
     - Check if the referral is eligible for rewards such as **₱108 per successful referral**, **0.88% on referrals’ deposits**, **0.72% on bets**.
   - For the player's participation in the Tuesday Surprise Gift:
     - Inform that gifts are automatically delivered between **22:00 - 23:59 (GMT+8)** every Tuesday.
     - Advise to log in during this window to receive the mystery bonus up to **388,888**.
     - Note that non-receipt indicates ineligibility.

7. **Explain the benefits and rewards clearly to the player:**
   - ₱108 for each successfully referred player.
   - 0.88% of each referral’s deposit.
   - 0.72% of each referral’s bets.
   - Tiered rewards up to **₱8,800,000** for inviting 20 or 50 players, respectively.

8. **If the referral or bonus is disqualified:**
   - Clearly inform the player of the reasons:
     - Multiple registrations, sharing bank card details, phone number, or IP addresses.
     - Not reaching the minimum deposit of **₱200**.
     - Any system detection of suspicious activity.
   - Advise the player to review their referral process and ensure compliance.

9. **If the player is interested in becoming an agent:**
   - Guide the player to click “Agent” on the homepage.
   - Instruct to copy their unique referral link.
   - Share the link via social media platforms as directed.
   - Reiterate the potential earnings:
     - ₱108 per successful referral.
     - 0.88% on deposit amounts.
     - 0.72% on bets placed.
     - Exclusive rewards up to **₱8,800,000**.

10. **Document and escalate as necessary:**
    - If there are technical issues or uncertain disqualifications, escalate to the back office or system support.
    - Note anomalies, potential violations, or player requests requiring further review.

## Notes

- Referral commissions are paid automatically once the referred user deposits and places bets.
- Remember that bonuses like the Tuesday Surprise Gift are only obtained through logging in during the specified time window.
- Ensure players understand the strict rules around account sharing, multiple registrations, and same bank or device usage to prevent disqualification.

## Key points for communicating with players

- Always specify the minimum deposit of **₱200** for referrals to qualify.
- Clarify the automatic nature of referral commissions and bonuses.
- Remind players to log in during Tuesday 22:00-23:59 (GMT+8) to receive the surprise gift.
- Be transparent about disqualification reasons: multiple accounts, same bank card, phone, or IP address.
- Encourage compliance with the program’s terms to ensure eligibility for rewards.