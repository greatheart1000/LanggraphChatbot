# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player information**  
   - Ask the player for their referral link or referral ID.  
   - Confirm the identity of the referred player if necessary (e.g., username, email).  
   - Request details of the referred player's recent deposits and bets, especially if the referral status or rewards are in question.

2. **Verify referral eligibility**  
   - Check whether the referred player's total deposits have reached 200 PHP.  
   - Review the referred player's transaction history for deposits and bets to verify this threshold.  
   - Ensure the referral is valid by confirming that the referee's account is not a multiple account, linked to the same bank card, phone number, or IP address as the referrer, to prevent disqualification.

3. **Check for disqualifying factors**  
   - Investigate if the referral is disqualified due to multiple account creation, same bank card, same phone number, or IP address usage.  
   - If disqualified, inform the player that the referral does not meet the eligibility criteria and clarify any violations if identified.  
   - If not disqualified, proceed to verify deposit and betting activity status.

4. **Verify deposit and betting activities**  
   - Confirm that the referred player has indeed deposited at least 200 PHP.  
   - Check the deposit and bet amounts and dates for consistency and validity.  
   - Confirm that the deposit and betting activities are legitimate and compliant with site policies.

5. **Assess reward and commission eligibility**  
   - For referral bonuses: verify that the referred player's total deposit of 200 PHP has been made.  
   - For referral commissions: confirm that deposits and bets by the referred player have been completed after the 200 PHP threshold.  
   - Determine whether the referral meets criteria to earn the fixed reward of 108 PHP per invite and the 0.80% deposit commission and 0.74% bet commission.

6. **Provide information on rewards and commissions**  
   - Inform the player that they will receive 108 PHP once the referral deposit reaches 200 PHP.  
   - Clarify that commissions are automatically credited and can be viewed in the Reward Center, where they can also claim them by clicking “Claim.”  
   - Explain the multi-level commissions: Level 1 (0.50%), Level 2 (0.18%), Level 3 (0.06%).

7. **Check system activity and automatic verification**  
   - Confirm that the system has automatically verified deposit and betting activities.  
   - If irregular activity or disqualification issues are detected (e.g., multiple accounts, invalid activity), inform the player about potential disqualification and that rewards may be withheld.

8. **Explain the payout process and conditions**  
   - Clarify that commissions are credited automatically after the downline deposits and bets are completed.  
   - Remind the player to visit the Reward Center to view and claim their rewards.

9. **Address any player questions or concerns**  
   - If the referral does not meet the requirements, explain that the referral is invalid or disqualified based on the rules.  
   - If the reward or commission is not credited yet, advise the player to check the Reward Center or wait until the activity is verified.

10. **Escalate if necessary**  
    - If complex issues arise or system errors are suspected, escalate to the technical or responsible department with relevant account details and transaction history for further investigation.

## Notes
- Referral is valid only when the referred player's total deposits reach 200 PHP.  
- Disqualifications may occur for multiple accounts, sharing the same bank card, phone number, or IP address.  
- Rewards are automatically credited and can be viewed in the Reward Center; the player must click “Claim” to collect bonuses.  
- System verification is automatic; invalid activities may lead to disqualification without reward issuance.  
- Always verify that the referrals and activities are genuine and compliant with the platform’s rules for eligibility and fairness.

## Key points for communicating with players
- Clearly state that the referral reward of 108 PHP is only credited once the referred user deposits at least 200 PHP.  
- Confirm that deposits and bets are complete and meet the time frame for the rewards to be credited.  
- Inform the player that commissions are automatically credited and viewable in the Reward Center.  
- Warn against using multiple accounts or sharing bank details, as these may disqualify the referral.