# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather referral inquiry details from the player**
   - Ask the player if they want to participate in the referral or agent program.
   - Confirm if they intend to share a referral link or become an agent.
   
2. **Provide instructions for becoming an agent or sharing referral links**
   - Guide the player: click on the **Agent** section on the homepage.
   - Advise them to copy their **Referral Link**.
   - Instruct them to share their link across social platforms such as Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.

3. **Explain the rules for valid referrals**
   - Emphasize that a referral is valid only if:
     - The referred user has no multiple accounts or duplicates.
     - The same bank card, phone number, or IP address is not used by both parties.
     - The referred user deposits a minimum of **200 PHP**.
   - Highlight that violations (e.g., same IP or multiple accounts) can disqualify referrals and commissions.

4. **Verify referral details provided by the player (if applicable)**
   - Collect the referral code or the details of the referred user.
   - Confirm the referred user’s deposit amount meets or exceeds 200 PHP.

5. **Check the referral activity in the system**
   - Access the back office or system's referral tracking.
   - Confirm the referred user has deposited at least **200 PHP**.
   - Check the deposit and betting activity of the referred user to verify eligibility.

6. **Determine eligibility for referral commissions and rewards**
   - Confirm that:
     - The referral does not breach rules (multiple accounts, shared IP, etc.).
     - The deposit threshold of 200 PHP has been met.
     - The referred user has placed bets (if applicable).
   - If all conditions are satisfied, the referral is considered valid.

7. **Explain automatic commission payout process**
   - Inform the player that:
     - The **168 PHP** for each successful referral is credited automatically.
     - Additional earnings from **1.00% of downline deposits** and **0.54% of downline bets** are also paid out automatically.
     - Wide thresholds for bonus milestones (e.g., at 20 and 50 referrals) exist, with rewards of **208 PHP** and **1,088 PHP** respectively, up to a maximum of **188,888 PHP**.

8. **Address potential issues or invalid referrals**
   - If the referral is disqualified (e.g., due to IP/share violations or insufficient deposit), inform the player:
     - The referral does not meet the eligibility criteria.
     - The referral reward or commission will not be processed.
   - Advise the player on avoiding violations (e.g., not using the same IP or bank card).

9. **Confirm the player understands weekly promotions and special bonuses**
   - Explain that **Weekly Thursday Gifts** are awarded for login between 22:00 and 23:59 (GMT+8) on Thursdays.
   - Clarify that rewards can be as high as **188,888 PHP**.
   - Warn that repeated use from identical IP, bank card, or phone number may result in reward confiscation.
   
10. **Assist with further questions or escalation**
    - If the player reports issues with their referral or rewards, verify their eligibility and check system records.
    - If there are discrepancies or suspected fraud, escalate to relevant support teams following internal procedures.
    
## Notes
- Always verify that the referred user’s deposit reaches **200 PHP** to qualify.
- Commissions are paid automatically after deposit and betting activity, requiring no manual intervention.
- Violations such as using the same IP address, bank card, or phone number for multiple accounts will disqualify referrals.
- Rewards and bonuses are linked to specific milestones (e.g., inviting 20 or 50 players), with maximum rewards of **188,888 PHP**.
- Players should be advised to use official social platforms for sharing referral links to avoid fraud suspicions.

## Key points for communicating with players
- Emphasize the importance of unique referrals with no shared credentials.
- Inform players that commissions are automatic upon verified deposit and betting.
- Clear explanations about eligibility criteria prevent misunderstandings.
- Remind players about weekly reward timing and potential restrictions to maximize their potential earnings.