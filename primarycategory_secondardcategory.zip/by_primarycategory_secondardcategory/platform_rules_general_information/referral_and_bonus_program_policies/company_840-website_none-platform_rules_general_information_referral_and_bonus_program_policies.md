# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Verify the player's inquiry or claim regarding the referral or bonus program.**
   - Determine if the question pertains to the referral program, weekly rewards, agent program, or any related policies.
   - Ask the player for their account details and relevant information about their activity.

2. **Collect necessary information from the player.**
   - Player's account ID or username.
   - Whether the player is referring a new user or is a referral.
   - Details of the referral activity (e.g., referral link shared, number of invites).
   - If applicable, confirmation of deposit amounts, bets placed, and activity levels.

3. **Check the player's status and activity in the system.**
   - Confirm if the player has referred friends: ensure referrals have deposited at least 200 PHP.
   - Verify the deposit and betting activity of referrals:
     - Whether the referrals have deposited at least 200 PHP.
     - Whether the referrals have placed bets.
   - Review the referral's account for potential disqualifying factors:
     - Same IP address, same phone number, same bank card, or multiple accounts.
     - Multiple accounts using the same bank card or same phone number.
   - Check if the referral activity meets the eligibility criteria for earning commissions.

4. **Determine if the referral is qualified for commissions.**
   - Confirm that the referral deposit reaches at least 200 PHP.
   - Ensure the referral is not disqualified due to shared IP, phone, bank card, or multiple accounts.
   - Verify system detection for any disallowed activity; if detected, the referral is not qualified.

5. **Explain to the player the eligibility and payout process.**
   - Inform them that:
     - They earn 109 PHP for each valid referral.
     - They receive 0.80% of each deposit from their referrals.
     - They receive 0.72% of each bet placed by their referrals.
     - Commissions are paid automatically after the activity (deposit and bets) occurs.
   - Clarify that commissions are credited in the Rewards Center and can be claimed by clicking 'Claim'.

6. **For players asking about commissions or claiming rewards:**
   - Guide them to visit the Rewards Center.
   - Instruct to click the ‘Claim’ button to collect earned commissions.

7. **If a player asks about becoming an agent:**
   - Advise them to click 'Agent' on the homepage.
   - Explain that they should copy their referral link and share it via social media platforms (e.g., Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp).

8. **Address questions related to weekly rewards:**
   - Inform players rewards are distributed every Wednesday.
   - They can log in and claim rewards through the Rewards Center.
   - Clarify that additional delays might occur due to high system volume.

9. **Handle cases where the activity does not meet conditions or disqualifications occur:**
   - Notify the player that their referral does not qualify due to:
     - Not reaching the minimum deposit of 200 PHP.
     - Using the same IP address, phone number, or bank card as existing accounts.
     - Multiple accounts or disallowed activities detected by the system.
   - If applicable, advise on what conditions need to be met for qualification.

10. **Escalate or advise further actions if necessary.**
    - If unclear system detection issues or disputes arise, escalate to the relevant support or technical team for review.
    - Use official logs or system reports to verify activity before providing final resolutions.

## Notes
- Commissions are automatically credited once deposit and betting activity are detected.
- Referrals are valid only if they reach at least 200 PHP in total deposits.
- Multiple accounts and sharing of personal information like phone number or bank card can disqualify referrals.
- Players can earn up to four levels of lifetime commissions.
- Emphasize to players that cheating, multiple accounts, or disallowed activity will lead to disqualification.

## Key points for communicating with players
- Always confirm the deposit amount of referrals (minimum 200 PHP).
- Clarify that commissions are credited automatically and can be claimed in the Rewards Center.
- Remind players about the disqualifying factors, especially shared IP, phone number, or bank card.
- Encourage players to share their referral links via social media to participate as agents.
- Inform players that weekly rewards are distributed every Wednesday, subject to high-volume delays.