# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding the referral or bonus program.**
   - Collect detailed information about the player's concern or question to understand what aspect they need assistance with (e.g., qualification status, commissions, claiming rewards).

2. **Verify the player's account details and eligibility.**
   - Confirm the player's identity and ensure they have an active account.
   - Request the player's referral link or ID if applicable.

3. **Check the player's referral activities and status in the system.**
   - Access the back-office system to review:
     - Whether the referred user(s) have deposited at least 200 PHP.
     - The deposit history of the referred user(s).
     - The bets placed by the referred user(s).
     - The total deposit amount of the referral.
     - The number of referrals invited by the player.

4. **Evaluate potential disqualifying factors.**
   - Confirm if any of these violations are present:
     - Multiple accounts connected to the same IP address, phone number, or bank card.
     - Referred user(s) below the minimum deposit threshold of 200 PHP.
     - Multiple accounts or violation of the referral program's policies.
   - If any disqualifying factors are detected, inform the player that their referral or commissions may be invalidated according to the program rules.

5. **Determine eligibility for commissions and bonuses.**
   - Verify that:
     - The referred user has deposited at least 200 PHP.
     - The referred user has placed bets; once deposits and bets are confirmed, commissions can be credited.
   - Check if the referral has reached specific milestones for tiered bonuses, if applicable.
   - Confirm if commissions have been automatically credited in the system:
     - ₱200 per successful referral.
     - 0.88% on each deposit of the referral.
     - 0.54% on each bet placed by the referral.

6. **Assist the player in claiming available rewards.**
   - If eligible, guide them to go to the Bonus Center.
   - Instruct the player to click the 'Claim' button to receive their commissions or tiered bonuses.
   - Verify in the system that the reward has been successfully credited.

7. **If the player reports issues or disputes regarding qualification status or amounts:**
   - Check for any system restrictions or violations.
   - Confirm whether the referral is qualified based on deposit and activity criteria.
   - Explain that commissions are awarded automatically after deposits and bets, subject to policy compliance.
   - If no errors are found, clarify that rewards are already credited; otherwise, explain the reasons for disqualification or deduction.

8. **Advise the player on policy restrictions and disqualifications.**
   - Warn about potential violations such as multiple accounts, same bank card, same IP address, or same phone number.
   - Clarify that violations may lead to disqualification or deduction of commissions.

9. **Escalate or refer to higher support if needed.**
   - If the case involves complex policy issues, discrepancies, or suspected violations, escalate to the appropriate department for further investigation.

10. **Document the interaction and findings.**
    - Record the player's account details, investigation results, and any actions taken.
    - Note the date and outcome of the claim or inquiry.

## Notes

- Commissions are automatically credited once the referred user deposits and places bets.
- Referred user(s) must deposit a minimum of 200 PHP to qualify; deposits below this amount do not count toward referral bonuses.
- Multiple accounts, same IP, phone number, or bank card can disqualify a referral.
- Tiered bonuses are awarded based on the number of invitees who reach deposit milestones.
- To claim rewards manually, players must visit the Bonus Center and click 'Claim'.
- Violations may result in deductions or disqualification from the program.

## Key points for communicating with players

- Clearly explain that commissions are credited automatically after activity confirmation.
- Emphasize the importance of the 200 PHP minimum deposit requirement for referrals.
- Warn players about disqualification conditions (e.g., multiple accounts, same IP, bank cards).
- Encourage players to verify their referral activity and eligibility in the system.
- Remind players to visit the Bonus Center for claiming rewards.