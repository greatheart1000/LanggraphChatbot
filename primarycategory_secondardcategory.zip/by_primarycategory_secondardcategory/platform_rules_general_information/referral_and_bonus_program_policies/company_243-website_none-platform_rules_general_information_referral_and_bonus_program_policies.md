# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry about the referral or bonus program.**  
   - Identify whether the player asks about the referral program bonus, invite friends program, or how the bonus/commission works.

2. **Verify the player's eligibility and understand their specific question.**  
   - Clarify if the player wants to know:
     - How the referral bonus works  
     - How to join the Agent Program  
     - Details about Invite Friends program  
     - How bonuses are earned and withdrawn  

3. **If the player asks about the referral or invite friends program:**
   - Explain that they need to share their 7XM referral link with friends.
   - Inform them that their invitee must deposit **₱200** and complete a **₱500** rollover in Slots or Fishing.
   - Clarify that they will earn **₱58** per qualified friend and receive an additional **₱200** bonus every **5 invites**.
   - Mention that milestone bonuses are unlockable for every invite.
   - Reinforce that all bonuses can be withdrawn once the conditions are met.
   - Warn that multiple accounts are strictly prohibited; violators will be disqualified.

4. **If the player asks about the Agent Program:**
   - Instruct them to fill out the application form with the following information:
     - Upline, Username, Name, Contact number, Telegram account (@), Viber Account, Agent experience status, Previous online casino experience (if any), Number of downlines from last casino.
   - Confirm they understand this is for becoming an agent and involves submitting detailed information.

5. **If the player asks about how bonuses or commissions are earned or work:**
   - Confirm that they must share their referral link.
   - Reinforce that:
     - The invitee must deposit **₱200** and complete **₱500** rollover.
     - They earn **₱58** per qualified friend.
     - They receive **₱200** bonus every **5** qualified invites.
     - Milestone bonuses are available for additional invites.
     - Bonuses are withdrawable after meeting the conditions.
     - Multiple accounts are prohibited; violators disqualified.

6. **Perform necessary checks in the system:**
   - Confirm the referral link shared by the player.
   - Check that the referral invites generated are valid.
   - Verify that each invitee has deposited **₱200** and completed **₱500** rollover in either Slots or Fishing.
   - Track the number of valid invites for milestone bonuses.
   - Ensure no multiple accounts are involved; disqualify and warn the player if violations are detected.

7. **If the player’s referral or bonus request does not meet the criteria:**
   - Inform the player that the conditions (₱200 deposit and ₱500 rollover in Slots or Fishing) must be fulfilled for the bonus to be credited.
   - Advise they complete the required deposit/rollover to qualify for the reward.
   - Escalate to a supervisor if there are issues related to account violations or technical errors.

8. **Provide clear instructions on withdrawal:**
   - Confirm that once all conditions are met, the bonuses are eligible for withdrawal.
   - Advise the player to check their bonus status in their account and follow the standard withdrawal process.

9. **Document all details and actions taken for the case:**
   - Record referral link, invitee details, deposit and rollover verification, and any warnings or escalations.

## Notes
- Strictly no multiple accounts; violators will be disqualified.
- Bonuses and commissions are only obtainable once the invitee deposits **₱200** and completes a **₱500** rollover.
- Milestone bonuses are awarded at every 5 qualified invites.
- All bonuses can be withdrawn once the fulfillments are met.
- Handle violations according to the site’s disqualification policy.

## Key points for communicating with players
- Emphasize the exact deposit and rollover amounts: ₱200 and ₱500.
- Clarify no multiple accounts are allowed—disqualification will occur if violated.
- Inform players that bonuses are withdrawable only after meeting the stated conditions.
- Reinforce that all actions must be in accordance with these explicit rules.