# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding the referral or bonus program**.  
   - Ask the player to specify which aspect they need help with (e.g., referral program details, earnings, conditions, bonuses).

2. **Verify the player’s eligibility for referral or bonus information**.  
   - Confirm if the player has an active account and is in compliance with the site’s terms.

3. **Collect relevant details from the player, if applicable**.  
   - Ask if they have a referral link or code ready, or if they are inquiring about general program rules.

4. **Explain the core structure of the Referral and Earn program** according to FAQs:
   - For each successful referral, the player earns 108 PHP.
   - They earn 0.99% of every referred player's deposits.
   - They earn 0.72% of every referred bet, whether won or lost.
   - There are tiered levels: Level 1 earns 0.5%, Level 2 earns 0.16%, and Level 3 earns 0.06%.
   - They can earn exclusive tier bonuses up to 8,800,000 PHP.

5. **Inform the player about referral validity conditions**:
   - The referred player must deposit at least 200 PHP for the referral to be valid.
   - The referral could be disqualified if there are multiple accounts, same IP address, same bank card, or same phone number.

6. **If the player asks about earning or commissions**:
   - Confirm that commissions are paid automatically once the referred player deposits and places bets.
   - Clarify the payout process and that commissions are credited following successful activity.

7. **Check if the player has specific concerns about their referrals**:
   - For eligibility, verify if the referred player has met the minimum deposit of 200 PHP.
   - If the referral is suspected of violating rules (e.g., multiple accounts, shared bank details, same IP), inform the player that such referrals may be disqualified or commissions deducted.

8. **If the player mentions promotional offers (e.g., Friday Weekly Gift)**:
   - Explain that the promotion is claimable every Friday between 22:00 and 23:59 (GMT+8).
   - Rewards can be up to 699,999 PHP and are limited to one claim per player.
   - Warn about the system’s detection of repeated claims via same IP, bank card, or phone number, leading to confiscation of rewards and profits if rules are violated.

9. **Advise the player on how to participate in tier bonuses**:
   - They receive additional bonuses when inviting multiple players (e.g., 400 PHP bonus at 20 invited players, 800 PHP at 50).
   - Note that bonus details are subject to site policies and maximum limits.

10. **Guide the player on checking their referral and bonus status**:
    - Instruct them to visit the Bonus Center or Rewards Center.
    - Remind them that all earnings are credited automatically after the relevant activity, and they can monitor their progress in their account dashboard.

11. **If the player inquires about penalties or violations**:
    - Clarify that using the same IP, phone number, bank card, or creating multiple accounts can lead to disqualification or deduction of commissions.
    - Emphasize the importance of complying with the terms, including minimum deposit requirements and unique registration details.

12. **If the player's inquiry involves technical issues or discrepancies**:
    - Request screenshots or relevant proof if necessary.
    - Escalate to the technical or responsible department if discrepancies are suspected or confirmed.

13. **Close the interaction** by summarizing the main program points:
    - Reinforce the commission structure, valid referral conditions, and automatic payout process.
    - Encourage the player to review the full terms in the Rewards or Bonus section on the website.

## Notes
- Be aware that all commissions are paid automatically after activity fulfillment; no manual claim is needed.
- The maximum total bonus pool is capped at 8,800,000 PHP.
- Violations such as multiple accounts, sharing bank details, or IP manipulation can result in disqualification or withholding of earnings.
- Promotions like the Friday Weekly Gift are one-time per week and limited per player.

## Key points for communicating with players
- Clearly specify the minimum deposit of 200 PHP for valid referrals.
- Emphasize the automatic nature of commission payouts.
- Warn against sharing personal information or creating multiple accounts to avoid disqualification.
- Remind players about the maximum bonus potential and tier incentives.
- Always refer players to the official Rewards Center for their bonus and referral status updates.