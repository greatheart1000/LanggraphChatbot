# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player’s inquiry about referral or bonus program**.
   - Confirm the specific program or policy the player is referring to (e.g., referral commissions, agent program, reward events).

2. **Verify the player's identity and account details**.
   - Ask for their registered username or account ID.
   - Check if the player has an active account on the platform.

3. **Determine if the player is inquiring about the referral or partner program**.
   - Clarify whether they want to know about earning commissions, how to become an agent, or about specific event programs such as "Refer A Friend" or "Earn Angpao".

4. **Collect relevant referral/agent information if applicable**.
   - For inquiries about earning: confirm if they already have a referral link or account for the partner program.
   - For new inquiries: inform them about the process to become an agent:
     - Click "Agent" on the homepage.
     - Copy their referral link.
     - Share the link via social media platforms.

5. **Explain the conditions for qualifying as a referral or agent**.
   - To qualify for commissions or tiers:
     - The referral or downline must reach a total deposit of 200 PHP.
     - Commissions are credited after the downline deposits and bets.
     - Commissions are claimable at the Reward Center every 00:30 AM (GMT+8).
   - Disqualifications include:
     - Multiple accounts created from the same IP address, phone number, or bank card.
     - Using the same or multiple IP addresses for referrals.
     - Binding the same bank card or using the same phone number for multiple accounts.

6. **Check for any current violations or disqualifications**.
   - Review system logs for:
     - Multiple account registrations linked to the player.
     - Suspicious activity such as same IP address, phone number, or bank card.
   - If violations are detected:
     - Inform the player that the referral may be disqualified or rewards deducted.
     - Advise compliance with platform rules for future referrals.

7. **Explain the specific commission structure and earning potential**.
   - For legitimate referrals:
     - 208 PHP per valid invite when the referral deposits at least 200 PHP.
     - 0.80% from each downline deposit.
     - 0.38% from each downline bet.
     - Up to 8,800,000 PHP in tier rewards.
   - Clarify that commissions are available daily at 00:30 AM (GMT+8) and can be claimed in the Bonus Center.

8. **Assist the player in checking their referral or agent status and earnings**.
   - Guide them to the Bonus Center.
   - Instruct them to click "Claim" to receive earnings.
   - If the player reports missing or ineligible rewards, verify activity logs and deposit/bet history linked to their referrals.

9. **Advise on proper sharing and promotion** to avoid violations.
   - Share the referral link via approved platforms (Facebook, Messenger, YouTube, Instagram, TikTok, Twitter, Viber, WhatsApp, etc.).
   - Emphasize avoiding multiple account creation using the same IP, phone number, or bank card.

10. **Handle cases of referral disqualification or reward deductions**.
    - Inform the player of the possible reasons:
      - Multiple accounts or violations of the policies.
      - Use of the same IP address, phone number, or bank card.
    - Explain that rewards may be deducted if policies are violated.

11. **Answer questions regarding the "Refer A Friend" or "Earn Angpao" event**.
    - Explain the process:
      - Obtain a TEMU Ticket for the initial score.
      - Complete tasks—such as inviting friends—to earn Random Reward Chests.
      - Reach target scores (e.g., 7777) for matching bonuses.
      - Only one active ticket can be used at a time.
      - Rewards are sent automatically after completing tasks.

12. **When players inquire about becoming an agent or partner**.
    - Confirm they follow the steps to generate their referral link.
    - Explain that they can earn:
      - 208 PHP per valid invite.
      - 0.80% on deposits.
      - 0.38% on bets.
      - Tier bonuses up to 8,800,000 PHP.
    - Remind them about the eligibility conditions for valid referrals.

13. **Escalate any unresolved issues or suspected policy violations**.
    - If the system detects violations or the player challenges disqualification:
      - Inform them that the platform will review the activity.
      - Suggest adhering strictly to the rules for future referrals.

## Notes
- All commissions are credited and claimable after the referral deposits and bets are completed.
- The platform enforces strict rules against multiple accounts from the same IP, phone number, or bank card to prevent incentivized abuse.
- Rewards are automatically sent after completing designated tasks, and players should verify their Reward Center periodically.
- For any discrepancies or further assistance, escalate to the appropriate department per company protocol.

## Key points for communicating with players
- Emphasize the importance of genuine and compliant activity for qualification.
- Clearly explain disqualifying factors: multiple accounts, same IP, same bank card, same phone number.
- Remind players that commissions are credited and claimable every 00:30 AM (GMT+8) in the Bonus Center.
- Encourage adherence to the platform's rules to ensure ongoing eligibility and rewards.