# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player information related to the referral query.**  
   - Confirm the player is inquiring about the referral program, bonus, or rewards.  
   - Record the player's account details and specific questions or issues related to the referral or bonus program.

2. **Explain the basic structure of the referral program.**  
   - Inform the player that:
     - They earn 208 PHP plus Angpao for every successful referral.
     - They earn 1.00% of every deposit made by their referrals.
     - They earn 0.40% of every bet placed by their referrals, with levels: Level 1 0.28%, Level 2 0.08%, Level 3 0.04%.
     - Additional bonuses are available for inviting more players (e.g., 400 PHP for 20 referrals, 800 PHP for 50 referrals, up to a cap of 8,800,000 PHP).

3. **Request confirmation about referral eligibility details from the player.**  
   - Confirm that the referral's account deposits at least 200 PHP in total for the referral to be valid.  
   - Explain that referrals who do not meet this minimum deposit are not eligible for rewards.

4. **Check for potential violations or disqualifications based on the referral's account setup.**  
   - Verify if the referral accounts are created from the same IP address, using the same phone number, bank card, or multiple accounts, as this may violate policy and lead to disqualification or deduction of commissions.

5. **Assist the player in verifying the status of their referrals.**  
   - Confirm if the referred users have deposited at least 200 PHP and have placed bets before the cutoff time (before 00:30 GMT+8).  
   - Check the transaction history to see if deposits and bets have been registered for the referred accounts.

6. **Explain the automatic payout process.**  
   - Inform the player that commissions are sent automatically once the referred user deposits and places bets, typically before 00:30 GMT+8.  
   - Clarify that payouts are processed based on the system's schedule and are not manually triggered.

7. **Identify if the player’s referrals meet the criteria for earning rewards.**  
   - If eligible, confirm that the referral meets all conditions (minimum deposit, no policy violation).  
   - If not eligible, inform the player of the specific reason (e.g., deposit below 200 PHP, policy violation).

8. **In case of discrepancies or issues, escalate as necessary.**  
   - If the player believes they have met all conditions but rewards are not credited, escalate to the back office with appropriate transaction details and screenshots if available.  
   - Note any warnings or violations detected, especially related to IP or account linking, and inform the player that commissions may be deducted if violations are confirmed.

## Notes

- Always clarify that the referral reward includes a fixed amount (208 PHP + Angpao) for each successful referral and ongoing percentages based on referrals’ deposits and bets.
- Remind players that multiple accounts from the same IP using referral links may violate policies and affect commission earnings.
- Confirm that commissions are paid automatically after the referral deposit and betting activity, not manually.

## Key points for communicating with players

- Reinforce the criteria for referral validity: minimum deposit of 200 PHP.
- Emphasize that commissions are automatically paid after the referred user deposits and bets before 00:30 GMT+8.
- Warn about potential disqualifications due to policy violations, such as shared IP addresses or account linking.
- Ensure players understand that rewards are subject to system checks and automatic processes.