# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player's referral or bonus program inquiry details.**  
   - Ask the player whether they are inquiring about the referral program or the VIP Weekly Salary.
   - If about the referral program, request their referral's details (if available), including deposit amount, IP address, bank card, and phone number information.
   - If about the VIP Weekly Salary, confirm the player's activity and deposits for the current week.

2. **Verify referral validity (if applicable).**  
   - Check if the referral has made a deposit of at least 200 PHP.  
   - Confirm that the referral has not used multiple accounts, shared the same IP address, bank card, or phone number with previous referrals, as these constitute invalid referrals.  
   - Ensure no disqualifying activities are detected according to the rules.

3. **Assess the referral's qualifying activities.**  
   - Confirm the deposit meets the minimum deposit requirement (200 PHP).  
   - Verify that there are no activities that would invalidate the referral, such as multiple registrations or sharing disqualifying information.

4. **Check for system or account flags.**  
   - Determine if the referral or referrer has any activity triggers that may lead to confiscation of bonuses or profits, such as repeated use of the same IP, card, or phone number.  
   - Review the player's activity for any irregularities that could block bonus crediting.

5. **Calculate and confirm incentive eligibility.**  
   - For valid referrals, confirm the referrer is eligible to earn PHP 108 for each successful invite, as well as 0.88% on deposit amounts and 0.74% on bets from the downline.  
   - For the VIP Weekly Salary, confirm the player has completed the minimum deposit for the week (e.g., 100 PHP) and meets tier requirements.

6. **Check reward credit processes.**  
   - Referral rewards (PHP 108 per invite, deposit, and bet commissions) are credited automatically after the downline deposits and bets.  
   - The VIP Weekly Salary is credited every Thursday between 22:00 and 23:59 (GMT+8), provided the weekly deposit and activity requirements are met.

7. **Inform the player of the status or next steps.**  
   - If the referral or VIP salary is eligible, explain that rewards will be credited automatically; emphasize the conditions met and timeframe.  
   - If the referral is invalid or conditions are not met, explain the reasons clearly: such as insufficient deposit, activity violation, or multiple account sharing.  
   - Clarify that delays may occur due to system load or system checks.

8. **Escalate as needed.**  
   - If suspicious activity or potential violations are detected, escalate according to internal protocols.  
   - If the instructions or system verification is inconclusive, advise the player that their case will be reviewed and they will be notified once resolved.

9. **Document the interaction and outcome.**  
   - Record relevant details of the referral or VIP salary inquiry, verification results, and any player communications for future reference.

## Notes

- Rewards are only credited for valid referrals where deposit requirements and activity conditions are met.  
- Multiple accounts, shared IPs, bank cards, or phone numbers can invalidate referrals.  
- System delays are normal during high load periods and should not be considered as penalties.  
- Bonuses and profits may be confiscated if irregular or suspicious activity is detected.  
- The VIP Weekly Salary is credited automatically every Thursday between 22:00 and 23:59 (GMT+8).  
- Ensure to verify that weekly deposit minimums (e.g., 100 PHP) are met for salary qualification.