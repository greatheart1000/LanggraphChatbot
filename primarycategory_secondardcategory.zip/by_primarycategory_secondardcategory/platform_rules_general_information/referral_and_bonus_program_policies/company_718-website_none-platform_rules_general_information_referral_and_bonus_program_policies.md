# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry about the referral or bonus program.**  
   - Determine whether the player asks specifically about how the referral system works, the policies for inviting friends, or the rewards they can earn.

2. **Verify if the player's question pertains to the current referral system.**  
   - Confirm if the player is referring to the new referral system, as the old system has been closed.

3. **Explain the current referral system to the player.**  
   - Inform that inviting friends is done via their referral link or username.  
   - Clarify that a referral is valid only once the friend deposits at least 500 PRK.  
   - State that the player earns a 2.2% bonus on each valid referral’s top-up.

4. **Collect relevant information from the player to verify the referral process.**  
   - Ask if the player has shared their referral link/username and if they've invited friends recently.  
   - Request details about any recent friend deposits, if applicable.

5. **Check the player’s referral score and status in the back office or system.**  
   - Confirm if the referred friends have made deposits of 500 PRK or more and are thus valid referrals.  
   - Determine how many valid referrals the player has and their current referral score to see if they can unlock the Golden Treasure Chest.

6. **Assess if the player has met the conditions to unlock the Golden Treasure Chest.**  
   - Verify if the player's referral score has reached the required threshold based on the number of valid referrals.  
   - If the score is incomplete, explain that more valid referrals are needed to unlock the chest.

7. **Provide information about additional referral efforts.**  
   - Encourage the player to continue inviting friends to increase their referral score and rewards.

8. **Address any discrepancies or clarify misconceptions.**  
   - If the player believes they have met the conditions but are not seeing reflected rewards or referrals, verify the status in the system.  
   - Confirm whether the referral deposit has been registered and validated.

9. **If the referral details are insufficient or unclear, instruct the player to provide evidence or documents.**  
   - For example, proof of referral links sent or deposit confirmation from friends.

10. **Document the case details, including referral activity, deposit amounts, and referral counts.**  
    - Record the verification steps and results for future reference.

## Notes

- The old referral system has been officially closed; only the new system's rules apply.  
- Valid referrals only count once the friend deposits at least 500 PRK.  
- The bonus is a 2.2% commission on each valid referral’s top-up.  
- The Golden Treasure Chest unlocks once the player's referral score reaches the required threshold, which depends on the number of valid referrals.  
- Always verify the deposit amount and referral validity in the system before providing a final explanation.

## Key points for communicating with players

- Clearly state that only deposits of 500 PRK or more are considered valid referrals under the current system.  
- Emphasize that rewards accumulate with each valid referral and that the Treasure Chest unlocks when the score is complete.  
- Remind players to invite friends actively to increase their scores and rewards.  
- Confirm the referral and deposit status in the back-office system before offering definitive answers about rewards or status.