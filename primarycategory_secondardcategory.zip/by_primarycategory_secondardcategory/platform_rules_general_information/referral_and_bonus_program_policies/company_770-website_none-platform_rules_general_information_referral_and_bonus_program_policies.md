# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Greet the player and clarify their inquiry about the referral or bonus program.**  
   - Confirm whether the player’s question pertains to new registration, existing account, or account transfer related to the referral or VIP program.

2. **If the player requests account transfer due to a VIP program merger with PHWIN:**  
   - Inform them that if their account was part of the old partner VIP program that merged with PHWIN, their account has been transferred to PHWIN.  
   - Instruct the player to register a new PHWIN account on the official signup pages if they haven't done so already.  
   - Advise them to contact customer support to request their VIP status, remaining balance, and any relevant account details to be transferred.  
   - **Note:** No further action is needed if the player already has a PHWIN account.

3. **If the player inquires about the **Referral Program** details or eligibility:**  
   - Explain that players can earn 308 PHP for each successful referral.  
   - Clarify that they can receive additional commissions: 0.98% of each deposit made by their referrals and 0.38% of each bet placed by their referrals.  
   - Mention that to qualify a referral, the referred player must deposit a minimum of 300 PHP.  
   - Inform the player about bonus milestones: inviting 20 players earns a 400 PHP bonus; inviting 50 players earns an 800 PHP bonus, with total maximum bonuses reaching up to 8,800,000 PHP.  
   - Emphasize that commissions are paid automatically after referrals deposit funds and place bets.

4. **Verify the player's information and referral activity:**
   - Collect relevant details such as the player's account ID, referral list (if available), and any screenshots or proof of referral activity if requested.  
   - Check the system for referral validity:  
     - Confirm successful deposit and bet activity from the referred accounts.  
     - Ensure there are no violations like multiple accounts, tied bank cards, the same phone number, or same/multiple IP addresses, as these may disqualify the referral.

5. **Perform system checks for compliance:**
   - Verify whether the referred accounts meet the minimum deposit of 300 PHP.  
   - Check for prohibited activities, like multiple accounts or sharing the same IP, bank card, or contact details.  
   - Determine if the referral is valid according to these criteria.

6. **Assess the referral’s qualification status:**  
   - If the referral meets all criteria, confirm the successful qualification.  
   - If not, explain the potential reasons (e.g., insufficient deposit, suspected policy violation) and advise on corrective actions if applicable, such as re-verification or providing additional proof.

7. **If the player reports issues with the referral or bonuses:**  
   - Verify whether the referral activity has been properly recorded and payments processed.  
   - Check if any violations or disqualifications apply based on system records.

8. **If the player is eligible for bonuses or commissions:**  
   - Explain that once the referral deposits and bets are confirmed, commission payments are processed automatically.  
   - Provide details about milestone bonuses, if applicable, and confirm whether the player has qualified for these rewards.

9. **In cases involving account merges from previous VIP programs:**  
   - Confirm whether the player’s old account is part of the merge (if applicable).  
   - Instruct on registering a new PHWIN account and contacting customer service for transfer of VIP status and balance, if required.

10. **Communicate important warnings and compliance points:**  
    - Remind players that creating multiple accounts, using the same bank card, phone number, or IP address for referral activities may disqualify their referrals and lead to deduction of commissions.  
    - Advise players to ensure all referral activities are legitimate and compliant with site policies.

11. **Close the case upon resolution:**  
    - Summarize the findings, confirm the qualification status, or explain disqualifications.  
    - Offer further assistance if needed, or instruct the player to contact support again if new issues arise.  
    - Document the case details and outcome in the system.

## Notes

- A referral is only valid if the referred account deposits at least 300 PHP.  
- Commissions are automatically credited after deposit and betting activities.  
- Referral violations such as multiple accounts, same IP address, bank card, or phone number can lead to disqualification and deduction of earnings.  
- For account transfer requests due to VIP program merges, players must register a new account and contact customer service for balance and VIP status transfer.

## Key points for communicating with players

- Clearly explain the qualification criteria for referrals (deposit minimum of 300 PHP).  
- Emphasize automatic payment of commissions after qualifying activities.  
- Warn against prohibited activities like multiple accounts and shared contact details.  
- Provide step-by-step guidance for account transfer requests relevant to VIP program merges if necessary.