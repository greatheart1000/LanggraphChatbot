# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player information related to the referral query.**  
   - Confirm if the player is inquiring about the referral program or has already referred others.  
   - Collect details about the referred users, including whether they registered via the player's referral link.

2. **Verify eligibility of the referral(s).**  
   - Check if the referred user(s) have deposited at least 200 PHP in total to qualify for the referral bonus.  
   - Confirm that the referral is valid: the referred user is a new account, not a multiple registration, and there is no binding of the same bank card, phone number, or use of the same/multiple IP addresses.  
   - Review if any violations have occurred that could disqualify the referral.

3. **Assess the referral success and deposit/bet activity.**  
   - Confirm that the referred user has made the minimum deposit (200 PHP).  
   - Check if the referred user has placed bets since depositing.  
   - Ensure that deposits and bets are properly recorded in the system.

4. **Verify automatic commission payments.**  
   - Confirm whether the system has credited the referral bonus: 208 PHP + Angpao for each valid successful referral, and the applicable percentage on deposits (0.88%) and bets (0.64%).  
   - Check the Bonus Center or relevant system logs to see if commissions from the referred user have been credited.

5. **Determine the level of the referral and associated commissions.**  
   - Identify the referral level: Level 1 (0.38%), Level 2 (0.18%), Level 3 (0.08%).  
   - Confirm if the referred user qualifies for higher milestone bonuses (e.g., after referring 20 or 50 players), based on the total number of successful invites.

6. **Address any issues if the referral does not qualify.**  
   - Explain to the player that the referral may not qualify if the referred user:  
     - Did not deposit at least 200 PHP;  
     - Registered multiple accounts;  
     - Used the same bank card, phone number, or IP address as the referrer or other users.  
   - If the referral is disqualified, advise that no bonus or commission will be paid for that referral.

7. **Handle claims or disputes.**  
   - If the player reports that they believe a qualifying referral was not rewarded, review the deposit, betting activity, and registration details.  
   - Confirm whether the system has automatically credited the bonuses.  
   - If discrepancies are found, escalate to the system support team following internal procedures.

8. **Close the case.**  
   - Inform the player of the current status: bonuses awarded or reason for disqualification.  
   - If bonuses are credited, advise the player they can view the rewards in the Bonus Center.  
   - Confirm the player understands the rules for eligibility and the automatic process of payment.

## Notes

- Commissions and bonuses are automatically credited once the qualifying activity (deposit and bets) is completed by the referred user.  
- Multiple account registrations, binding the same bank card, using the same phone number, or same/multiple IP addresses can disqualify referrals.  
- Higher milestone bonuses are attained when successful referrals reach specific thresholds (e.g., inviting 20+ or 50+ players).  
- Always verify deposit and betting activity in the system before informing the player of their bonus status.  

## Key points for communicating with players

- Clearly explain that the referral bonus requires the referred user to deposit at least 200 PHP.  
- Emphasize that bonuses are credited automatically after deposit and bet activities.  
- Mention disqualification reasons: multiple accounts, same bank card, phone number, or IP address usage.  
- Encourage players to ensure their referrals follow the proper registration process to remain qualified.