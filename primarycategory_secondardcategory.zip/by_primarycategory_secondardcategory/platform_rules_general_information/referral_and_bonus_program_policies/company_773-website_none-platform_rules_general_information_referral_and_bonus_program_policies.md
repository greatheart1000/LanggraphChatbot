# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Identify the player's inquiry or issue related to the referral or bonus program.**
   - Determine if the player is asking about referral rewards, eligibility, commission calculations, VIP Weekly Salary, or program terms.
   - Ask the player for necessary identifying information (e.g., player ID, username).

2. **Gather detailed information from the player regarding their referral or bonus program activity.**
   - Confirm if the player has invited referrals and how many.
   - Check if the player has received or claims any rewards or commissions.
   - Ask if the player has any concerns about specific referrals, deposits, or bets.

3. **Verify the player's referral account status and activities in the system.**
   - Check whether the referred players (downlines) have deposited at least 200 PHP.
   - Confirm if the downline deposits and bets meet the program conditions, such as deposit thresholds.
   - Review if the referral account(s) are linked via permitted channels (e.g., different IPs, separate bank cards, phone numbers).

4. **Check for compliance with the program policies to determine eligibility and potential deductions.**
   - Confirm that there are no violations such as:
     - Multiple accounts using the same referral link.
     - Binding the same bank card to multiple accounts.
     - Using the same phone number for multiple accounts.
     - Multiple IP addresses from which activity is conducted.
   - Verify that the referral is valid (downline has deposited ≥200 PHP).

5. **Assess the timing and status of commissions or rewards.**
   - Confirm if the downline has completed deposits and bets for the rewards to be processed.
   - Ensure rewards such as the VIP Weekly Salary are credited within the specified time frame (every Friday between 22:00 and 23:59 GMT+8).
   - Check if system delays have occurred, especially during high load periods.

6. **Explain the findings to the player.**
   - If eligible, inform the player that their referral or bonus rewards/commissions are credited automatically after qualifying activities.
   - If not eligible, clarify the reasons:
     - Downline has not reached the required deposit amount.
     - Potential policy violations (e.g., duplicate accounts, shared bank cards, same IP or phone number).
     - Rewards are pending processing or delayed due to system load.
   - Advise the player on actions to ensure future eligibility, e.g., inviting more players, avoiding policy violations.

7. **If the player reports a deduction or suspected violation, advise them accordingly.**
   - Explain that referral commissions may be deducted if violations are found, such as multiple accounts, binding the same bank card, or using the same IP/phone.
   - Clarify that commissions are paid automatically after the qualifying activities, and any deductions are based on policy enforcement.

8. **Guide the player on how to view or claim rewards in the Reward Center if applicable.**
   - Instruct to navigate to the Reward Center on the website or app.
   - Confirm if the reward/commission appears as credited; if not, advise to wait for system processing or check back later.

9. **Escalate or refer complex cases to the appropriate department if necessary.**
   - For disputes involving policy violations or deductions, escalate according to internal procedures.
   - Document all findings and communications with the player.

## Notes

- Always verify deposit amounts and activity status before confirming eligibility.
- Rewards such as VIP Weekly Salary are credited every Friday between 22:00 and 23:59 (GMT+8).
- Commissions are paid automatically after the downline deposits and bets meet the minimum threshold of 200 PHP.
- Ensure the player is aware of the policy restrictions against multiple accounts, binding the same bank card, or using the same IP or phone number.
- Deductions may occur if violations are detected, and these are enforced automatically based on policy compliance.
- Keep communication clear, especially regarding reasons for non-eligibility or delays, and advise players to ensure compliance with the rules for future eligibility.