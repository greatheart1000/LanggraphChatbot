# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding the referral or bonus program.**
   - Collect relevant information from the player:
     - Player ID or account details
     - Specific question or issue about the referral or bonus program
     - If claiming a reward, ask about their referral activity or deposits/bets made
   
2. **Verify if the player is eligible for the referral or bonus program rewards.**
   - Check if the player has shared a valid unique referral link.
   - Confirm whether the referred player has reached the minimum deposit of 200 PHP to qualify as a valid invite.
   - Confirm the number of referrals (if relevant) and the corresponding invite tiers.
   - For VIP Weekly Salary qualification, verify if the player has completed at least one valid bet in the current week (Monday to Sunday).  
   
3. **Review referral and bonus transaction records in the system.**
   - Check the Rewards Center or equivalent system:
     - Confirm the earned amounts:
       - 88 PHP per successful referral
       - 0.88% of each referral deposit
       - 0.74% of each referral bet (win or lose)
     - Verify if the account has reached higher tiers for additional rewards
     - Examine if the player has received the VIP Weekly Salary (paid automatically every Wednesday between 22:00–23:59 GMT+8)
   
4. **Assess for any suspicious or fraudulent activity.**
   - Look for signs of activity that could lead to confiscation of rewards:
     - Same IP address, same bank card, or same phone number among multiple accounts
     - Unusual activity pattern or activity that violates the terms
   - If any suspicious activity is detected, inform the player that rewards may be confiscated as per system rules.
   
5. **Determine the appropriate resolution based on verification results.**
   - If the player has fulfilled all conditions:
     - Confirm the earned rewards and instruct the player on how to claim them via the Rewards Center.
     - If the VIP Weekly Salary is due, explain that it is paid automatically every Wednesday within the specified time window and indicate potential reasons if not received (e.g., missing turnover requirement).
   - If the player has not met the conditions:
     - Explain that rewards will be granted once the referral qualifies or the betting turnover/match requirements are fulfilled.
     - Clarify that ongoing promotional conditions or tiers may influence reward amounts.
   
6. **Guide the player on claiming rewards, if applicable.**
   - Direct the player to the Rewards Center or relevant section in their account.
   - Confirm if the player has successfully claimed the rewards or if they need further assistance in doing so.
   
7. **Escalate issues or unclear disputes to the appropriate team if necessary.**
   - If the question or issue involves system errors, reward discrepancies, or suspicious activity, escalate following internal protocols.
   
8. **Close the interaction by summarizing the key points discussed.**
   - Reinforce the key rules:
     - 88 PHP for each valid referral
     - 0.88% on deposit, 0.74% on bets
     - Tier-based rewards and maximum rewards as applicable
     - Bonus precautions against fraudulent activity
     - Automatic VIP Weekly Salary payments on Wednesdays

## Notes

- Always verify the specific referral activity and deposit/bet amounts before confirming rewards.
- Remember that rewards can be confiscated if suspicious activity is detected.
- Rewards are claimable in the Rewards Center, but VIP Weekly Salary is paid automatically on Wednesdays.
- Upward tier progression is possible, increasing potential earnings as players meet the criteria.

## Key points for communicating with players

- Confirm their referral activity and whether the referral has deposited at least 200 PHP.
- Explain that rewards are credited in the Rewards Center and that VIP Weekly Salary is paid automatically on Wednesdays.
- Warn about possible reward confiscation if activity appears suspicious.
- Clarify that tier-based rewards and promotions depend on ongoing activity and system rules.