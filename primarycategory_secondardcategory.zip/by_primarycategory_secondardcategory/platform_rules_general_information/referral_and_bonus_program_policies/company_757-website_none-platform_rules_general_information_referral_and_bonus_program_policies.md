# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Identify the player's inquiry or issue related to the referral or bonus program.**  
   - Determine if the player is asking about claiming a specific bonus (e.g., Weekly Friday Gifts, Lucky 9th Monthly Gifts).  
   - Check if the player is questioning their referral status or commission earnings.

2. **If the player is requesting to claim a bonus (e.g., Weekly Friday Gifts or Lucky 9th Monthly Gifts):**  
   - Confirm the current claim time window:  
     - Log in and navigate to the Rewards Center.  
     - For Weekly Friday Gifts: between 22:00 - 23:59 (GMT+8) every Friday night.  
     - For Lucky 9th Monthly Gifts: on the 9th of each month between 22:00 - 23:59 (GMT+8).  
   - Advise the player to claim the reward within these hours.  
   - Ensure the player has downloaded the official app if they wish to enjoy exclusive rewards.  

3. **Verify the eligibility conditions for claiming rewards:**  
   - Check if the system detects any repetition involving the same IP address, bank card, or phone number.  
   - Inform the player that if such repetitions are detected, both rewards and profits will be confiscated.  
   - Confirm the player is logged in before attempting to claim.

4. **If the player reports not receiving a reward or an issue claiming it:**  
   - Ask for the date and time they attempted to claim.  
   - Confirm they were within the correct time window.  
   - Check system logs for any detection of repeated activity or violation.  
   - Tell the player that rewards are awarded randomly when conditions are met and that multiple attempts from identical details may result in confiscation.

5. **If the player asks about the referral program (commissions, benefits, eligibility):**  
   - Explain the commission structure:  
     - 139 PHP for each successful referral.  
     - 1% on every deposit made by referred players.  
     - 0.62% on every bet placed by referred players (Level 1: 0.36%, Level 2: 0.18%, Level 3: 0.08%).  
   - Clarify that each referral must:  
     - Register using the player’s referral link.  
     - Make a minimum total deposit of 200 PHP.  
   - Mention the bonus rewards for inviting a specific number of players:  
     - 499 PHP bonus for inviting 20 players.  
     - 1,099 PHP bonus for inviting 50 players (max bonus up to 3,999,999 PHP).  
   - Emphasize commissions are paid automatically once the deposit and bets are made by the referred players.

6. **Check the player’s referral activity for eligibility and validity:**  
   - Verify if the referred players have made at least 200 PHP in total deposits.  
   - Ensure the player has not created multiple accounts with the same referral link, bank card, phone number, or IP address, as these violate site policies and cause disqualification.  
   - If violations are detected, inform the player that their referrals may be invalid and commissions will be deducted or withheld.

7. **If the player questions their earning history or missing commissions:**  
   - Advise them to visit the Bonus Center to check pending rewards or commissions.  
   - Confirm with system logs whether deposits and bets from referred players meet the minimums for commission calculations.  
   - Explain that commissions are paid automatically after the conditions (deposit + activity) are fulfilled.

8. **For questions about the TEMU referral event:**  
   - Explain the process: players earn a TEMU ticket, complete tasks (like inviting friends), and accumulate points towards a total score (e.g., 7777).  
   - Clarify rewards are granted based on qualification rules such as one-time gifts, per-invite rewards, and interval rewards.  
   - Emphasize the importance of following event-specific instructions for participation and claiming.

9. **If a player reports multiple accounts created with the same referral link or violations:**  
   - Confirm that creating multiple accounts using the same referral link violates policies.  
   - Inform the player that detected violations will lead to deductions of all commissions earned from such referrals.  

10. **Throughout the interaction, ensure all actions are documented in the case record, including:**
    - Player's account details.  
    - A summary of the inquiry or issue.  
    - Steps taken, checks performed, and any system logs reviewed.  
    - Resolution provided or next steps if further investigation is needed.

## Notes

- All rewards and commissions are automatically calculated and paid after the referral or activity conditions are met.  
- The minimum deposit to qualify a referral for commission is 200 PHP.  
- Repetitive or suspicious activity involving the same IP, bank card, or phone number may lead to confiscation of rewards and profits.  
- For event-specific rewards (e.g., TEMU), follow the particular event instructions and rules as published.  

## Key points for communicating with players

- Confirm the timing and eligibility conditions clearly before guiding them on claiming rewards.  
- Reinforce the importance of using unique details for registration to avoid disqualification of referrals.  
- Clearly explain the automatic nature of earnings and the conditions needed for payouts.  
- Be transparent about potential disqualifications and reward confiscation if rules are violated.