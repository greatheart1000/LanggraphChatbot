# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry regarding the referral or bonus program.**  
   - Determine the nature of the question (e.g., referral process, commissions, bonuses, or policies).

2. **Verify the player's eligibility and identity.**  
   - Check if the player has an active account registered with the site.

3. **If the player asks about becoming an agent or referral program:**
   - Instruct the player to navigate to the homepage and click on the **"Agent"** link.  
   - Guide the player to **copy their Referral Link** from the agent section.  
   - Advise sharing the referral link on social media platforms to recruit new players.

4. **Explain the referral program benefits and structure to the player:**
   - Inform that they earn:  
     - **109 PHP** for every successful referral (when the referred player deposits and bets).  
     - **0.88%** from each downline deposit.  
     - **0.72%** from each downline bet.  
     - Tiered levels: **Level 1: 0.5%**, **Level 2: 0.16%**, **Level 3: 0.06%**.  
     - Potential rewards up to **8,800,000 PHP** based on tier achievement.  
     - **Lifetime rewards** apply for each referral.

5. **Check if the player has generated referrals:**
   - Verify the number of invited players and their deposit/bet activity through the system.  
   - Confirm each referral has deposited a **minimum of 200 PHP** for valid tracking.

6. **Explain the operation of commissions:**
   - Confirm commissions are **automatically** sent once the referred user deposits and places bets.  
   - Clarify that multiple referral accounts using the same referral link **violate policy**.  
   - Notify that commissions earned from such accounts **will be deducted**.

7. **In case of multiple referral accounts or suspicious activity:**
   - Check system records for signs of violations such as multiple accounts, same IP address, bank card, or phone number.  
   - If violations are detected, inform the player that **commissions may be revoked** or accounts **may be penalized**.

8. **If the player inquires about bonus tiers or promotional conditions:**
   - Confirm that bonuses for inviting **20 players** yield a **400 PHP bonus**.  
   - Inviting **50 players** awards a **800 PHP bonus** (maximum payout **8,800,000 PHP**).  
   - Emphasize that these bonuses are **subject to the terms** and conditions.

9. **If the player asks about other promotions or rewards (e.g., Sunday Gifts, birthday bonus):**
   - Share that:
     - Sunday Weekly Gifts are claimable **every Sunday between 22:00 and 23:59 (GMT+8)** from the Rewards Center, with potential rewards up to **699,999 PHP**.  
     - Birthday bonuses are available **only on the player's exact birthdate**.

10. **Remind the player of key eligibility rules for referral rewards:**
    - Referred player must deposit at least **200 PHP** in total.  
    - No **multiple accounts**, no **binding the same bank card or phone number**, and avoid using the **same IP address** for linking referrals.

11. **If the player reports issues or discrepancies:**
    - Verify the referral activity in the back office/system.  
    - Check for signs of fraudulent activity, such as account sharing or multiple accounts.  
    - If a problem is confirmed, explain that rewards may be **confiscated** if violations are detected.

12. **Close the case:**
    - Summarize the key points discussed.  
    - Advise the player to follow the site rules to ensure continued eligibility.  
    - Offer further assistance if necessary.

## Notes

- All commissions are calculated **based on deposits and bets** of the referred players and are **automatically** processed after activity confirmation.  
- Violations of referral policies, such as creating multiple accounts or using the same bank card, may lead to **loss of commissions and penalties**.  
- The maximum lifetime reward per referral can reach **8,800,000 PHP**.  
- Keep the messaging aligned with the FAQs, emphasizing that rewards are subject to verification and compliance with the terms.