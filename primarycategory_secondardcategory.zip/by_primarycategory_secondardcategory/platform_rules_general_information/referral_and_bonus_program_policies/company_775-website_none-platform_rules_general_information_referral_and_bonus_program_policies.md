# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry or request regarding the referral or bonus program.**  
   - Determine the specific nature of the query (e.g., referral commissions, bonus payout, eligibility, claiming process, or weekly gifts).

2. **Gather necessary information from the player to assess their case:**
   - Confirm if they are referring a new player or are a referred player.
   - Ask for the total deposits made by their downline (if applicable).
   - Verify the number of players they have invited.
   - Check if they have made or received any specific bonus or reward claims.
   - Obtain their account details (e.g., username, registered phone number, bank card info, deposit history).

3. **Verify the validity of the referral or bonus eligibility:**
   - Ensure each referred player deposits a **minimum of 200 PHP** to qualify.
   - Confirm that the referral is genuine—no multiple accounts, binding the same bank card, using the same phone number, or same IP address that may violate the terms.
   - Confirm that the downline has deposited and placed bets; commissions are paid **automatically** once these conditions are met and confirmed in the system.
   
4. **Check the system for recorded deposits and bets:**
   - Access the Bonus Center in the player's account.
   - Verify if the downline's deposits (total ≥200 PHP) and bets are registered.
   - Confirm that the deposit and betting activities are correct and within the relevant time frames (commissions are claimable around **00:30 AM GMT+8**).

5. **Determine eligibility for commissions or rewards:**
   - For each valid referral, confirm that the deposit and betting activities are completed and approved.
   - For tiered commissions, verify the referral's level (Level 1, 2, or 3).
   - Check if the player has invited **20 players** to qualify for an **additional bonus of 400 PHP** or **50 players** for an **800 PHP bonus** (up to the cap).
   - For weekly gifts, verify if the player logged in and visited the Rewards Center between 22:00 and 23:59 (GMT+8) on Thursday.

6. **Process the payout or bonus claim:**
   - Inform the player that commissions are **automatically sent** once deposits and bets are verified.
   - Advise the player to **claim in the Bonus Center** if manual claim is needed (e.g., after the systems have registered the activities at around 00:30 AM GMT+8).
   - For special bonuses like invite rewards, confirm the number of invites and process accordingly if manual intervention is required.

7. **Handle edge cases or insufficient activity:**
   - If deposits or bets are below 200 PHP, explain that the referral/commission is invalid.
   - If the referral appears invalid (e.g., multiple accounts, same IP, or other rule violations), inform the player that the referral cannot be credited.
   - If the player has not logged in or visited the Rewards Center on Thursday, clarify that the weekly gift is not available.

8. **Advise the player on additional rules or conditions:**
   - Emphasize that ongoing commissions depend on the validity of each referral.
   - Remind that bonuses are subject to the site’s current configuration and official promotions.
   - If players request clarification about levels or specific percentages, refer to the official program structure: 108 PHP per referral, 1% deposit, 0.72% bets, and tier levels (Level 1: 0.5%, Level 2: 0.16%, Level 3: 0.06%).

9. **Escalate or refer to further support if:**
   - The player's case involves suspected fraud, multiple violations, or unverified activities.
   - There are system errors or discrepancies that cannot be resolved immediately.

## Notes

- Commissions are paid **automatically** once the deposit and betting activities are confirmed.
- For manual claims, direct players to the **Bonus Center** and instruct them to click **Claim** after the activities are verified.
- Weekly Thursday gifts are only available if the player logs in and visits the Rewards Center during the specified time window.
- All referral transactions are subject to validation against anti-fraud rules such as matching bank cards, phone numbers, IP addresses, and deposit amounts.

## Key points for communicating with players

- Clearly explain the validation of deposits and bets: **minimum 200 PHP**, completed activities, and no rule violations.
- Remind players that commissions are **credited automatically** but can be claimed manually after verification.
- Emphasize that ongoing commissions depend on the activity's validity and adherence to rules.
- Inform players that weekly gifts are only obtainable if they follow the visit and login schedule on Thursdays.