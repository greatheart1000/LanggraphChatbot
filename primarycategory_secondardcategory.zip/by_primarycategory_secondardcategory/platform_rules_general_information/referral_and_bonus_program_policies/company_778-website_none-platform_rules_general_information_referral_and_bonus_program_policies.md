# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Identify the player’s inquiry or issue** related to the referral or bonus program policies, and determine if they are asking about earning, claiming, rules, or eligibility.

2. **Gather necessary information from the player**:
   - Confirm the player's account details.
   - Ask for the method of inquiry: referral program details, bonus claim, or rule clarification.
   - If relevant, request player identification data to verify account ownership.

3. **Verify referral program eligibility and activity**:
   - Check if the player has sent a referral link or invite.
   - Confirm if the referred player has deposited at least 200 PHP to qualify the referral.
   - Review the referral records to see if the number of invites and downline activity meets the requirements for earning commissions.

4. **Check the specific referral commissions earned**:
   - Confirm the number of valid invites: each valid invite earns 88 PHP.
   - Verify downline deposits and bets:
     - For deposits, confirm the total deposit amount from downlines and calculate 0.68% of the total.
     - For bets, verify total bets from downlines and calculate 0.74% of the total.
   - Ensure no disqualifying factors are present:
     - Multiple accounts linked to the same person.
     - Common bank card, IP address, or phone number used to register or deposit by multiple accounts.

5. **Review bonus claim details**:
   - Check if the player has visited the Bonus Center.
   - Confirm if the claim is available under current conditions.
   - Verify that the player has met the requirements, such as deposit thresholds and activity thresholds, if applicable.

6. **Inform the player of their current status**:
   - If eligible, guide them to the Bonus Center and instruct to click 'Claim' to receive their commission or bonus.
   - Confirm the date and time of their last actions if necessary.
   - If ineligible, explain the reason based on the missing or failed conditions (e.g., insufficient deposit, disqualified due to multiple accounts, or not reaching activity thresholds).

7. **Check for system-related issues or violations**:
   - If the player reports unexplained disqualification or missing commissions, verify system records.
   - Look for detection of repeated IP address, bank card, or phone number usage, which could result in confiscation of rewards and profits.

8. **Address issues or disputes**:
   - If the player’s eligibility depends on correct deposit or activity, advise they meet the requirements and wait for the next cycle if applicable.
   - If a violation is suspected, inform the player that rewards and profits may be confiscated if repeated usage from the same IP, bank card, or phone number is detected.
   - For disputes or unresolved issues, escalate to the appropriate department following internal procedures.

9. **Document the interaction**:
   - Record the player’s details, inquiry, and resolution steps taken.
   - Note any disqualifications or violations found.

## Notes
- Commissions and rewards are credited automatically after the downline deposits and bets.
- Referral rewards reset monthly, and certain eligibility thresholds (like invited deposits) must be met.
- Repeated use of the system from the same IP address, bank card, or phone number could lead to confiscation of rewards and profits.

## Key points for communicating with players
- Clearly explain the specific criteria for earning referral commissions.
- Remind players that commissions are credited automatically after deposit and bets are verified.
- Warn that system detection of repeated IP, bank card, or phone number usage may result in confiscation of rewards.
- Inform players that reward resets monthly and that successful referrals require invited players to deposit at least 200 PHP.