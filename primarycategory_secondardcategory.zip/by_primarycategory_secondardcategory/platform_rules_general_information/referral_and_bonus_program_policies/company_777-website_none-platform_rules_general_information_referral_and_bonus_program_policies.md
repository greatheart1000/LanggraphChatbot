# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player’s information regarding inquiry**:
   - Ask if the player is inquiring about the referral program, referral rewards, or VIP Weekly Salary.
   - Confirm if the player has a specific referral or downline account they are referring.

2. **Verify the referral eligibility and identify the referral source**:
   - Request the referred user’s details if applicable, including:
     - Deposit status and amount (must be at least 200 PHP for qualification).
     - User’s deposit and betting activity.
   - Check for compliance with eligibility rules:
     - No multiple accounts linked to the same person.
     - Same IP address, same bank card, or same phone number as the referrer or across accounts.
   - Ensure that the referral is not from a disqualified device, IP, or account setup based on detected overlaps or policy violations.

3. **Perform background system checks**:
   - Review the referred user’s deposit activity to confirm they deposited at least 200 PHP.
   - Confirm that the referral activity (deposit and bets) has been completed after the referral link was shared.
   - Check for any policy violations that might disqualify the referral, such as:
     - Multiple accounts.
     - Same bank card or phone number used.
     - Same or overlapping IP addresses.

4. **Determine reward eligibility**:
   - Verify if the referral meets all given criteria for qualification.
   - If the referred user’s deposit is below 200 PHP, or if any disqualifying conditions are detected, inform the player that the referral is not valid.

5. **Advise on claiming the referral reward**:
   - If eligible:
     - Instruct the player to go to the Reward Center.
     - Indicate they should click “Claim” after the downline (referred user) deposits and bets.
     - Clarify that commissions are automatically credited, but claiming in Reward Center is necessary to view rewards.
   - If reward has not appeared:
     - Confirm that the referral is eligible.
     - Check if the referral’s deposit and activity are complete and meet requirements.
     - Advise patience if waiting period is needed, or escalate if rewards are still missing after a reasonable time.

6. **Explain the VIP Weekly Salary process (if applicable)**:
   - Inform the player that the VIP Weekly Salary is credited automatically every Thursday (GMT+8).
   - Confirm if the player has completed the required bets for the week (e.g., at least one valid bet).
   - Clarify that qualification depends on the current VIP tier and activity level.

7. **Handle policy violations or disqualifications**:
   - If irregular activity or violations are detected:
     - Explain that the referral or reward may be disqualified.
     - Advise the player on the possible reasons, such as multiple accounts or same payment methods.
   - Escalate cases involving suspected fraudulent activity or disputes to the relevant department.

8. **Document the case and close the inquiry**:
   - Record all findings, including referral details, deposit amounts, and any system checks performed.
   - Summarize the resolution provided (valid referral, disqualification, pending status, etc.).
   - Confirm the player understands the outcome and any further steps if necessary.

## Notes

- The referral must involve a user who deposits at least 200 PHP for the referral to be valid.
- Eligibility is invalidated if:
  - Same IP address, bank card, or phone number is used by the referral or referrer.
  - Multiple accounts are involved.
- Commissions are paid automatically after the referral deposits and bets; players must manually claim rewards through the Reward Center.
- The VIP Weekly Salary is credited automatically every Thursday (GMT+8), only if weekly betting requirements are fulfilled.
- Suspected fraudulent activity may result in disqualification of the referral or reward.

## Key points for communicating with players

- Clearly confirm deposit and activity details before confirming eligibility.
- Remind players to avoid sharing accounts, devices, or payment methods that might violate the policies.
- Inform that rewards are automatically credited but players can claim them in the Reward Center.
- Advise patience if rewards are pending and escalate any suspicious activity or technical issues accordingly.