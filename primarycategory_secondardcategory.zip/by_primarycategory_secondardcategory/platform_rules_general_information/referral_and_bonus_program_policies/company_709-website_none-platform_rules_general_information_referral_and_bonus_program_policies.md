# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Identify the player's inquiry or issue related to referral or bonus programs.**  
   - Confirm if the player is asking about referral bonuses, weekly rewards, or any related program benefits.

2. **Gather necessary account details from the player to verify eligibility.**  
   - Request the player’s account ID or username.
   - Ask if they are referring a new player or inquiring about their own referral/deposit activity.
   
3. **Check the player's registration and account status, including:**
   - Whether the player has a bound bank card.
   - Whether the player has a verified real name.
   - Whether a mobile phone number is bound to the account.
   - The IP address associated with their account.

4. **Assess referral eligibility based on the provided account information and activity.**  
   - Verify if the player has created multiple accounts or if multiple accounts are created from the same IP address.
   - Confirm if the referral has been made via a valid link and not through multiple registrations.
   - Check if the referred user has deposited at least 200 PHP.

5. **Review the referral’s deposit and betting activity.**  
   - Confirm the deposit amount meets the minimum of 200 PHP.
   - Verify that the deposit and bet activities are completed and credible.
   - Check for any signs of activity involving the same IP, bank card, or phone number as the referrer that could disqualify the referral.

6. **Explain to the player the conditions for earning referral rewards and bonuses:**  
   - For a referral to be valid, the referred player must deposit ≥200 PHP.
   - Multiple account registration, same bank card, phone number, or IP address usage can disqualify the referral.
   - Rewards are automatically credited after deposit and betting activities are verified.
   
7. **Check for specific reward eligibility for weekly rewards (Weekly Wednesday Gifts) or Monthly Rewards:**  
   - Confirm if the player logged in and visited the Rewards Center between 22:00 - 23:59 (GMT+8) on the relevant date.
   - Advise the player to visit the Rewards Center during that timeframe to receive the rewards.
   - Make sure the player’s IP address, bank card, or phone number are not flagged for repetition, as rewards will be confiscated if detected.

8. **If the player reports issues with missing or uncredited rewards or bonuses:**
   - Verify system logs to confirm the player’s login time and Rewards Center visit.
   - Confirm no activity involving the same IP, phone number, or bank card is flagged for violations.
   - If eligibility criteria are met and no violations are detected, instruct the player on how to claim rewards via the Rewards Center or remind them that rewards are credited automatically.

9. **Inform the player of violations or disqualifications if applicable:**  
   - If multiple accounts, same IP, bank card, or phone number are detected, or the deposit amount is below 200 PHP, explain that the referral is invalid or rewards are confiscated.
   - Clarify that any system detections of duplication involving IP, bank card, or phone number result in confiscation of rewards and profits.

10. **For players requesting help with claiming rewards or understanding program details:**
    - Guide them to visit the Rewards Center and click “Claim” for applicable bonuses.
    - Reiterate the requirements: deposit ≥200 PHP, no multiple accounts, no shared bank card or phone, correct login procedures during reward times.

11. **Escalate or record cases where violations are suspected or confirmed, especially involving multiple accounts, repeated IP addresses, or use of same bank or phone details.**  
    - Note the details in the case management system.
    - Follow internal escalation procedures if necessary.

12. **Close the case after providing the necessary information or resolution, ensuring the player understands the rules and their current status.**

## Notes

- Rewards such as Weekly Wednesday Gifts can be up to 999,999 PHP; Monthly Rewards are available on the 11th of each month during 22:00 - 23:59 (GMT+8).  
- Rewards and profits will be confiscated if the system detects activity involving the same IP address, bank card, or phone number in violation of the terms.  
- Referral bonuses include 200 PHP per valid referral, 1.00% on each downline’s deposits, and 0.63% on bets, with potential tier bonuses up to 188,888 PHP.  
- All referrals must deposit at least 200 PHP and avoid duplicate registration methods or sharing account details for eligibility.  
- Commissions are automatically credited after deposit and betting verification; players can manually claim rewards in the Bonus Center.  
- Creating multiple accounts using the same referral link from the same IP or with shared details violates platform policies and results in deductions of earnings.