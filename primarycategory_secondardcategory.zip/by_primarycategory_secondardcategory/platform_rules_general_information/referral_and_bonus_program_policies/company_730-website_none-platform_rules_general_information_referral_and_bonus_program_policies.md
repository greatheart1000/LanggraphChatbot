# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player information regarding the referral or bonus inquiry.**  
   Ask the player for details about their current referral activity or bonus status, including whether they are referring new players or have questions about their commissions or rewards.

2. **Verify the player's eligibility for the referral or bonus program.**  
   Confirm that the player is a registered member eligible to participate in the Agent Commission or referral program.  
   - Ensure they are sharing their referral link correctly.  
   - Check if they have already reached or exceeded bonus thresholds (e.g., invite 20 players for 209 PHP bonus, invite 50 players for 1,099 PHP bonus).  

3. **Instruct the player on how to properly share their referral link.**  
   Advise them to distribute the referral link on social media platforms or appropriate channels in accordance with the program rules.

4. **Ask the player to confirm the details of the referred players' activities.**  
   - Determine if the referred players have completed necessary actions, such as making a minimum total deposit of 200 PHP, to qualify for commissions.  
   - Confirm that the referred parties have not registered multiple accounts, used the same bank card, phone number, or IP address to prevent eligibility issues.

5. **Check for potential reasons why a referral might not qualify or commissions might be denied.**  
   - Review if there are multiple account registrations, binding the same bank card, same phone number, or use of the same/multiple IP addresses.  
   - Verify that the referral’s total deposit has reached at least 200 PHP.  
   - Identify any suspicious activity or rule violations that could lead to denial.

6. **Access the system or back-office tools to verify the referral activity.**  
   - Confirm if the referred player has deposited at least 200 PHP.  
   - Check deposit and betting records to see if the referral is eligible for commissions.  
   - Verify tier levels and whether bonus thresholds (up to 199,999 PHP) are being met based on the number of invited players and their activities.

7. **If referral is valid and meets all the conditions:**
   - Confirm with the player that their referral activity is eligible.  
   - Inform them that commissions are paid automatically after the referred user deposits and places bets.  
   - Advise that commissions can be claimed or viewed in the Rewards Center if applicable.  

8. **If the referral is invalid or does not meet the requirements:**
   - Explain clearly the reasons, such as multiple accounts, insufficient deposit amount, or use of restricted information (same bank card, phone number, IP).  
   - Suggest corrective actions if possible (e.g., ensuring the referral reaches the minimum deposit) or inform them that the referral does not qualify for rewards.

9. **For ticket escalation or further review:**
   - Document the case with relevant details, including player explanations, verification results, and screenshots if necessary.  
   - Escalate to the appropriate department if there are discrepancies, potential violations, or system issues affecting referrals or commissions.

10. **Close the interaction:**
    - Summarize the findings and confirm the next steps with the player.  
    - Remind the player to follow the program rules for future referrals.  
    - Thank them for their participation and prompt them to contact support if they have further questions.

## Notes
- Commissions are only paid after the referred user deposits at least 200 PHP.  
- Referrals may be denied if there are multiple accounts, same bank card, same phone number, or same/multiple IP addresses detected.  
- Tier bonuses and cumulative rewards are based on the number of successful invited players and their deposit activities, with maximum bonuses up to 199,999 PHP.  
- Commissions are sent automatically after qualifying deposits and bets, and players can view their rewards in the Rewards Center.  

## Key points for communicating with players
- Always verify the deposit amount of the referral (must reach 200 PHP) before confirming eligibility.  
- Clearly explain why a referral may not qualify if eligibility criteria are not met, referencing the rules (e.g., multiple accounts, same IP).  
- Encourage fair participation in the referral program and adherence to the rules to maximize rewards.