# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Receive the player's inquiry about the referral or bonus program.**  
   - Ask for details about the player's current account and specific question or concern.

2. **Verify the player's referral or bonus-related information.**  
   - Check if the player is inquiring about the referral bonus or the Lucky Draw program.  
   - Confirm whether the player claims to have referred friends or received referral bonuses.

3. **Gather essential information from the player.**  
   - For referral questions:  
     - Confirm if the player used a referral link for registration.  
     - Ask if the referred friend has completed the minimum deposit of 100 and wagered at least 2,000.  
     - Check if the referred friend's IP address is unique and not shared with another account.
   - For bonus questions:  
     - Clarify if the question relates to the referral bonus conditions or payout timing.  
   - For Lucky Draw questions:  
     - Confirm if the player has followed the Telegram channel, received a promo code, entered it in the Reward Center, and met any wagering requirements to withdraw prizes.

4. **Perform system checks based on the provided information.**  
   - Verify if the referred friend’s account:
     - Registered using the player's referral link.  
     - Made at least 100 deposit and wagered at least 2,000.  
     - Has a unique IP address (not shared with another account).  
   - Check whether the referral bonus was automatically credited:  
     - To the player’s account before 12:00 noon the next day if conditions are met.  
   - For Lucky Draws, confirm if the player has correctly followed the participation steps and met withdrawal conditions (e.g., 10x wagering requirement).

5. **Determine the appropriate resolution or explanation based on the checks.**  
   - **If all conditions for the referral bonus are satisfied:**  
     - Confirm that the bonus has been credited or is in process.  
   - **If conditions are not met:**  
     - Explain which specific condition(s) failed (e.g., deposit amount, wagering, IP restriction).  
     - Advise the player if additional actions are needed (e.g., deposit, wager).  
   - **If the bonus has not been credited despite meeting conditions:**  
     - Confirm timing (before 12:00 noon the next day).  
     - Escalate if system delay or error is suspected.

6. **Advise the player on next steps or resolution details.**  
   - If the bonus is correctly credited:  
     - Inform the player that their referral bonus has been credited or will appear shortly.  
   - If the bonus has not been credited and conditions were met:  
     - Notify the player to wait until the next payout time or escalate the issue.  
   - For Lucky Draw:  
     - Confirm whether the player has met all requirements to withdraw prizes and advise accordingly.

7. **Document all findings and actions taken.**  
   - Record verification results, system checks, and player statements for future reference.

## Notes

- Always check whether the player’s referred friend’s IP is shared, as the referral policy restricts sharing IPs with other accounts.
- The referral bonus is automatically sent before 12:00 noon the following day once all conditions are met.
- For the Lucky Draw program, participation involves following specific steps, entering promo codes, and meeting wagering requirements to withdraw prizes.
- Clarify that bonus amounts and availability may vary based on VIP level or specific event rules, but these details are not specified explicitly in the FAQs. Handle according to current site configuration.

## Key points for communicating with players

- Confirm all referral conditions: registration via referral link, minimum deposit, wagering, and IP restrictions.
- Inform players that bonuses are credited automatically the day after meeting the criteria, before 12:00 noon.
- For Lucky Draws, emphasize following all participation steps and meeting wagering requirements to withdraw prizes.
- Always verify and record the outcome of system checks and player statements to ensure accurate support.