# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Gather player information**
   - Confirm the player's identity and account details.
   - Ask the player for the account registration link or username associated with the referral.
   - Request relevant details such as the referred player's username, deposit amount, and betting activity if available.

2. **Verify the referral qualification criteria**
   - Check whether the referred player has made a total deposit of at least PHP 200.
   - Confirm that the referral is unique and not a duplicate from previous referrals.
   
3. **Perform system checks to detect potential disqualifications**
   - Review if multiple accounts are registered from the same IP address.
   - Check if the same bank card has been used across multiple accounts.
   - Verify if the same phone number has been used to register multiple accounts.
   - Confirm whether the logged-in IP address matches previous activity (same or multiple).
   
   - *Note:* These checks can typically be performed through the system's back office or automated screening tools.
   
4. **Evaluate the referral’s qualification status**
   - If any disqualifying activity (multiple accounts, same bank card, phone number, or IP address) is detected, mark the referral as not qualified.
   - If the referral passes these checks and the referred player's deposit criteria are met, proceed to qualification.

5. **Confirm deposit status**
   - Verify the referred player's deposit amount.
   - If the deposit is at least PHP 200, the referral qualifies.
   - If not, notify the player that the referral does not meet the minimum deposit requirement.

6. **Verify and record the referral details**
   - Ensure the invitation was a unique invite.
   - Confirm the referred player's deposit and betting activity in the system.
   - Document the referral's qualification status, deposit amount, and reasons if disqualified.

7. **Explain to the player the qualification outcome**
   - If qualified:
     - Inform about the successful qualification.
     - Detail the earning opportunities: PHP 168 per qualified invited player, 0.88% on deposits, 0.62% on bets, and potential tier bonuses.
   - If not qualified:
     - Clearly state the possible reasons (e.g., multiple accounts, same bank card, phone number, or IP address, or deposit below PHP 200).
     - Advise the player to ensure future referrals meet the requirements.

8. **If the referral is qualified, process the earnings and commissions**
   - Confirm that the system will automatically credit the earnings:
     - PHP 168 per qualified invited player.
     - 0.88% of the deposit amount from the referred player.
     - 0.62% of the betting activity from the referred player.
     - Any tier bonuses applicable.
   - If manual intervention is required or any discrepancy is noticed, escalate as per the internal procedures.

9. **Document and close the case**
   - Record all findings, communication, and system actions taken.
   - Update the case status in the support system.
   - Provide the player with relevant confirmation or further instructions if necessary.

## Notes
- Always verify deposit amounts and activity against the system records.
- Remind players that multiple account registration, same bank card, same phone number, or logging in from the same IP address may disqualify a referral.
- For any unclear cases or suspected violations, escalate to the relevant department for further inspection.
- Screenshots or evidence may be requested if verification of income or qualification is needed.

## Key points for communicating with players
- Clearly explain the qualification criteria, especially the PHP 200 deposit minimum.
- Emphasize that system checks for multiple accounts, shared bank details, phone numbers, and IP addresses are standard for qualifying referrals.
- Inform players that violations of these rules can disqualify their referrals.
- Maintain transparency and professionalism when discussing qualification reasons or system checks.