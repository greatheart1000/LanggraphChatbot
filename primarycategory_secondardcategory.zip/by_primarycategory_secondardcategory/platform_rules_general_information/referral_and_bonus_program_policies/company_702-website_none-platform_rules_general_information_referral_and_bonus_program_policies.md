# Platform Rules & General Information - Referral and Bonus Program Policies

## Steps

1. **Identify the player's inquiry or issue regarding referral or bonus programs.**  
   - Confirm whether the player is asking about the agent referral program, general referral requirements, or specific bonus details.

2. **Collect relevant information from the player.**  
   - Ask for the player’s username or account ID.  
   - Request details about the referred players, such as their usernames if available.  
   - Inquire whether the player has already received any bonuses or commissions related to referrals.

3. **Verify the referred player's account status and activity.**  
   - Check if the referred user has successfully registered and made a deposit of at least 200 PHP (the minimum deposit for the referral to be valid).  
   - Confirm that the activity conditions (deposits and bets) are met according to site rules.

4. **Check for potential disqualifiers.**  
   - Ensure that:
     - The referral is not a multiple account or duplicate registration.  
     - The same bank card, phone number, or IP address is not used for both the referrer and referred user (if possibly suspicious).  
   - Verify that the referral is valid, i.e., the referred user has made the required deposit and engaged in activity meeting the program’s criteria.

5. **Evaluate the status of the referral based on system data.**  
   - Confirm whether the referred user has deposited at least 200 PHP and placed bets, qualifying the referral for earning.  
   - Check if the commission has already been credited (automatic payout occurs after deposit and betting activity).

6. **Explain the referral program terms to the player.**  
   - Inform the player that:
     - For each valid referral, they earn 108 PHP + Angpao.  
     - Additionally, they earn 1.09% on each deposit and 0.68% on each bet made by the downline.  
     - Commissions are distributed across five levels: Level 1 (0.29%), Level 2 (0.19%), Level 3 (0.10%), Level 4 (0.06%), Level 5 (0.04%).  
   - Clarify that to be considered a successful referral, the referred user must make a minimum total deposit of 200 PHP.  
   - Mention that commissions are sent automatically once the conditions are met (deposit and betting).

7. **If the referral is not qualified or disqualified, communicate reasons clearly.**  
   - Explain that:
     - Multiple accounts, same IP, same bank card, or same phone number could disqualify a referral.  
     - The referred user has not met the minimum deposit or activity requirements.  
   - Advise on any corrective actions, such as verifying account information or encouraging proper registration procedures.

8. **For valid and qualified referrals, confirm the earnings and process.**  
   - Let the player know that the system automatically credits commissions once conditions are met.  
   - Clarify that the first earning (108 PHP + Angpao) and ongoing sharing percentages are included under the program rules.

9. **Assist with claiming, viewing, or troubleshooting referral bonuses and commissions as needed.**  
   - Guide the player on how to view their referral earnings in the system.  
   - For any delays or discrepancies, advise to wait for automatic processing or escalate according to operational procedures.

10. **Record the case details and conclude the interaction.**  
    - Document the inquiry, verification results, and any explanations provided.  
    - Offer further assistance related to referral program policies if required.

## Notes

- All commissions are sent automatically after the referred user deposits and bets.  
- The maximum bonus per referral tier can reach up to 199,999 PHP based on the number of referrals and tier milestones.  
- Multiple account registrations or identical personal information may disqualify referrals.  
- Always verify that the referred user has met the minimum deposit of 200 PHP to qualify the referral.  

## Key points for communicating with players

- Remind players that each referral must meet the activity criteria to qualify for earnings.  
- Clearly explain the different earning components: initial 108 PHP + Angpao, deposit shares, bet shares, and level commissions.  
- Emphasize the automatic payout process once the referral conditions are satisfied.  
- Be transparent about potential disqualifiers and encourage proper registration practices.