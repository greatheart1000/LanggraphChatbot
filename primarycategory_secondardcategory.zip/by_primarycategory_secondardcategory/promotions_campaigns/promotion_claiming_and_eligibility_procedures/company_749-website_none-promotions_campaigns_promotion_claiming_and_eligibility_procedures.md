# Promotions & Campaigns - Promotion Claiming and Eligibility Procedures

## Steps

1. **Identify the promotion queried by the player.**  
   - Determine if the player is referring to the Tuesday Surprise Gifts bonus or the daily Angpao bonus based on their question.
   - Confirm whether the query is about claiming, eligibility, or accessing current promotions.

2. **Verify the player's eligibility for the promotion.**  
   - For Tuesday Surprise Gifts:
     - Check if the account is eligible to receive the Tuesday bonus (being eligible is implied if the bonus is not received).
   - For Daily Angpao:
     - Confirm the player downloaded and logged into the PHLOVE app.
     - Check if the player is a new player or a VIP member.
     - For deposit requirements:
       - Verify if the player has deposited at least 100 PHP (for new players).
       - Verify the number of deposits since registration:
         - If deposited more than 5 times, the player can withdraw directly.
         - If deposited less than 5 times, confirm if the player has completed 10x turnover to unlock withdrawal.
   - For accessing current promotions:
     - Ensure the player has downloaded and logged into the official PHLOVE app.

3. **For Tuesday Surprise Gifts:**
   - Confirm the current date and time meets the promotion window (Tuesday between 22:00 - 23:59 [GMT+8]).
   - Ask the player to log in during this time to receive the bonus.
   - Inform the player that the Surprise Gifts are automatically delivered if eligible.
   - If the bonus is not received:
     - Clarify that the player is not eligible for the bonus at that time.

4. **For claiming the Tuesday bonus:**
   - Advise the player to log in during the promotion period (Tuesday 22:00 - 23:59 [GMT+8]) to receive the mystery bonus.
   - Confirm that they have successfully logged in during the specified window.
   - If they did not receive the bonus, inform them that it indicates they are not eligible.

5. **For the daily Angpao bonus:**
   - Confirm the player meets the participation criteria:
     - Downloaded and logged into the PHLOVE app.
     - If a new player, deposited at least 100 PHP (automatic bonus of 108 PHP).
     - If a VIP, inform them they are eligible for higher rewards.
     - If a returning member, verify deposit count and turnover requirements for withdrawal.
   - Explain the time window (21:00 to 21:30 GMT+8) during which the bonus runs.
   - Confirm if the player has fulfilled the deposit and turnover conditions for withdrawal if applicable.

6. **For accessing current promotions and bonuses:**
   - Instruct the player to download the official PHLOVE app.
   - Guide them to tap "App Download," install the Android app, follow prompts to finish installation, and then sign in.
   - After signing in, confirm they can view ongoing offers and bonuses.

7. **If the player reports not receiving a bonus they are eligible for:**
   - Double-check the eligibility criteria and logs.
   - Confirm whether the player performed actions within the specified times.
   - Inform the player if they are not eligible at this time, or advise on the necessary steps (e.g., logging in during promotion hours, completing deposit or turnover requirements).

8. **Escalation or further assistance:**
   - If eligibility or bonus delivery issues persist that cannot be resolved with these steps, escalate to the relevant support team with details of the player's account and promotion activity.

## Notes

- The Tuesday Surprise Gifts are delivered automatically, so manual claiming is not required.
- The bonus conditions, such as minimum deposit and turnover (for withdrawals), depend on the player's current VIP level and deposit history.
- The key to successful resolution is verifying eligibility based on the specific criteria for each promotion and timing.

## Key points for communicating with players

- Clearly inform the player that the Tuesday bonus is automatically received between 22:00 - 23:59 every Tuesday.
- Emphasize the importance of logging in during the promotion periods to receive bonuses.
- Confirm the player's app download and login status for promotion access.
- Explain the deposit and turnover requirements for withdrawals related to the Angpao bonus.
- Keep the player informed about their eligibility status and next steps if they encounter issues.