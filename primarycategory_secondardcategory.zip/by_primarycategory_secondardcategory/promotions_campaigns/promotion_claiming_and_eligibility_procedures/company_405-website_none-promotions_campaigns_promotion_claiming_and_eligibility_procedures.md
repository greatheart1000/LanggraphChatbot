# Promotions & Campaigns - Promotion Claiming and Eligibility Procedures

## Steps

1. **Identify the player's inquiry or request regarding a promotion or promo code.**  
   - Determine if the player is asking how to use a promo code, how to access promotions, or about eligibility criteria.

2. **Gather necessary information from the player.**  
   - Ask for the player's account details to verify identity.  
   - Confirm which promotion or promo code they are referring to, including any specific code if applicable.  
   - Note if the player has received promo codes via official channels like the Telegram support channel, member inbox, or website.

3. **Check the player's eligibility and current promotion status.**  
   - Verify if the player has followed the official channels to access promo codes.  
   - Confirm if they have met specific requirements, such as depositing (if required), following instructions in the promotion page, or completing necessary steps (e.g., wagering the required amount).  
   - For promotional participation, check if the player has deposited and adhered to the rules, e.g., the required turnover (1x) on eligible games for BERMONTH promotions.

4. **Assist the player in promo code redemption or promotion participation as appropriate.**  
   - **For promo code usage:**  
     - Log in to the player's account.  
     - Navigate to the 'Reward Center.'  
     - Click on the 'Promo Code' tab.  
     - Have the player enter or redeem the code.  
     - Confirm that the code is successfully applied, and advise the player to check the Rewards/Promo section for confirmation.  
     - Remind the player to review each promo's specific requirements and terms before redemption, especially if a deposit is required before redeeming.

   - **For participating in promotions (like BERMONTH):**  
     - Guide the player to log in to the Lodibet official website.  
     - Instruct them to tap the Christmas icon at the bottom of the homepage (for BERMONTH).  
     - Advise the player to follow on-screen instructions: deposit, complete any required wagering or turnover (e.g., 1x on eligible games), and join the promotion in the promotion page.

5. **Verify that the player has fulfilled all promotion-specific conditions.**  
   - Confirm deposit amounts, wagering requirements, or eligibility criteria are met as per the promotion rules.  
   - If the conditions are not met, inform the player of the specific reason why they cannot claim or participate further.

6. **If the player does not meet the eligibility criteria or has not fulfilled necessary steps:**  
   - Explain the specific requirements clearly.  
   - Advise on how to complete remaining steps or conditions for future eligibility.  
   - If applicable, suggest checking official channels for updated promotion terms or promo codes.

7. **Document the interaction appropriately.**  
   - Record the promo code used, promotion name, and any relevant details about promotion eligibility or completion status in the player's account notes.

8. **If the issue cannot be resolved immediately (e.g., system error, missing info):**  
   - Escalate to the relevant support team with all gathered details.  
   - Inform the player that their request is being escalated and provide an estimated resolution time if possible.

## Notes

- Promo codes are officially announced via Lodibet’s Telegram channel, member inboxes, and the official website.  
- Promo codes may require a deposit before redemption—players must review specific promo terms.  
- Participation in BERMONTH promotions involves depositing, following instructions at the bottom of the homepage, and fulfilling a 1x turnover on eligible games before withdrawals.  
- Always verify current official channels for the latest promo codes and promotions.

## Key points for communicating with players

- Clearly explain the requirements and steps for claiming promo codes or participating in promotions.  
- Remind players to review the specific terms and conditions linked with each promotion or promo code.  
- Encourage players to follow official channels for updated promo information.