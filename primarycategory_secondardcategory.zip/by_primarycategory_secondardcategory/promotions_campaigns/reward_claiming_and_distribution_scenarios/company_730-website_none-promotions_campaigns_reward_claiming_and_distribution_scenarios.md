# Promotions & Campaigns - Reward Claiming and Distribution Scenarios

## Steps

1. **Identify the specific promotion or campaign the player is inquiring about** (e.g., Lose on Slot and Fish rewards, Monday Weekly Gifts, 24th Monthly Rewards).

2. **Collect necessary information from the player**, including:
   - The specific reward or promotion they are referring to.
   - The date and time they attempted to claim the reward.
   - If applicable, the amount lost or wagered (for reward eligibility verification).
   - Their account details to verify eligibility.

3. **Verify the player's eligibility and reward status**:
   - Check system records or the Rewards Center for the specific reward:
     - Confirm if the player has met the criteria (e.g., lost PHP 100 or more on Slot or Fish games for Lose rewards).
     - For Monday Rewards, verify if the claim is made between 22:00 and 23:59 (GMT+8) on a Monday.
     - For 24th Monthly Rewards, verify if the player visited the Rewards Center on the 24th of the month between 22:00 and 23:59 GMT+8.
   - Check if the player has previously received the reward to determine if they are eligible or if the reward has already been claimed.

4. **Determine if the player is eligible to claim the reward**:
   - If eligible (criteria met, timing within claim window, and reward not already claimed), proceed to instruct the player to claim the reward.
   - If not eligible:
     - Inform the player why they are not eligible (e.g., outside claim window, not met requirements, already received).

5. **Guide the player on how to claim the reward**:
   - Advise them to login to their account.
   - Instruct them to go to the Rewards Center.
   - Remind them of the specific claim window:
     - For Lose rewards: Log in the next day to claim between 04:00-06:00 AM (GMT+8).
     - For Monday Rewards: Claim every Monday between 22:00-23:59 (GMT+8).
     - For 24th Monthly Rewards: Claim on the 24th of each month between 22:00-23:59 (GMT+8).

6. **Check the reward receipt**:
   - Confirm if the reward has been successfully credited to the player’s account.
   - If the reward is not credited:
     - Verify if the claim was made during the proper window.
     - Check for any system issues or delays.
     - If no issues are identified, clarify to the player that they may not be eligible or that the reward has already been claimed.

7. **Escalate or follow up if necessary**:
   - If the player claims not to have received a reward despite meeting all criteria, escalate for further investigation.
   - If the reward has already been claimed or no reward is available, explain clearly and document the case.

## Notes
- For reward eligibility, ensure that players meet all specified conditions such as the minimum loss or wager, specific dates, and claim windows.
- If players claim outside the designated time frames, inform them that claims are only accepted during the specified hours.

## Key points for communicating with players
- Clearly specify the claim window times in GMT+8.
- Remind players that rewards for Lose on Slot and Fish are available the following day after losing PHP 100 or more.
- Confirm whether the rewards have been already claimed to avoid duplicate claims.
- If players did not receive rewards despite meeting the criteria, inform them of potential ineligibility or timing issues.