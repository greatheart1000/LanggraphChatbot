# Promotions & Campaigns - Reward Claiming and Distribution Scenarios

## Steps

1. **Identify the promotion or campaign the player is referring to**, e.g., Weekly Rewards, Monthly Rewards, Red Packet/Angpao bonus, or other campaign-specific offers.

2. **Verify the timing and eligibility details for the specific promotion**:
   - For Weekly Rewards:
     - Confirm if the current day is Wednesday.
     - Check if current time is between 22:00 - 23:59 (GMT+8).
   - For Monthly Rewards:
     - Confirm if the current date is the 8th of the month.
     - Check if current time is between 22:00 - 23:59 (GMT+8).
   - For Red Packet/Angpao bonus:
     - Ensure player has completed >50 spins on specified games and has met spin bet conditions.
   - For all campaigns:
     - Confirm player is eligible based on deposit count or betting conditions if specified.

3. **Request relevant player information to confirm eligibility**:
   - Player's registration details (to verify deposit or spin history).
   - Player's account activity related to the campaign (e.g., recent spins, deposits).

4. **Instruct the player to log in during the scheduled claim window**:
   - Emphasize the specific time window for claiming, e.g., 22:00 - 23:59 (GMT+8) on Wednesdays or the 8th of the month for monthly rewards.
   - Advise to navigate to the Rewards Center directly.

5. **Guide the player to the Rewards Center**:
   - Instruct on how to access the Rewards Center from the main menu/dashboard.
   - Confirm they are on the correct page for claimable rewards.

6. **Verify the player's attempt to claim the reward**:
   - Check for confirmation that the player has clicked or selected the reward during the claim window.
   - Confirm the claim attempt was made within the designated time.

7. **Perform system validation checks**:
   - Ensure the system recognizes the player as eligible for the campaign.
   - Check for duplicate accounts, IP address, bank card, or phone number matches if the system detects multiple claims or suspicious activity.
   - Confirm whether the player has already claimed for the current period (if only once per period).
   - For Monthly Rewards, ensure the claim is on the 8th of the month.

8. **If the claim is successful**:
   - Inform the player of the reward received, noting it is assigned randomly and can be up to the maximum specified (e.g., up to 299,999 PHP for Weekly Rewards).
   - Clarify that each player can only claim once per eligible period and that duplicate accounts using the same IP or personal details may lead to forfeiture.

9. **If the claim is rejected or system flags an issue**:
   - Explain clearly the reason, e.g., outside claim window, already claimed, duplicate account, or ineligible based on deposit/spin history.
   - Advise the player of any next steps or to try again in the next eligible period if applicable.

10. **Document the transaction and outcome**:
    - Record player's details, timing, and result of the claim.
    - Note any system errors or irregularities encountered.

## Notes

- Rewards are randomly distributed within the maximum limit (e.g., up to 299,999 PHP for Weekly Rewards and similar for Monthly Rewards).
- Players must claim within the specified time window; claims made outside this window are invalid.
- Multiple accounts using the same IP, bank card, or phone number will result in forfeiture of rewards and profits.
- For Red Packet/Angpao bonuses, spins must average at least 6 PHP per spin and bets over 50 spins; rewards can be claimed by logging in the day after completing spins and before 04:00 PM.
- For monthly rewards, ensure only one claim per player per month, and prevent multiple claims by detection of duplicated account information.

## Key points for communicating with players

- Remind players of the exact claim times (e.g., Wednesdays 22:00 - 23:59 GMT+8; 8th of the month 22:00 - 23:59 GMT+8).
- Instruct them to access the Rewards Center during the claim window.
- Emphasize that only one claim per period is allowed, and duplicate accounts or details will result in forfeiture.
- Clarify the randomness and maximum limit of rewards.
- Inform players that claims outside the specified times are invalid.