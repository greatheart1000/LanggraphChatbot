# Promotions & Campaigns - Promotion and Bonus Eligibility and Claims

## Steps

1. **Identify the player's query and determine the context.**  
   - Check if the player is asking about the availability, eligibility, or claiming of promotions or bonuses, including specific campaigns like the Birthday Bonus.

2. **Verify the current promotion offerings.**  
   - Inform the player that the Birthday Bonus is currently unavailable, if applicable.  
   - Advise the player to check the Promotions section on the official website for the latest updates on available promotions and campaigns.

3. **Gather necessary information from the player to assess eligibility.**  
   - Request the player’s deposited amount, if relevant (e.g., for first deposit bonus).  
   - Confirm if the player meets specific promotion criteria such as deposit amount (e.g., minimum of 100 PHP).  
   - Ask the player if they are attempting to claim a specific bonus or promotion.

4. **Guide the player to access promotions and bonuses properly.**  
   - Instruct the player to use the official DreamJILI app for the best experience and security.  
   - Steps for app access:  
     - Download the official DreamJILI app (via "App Download").  
     - Install the Android app.  
     - Open the app to stay updated on current promotions and bonuses.

5. **Check the player's eligibility for the specific promotion or bonus.**  
   - Verify that the player’s deposit or action meets the requirements specified in the promotion rules (e.g., minimum deposit, eligible game types).  
   - Ensure the player has fulfilled any additional criteria such as account verification or registration date.

6. **Assist the player in claiming the bonus if eligible.**  
   - Direct the player to the promotion page to review bonus details.  
   - Confirm that the player has made the required deposit and followed the correct process.  
   - If the promotion requires, instruct the player to provide a screenshot showing the promotion details for verification.

7. **Perform back-office checks for potential issues.**  
   - Check for signs of multiple accounts, binding the same bank card, phone number, or IP address, which may void the bonus.  
   - Confirm that the player has not exceeded any claim limits or restrictions specified in the promotion’s rules.

8. **Communicate the outcome to the player.**  
   - If the player is eligible and the bonus can be claimed, confirm successful processing.  
   - If the bonus is unavailable (e.g., the Birthday Bonus), clearly inform the player that it is not currently offered but encourage them to check regular promotions.  
   - If the player is ineligible, explain the reason based on promotion rules and checks.

9. **Close the case with appropriate follow-up.**  
   - Ensure the player understands the terms for wagering or turnover requirements, if applicable.  
   - Remind the player to check the Promotions section frequently for updates.

## Notes

- The Birthday Bonus is currently not available; players should check the Promotions section regularly for updates.  
- The first deposit bonus involves a minimum deposit (usually 100 PHP) and is subject to turnover requirements before withdrawal.  
- Rewards may be limited or voided in cases of suspected multiple accounts or if the same payment details are used across accounts.  
- Using the official DreamJILI app ensures access to current promotions and enhances account security.  

## Key points for communicating with players

- Inform players that the Birthday Bonus is currently unavailable but promote checking the Promotions page regularly.  
- Clarify that eligibility depends on meeting deposit and other specific promotion requirements.  
- Emphasize the importance of using the official app for accessing promotions and bonuses.