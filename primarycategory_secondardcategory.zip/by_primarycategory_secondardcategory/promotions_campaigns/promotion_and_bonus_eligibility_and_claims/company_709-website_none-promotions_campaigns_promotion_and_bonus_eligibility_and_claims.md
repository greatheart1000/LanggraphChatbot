# Promotions & Campaigns - Promotion and Bonus Eligibility and Claims

## Steps

1. **Identify the player's inquiry**:
    - Determine whether the player is asking about current promotions, bonuses, or eligibility.
    - Confirm if the inquiry is about specific bonuses (e.g., birthday bonuses, referral bonuses, new member bonuses).

2. **Verify if the player is eligible for any promoted bonus**:
    - For general promotion inquiries:
        - Check if the promotion is applicable based on the promotion's specific conditions.
        - For example, the Weekly Wednesday Gifts:
            - Ensure the player logs in on a Wednesday.
            - Confirm the visit to the Rewards Center occurs between 22:00 - 23:59 pm [GMT+8].
            - Check if the rewards are correctly received (up to 999,999 PHP for single rewards).
            - Be aware of restrictions: rewards and profits will be confiscated if the system detects repetition involving the same IP, bank card, or phone number.
        - For referral bonuses:
            - Confirm the referral has reached a total deposit of 200 PHP.
            - Check for restrictions:
                - Multiple account registration.
                - Binding same bank card.
                - Using the same phone number.
                - Using the same or multiple IP addresses.
            - Verify if the referral has been properly tracked and commission sent after downline deposits and bets.
    - For the New Member Bonus:
        - Confirm the player's registration date and process:
            - Registration on the official website.
            - App download.
            - Automatic credit of the new member bonus (up to 999 PHP) triggered.
            - Bonus applicable only on Slot & Fish Games.
            - Ensure they meet the 20x turnover requirement before withdrawal.
            - Check if the bonus was credited within about 2 hours of registration and app download.
    - **Note**: Currently, there are no birthday bonuses available; inform the player accordingly.

3. **If the player claims or inquires about a bonus**:
    - Confirm they have completed the necessary steps:
        - Registration and app download for the new member bonus.
        - Visiting the Rewards Center on Wednesday for the Weekly Gifts.
    - Check their transaction records and bonus status in the system to verify eligibility.
    - Confirm that all conditions are met (e.g., time frame, deposit amounts, gameplay restrictions).

4. **If the bonus is eligible and correctly claimed**:
    - Advise the player about the bonus details:
        - The amount credited (if applicable).
        - The applicable games (e.g., Slot & Fish Games for new member bonus).
        - The turnover requirement (e.g., 20x for the new member bonus).
        - The time frame for bonus validity.
    - Guide the player on the required steps to meet wagering requirements if needed.
    - Confirm that the bonus has been credited in the player's account.

5. **If the player is not eligible or the bonus was not credited**:
    - Investigate the reason:
        - Insufficient deposit or activity.
        - Eligibility restrictions not met (e.g., multiple accounts, IP, phone, or bank card issues).
        - Bonus not claimed within the eligible window.
        - Bonus not credited within the specified time (about 2 hours for new member bonus).
    - If any violations or issues are detected, explain the reason clearly and courteously.
    - If system errors are suspected, escalate to technical support with detailed information.

6. **Close the case with appropriate advice**:
    - For eligible bonuses: instruct the player on how to proceed with wagering or withdrawals.
    - For ineligible cases: clarify the specific reason based on the findings.
    - For ongoing issues or uncertainties, advise the player to monitor the Promotions page regularly for updates.

## Notes

- Promotions are subject to specific conditions; always verify details before providing instructions.
- System detection mechanisms (e.g., IP, bank card, phone number) are in place to prevent abuse of promotions such as weekly rewards and referrals.
- The current site configuration does not include birthday bonuses; inform players that they can explore other available promotions.
- The 20x turnover condition applies only to certain bonuses like the New Member Bonus.

## Key points for communicating with players

- Clearly explain eligibility criteria based on the specific promotion.
- Confirm that the player has met all required steps for claiming bonuses.
- Warn about restrictions involving multiple accounts, IP, banking, or phone details to avoid future issues.
- Advise players to regularly check their Promotions page and system notifications for updates or changes.