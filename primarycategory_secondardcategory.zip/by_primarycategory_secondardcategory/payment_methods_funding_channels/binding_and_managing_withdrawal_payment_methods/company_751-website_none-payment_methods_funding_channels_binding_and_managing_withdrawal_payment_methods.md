# Payment Methods & Funding Channels - Binding and Managing Withdrawal Payment Methods

## Steps

1. **Identify the player's request or issue**  
   - Determine if the player wants to bind a new payment account, bind specific methods like GCash, or manage existing withdrawal payment methods.

2. **Gather required information from the player**  
   - Confirm which payment method(s) the player wishes to bind or manage.  
   - If binding a new payment account, ask for the account details (e.g., Account Number).  
   - Clarify if the player intends to bind GCash or other e-wallets/bank accounts.

3. **Instruct the player on how to bind a new payment account**  
   - Advise the player to click on the **My Cards** button in their account dashboard.  
   - Instruct them to click the **"+"** or add sign.  
   - Choose **Bank Accounts** or **E-Wallets** depending on their payment method.  
   - Request the player to input their **Account Number** in the provided field.  
   - Have them click **Submit** to complete the binding process.  

4. **Verify the binding process**  
   - Confirm that the player has successfully added the payment account.  
   - Check in the system whether the new payment method appears in their list of bound accounts.

5. **Manage the number of bound payment accounts**  
   - Inform the player that they can bind up to **2 GCash** and **2 PayMaya** accounts for withdrawals, per the current rules.  
   - If the player attempts to bind more than allowed, explain the limit and advise on managing existing accounts if necessary.

6. **Address issues or errors**  
   - If the player reports problems binding the account, verify the validity of the account details provided.  
   - Ensure the account is entered correctly and is supported by the system.  
   - If issues persist, advise the player to reattempt or contact support if an error cannot be resolved.

7. **Confirm the player's understanding and complete the process**  
   - Summarize the steps taken and confirm that the payment method is successfully bound.  
   - Advise the player that they can manage or unbind payment methods via the **My Cards** section at any time.

## Notes

- Use clear instructions aligned with the current site interface regarding button labels and navigation.  
- Always verify the accuracy of account details entered by the player.  
- Ensure adherence to the limit of bound accounts for withdrawal purposes.

## Key points for communicating with players

- Emphasize that binding is done through the **My Cards** section and involves clicking the "+" or add sign.  
- Clarify the supported methods (Bank Accounts or E-Wallets) and the account number input requirement.  
- Remind players of the maximum limit: **2 GCash** and **2 PayMaya** accounts for withdrawals.  
- Reiterate the importance of correct information entry to prevent delays or errors.