# Payment Methods & Funding Channels - Binding and Managing Withdrawal Payment Methods

## Steps

1. **Identify the player's request**
   - Determine if the player wants to bind a new withdrawal payment method, update an existing one, or verify their current setup.
   
2. **Collect necessary information from the player**
   - Confirm which type of payment method they wish to bind (Bank Account or E-Wallet).
   - For binding a bank account or e-wallet:
     - Player's full name (if applicable).
     - Account number for bank account or e-wallet.
     - E-wallet selection (G-Cash, PayMaya).
   - Ensure the player is aware to double-check their details for accuracy to avoid transfer issues.

3. **Guide the player through binding a bank account or e-wallet**
   - Instruct the player to click on the **My Cards** button.
   - Ask them to click the '+' or add sign.
   - Have them select the appropriate option:
     - **Bank Accounts** for bank accounts.
     - **E-Wallets** for e-wallets.
   - Request the player to input their account name and account number.
   - For e-wallets:
     - If they choose G-Cash or PayMaya, instruct them to input their e-wallet number.
     - Remind them to create a transaction password if required.
   - Ask the player to click **Submit** to complete binding.

4. **Verify the details provided**
   - Confirm with the player that they entered correct account details.
   - Emphasize that incorrect details (such as wrong e-wallet account numbers) may result in failed transactions.
   - Inform the player that PHCASH is not responsible for mistakes made by incorrect information entry.

5. **Check existing linked payment methods in the back office**
   - Review the player's account for already bound payment methods.
   - Determine if the player is replacing or adding new methods.
   - Ensure that the new payment method is active and correctly listed.

6. **Address specific scenarios**
   - If the player wants to **bind a new withdrawal account**:
     - Follow the same steps as in step 3.
   - If the player reports issues with existing payment methods:
     - Verify entered details.
     - Advise re-binding if necessary or update the existing method.

7. **Additional guidance for e-wallet bindings**
   - When binding an e-wallet:
     - Guide the player to the Profile page if they are using the website.
     - Have them click the **Withdraw** button.
     - Repeat the process of '+' or add sign, select G-Cash or PayMaya, and input account details.
     - Instruct to create a transaction password if prompted.
     - Click **Submit** to finalize.

8. **Inform the player about payment method options and benefits**
   - Recommend using Maya for deposits and withdrawals, highlighting:
     - 6% rebate on every recharge.
     - No limits on deposit or withdrawal amounts.
     - Higher stability and safety for funds.
   - Mention that other accepted payment methods include Online Banking and USDT.

9. **Confirm the transaction and next steps**
   - After binding, verify with the player that the new payment method has been successfully registered.
   - Advise the player to double-check details before making withdrawal requests.
   - If issues persist, suggest re-binding or escalate according to protocol.

## Notes
- Always emphasize the importance of double-checking account details to avoid transaction failures.
- Remember that PHCASH is not responsible for mistakes when incorrect details are entered.
- When guiding players, ensure they understand the types of accounts they are binding and the benefits of using Maya.

## Key points for communicating with players
- Encourage careful verification of account details before submitting.
- Highlight Maya's benefits for deposits and withdrawals.
- Clarify that changes or bindings take effect immediately upon submission.
- Remind players about the importance of creating a transaction password for e-wallet bindings.