# Payment Methods & Funding Channels - Binding and Managing Withdrawal Payment Methods

## Steps

1. **Identify the player's request**:
   - Determine if the player wants to bind a new withdrawal account, switch an existing linked account, or verify their current withdrawal method.

2. **Collect necessary information from the player**:
   - Obtain the e-wallet number (for GCash or PayMaya).
   - Confirm the choice of wallet type (GCash or PayMaya).
   - Confirm whether they want to bind, switch, or verify an e-wallet.

3. **Check for existing linked e-wallets**:
   - Review the player's account in the system to see if an e-wallet is already linked.
   - Verify that the e-wallet number is not already linked to another PHFUN account (this applies when binding a new wallet).

4. **Binding or switching the e-wallet**:
   - **To bind a new e-wallet**:
     - Guide the player to go to the "Profile" on the homepage.
     - Click "Withdraw" and then the "+" (Add) sign.
     - Select GCash or PayMaya.
     - Ask the player to enter their e-wallet number.
     - Instruct them to create a transaction password.
     - Submit the information to bind the wallet.
   
   - **To switch or re-bind an existing wallet**:
     - Instruct the player to first unbind the current wallet if they wish to switch.
     - Then, repeat the binding steps as above with the new wallet details.

5. **Verification and confirmation**:
   - Ensure the player confirms their e-wallet number in the system.
   - Confirm that the transaction password is created successfully.
   - Verify the binding process is completed without errors.

6. **Final check and confirmation with the player**:
   - Confirm the wallet has been successfully linked or switched.
   - Advise the player that they can now use this wallet for withdrawal transactions.

7. **Escalate if issues arise**:
   - If the e-wallet number is already linked to another account or there are system errors, escalate as per current procedures.
   - Advise the player to check their wallet details and try again or contact support for further assistance.

## Notes

- The e-wallet number must not be linked to another PHFUN account when binding a new wallet.
- To switch wallets, unbind the current one before binding a new one.
- Ensure the player creates and confirms their transaction password during the binding process.

## Key points for communicating with players

- Clearly instruct the player to enter their correct e-wallet number.
- Remind players that they must not link an e-wallet already associated with another account.
- Explain that unbinding is necessary before switching to a different wallet.
- Confirm each step with the player to ensure the process is completed successfully.