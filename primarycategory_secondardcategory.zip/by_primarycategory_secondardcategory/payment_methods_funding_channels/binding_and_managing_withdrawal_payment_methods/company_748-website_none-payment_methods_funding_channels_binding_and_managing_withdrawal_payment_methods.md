# Payment Methods & Funding Channels - Binding and Managing Withdrawal Payment Methods

## Steps

1. **Verify the player's request** to bind, change, or unbind a withdrawal payment method (bank account or e-wallet).

2. **Collect the necessary information**:
   - Confirm the type of payment method: Bank Account or E-Wallet.
   - Obtain the account number or E-wallet account details (e.g., GCash, PayMaya, Maya).
   - If the player wishes to unbind or replace an existing e-wallet, specify which one (Gcash or PayMaya).

3. **Check current binding status**:
   - Access the player's account in the back office.
   - Verify if the player has already linked the maximum allowed accounts:
     - Up to 2 GCash accounts and 2 PayMaya accounts for withdrawal.
     - For bank accounts, ensure the player follows the rules about unbinding before binding new accounts if limits are reached.

4. **For binding a new account (bank or e-wallet)**:
   - Click on the "My Cards" button.
   - Click the '+' or add sign.
   - Select **Bank Accounts** or **E-Wallets**.
   - Input the account number.
   - Click **Submit**.

5. **For unbinding or changing an e-wallet**:
   - Confirm which e-wallet (Gcash or PayMaya) the player wants to unbind.
   - Remove the specified e-wallet:
     - Ensure the player unbinds only one e-wallet at a time.
     - If unbinding a bank account, verify whether the player has another linked bank account or e-wallet.
   - After unbinding, the player can bind a new account following step 4.

6. **Special rules and checks**:
   - If the player wants to bind a new GCash or PayMaya account, verify that the maximum of 2 accounts per e-wallet is not exceeded.
   - To add an additional bank account, unbind an existing one if the limit is reached.
   - The player cannot unbind if only one e-wallet is associated with their account.

7. **Confirm the binding or unbinding**:
   - Ensure the account has been successfully added or removed.
   - Inform the player if any limits or restrictions prevent the action.

8. **Document the action**:
   - Save details of new bindings or unbindings in the system.
   - Note any issues or restrictions encountered during the process.

## Notes

- Maya e-wallet is recommended for deposits and withdrawals, offering a 6% rebate on recharge, with no limit on deposit or withdrawal amounts.
- Only one withdrawal e-wallet (Gcash or PayMaya) can be unbound at a time.
- In case the player is unable to unbind an e-wallet due to restrictions, advise to follow the current system rules and try again after unbinding the other e-wallet, if applicable.

## Key points for communicating with players

- Clearly explain the binding limits: up to 2 GCash and 2 PayMaya accounts.
- Inform players that unbinding of one e-wallet is allowed, but only one at a time.
- Emphasize the need to unbind existing accounts before adding new ones if limits are reached.
- Recommend using Maya for deposits and withdrawals for better benefits and safety.