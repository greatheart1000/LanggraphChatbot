# Payment Methods & Funding Channels - Binding and Managing Withdrawal Payment Methods

## Steps

1. **Verify the player's request to bind or update a withdrawal payment method**  
   - Confirm exactly which method the player wants to bind (e-wallet or bank account).  
   - Clarify whether they need to bind a new method or update an existing one, if applicable.

2. **Gather the necessary information from the player**  
   - For e-wallets (G-Cash or PayMaya):  
     - Collect the E-Wallet account number.  
   - For bank accounts or e-wallets via My Cards:  
     - Collect the account number (or card details if applicable).  

3. **Check if the player already has a bound withdrawal method**  
   - Access the player's profile and payment methods in the back office/system.  
   - Determine if there is an existing withdrawal method already bound.  

4. **Proceed based on the player's intent**  
   
   **a. To bind a new withdrawal e-wallet (G-Cash or PayMaya):**  
   - In the player's profile, click **Profile** from the homepage.  
   - Click **Withdraw**.  
   - Click the **+** (add) sign.  
   - Select **G-Cash** or **PayMaya** as the method.  
   - Enter the collected e-wallet number.  
   - Create a **Transaction Password** (security step).  
   - Click **Submit** to confirm binding.  

   **b. To bind or update a bank account or e-wallet via My Cards:**  
   - Click on the **My Cards** button.  
   - Click the **+** (add) sign.  
   - Choose **Bank Accounts** or **E-Wallets**.  
   - Input the account number.  
   - Click **Submit** to save the details.  

5. **Verify successful binding/update**  
   - Confirm with the player that the method has been successfully added.  
   - Check the player's profile/system to ensure the new payment method appears correctly.  

6. **Inform the player about the binding status and any additional instructions**  
   - Confirm that they can now use the bound method for withdrawals.  
   - Remind them that they may use any active GCash or Maya account for deposits or withdrawals, even if not under their name, as long as the account is active and functioning properly.  

## Notes
- The binding process is identical whether it is for a new method or updating an existing one, focusing on entering correct details and creating a transaction password for security.  
- If the player reports issues or errors, verify the details entered and ensure the account is active and properly functioning.  
- No specific numeric limits or special conditions are noted in the FAQs, so follow the current site configuration and official guidelines.  

## Key points for communicating with players
- Clearly explain that they can use any active GCash or Maya account for deposits/withdrawals, even if not in their name.  
- Ensure they understand the importance of entering correct account numbers and creating a transaction password.  
- Confirm the binding has been successful before concluding the support interaction.