# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player’s inquiry regarding bonuses, cashback, or VIP benefits**.
   - Determine if the player is asking about bonus eligibility, claiming issues, or specific benefits like VIP Weekly Salary or Birthday VIP Bonus.

2. **Gather relevant account information from the player**.
   - Confirm the player's account details, including VIP level, recent deposit history, and any prior bonus activity.
   - Ask if the player has met basic eligibility requirements, such as:
     - Bound real name, bank card, and mobile number (for bonus eligibility).
     - Made a first deposit (for the New Member First Deposit Bonus).
     - Achieved VIP level 3 (for Birthday VIP Bonus).

3. **Check the specific bonus or benefit in the system based on the player’s query**.
   - **For VIP Weekly Salary or Wages Bonus**:
     - Verify if the player has completed at least one valid bet on slots or fish within the current week.
     - Confirm if it is Friday between 22:00 and 23:59 (GMT+8) when the salary is credited.
     - Check the Rewards Center for credited amount.
   - **For Weekly Bonuses and Promotions**:
     - Check if it is Tuesday between 10:00 PM and 11:59 PM for the bonus distribution.
     - Confirm if the player has met deposit and turnover requirements.
   - **For Other Bonuses / Cashback / Rebates**:
     - Review the Bonus/Rebate status in the Rewards Center.
     - Validate if the player is eligible, ensuring no restrictions via system checks (e.g., same IP, bank card, or phone number used for multiple accounts).
   - **For Birthday VIP Bonus**:
     - Confirm if the player is VIP level 3 or higher and if the date is their birthday.
     - Verify if the player has provided necessary proof, such as a screenshot if requested.

4. **Perform eligibility checks based on the conditions specified** in the FAQs.
   - Confirm if the player:
     - Has met the requirements for buffer deposits (e.g., minimum deposit of 100 PHP for first deposit bonus).
     - Has fulfilled turnover requirements (e.g., 20x wager for the first deposit bonus).
     - Has completed the required activity (e.g., winning at least one valid bet for VIP Weekly Salary).
     - Is not restricted by anti-abuse rules (e.g., repeated bonuses from the same IP, bank card, or phone number).

5. **Determine the appropriate resolution based on eligibility**.
   - If the player is eligible:
     - Explain that the bonus/reward is automatically credited system-side.
     - Confirm the specific timing:
       - VIP Weekly Salary: credited automatically every Friday between 22:00 and 23:59 (GMT+8).
       - Weekly bonuses: credited every Tuesday between 10:00 PM and 11:59 PM.
       - Birthday VIP Bonus: awarded on the player's birthdate if VIP level 3 or above.
   - If the bonus/reward has not appeared after the expected time:
     - Advise the player to check the Rewards Center.
     - Confirm that the player has met all requirements.
     - If still not received, escalate or ask the player to contact support with relevant details.

6. **Address possible reasons for non-receipt** if the player is ineligible or if the bonus is missing:
   - Explain that bonuses, cashback, and rebates are distributed automatically; failure to receive may be due to ineligibility or violation of rules.
   - Remind about restrictions like same IP, bank card, or phone number that could block bonus distribution.
   - For the first deposit bonus or birthday VIP bonus, verify if the player has followed all claiming procedures (e.g., logging into the Reward Center within the specified time window).

7. **Provide instructions for next steps if necessary**.
   - If eligible but bonus not received:
     - Ask the player to wait for the system process.
     - Suggest checking all conditions again.
     - If still pending after the specified timeframe, advise contacting customer support with relevant evidence.

8. **Document the interaction and findings**.
   - Record the player's eligibility status, actions taken, and any discrepancies or special notes for future reference.

## Notes

- Bonuses, cashback, and rebates are automatically distributed; manual claim is generally not needed unless specified.
- Eligibility checks include ensuring real name, bank card, and mobile number are bound.
- Anti-abuse measures may prevent bonus issuance, such as multiple accounts from the same IP, bank card, or mobile number.
- For the first deposit bonus, ensure the player logs into the Reward Center within 12 hours of deposit and meets the 20x turnover requirement before withdrawal.
- For VIP weekly benefits, the reward is credited automatically each Friday if the player has completed at least one valid bet that week.

## Key points for communicating with players

- Clearly inform players that bonuses are system-credited following eligibility criteria.
- Emphasize that delays can occur if conditions are not met or if restrictions are detected.
- Encourage players to confirm their activity and details, and advise them to contact support if issues persist after verification.