# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather Player Information**
   - Confirm the player's account details and verify that the account is correctly linked.
   - Ask the player about the specific bonus, cashback, or VIP benefit they are inquiring about.
   - For bonuses linked to deposits or promotional campaigns, inquire about recent transactions, deposits, or wagering activities.
   - For VIP benefits, ask about the player's VIP level and recent betting activity.

2. **Verify Bonus or Reward Eligibility**
   - Check if the player has fulfilled the deposit requirements needed to receive bonuses.
   - Ensure the player has met the activity criteria, such as wagering amounts or playing during the promotional period, as specified for the bonus.
   - Confirm if the player’s VIP level qualifies them for specific bonuses or rewards based on their recent betting activity.
   - Verify that the player’s account meets any registration or account age requirements if specified.

3. **Check System and Transaction Data**
   - Access the back-office system to confirm eligible transactions, deposits, and wagering activities.
   - Verify that the bonus or reward should be credited automatically according to system records.
   - Ensure that the bonus is not already credited or has not been claimed previously, if applicable.
   - For VIP rewards, confirm their upgrade level and whether the benefit is due for automatic awarding or needs manual intervention.

4. **Determine the Appropriate Action**
   - If the player has met the criteria and the bonus/reward has not yet been credited:
     - Confirm that all requirements (deposit amount, wagering, VIP level) are fulfilled.
     - Check if any deadlines or claim windows are still open.
     - Proceed to manually credit the bonus if system does not do so automatically.
   - If criteria are not met:
     - Explain the specific requirements (e.g., minimum deposit amount, wagering multiples) based on the platform rules.
     - Advise the player to fulfill missing conditions and inform about any applicable deadlines.
   - If the bonus has already been claimed or credited:
     - Inform the player accordingly.
     - Verify for any restrictions on multiple claims or repeats.

5. **Perform Final Actions**
   - Credit the bonus or reward manually if necessary and confirm with the player.
   - Note any important details, such as bonus expiry dates or wagering requirements.
   - Clearly communicate the rules for bonus usage and any applicable restrictions.

6. **Follow-Up and Closure**
   - Ensure the player understands how to use the bonus or benefits.
   - Document the case correctly, including all verification steps and actions taken.
   - Close the case once everything is resolved and the information is conveyed.

## Notes
- Bonuses are credited automatically once the specified conditions are met. Manual intervention is only required if the system does not do so.
- VIP benefits are granted based on the player’s activity and VIP level, which are upgraded according to betting activity, and rewards are credited automatically or after collection periods.
- Always verify the eligibility criteria and deadlines before crediting or explaining the issuance of bonuses or benefits to players.

## Key points for communicating with players
- Clearly explain the specific requirements such as deposit amounts or wagering multiples.
- Remind players to meet deadlines for claiming or fulfilling conditions.
- Advise players to ensure their account is correctly linked and active.
- Inform players about automatic vs. manual bonuses or rewards.