# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's query or request related to bonuses, cashback, or VIP benefits** and verify whether they are inquiring about eligibility, claiming procedures, or specific promotions.

2. **Gather requisite information from the player**, including:
   - Player's current VIP level or tier
   - Recent deposit amounts (minimum deposit for the promotion or bonus, e.g., 5,000 MMK)
   - Verification status of the account (e.g., whether proof of deposit or identity verification is completed)
   - Whether the player has joined necessary channels or submitted deposit proof if required
   - Specific promotional or bonus codes used or intended to redeem

3. **Check the player's eligibility for the requested bonus or promotion**:
   - Confirm the player has met minimum deposit requirements (e.g., at least 2000 MMK or 5,000 MMK if applicable)
   - Verify VIP level meets the promotion's criteria
   - Ensure the account is verified and any submitted proofs are approved
   - If promotion involves promotional codes, verify the code has been correctly applied and is valid
   - Confirm the player fulfills any activity or gameplay conditions, such as reaching required levels or engaging during specified times

4. **In the system/back office, perform the following checks**:
   - Review the player's deposit history to ensure the minimum deposit criteria are satisfied
   - Confirm their VIP level or tier aligns with promotion eligibility
   - Check if the bonus, cashback, or rewards are within designated timeframes (e.g., weekly bonuses credited between specific hours)
   - Look for any specific requirements such as joining channels or submitting deposit proof if relevant

5. **Determine the appropriate resolution based on eligibility**:
   - If the player fulfills all criteria:
     - Inform the player they are eligible for the bonus, cashback, or VIP reward
     - Provide instructions on how to claim the bonus, such as confirming the deposit, redeeming a promo code, or waiting for automatic crediting
     - If it is a manual process, proceed to credit the bonus/cashback according to the promotion schedule
   - If the player does not meet the requirements:
     - Clearly explain the specific reason (e.g., deposit amount insufficient, VIP level below threshold, account not verified)
     - Advise on the steps they need to take to become eligible (e.g., deposit more, verify account, join channels)
     - Inform if they need to wait until a future promotional cycle or by completing further activity

6. **For bonus or promotion claiming procedures**:
   - Confirm if the bonus is credited automatically during the designated times or needs manual intervention
   - Verify if any promotional codes are needed and, if so, check whether they have been correctly applied
   - For free spins or similar rewards, confirm deposit requirements (e.g., deposit 20,000 PHP for 100 free spins) are met

7. **Document and communicate**:
   - Record the interaction, including eligibility status and any actions taken
   - Provide clear, concise instructions or explanations to the player
   - If applicable, inform the player about next steps for claiming or waiting for bonus credit

8. **Close the case** once all relevant information and actions are completed:
   - Confirm the player understands the process
   - Advise them to contact support again if they face issues in claiming or using the bonus or benefits

## Notes

- Bonuses and weekly rewards are credited during specific hours; advise players accordingly.
- Promotions may require joining specific channels or submitting deposit proof for eligibility.
- VIP bonuses and rewards vary based on VIP level or tier, with specific benefits during designated times or on particular games.
- Always verify that the account is verified before processing bonus claims.
- Check that the promotional period or scheduled bonus credit times are adhered to.

## Key points for communicating with players

- Clearly explain the minimum deposit amounts and verification requirements.
- Inform players if they need to have completed specific actions like submitting deposit proof or joining channels.
- Ensure players understand the timing of bonus crediting (automatic vs manual).
- Guide players on how to redeem promo codes if applicable.
- Be transparent about reasons for ineligibility and advise on steps for future eligibility.