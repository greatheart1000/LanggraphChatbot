# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather initial information from the player about their bonus or promotion inquiry.**  
   - Confirm if the player is asking about a specific bonus, cashback, or VIP benefit.  
   - Ask for relevant details such as deposit amount, timing, and whether they have completed registration or specific actions.

2. **Verify the player's account details and registration status.**  
   - Ensure the account is correctly registered and completed according to site requirements, including real name registration if applicable.  
   - Check for multiple account violations (e.g., multiple accounts, multiple IPs, or sharing the same bank card or phone number).

3. **Assess the player's eligibility based on the current promotion rules.**  
   - Confirm that the player has not used restricted behavior such as linking the same bank card, phone number, or IP address with multiple accounts.  
   - Ensure the deposit meets the minimum required amount for the specific bonus or promotion.

4. **Check system distribution status for the bonus or cashback.**  
   - Verify if the bonus or cashback was automatically credited by the system.  
   - Typically, bonuses are credited within 2 hours after the qualifying deposit or registration.

5. **If the bonus or cashback has not been received:**
   - Confirm the player's deposit details and whether they meet all eligibility criteria, including link completion and adherence to promotion conditions.  
   - Advise the player to check the Rewards Center or relevant promotion page for status or further instructions.

6. **If the player is eligible but bonus has not been credited within 2 hours:**
   - Inform the player that bonuses are system-credited within this timeframe, but if not received, they should verify their eligibility.  
   - Recommend checking for common issues: account linking, multiple accounts, or IP sharing.

7. **If eligibility issues are identified (e.g., multiple accounts, same bank card, or IP):**
   - Explain that these restrictions prevent bonus distribution.  
   - Advise the player to ensure compliance with the promotion rules for future eligibility.

8. **If the player has met all conditions but still did not receive the bonus or cashback:**
   - Escalate the case to technical support or relevant department with details of the player's actions and checks conducted.  
   - Ensure the player understands that bonuses only apply to certain games (like Slot & Fish Games, if relevant).

9. **For claiming bonuses via the Rewards Center or promotional pages:**
   - Instruct the player to claim the bonus manually if required (not typical, as distribution is automatic, but some bonuses may require manual claim).  
   - Confirm if the system shows the bonus as available to claim or already credited.

## Notes

- Bonuses, including welcome and deposit bonuses, are generally credited within 2 hours after deposit, provided all eligibility criteria are met.  
- Bonuses are automatically distributed once players fulfill deposit and activity requirements, and restrictions such as multiple accounts, shared bank card, phone number, or IP address may disqualify eligibility.  
- Always verify registration details, linking, and the equity of information before concluding the case.

## Key points for communicating with players

- Clearly explain that bonuses are system-credited within 2 hours after qualifying actions.  
- Remind players to ensure they have not used restricted behaviors (multiple accounts, same bank/phone/IP).  
- Encourage players to check the Rewards Center or promotional page for status before contacting support.  
- Escalate cases where eligibility seems met but bonuses are not received within the expected timeframe.