# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Collect and verify player information regarding bonus eligibility:**
   - Confirm player identity and account status.
   - Ask if the player has made the required deposit(s) for the promotion.
   - Verify if the player has used eligible channels or methods as specified (e.g., correct bank/card).
   - Check if the player’s account complies with restrictions (e.g., same bank, IP, phone number).
   - For VIP Weekly Salary, confirm the player’s VIP tier and activity (at least 1 valid bet on slot or fish within the week).

2. **Assess automatic bonus distribution:**
   - Determine if the promotion or bonus (e.g., first deposit bonus, third deposit bonus, VIP Weekly Salary) is eligible based on the player's activity and deposits.
   - For first deposit bonus: ensure the player made a minimum deposit of 100 PHP.
   - For third deposit bonus: verify deposit of at least 50 PHP and check turnover requirement of 15x before withdrawal.
   - For VIP Weekly Salary: check if the player deposited at least 100 PHP within the week and completed a valid bet.

3. **Check system crediting and distribution:**
   - Confirm that the bonus amount is credited within 12 hours after the qualifying deposit or activity.
   - For bonuses such as the first deposit and third deposit, verify the bonus has been credited in the Rewards Center.
   - For VIP Weekly Salary, verify automatic credit to the Rewards Center on Wednesday between 22:00 and 23:59 GMT+8.
   
4. **Advise the player on claiming and verification:**
   - Inform the player that all bonuses, cashback, and rebates are credited automatically once eligibility criteria are met.
   - Instruct the player to check the Rewards Center or promotion page for credited bonuses.
   - Clarify that bonuses are automatically distributed without manual intervention unless the system fails to credit them within 12 hours.

5. **Identify and troubleshoot common issues:**
   - If the bonus is not credited within 12 hours, verify if the player fulfilled all eligibility requirements.
   - Check for potential violations such as fraudulent activity, repeated use of the same IP, bank, or phone number, which may result in confiscation.
   - Confirm the player claimed within the designated claiming period; bonuses not claimed within this period may be forfeited.
   - For VIP Weekly Salary, if not received, confirm whether the player completed the minimum deposit and activity requirements.

6. **Respond to specific player inquiries:**
   - For questions about promotion rules or eligibility, explain that bonuses are distributed automatically upon meeting the criteria.
   - If a player claims they did not receive their bonus, verify their deposit activity, eligibility, and check the Rewards Center for automatic credit.
   - For any discrepancies or delays, advise the player to ensure no violations occur and suggest checking again after 12 hours or contacting support if needed.

7. **Escalate unresolved issues:**
   - If eligibility is confirmed but the bonus remains uncredited after 12 hours, escalate to the technical team.
   - If the player disputes eligibility or alleges fraudulent activity, document the case and forward it per internal procedures.

## Notes
- Bonuses such as the first deposit bonus and VIP Weekly Salary are automatically credited once the player meets the requirements.
- Bonuses have designated claiming periods; failure to claim within these periods may lead to forfeiture.
- Bonuses may be confiscated if fraudulent activity like using the same IP, bank, or phone number repeatedly is detected.
- Always verify the player's deposit and activity history before providing explanations or resolutions.

## Key points for communicating with players
- Confirm deposit amounts and channels align with promotion criteria.
- Explain bonuses are credited automatically within 12 hours, and the player should check the Rewards Center.
- Remind players of the importance of fulfilling turnover requirements before withdrawal.
- Emphasize the automatic nature of crediting for VIP Weekly Salary and other promotions.
- Advise patience and recheck if bonuses are missing or delayed, and escalate if issues persist.