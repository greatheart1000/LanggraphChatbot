# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information regarding the specific bonus or promotion:**
   - Confirm which bonus or benefit the player is referring to (e.g., Tuesday Surprise Gift, VIP Weekly Salary, Bet on Slot Bonus, Free Angpao, birthday bonus, etc.).
   - Collect necessary identification or verification details if required (e.g., VIP level, deposit history, VIP tier).

2. **Check eligibility criteria based on the promotion or bonus type:**
   - Verify if the player qualifies for the bonus by confirming:
     - For Tuesday Surprise Gift: Player logged in between 22:00–23:59 (GMT+8) on Tuesday.
     - For VIP Weekly Salary: Player completed at least 1 valid bet on slot or fish games within the week and has VIP Tier.
     - For Bet on Slot Bonus: Player bet more than 1500 PHP whether they win or lose.
     - For Free Angpao Daily: Player is either a new download app user or a VIP member logged in between 21:00–21:30 (GMT+8); deposit criteria for withdrawal eligibility if applicable.
     - For birthday bonuses: Player is VIP3 and has completed required verification (e.g., submitting IDs, selfies).
     - For other promotions: Follow specific eligibility rules as per their description.

3. **Verify necessary activity or conditions logged in the system:**
   - Confirm deposit amounts (e.g., minimum 100 PHP for first deposit bonus).
   - Check if player completed the required betting activity (e.g., 1 valid bet per week for VIP Weekly Salary).
   - For deposit-based rewards, confirm deposit frequency or turnover requirements (e.g., 10x turnover for members who deposited less than 5 times).
   - Ensure login timing aligns with promotional periods (e.g., login within the specified timeframes).

4. **Perform system checks for automatic distribution:**
   - Check if the system has credited the bonus or reward:
     - Bonuses like Welcome Bonus, VIP Weekly Salary, Birthday Bonus, Monthly Rewards, and special event rewards are automatically credited within the designated timeframe (often up to 12 hours).
     - Confirm whether the bonus has been received in the player’s account or Rewards Center.

5. **If the bonus has not been received when expected:**
   - Instruct the player to verify their deposit history, activity logs, or confirm they met the eligibility criteria.
   - If eligibility is confirmed but the bonus is missing, escalate or advise the player to contact customer support for manual addition.
   - For bonuses requiring confirmation via screenshots or videos (e.g., deposit history from GCash inbox), instruct the player to submit these as proof if requested.

6. **For bonuses that are automatically credited:**
   - Confirm with the player that the bonus or reward is visible in their account.
   - Explain that certain bonuses, like the first deposit, are credited within 12 hours after qualifying deposit.

7. **Address any discrepancies or issues:**
   - If the player claims they did not receive an eligible bonus or reward:
     - Verify system logs and deposit records.
     - Check for common issues such as identical IP addresses or multiple accounts.
     - Ensure the player adhered to the specific incentive conditions (e.g., deposit amount, login time).
     - If rules are met but bonus is still missing, escalate for manual credit.

8. **Advise on withdrawal or usage of bonuses:**
   - Inform the player that most bonuses, once credited, are withdrawable without additional turnover requirements (subject to specific bonus rules).
   - Clarify any specific bonus conditions if applicable (e.g., need to fulfill wagering requirements).

9. **Record and close the case:**
   - Confirm that the bonus or reward has been successfully received or appropriate action has been initiated.
   - Provide the player with any further instructions or clarifications needed.
   - Document the case resolution following internal procedures.

## Notes
- Bonuses such as Tuesday Surprise Gift, VIP Weekly Salary, and birthday bonuses are automatic and system-distributed within designated timeframes.
- VIP tiers influence the amount and frequency of rewards like the VIP Weekly Salary and birthday bonuses.
- For bonuses requiring verification documents (e.g., IDs, selfies), ensure proper submission and approval before proceeding.
- If a player did not meet the eligibility criteria, explain eligibility rules clearly, referencing the relevant FAQ points.
- Avoid offering manual intervention unless the player qualifies and the system confirms non-distribution.

## Key points for communicating with players
- Remind players of specific login times and activity requirements tied to bonuses.
- Emphasize that most rewards are automatically credited within a 12-hour window once qualified.
- Clarify that verification steps (screenshots, deposit proof) are necessary only when explicitly required.
- Encourage players to contact support if they believe they are eligible but have not received their bonuses after the designated time.