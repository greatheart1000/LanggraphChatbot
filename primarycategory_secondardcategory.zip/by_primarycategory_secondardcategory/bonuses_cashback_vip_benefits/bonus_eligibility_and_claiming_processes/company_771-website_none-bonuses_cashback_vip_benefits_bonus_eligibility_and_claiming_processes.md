# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify the player's inquiry and identify the type of benefit involved.**  
   - Ask the player whether they are inquiring about bonuses, cashback, rebates, or VIP benefits.  
   - Clarify the specific benefit they are trying to claim or review.

2. **Check the player's account for automatic bonus delivery or credit status.**  
   - Review the account to see if bonuses, cashback, or rebates have been credited as per system records.  
   - Confirm whether the benefits have appeared in the Rewards Center or the player’s account balance.

3. **If benefits are not visible but should have been delivered:**  
   - Inform the player that bonuses, cashback, and rebates are automatically credited once they are eligible.  
   - Explain that delays can occur due to high user volume; advise them to wait until 23:59 GMT+8.  
   - Recommend the player check again later before escalating.

4. **Advise the player to wait if benefits are not received immediately:**  
   - Instruct the player to wait and recheck their account or Rewards Center later.  
   - If benefits are still missing after the specified delay, escalate the case to support for manual processing.

5. **Determine the player's eligibility for VIP upgrade or rewards:**  
   - Confirm if the player has met the required betting turnover to upgrade to VIP.  
   - Advise the player that VIP upgrade is contingent on completing the required total valid bets.

6. **Assist with VIP upgrade requests:**  
   - If eligible, instruct the player to contact support to claim the VIP upgrade bonus.  
   - Confirm that the player has fulfilled the turnover requirement before proceeding.

7. **Verify weekly VIP rewards distribution:**  
   - Check if the player qualifies for the VIP Weekly Salary by confirming that they deposited a minimum of 100 PHP within the week and have met VIP tier requirements.  
   - Inform the player that the VIP Weekly Salary is automatically sent to the Rewards Center every Sunday between 22:00 and 23:59 (GMT+8).  
   - Advise the player to check the Rewards Center; if not received, explain potential reasons such as unmet requirements or distribution delays.

8. **Clarify bonus eligibility and claim conditions:**  
   - Explain that bonuses, including weekly, monthly, birthday, and event rewards, are credited automatically upon meeting eligibility criteria such as minimum deposit amounts and placing valid bets within specified timeframes.  
   - Remind the player to download and use the official app to access all promotions if required.  
   - Highlight that some bonuses may require meeting specific turnover or deposit thresholds.

9. **If the player reports a missing bonus or cashback and eligibility appears satisfied:**  
   - Confirm that the player has met all eligibility criteria at the time of benefit issuance.  
   - Check the transaction history and system logs for credited benefits.  
   - If benefits are absent despite eligibility, escalate for manual processing with system review.

10. **Document all findings and communicate accordingly:**  
    - Provide the player with transparent explanations based on system checks.  
    - If delays or issues are due to high volume or system processing times, inform the player accordingly.  
    - Advise on waiting times and support escalation if benefits remain uncredited.

## Notes

- Bonuses, cashback, and rebates are sent automatically once the system determines the player is eligible.  
- Delays in delivery might occur due to high user volume; encourage players to wait until 23:59 GMT+8 before contacting support.  
- VIP Rewards (Weekly Salary) are distributed automatically every Sunday, provided the weekly deposit minimum (100 PHP) and VIP tier requirements are met.  
- Rewards are credited to the Rewards Center; players should check there first.  
- All bonus and reward claims are conditional on meeting the specific rules outlined in the current promotion and system configuration.

## Key points for communicating with players

- Always inform players of the automatic nature of bonus and reward distribution.  
- Explain delays as system processing times and system load; advise waiting until the 23:59 GMT+8 cutoff.  
- Confirm eligibility criteria (deposit amounts, betting turnover, VIP tier requirements) before escalating claims.  
- Encourage players to check the Rewards Center for pending benefits.  
- Escalate to support if benefits are missing despite meeting all conditions or if delays persist beyond the expected processing time.