# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue related to bonuses, cashback, or VIP benefits.**  
   - Determine if the question pertains to eligibility, claiming, distribution, or ongoing promotion status.

2. **Gather necessary player information:**
   - Confirm the player's registered details, including bank card, mobile number, and IP address.
   - Ask if they have already received the bonus or promotion in question.

3. **Check the player's eligibility for the bonus or promotion:**  
   - Verify if the player has met the specific criteria, such as:
     - Making the minimum deposit (e.g., PHP 100 for the first deposit bonus).  
     - Using a unique bank card, mobile number, and IP address (not used previously for bonus activation).  
   - Confirm whether the player’s account is linked correctly and avoid repeated use of same payment details or IP address involved in previous bonus claims.

4. **Determine if the bonus should be automatically credited:**  
   - Bonuses, including first deposit and promotional rewards, are distributed automatically once eligibility is confirmed.  
   - Bonuses are credited within 12 hours after meeting the criteria and deposit.

5. **Assess if the bonus has been credited to the player’s account:**  
   - If within the expected time frame (e.g., 12 hours), check the account for credited bonuses.  
   - If not received, advise the player to verify if they meet the eligibility requirements or if system restrictions apply.

6. **If the bonus has not been credited, verify potential reasons:**  
   - Check for violations of rules, such as using the same bank card, phone number, or IP address involved in previous bonus activations.  
   - Confirm that the player’s deposit and account details align with the promotion criteria.

7. **For players asking about eligibility confirmation:**  
   - Suggest attempting a withdrawal, which will display any required turnover/outcome conditions if ineligible.  
   - Encourage players to check the Rewards Center for their current bonuses and benefits status.

8. **Inform the player of the following regarding claiming and distribution:**
   - Bonuses are automatically credited by the system after meeting all criteria.  
   - The maximum time for crediting is 12 hours.  
   - Repeating bonus claims with the same payment details or IP address may result in disqualification or confiscation of rewards.

9. **Advise on compliance and proper bonus use:**
   - Ensure they follow all promotion rules, including turnover requirements (e.g., 15x for certain bonuses).  
   - Warn players that any violation, like using the same payment method or IP, can lead to ineligibility or confiscation of bonuses.

10. **If the player’s issue involves unclear eligibility or a suspected technical error:**  
    - Escalate to the technical or promotions team if appropriate.  
    - Instruct the player to check back after some time or to submit necessary verification if requested.

## Notes
- Bonuses such as the first deposit of PHP 100 or 108 PHP are automatically credited after meeting eligibility criteria.  
- Repetition of the same IP, bank card, or mobile number involved in previous bonus claims can cause disqualification.  
- Bonuses include rewards like weekly salary or reward points, also credited automatically within the designated timeframe.

## Key points for communicating with players
- Always verify whether the player has met all the stated requirements before explaining further.  
- Inform players that bonuses are automatically distributed within 12 hours after successful eligibility confirmation.  
- Clarify that repeated use of the same payment or IP address can disqualify bonuses.  
- Encourage players to check the Rewards Center for current bonuses and to attempt a withdrawal to verify their bonus status if uncertain.