# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player’s inquiry or request related to bonuses, cashback, or VIP benefits.**  
   - Clarify whether the issue pertains to a specific bonus type, cashback, VIP Weekly Salary, VIP Birthday Bonus, or other VIP benefits.

2. **Verify the player's account details and VIP status.**  
   - Confirm if the player is a VIP member, specifically VIP4 or higher for birthday-related perks.  
   - Check the player's VIP tier in the system.

3. **Gather relevant information from the player.**  
   - Ask for details about recent deposits, bets, and the specific promotion or bonus they are referencing.  
   - Request screenshots if necessary, especially when verifying VIP level (e.g., selfie holding valid IDs and VIP card proof).

4. **Check the player's eligibility for the bonus or benefit in the system.**  
   - For deposit-related bonuses (e.g., Maya deposit bonus rebate): ensure the deposit was made via Maya, and verify that no disqualifying conditions apply (e.g., same bank card, mobile number, phone number, or IP used for different accounts).  
   - For VIP Weekly Salary: verify if the player completed at least one valid bet on slot or fish within the week. Confirm deposit amount of at least 100 PHP within the eligible week.  
   - For birthday bonuses: confirm whether the player has reached VIP4 or higher.

5. **Determine if the bonus, cashback, or benefit has been automatically credited. &nbsp;**  
   - For bonuses and rebates: check the player’s balance or transaction history for the specific bonus/rebate.  
   - For VIP Weekly Salary: check the Rewards Center for accumulated rewards received on Friday between 22:00 and 23:59 GMT+8.  
   - For promotional offers such as VIPPH bonuses or Tuesday bonuses: verify based on participation records and promotion terms.

6. **If the bonus or reward has not been received and the player is eligible:**  
   - Explain that bonuses, rebates, and rewards are automatically credited when criteria are met, but delays can occur, especially during high volume times.  
   - Advise the player to wait up to 12 hours if systematic delays are known or check the Rewards Center again later.

7. **If the player claims a bonus or reward that is time-limited (e.g., VIP Weekly Salary bonus):**  
   - Instruct the player to claim it within the designated claiming window.  
   - If they missed the window, inform them they cannot claim for that period over and to try again during the next scheduled window.

8. **For VIP Birthday Bonuses or Gifts:**  
   - Confirm VIP level (must be VIP4 or higher).  
   - Advise the player to contact customer service to receive the bonus after reaching VIP4.  
   - Collect necessary verification (e.g., ID, selfie holding IDs) if not already provided.

9. **In cases where eligibility criteria are not met:**  
   - Clearly explain the specific disqualifying conditions (e.g., not eligible for the promotion, no qualifying deposit, age requirement not met, or VIP level insufficient).  
   - Recommend they fulfill the necessary requirements before reapplying or attempting again.

10. **If discrepancies or issues are identified (e.g., bonus not credited despite meeting criteria):**  
    - Escalate the case to the technical support or relevant department for system verification.  
    - Request further documentation if needed, such as deposit receipts or ID verification.

11. **Advise the player on the next steps:**  
    - If eligible and bonuses are available, instruct how to claim bonuses or benefits via the Bonus Center or system prompts.  
    - If bonuses are system-generated, reassure that they will be automatically credited once criteria are met.

12. **Close the case with a summary of actions taken and next steps.**  
    - Confirm whether the bonus/rebate has been successfully credited or if further investigation is required.  
    - Remind the player of any operational restrictions, such as windows for claiming or VIP level requirements.

## Notes

- Bonuses and rebates are automatically system-credited when players are eligible; manual application is not typically necessary.  
- Delays can happen due to system load; advise patience within the standard 12-hour timeframe.  
- For VIP Weekly Salary, ensure the player completed at least one valid bet on slot or fish and deposited at least 100 PHP within the week.  
- For bonuses requiring verification (VIP4 birthday, additional IDs): ensure all documentation is correctly provided to avoid delays.

## Key points for communicating with players

- Always verify VIP level and recent activity upfront.  
- Explain that bonuses are system-credited and delays are possible; patience can be required.  
- Clarify eligibility requirements specific to each bonus or reward type, referencing the promotion’s terms if needed.  
- Remind players to claim timed bonuses within the designated windows.  
- Collect proof or escalate if discrepancies arise.