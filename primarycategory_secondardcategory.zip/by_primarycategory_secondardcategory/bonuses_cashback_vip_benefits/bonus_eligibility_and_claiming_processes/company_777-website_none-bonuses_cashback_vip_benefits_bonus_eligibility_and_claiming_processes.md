# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue**:  
   - Determine if the player is asking about receiving a bonus, cashback, or VIP benefit, or reporting a missing bonus or reward.

2. **Gather pertinent information from the player**:  
   - Ask for their registered account details, including username or registered email.  
   - Confirm the registration date, deposit history, and deposit amounts.  
   - Verify whether the player has downloaded and used the official app, and if they have an active Rewards Center account.  
   - Inquire about the payment method used (bank card linked).  
   - Check if the player has multiple accounts or has used shared IPs or devices.

3. **Check for common issue causes affecting bonus eligibility**:  
   - Confirm if the player has multiple account registrations, binding the same bank card, or using the same phone number/IP address.  
   - Verify if the player has made the minimum deposit required for specific bonuses (e.g., 50 PHP for first deposit bonus).  
   - Ensure the player has met any other stated activity or turnover requirements (e.g., 8x or 15x for certain bonuses).  
   - Confirm that the player has claimed their bonus in the Rewards Center within the designated timeframe if applicable (e.g., within 4 hours for the first deposit bonus).

4. **Check the system for bonus or cashback crediting**:  
   - For *new user bonuses*:  
     - Verify registration and app download status.  
     - Confirm if the bonus has been credited within the typical processing time (around 12 hours).  
   - For *deposit bonuses*:  
     - Ensure the deposit amount meets the minimum (e.g., 50 PHP).  
     - Check if the player has clicked “Claim” in the Rewards Center for the bonus (if applicable).  
     - Confirm turnover requirements are being or have been met before withdrawal.  
   - For *cashback*:  
     - Verify eligible bets have been placed; cashback applicable up to 3.80%.  
     - Confirm whether cashback has been claimed manually or check if it has been automatically sent to the Rewards Center at 10:00 AM daily.  
   - For *VIP Weekly Salary*:  
     - Check if the deposit requirement of at least 100 PHP within the week has been met.  
     - Confirm the bonus distribution date (Thursday between 22:00 and 23:59 GMT+8).

5. **Identify potential eligibility issues**:  
   - If bonuses are not received and none of the above conditions are violated, consider the possibility of system restrictions due to shared accounts or suspicious activity.  
   - Notify the player that if they are ineligible due to system detection, bonuses will not be credited; otherwise, bonuses are credited automatically once all criteria are met.

6. **Explain to the player the next steps or resolutions**:  
   - If eligible and bonus not received, advise the player to wait as the bonus will be credited automatically or check their Rewards Center.  
   - If the bonus should have been credited but is missing, instruct the player to verify the above conditions and inform them of potential reasons (e.g., incomplete activity, multiple accounts).  
   - If the player claims they met all requirements but still did not receive the bonus, escalate the case according to internal procedures.

7. **If necessary, instruct the player on additional actions**:  
   - Guide them to claim bonuses manually from the Rewards Center if applicable.  
   - Suggest they ensure they meet all activity criteria and claim within the required time window.

8. **Record the case details and conclude**:  
   - Document all relevant information, checks performed, and the player’s responses.  
   - Advise the player on any further steps or support options if unresolved.

## Notes
- Bonuses are only valid for designated game types such as SLOT and FISHING GAMES unless specified otherwise.
- Bonuses are credited automatically after meeting specific deposit or activity requirements.
- Bonuses not received within the designated timeframe may indicate ineligibility due to account sharing, multiple registrations, or violation of rules.
- For any discrepancies involving the distribution of VIP Weekly Salary or other rewards, check the deposit requirements of at least 100 PHP within the week.

## Key points for communicating with players
- Always clarify the specific bonus or benefit they are referring to.
- Gently explain possible reasons for ineligibility, referencing their account activity or compliance with the rules.
- Encourage players to check their Rewards Center for any pending bonuses or claims.
- Escalate cases that involve suspected system errors or unfulfilled eligibility despite meeting conditions.