# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information and initial details**
   - Verify the player's identity and account status.
   - Ask the player if their concern relates to a specific promotion or bonus.
   - Confirm the type of bonus or promotion they are referring to (e.g., first deposit bonus, weekly bonus, VIP benefit).

2. **Check player's eligibility criteria**
   - Confirm the player has met all specific eligibility requirements, such as:
     - Making the minimum deposit amount (e.g., for first deposit bonuses).
     - Registering using the official method and completed verification processes.
     - Meeting any registration conditions specified by the promotion.
   - Ensure the player has provided any required promotion-related details, such as a screenshot from the promotion page when claiming, if applicable.

3. **Verify system and activity conditions**
   - Confirm the player’s activity aligns with promotion rules:
     - Has the player used different bank cards or IP addresses (to avoid disqualification)? 
     - Does the player have a mobile phone number linked to their account? 
     - Ensure the player does not violate restrictions like using the same or multiple IP addresses.
   - Check if the bonus was automatically credited:
     - Bonuses such as first deposit bonuses are credited within 12 hours after meeting the conditions.
     - Bonuses are distributed automatically by the system once requirements are fulfilled.

4. **Identify potential reasons for non-receipt of bonuses**
   - Explain to the player that common causes for not receiving bonuses include:
     - Restrictions related to bank card, IP address, or mobile phone number.
     - Failing to meet eligibility criteria.
     - System delays or ineligibility due to unmet requirements.
   - Advise the player to ensure they meet all the conditions and have provided all necessary details.

5. **Check for bonus-specific conditions and terms**
   - Verify the bonus applies to the relevant games (e.g., SLOT & FISH GAMES for the New Register Bonus).
   - Confirm any specific promotion terms, such as:
     - Minimum deposit amount.
     - Turnover or wagering requirements (e.g., 20x for withdrawal eligibility).
   - For the New Register Bonus:
     - Confirm the player has registered via the official website.
     - Confirm the player has downloaded and used the official DREAMJILI app if necessary.
     - Check whether the bonus was credited automatically within 2 hours after registration.

6. **Resolve or escalate based on findings**
   - If the player has met all conditions but did not receive the bonus:
     - Advise them to check their rewards center and activity logs.
     - Confirm no violations or restrictions are in place.
   - If the bonus is not credited due to system delay or technical issues, inform the player that it may take time, or escalate to technical support if needed.
   - If the player did not meet eligibility or promotion terms:
     - Explicitly explain which condition they failed and why the bonus was not awarded.
     - Suggest corrective actions, such as completing missing steps or meeting wagering requirements.

7. **Provide guidance to the player for future claims**
   - Advise on how to access current and upcoming promotions via the official DREAMJILI app.
   - Remind the player to follow all promotion terms, including minimum deposits and turnover criteria, to ensure eligibility.
   - Encourage them to contact support if they believe an error occurred after following all procedures.

## Notes
- Bonuses are automatically credited once all conditions are fulfilled.
- Always verify that the player has followed correct steps to claim the bonus, including providing any necessary screenshot evidence.
- Keep the player informed about the importance of matching criteria such as deposit amount, gameplay, and registration details to maintain eligibility.
- Remind players that system delays or violations may prevent bonus receipt.

## Key points for communicating with players
- Emphasize that bonuses are distributed automatically after meeting all conditions.
- Clarify the importance of meeting all eligibility criteria, including deposit amounts and turnover requirements.
- Encourage players to use the official app for easy access to bonuses and promotions.
- Be transparent about potential reasons for non-receipt and the steps to resolve issues.