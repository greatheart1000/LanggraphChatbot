# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's query or issue** regarding bonuses, cashback, or VIP benefits, such as eligibility, claiming process, or missing rewards.

2. **Verify the player’s account information and current VIP status**:
   - Check if the player has reached the required VIP level (e.g., VIP3 for Birthday Bonus).
   - Confirm account details such as registration date, deposit history, and activity.

3. **Collect relevant documents or verification if necessary**:
   - For VIP-specific bonuses (e.g., Birthday Bonus), require documentation such as two valid IDs and a selfie holding them.
   - Ensure the player has submitted all required verification if they claim VIP benefits.

4. **Check the eligibility criteria based on the type of bonus or benefit**:
   - **Welcome Bonus**:
     - Confirm the player has made a first deposit of at least 100 PHP.
     - Verify that the deposit was successful and the bonus has not already been claimed.
   - **New Register Bonus / ANGPAO**:
     - Confirm registration and app download.
     - Check if the bonus has been sent to the Rewards Center within about 2 hours.
     - For non-deposit users, confirm the maximum withdrawal limit of 100 PHP.
   - **Birthday Bonus**:
     - Confirm VIP3 status and proper verification submission.
     - Check if the current date matches the player's birthdate.
   - **VIP Weekly Wages / Salary Bonus**:
     - Verify if the player deposited at least 100 PHP within the relevant week.
     - Confirm whether a valid bet has been placed during the week.
     - Check if the bonus has been automatically distributed on Monday between 22:00 and 23:59 GMT+8.
   - **Cashback/Rebates**:
     - Confirm if the promotion is active and the player is eligible.
     - Check if the rebate has been credited automatically to the account.

5. **Review in the system or Rewards Center**:
   - Check if the bonus or benefit has been credited automatically.
   - If not received yet, ensure the player has met all criteria and that the bonus is within the specified timeframe (e.g., up to 12 hours after deposit or activity).

6. **Instruct the player on claiming the bonus if it is not yet claimed**:
   - Guide them to click the Rewards Center in the app if the bonus is pending.
   - Confirm proper acceptance of system notifications or prompts.

7. **Address any issues related to non-receipt of bonuses**:
   - Ensure the player’s account meets all eligibility requirements (e.g., deposit amount, VIP status).
   - Check for issues such as shared IP addresses, duplicate registration details, or incomplete verification.
   - If eligibility criteria are met but bonus is not received, advise waiting up to 12 hours or escalate if necessary.

8. **Explain restrictions and important conditions to the player**:
   - Bonuses are automatically distributed based on activity and meeting specific criteria.
   - Bonuses such as the first deposit bonus can only be used on SLOT and FISH games.
   - For non-deposit bonuses, maximum withdrawal may be limited (e.g., 100 PHP for non-deposit users).
   - Valid bets and sufficient deposits are typically required to unlock withdrawals and further benefits.

9. **If the player is claiming a VIP benefit (e.g., birthday bonus, weekly wages)**:
   - Confirm all verification steps are completed.
   - Ensure the player provides any requested documentation or screenshots.
   - Confirm the bonus has been credited in the Rewards Center or inform them of the automatic distribution timing.

10. **Advise the player on next steps if the bonus or benefit is still not available**:
    - Remind them to check Rewards Center and their email notifications.
    - Suggest verifying if all activity requirements have been met.
    - Escalate to a supervisor if the bonus remains undistributed despite meeting all criteria.

## Notes

- Bonuses are automatically distributed when conditions are met; manual claiming is generally not needed unless stated.
- The distribution timeframe is typically within 12 hours after meeting the criteria.
- For weekly bonuses (e.g., VIP Weekly Salary), distribution occurs automatically every Monday during 22:00–23:59 GMT+8.
- Verification and proper documentation are mandatory for VIP-specific bonuses.
- Always confirm that players understand the conditions and restrictions associated with each bonus or benefit.

## Key points for communicating with players

- Clearly explain that bonuses are credited automatically once all requirements are satisfied.
- Inform players of the timeframe for bonus distribution.
- Remind players to check the Rewards Center regularly.
- Advise on submitting necessary verification documents for VIP benefits.
- Confirm they are participating in eligible games (e.g., SLOT & FISH for certain bonuses) to utilize the bonus effectively.