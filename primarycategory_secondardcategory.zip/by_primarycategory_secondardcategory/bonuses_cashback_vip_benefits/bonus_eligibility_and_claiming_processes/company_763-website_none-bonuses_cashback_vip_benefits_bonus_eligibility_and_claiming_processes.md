# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue regarding bonuses, cashback, or VIP benefits.**  
   - Clarify whether the player is asking about specific bonuses, cashback, or VIP rewards.

2. **Verify the player's account details and recent activity.**  
   - Check if the player has made the required deposits (e.g., at least 100 PHP for the VIP Weekly Salary).  
   - Confirm recent login activity, deposit history, and VIP tier if applicable.

3. **Determine the type of bonus or benefit in question.**  
   - Is it the Thursday Weekly Gift, the monthly cashback, the 19th Monthly Bonus, a first deposit bonus, or a VIP Weekly Salary?  
   - Ask if the player has already claimed or received it.

4. **Check timing and distribution periods based on the FAQ specifics.**  
   - For Thursday Weekly Gifts: the player must log in and claim rewards at the Rewards Center every Thursday between 22:00 and 23:59 (GMT+8).  
   - For Monthly Cashback: it is automatically sent to the Rewards Center on the 19th of each month between 22:00 and 23:59 (GMT+8).  
   - For the 19th Monthly Bonus: check if the player received the bonus on the 19th of the current month; if not, they may not be eligible.  
   - For the VIP Weekly Salary: credited automatically every Monday between 22:00 and 23:59 (GMT+8) to eligible players.

5. **Assess eligibility based on system information and rules.**  
   - Confirm whether the player meets the criteria, such as:  
     - Having made a qualifying deposit (e.g., minimum of 100 PHP for bonuses).  
     - Not having duplicate accounts using the same IP address, bank card, or phone number, which could lead to confiscation of rewards.  
     - Meeting turnover requirements (typically 8x for bonuses to become withdrawable).  
     - Having fulfilled activity conditions for specific benefits, like reaching a VIP tier or depositing in the relevant timeframes.

6. **For bonuses or cashback not received or unavailable:**
   - Check if the bonus is currently active or if the player is eligible at this time.  
   - Inform the player that bonuses are system-distributed or automatically sent; if not received, it may mean they are not eligible, or the bonus is not active.

7. **If the player reports not receiving an eligible bonus:**
   - Confirm that the deposit amount and activity meet the minimum requirements.  
   - Verify that the player has completed any necessary actions, such as claiming from the Rewards Center for bonuses that require manual claiming.  
   - If the bonus is supposed to be auto-distributed (like the first deposit bonus or VIP Weekly Salary), inform the player that distribution is automatic and may take up to 12 hours.  
   - Check for system restrictions: duplicate accounts, use of the same phone number or bank card, or IP address issues.

8. **Guide the player on how to claim bonuses or rewards in system:**
   - For bonuses like the first deposit bonus (if eligible), instruct the player to visit the Rewards Center and tap "Claim."
   - For system-automated bonuses, confirm that the player checks the Rewards Center (or relevant bonus page) after the distribution period.

9. **If the player is ineligible or bonus is not available:**
   - Clearly explain that the bonus may not be active, they may not qualify at this time, or their account may not meet the criteria.
   - Advise to review the latest promotion details on the official promotions page or channels.

10. **Document the interaction and any relevant details or screenshots provided by the player.**  
    - Record deposit amounts, timestamps, and any error messages.

11. **Close the case once the player's inquiry is resolved or escalated if necessary.**  
    - If the issue is system-related or involves bonuses not distributed in error, escalate to the technical team as per internal protocol.

## Notes

- Bonuses including the Thursday Weekly Gift and the monthly cashback are distributed systemically and automatically or via claimed rewards, respectively.
- The 19th Monthly Bonus is automatically sent on the 19th of each month, between 22:00 and 23:59 (GMT+8).
- The VIP Weekly Salary is credited automatically every Monday between 22:00 and 23:59 (GMT+8), provided the player has made at least 100 PHP in deposits within that week.
- Eligibility can be affected by multiple account registrations, IP, bank card, or phone number duplication; these may result in confiscation of rewards and profits.
- Always verify timing and eligibility before instructing the player to claim bonuses or confirming receipt.