# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information regarding the bonus inquiry**
   - Ask the player whether they are reporting a missing bonus, difficulty claiming, or understanding the bonus rules.
   - Collect details about their recent activity: deposit amount, game activity, and whether they have completed verification steps, such as phone number verification if applicable.

2. **Check the player's deposit and activity status in the system**
   - Verify if the player has made the qualifying deposit(s) for the bonus.
   - Confirm if the player selected the relevant promotion and checked the bonus checkbox at the time of deposit.
   - Ensure the player has fulfilled any wagering or betting thresholds required by the bonus rules.

3. **Determine bonus claimability based on system limitations**
   - Check if the player’s IP address or device has already claimed a bonus, as bonuses are generally limited to one per IP or device.
   - Verify if the player has already claimed a promotion or bonus on the same IP or device, which could prevent further claims.

4. **Assess bonus eligibility and status**
   - Confirm if the player meets all eligibility criteria, such as account verification status and any specific promotional rules.
   - For deposit bonuses, verify if the bonus has been credited after the deposit and bonus conditions are met.
   - For VIP bonuses, check if the bonus has been updated automatically by the system, noting it can take up to 24 hours to reflect.

5. **Address issues with missing or delayed bonuses**
   - If the bonus has not been credited and the applicable period (e.g., up to 24 hours for VIP bonuses) has passed:
     - Inform the player that the bonus may still be processing.
     - If the bonus remains missing after the stated period, escalate the issue to support with specific account and bonus details.
   - For promotional rebates:
     - Inform the player rebates are processed automatically, with settlement around 4:30 am daily.
     - Rebate calculations are based on the previous day’s bets and may begin crediting from around 2:00 am onwards.

6. **Clarify bonus limitations and rules to the player**
   - Explain that bonuses are limited to one per IP address or device.
   - Remind the player to claim promotions only from a unique IP or device.
   - inform about the requirement to follow specific steps during deposit, such as selecting the promotion checkbox, and meeting wagering thresholds.

7. **Provide guidance on next steps or further actions**
   - If the bonus is correctly claimed, thank the player and remind them to fulfill wagering requirements.
   - If the bonus is missing despite meeting all conditions, advise the player to contact support with relevant details.

## Notes
- Bonuses are generally limited to one per IP address or device, which can prevent multiple claims.
- Deposit bonuses require selecting the promotion checkbox before depositing and fulfilling wagering conditions.
- VIP bonuses are updated automatically and may take up to 24 hours to be visible.
- Rebate processing occurs automatically around 4:30 am daily, based on the previous day’s bets.

## Key points for communicating with players
- Confirm they are claiming from a unique IP or device.
- Ensure they have completed verification steps if required.
- Clarify that bonuses are limited per IP/device and explain the automatic processing timelines.
- Encourage players to contact support if their bonus remains missing after the appropriate period.