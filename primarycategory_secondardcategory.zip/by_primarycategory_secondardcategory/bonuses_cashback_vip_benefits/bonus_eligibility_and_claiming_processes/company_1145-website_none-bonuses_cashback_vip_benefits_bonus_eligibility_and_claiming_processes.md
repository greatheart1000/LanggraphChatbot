# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps
1. **Gather initial information from the player**:
   - Confirm the type of bonus or promotion the player is referring to (e.g., welcome bonus, invite bonus, cashback, VIP benefits).
   - Ask for details on recent deposit amounts, device, and IP address if applicable.

2. **Verify deposit and account conditions**:
   - Ensure the player has made the required minimum deposit amount for the bonus.
   - Confirm that the player has completed all necessary account verification steps on the same day if the bonus requires verification for qualification (e.g., for welcome or invite bonuses).

3. **Check for bonus claim limitations**:
   - Confirm if the player is eligible based on IP address or device restrictions, noting that bonuses are limited to one per IP address or device.
   - Verify if the player has already claimed a similar bonus from the same IP or device, which may limit further claims.

4. **Review bonus/ promotion conditions**:
   - Ensure the bonus has not already been claimed, as bonuses cannot be removed once claimed.
   - Check if the bonus is subject to specific game restrictions or designated games, if applicable.
   - Confirm that the player meets the specific conditions like deposit amount, game activity, or other promotion-specific rules.

5. **Check system and back-office records**:
   - Use the system to verify if the bonus has been successfully awarded automatically upon meeting the conditions.
   - Confirm that the bonus was claimed according to the platform’s process and that all conditions (minimum deposit, verification, IP/device restrictions) are met.

6. **Decide on the appropriate resolution based on verification**:
   - **If all conditions are met and bonus is successfully awarded**:
     - Inform the player that the bonus has been credited and explain any relevant restrictions (e.g., use in designated games).
     - Advise the player on wagering requirements or other relevant rules if applicable.
   - **If conditions are not met or bonus was not awarded**:
     - Confirm which condition was not fulfilled (e.g., deposit below minimum, missing verification, IP/device restriction violation).
     - Explain that the bonus cannot be claimed or has not been credited due to these reasons.
     - If applicable, guide the player on how to meet the requirements for future bonus claims, such as depositing the minimum amount or completing verification.

7. **Escalate or conclude**:
   - If player’s situation involves an unexpected issue or a suspected system error, escalate to technical support or verification team.
   - Close the case with a clear summary of actions taken and the current status of the bonus claim.

## Notes
- Bonuses are awarded automatically once all conditions are met; manual intervention is not typically required unless a system issue occurs.
- Bonuses and promotions are limited to one per IP address or device, so inform players accordingly when they attempt multiple claims from the same setup.
- Make sure to verify account details and documentation if the bonus requires account verification within the same day.

## Key points for communicating with players
- Clearly explain the conditions required for bonus eligibility, including deposit amount, verification, and IP/device restrictions.
- Inform players that bonuses, once claimed, cannot be removed.
- Advise players on game restrictions and wagering requirements if relevant.
- Emphasize the importance of meeting all specified conditions promptly to qualify for the bonus.