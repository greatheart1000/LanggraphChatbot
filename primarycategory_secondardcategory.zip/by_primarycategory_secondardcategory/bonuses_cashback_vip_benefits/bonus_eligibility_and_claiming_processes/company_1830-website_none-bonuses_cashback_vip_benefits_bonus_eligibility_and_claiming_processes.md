# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information and clarify their inquiry**  
   - Confirm the type of bonus or promotion the player is referring to (e.g., first deposit bonus, reload, cashback, VIP benefits).  
   - Collect details on the player's recent activities, including deposit amounts, dates, and any specific bonuses they expect to receive.  
   - Ask if the player has encountered any specific error messages or notifications.

2. **Check the player's account for eligibility**  
   - Verify if the player has completed the required actions for the bonus in question:  
     - Made the minimum deposit amount (e.g., at least 100 PHP for first deposit bonus).  
     - Met any specified wagering or turnover requirements (e.g., 10x).  
     - Followed steps like downloading the official app or registering through the designated process if applicable.  
   - Confirm account details such as registration date, IP address, phone number, and bank card information to check for potential disqualifying factors, such as repeated or conflicting entries.

3. **Assess system detection for restrictions**  
   - Ensure the player is not using the same IP address, bank card, or phone number that could disqualify eligibility based on system restrictions.  
   - Confirm there are no indications of multiple accounts or suspicious activity that might impact bonus eligibility.  
   - Check if the player's account is within the promotional time limits (e.g., claiming within 2 hours after deposit).

4. **Determine bonus distribution eligibility**  
   - Confirm whether the player meets all criteria explicitly outlined in the FAQs:  
     - Deposit threshold met (e.g., 100 PHP minimum).  
     - Turnover/wagering requirements fulfilled (e.g., 10x).  
     - Action or steps like registration, download, or claim within specified timeframes are completed.  
   - If all conditions are satisfied and no restrictions are detected, proceed to bonus distribution.

5. **Verify bonus distribution status**  
   - Check if the bonus has been credited automatically within the 2-hour window specified in the FAQs.  
   - Guide the player to their Rewards Center or ask if they see the bonus credited.  
   - If the bonus is not credited and eligibility is confirmed, inform the player that the bonus should be distributed shortly, and advise them to wait or to recheck later.

6. **Handle cases of non-receipt of bonus**  
   - If conditions are met but the bonus is not received within the expected timeframe, verify potential issues:  
     - Repeated violations such as using the same bank card or IP, or no mobile phone registered.  
     - Missing required actions like claiming the bonus explicitly if needed (although most are automatic).  
   - If eligibility appears intact but delay persists beyond the stated timeframe, escalate to specialist support or advise the player to wait up to the next business day.

7. **Explain the process and next steps to the player**  
   - Clarify that bonuses are automatically distributed once system requirements are satisfied.  
   - Remind about specific conditions affecting eligibility: deposit amount, turnover, system restrictions, and submission steps.  
   - If applicable, guide the player to the Rewards Center to claim or view the bonus.

## Notes
- Bonuses are only credited if all system conditions are met within the designated or implied timeframes (mostly within 2 hours).  
- Repeated registration, using the same bank card, IP address, or phone number can disqualify bonuses or result in confiscation of rewards and profits.  
- Bonuses are specifically applicable to certain game types (e.g., SLOT & FISH GAMES for some offers).  
- For unreceived bonuses, confirm that the player has not violated any restrictions and that the deposit and wagering requirements are followed precisely.

## Key points for communicating with players
- Emphasize that bonuses are automatic and system-credited.  
- Confirm deposit amounts and required actions clearly.  
- Remind players of the 2-hour timeframe for bonus crediting.  
- Clarify restrictions involving IP, phone number, and bank card to prevent confusion or misinterpretation.  
- Encourage players to check their Rewards Center regularly and advise patience if delays occur.