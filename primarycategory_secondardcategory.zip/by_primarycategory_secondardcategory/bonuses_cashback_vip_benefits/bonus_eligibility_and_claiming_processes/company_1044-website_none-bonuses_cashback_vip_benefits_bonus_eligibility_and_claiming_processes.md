# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information**:  
   - Confirm the player's account details, including registered phone number and device information.  
   - Ask if the player is attempting to claim a specific bonus or promotional offer.

2. **Verify deposit requirements**:  
   - Ensure the player has made a deposit meeting the minimum required amount, e.g., ₱500 for the welcome bonus or NEW MEMBERS bonus.  
   - Check that the deposit was successfully completed and properly recorded in the system.

3. **Check for bonus claim eligibility**:  
   - Confirm the player is not sharing the same IP address or device as another account that has already claimed a bonus, as bonuses are limited to one claim per IP or device per promotion.  
   - Verify the player accessed the bonus via RewardCenter > Bonus > Tickets (if applicable).  
   - Ensure the promotional period is still active.

4. **Verify activity conditions for bonus redemption**:  
   - Confirm that the player has completed the required activities, such as placing SLOT bets worth ₱2500 for the welcome or NEW MEMBERS bonus, or fulfilling other designated betting criteria.  
   - For deposit-based bonuses, ensure the deposit amount and type meet the bonus-specific conditions.

5. **Check bonus redemption process**:  
   - Ensure the player redeems their bonus ticket within the applicable time frame, i.e., within 7 days of receipt, as overdue tickets will be forfeited.  
   - Confirm the player has redeemed their ticket bonus properly in the system.

6. **Confirm turnover and wagering requirements**:  
   - Verify that the player has fulfilled the 1x turnover requirement or other specific wagering conditions before attempting withdrawals or further gameplay.  
   - Confirm that bonus credits are credited automatically upon meeting all deposit and activity conditions.

7. **Address potential issues or deficiencies**:  
   - If the player did not receive their deposit bonus, verify they met the initial deposit requirements, confirmed their phone number, and selected the promotion during deposit.  
   - If the player used the same IP or device and is ineligible for multiple bonuses, inform them of the restriction.

8. **Advise on next steps**:  
   - If all conditions are met, confirm the bonus has been successfully claimed and provide guidance on wagering or using the bonus.  
   - If conditions are not met or there are issues, explain the specific reason based on system checks (e.g., insufficient deposit, expired ticket, IP/device restrictions).

## Notes

- Bonuses and promotions are limited to one claim per IP address and device unless otherwise specified.  
- Bonuses are credited automatically once all conditions are fulfilled.  
- Ensure the player redeems their tickets within 7 days; otherwise, they will be forfeited.  
- Verify all requirements (deposit amount, betting conditions, redemption timing) before approving the bonus claim.

## Key points for communicating with players

- Clarify that bonuses are limited to one per IP/device unless specified otherwise.  
- Remind players to complete the required bets and redeem within the valid period.  
- Confirm all deposit and activity steps are correctly followed for successful claim and wagering.