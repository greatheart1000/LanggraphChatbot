# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue related to bonuses, cashback, or VIP benefits.**  
   - Gather basic information:  
     - Player's current VIP level  
     - Recent deposit activity  
     - Recent betting activity on slot or fish games  
     - Specific bonus or benefit the player is referring to (e.g., VIP Weekly Salary, birthday bonus)  

2. **Verify the player's eligibility for the specific bonus or benefit they are claiming or inquiring about.**  
   - Check VIP level:  
     - For Birthday Bonus, confirm VIP3 status or higher.  
     - For VIP Weekly Salary, confirm VIP tier, and ensure the player has completed a minimum deposit of 100 PHP within the week.  
   - Check activity requirements:  
     - For VIP Weekly Salary, verify that at least one valid bet on slot or fish games was made within the week.  
   - Confirm deposit requirements for deposit bonuses:  
     - Ensure the deposit meets the minimum deposit amount (if specified) and was made using acceptable methods (e.g., different bank card, IP address, mobile number, as per promotion rules).  

3. **Review system distribution status and transaction logs.**  
   - Check the Rewards Center or system logs to confirm if the bonus, cashback, or VIP benefit has already been credited.  
   - For automatic distributions:  
     - Confirm if the bonus was sent within the usual timeframe (e.g., within 12 hours after meeting criteria).  
   - For VIP Weekly Salary:  
     - Confirm it was credited on the scheduled Tuesday between 22:00 and 23:59 (GMT+8).

4. **Determine if the player meets all eligibility and distribution criteria.**  
   - If eligible but the bonus or benefit has not been received:  
     - Validate that the player met all conditions at the time of distribution.  
     - Check if any eligibility conditions (e.g., eligible deposit, activity) were met within the relevant timeframe.  
   - If not eligible:  
     - inform the player of the specific unmet criteria (e.g., VIP level, activity, deposit requirements).  

5. **Address any issues or discrepancies.**  
   - If the player claims they fulfilled criteria but system logs show otherwise:  
     - Request relevant proof if applicable (e.g., transaction history).  
     - Escalate if necessary, following company protocol.  

6. **Advise the player on current promotion rules and potential next steps.**  
   - Explain that bonuses are automatically distributed and should appear in the Rewards Center.  
   - Clarify that bonuses can be claimed there if applicable.  
   - Inform the player that if they did not receive a bonus or salary, it is likely due to unmet requirements or timing issues.  

7. **Document the interaction and the verification process.**  
   - Record the player's eligibility status, confirmation of system distribution, and any actions taken.  
   - Note any discrepancies or required escalations.

## Notes

- VIP Weekly Salary is only credited if the player completes at least 1 valid bet on slot or fish games within the week, and has met the VIP and deposit thresholds.
- Bonuses and rewards are automatically credited within a specified timeframe (usually within 12 hours) after meeting the criteria.
- Ensure the player is aware that repeatedly using the same bank card, IP address, or phone number may cause withholding or rejection of bonuses.
- For bonus-specific questions, always verify the latest eligibility and distribution details according to the current promotion rules.

## Key points for communicating with players

- Clearly explain that bonuses are automatically distributed upon meeting eligibility criteria.
- Remind players to check their Rewards Center for credited bonuses.
- Confirm eligibility in detail before providing explanations or further assistance.
- Be transparent about timing and conditions to manage player expectations.