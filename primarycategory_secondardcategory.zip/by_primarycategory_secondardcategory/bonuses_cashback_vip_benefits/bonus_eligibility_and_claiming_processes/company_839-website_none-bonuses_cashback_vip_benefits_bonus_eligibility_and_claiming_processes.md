# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather Player Information**
   - Request the player's username or account ID.
   - Confirm whether the player has completed the necessary registration and download of the official KINGJL app, if applicable.
   - Ask if the player has noticed any bonus or promotion offers or received any notifications regarding bonuses.

2. **Determine the Type of Promotion or Bonus Involved**
   - Identify if the player is inquiring about:
     - Welcome/New Register Bonus
     - Other promotions or bonuses
     - Cashback/Reward rebates
   - Clarify the specific promotion or bonus the player is referring to.

3. **Verify Player's Eligibility**
   - Check for timely deposit, registration, and activity criteria based on the specific promotion:
     - For the New Register Bonus, ensure the player has registered and downloaded the app.
     - For other promotions, check if the player fulfilled deposit requirements (e.g., minimum amount such as 100 PHP) and met activity conditions.
   - Confirm whether the player has any restrictions such as multiple accounts or binding of the same bank card or phone number, which may affect eligibility.
   - Review system notifications for any restrictions or eligibility issues.

4. **Check Bonus Claim Status and Delivery Method**
   - Confirm if the bonus is meant to be distributed automatically or via manual claim:
     - Bonuses and rebates are generally distributed automatically upon meeting criteria.
     - Some promotions require the player to click 'Claim' in the Rewards Center.
   - Verify if the bonus or cashback has already been credited or if it is pending.
   - Ask whether the player has access to the Rewards Center or the KINGJL app for bonus claim options.

5. **Assist with Bonus Claiming Process (if applicable)**
   - If the bonus or cashback requires manual claiming:
     - Guide the player to navigate to the Rewards Center or Cashback/Rewards section.
     - Instruct them to click the 'Claim' button within the relevant promotion or cashback offer.
   - Advise the player that bonuses are typically credited within a set timeframe (e.g., 2–12 hours), depending on the promotion.
   - For cashback, inform that it is usually credited automatically and if manual claiming is needed, to use the Cashback/Rewards option.

6. **Address Non-Receipt of Bonuses or Cashbacks**
   - If the player reports not receiving the bonus within the expected timeframe:
     - Verify eligibility criteria were met at the time.
     - Check whether system restrictions or multiple account detections may have prevented distribution.
     - Request evidence (e.g., screenshot of the promotion offer).
     - Escalate the issue with support if needed or advise the player to wait up to the maximum expected timeframe for automatic credit.

7. **Handle Special Cases and Additional Checks**
   - For evidence-based cases, review the provided screenshots.
   - If the player is not eligible (e.g., did not meet deposit or activity requirements):
     - Inform them that the promotion will not be credited.
   - Remind players that bonuses are usually automatically credited and cannot be dispatched manually by agents.

8. **Close the Case**
   - Confirm that the player has received or has been informed about their bonus or cashback status.
   - Provide any relevant tips, such as ensuring app notifications are enabled or checking the Rewards Center regularly.
   - Summarize the next steps or wait times if appropriate.
   - End the interaction politely.

## Notes
- Bonuses are credited mostly automatically once eligibility is confirmed.
- Some promotions, especially new register bonuses, require downloading the KINGJL app and clicking 'Claim' in the Rewards Center.
- Cashback is typically credited automatically before 04:00 AM the next day, but manual claim options are available if needed.
- Eligibility may be affected by restrictions like multiple accounts or linked bank accounts; always verify these during eligibility checks.
- If players have evidence of the offer or promotion, encourage sharing it for verification.

## Key points for communicating with players
- Clearly explain the automatic or manual process of receiving bonuses.
- Remind players about the typical timeframes for credit.
- Politely clarify why a bonus might not be credited if eligibility requirements were not met.
- Offer assistance if the bonus has not been received within the expected period.