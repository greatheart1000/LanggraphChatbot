# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's query or issue related to bonuses, cashback, or VIP benefits.**  
   - Determine if the question concerns bonus eligibility, claiming process, specific promotions (e.g., Register Bonus, VIP Weekly Salary, Angpao, Lucky Wheel), or withdrawal conditions.

2. **Gather necessary information from the player.**  
   - Confirm the player's registration status (new or existing).
   - Ask for the player’s deposit history and recent activity (number of deposits, deposit amounts, dates).
   - Verify if the player has completed the required deposits or turnover for the requested bonus or promotion.
   - Obtain the player's VIP tier level if relevant.
   - Confirm if the player has claimed the bonus before or if they meet specific promotion requirements.
   - Clarify if the player used the official website or app for registration.
   - Note any specific details provided by the player, such as promotion names or bonus amounts.

3. **Check bonus eligibility and system conditions in the back office or system interface.**  
   - Verify if the player has met deposit thresholds (e.g., at least PHP 100 deposit for Register Bonus, PHP 100 deposit per week for VIP Salary).  
   - Confirm if the player has completed the stipulated turnover requirements (e.g., 10x turnover for withdrawal eligibility of certain bonuses).  
   - Check if the bonus has been automatically credited or if it is pending claiming via the Rewards Center.  
   - For promotions like Angpao, confirm if the player has made 5 or more deposits since registration for direct withdrawal eligibility, or if they need to complete required turnover.

4. **Assess the specific promotion or bonus process:**
   - For **Register Bonus**:  
     - Confirm registration is complete on the official website and app.  
     - Check if bonuses including Angpao (up to ₱888) and other rewards are available in the Rewards Center.  
     - Confirm if the bonus has been successfully claimed.  
   - For **VIP Weekly Salary**:  
     - Verify if the weekly deposits ≥ PHP 100 and if the player qualifies through their VIP tier.  
     - Check whether the salary has been automatically credited the preceding Wednesday between 22:00 and 23:59 GMT+8.  
   - For **Angpao promotion**:  
     - Confirm the player has made 5 or more deposits since registration for direct withdrawal.  
     - If fewer than 5 deposits were made, verify if the player has completed the required turnover.  
   - For **Lucky Wheel / Spin Bonuses**:  
     - Confirm spins made on JILI & PG slot games meet the required thresholds for bonus amounts.  
     - Check additional turnover if applicable (1X on spins of certain amount).

5. **Explain to the player the current status and next steps:**
   - If eligibility criteria are met and the bonus has not yet been credited, inform the player that the bonus is automatically distributed but may require time (e.g., up to 12 hours for first deposit bonus).
   - If they have claimed the bonus but are unclear about withdrawal restrictions, explain that:  
     - Bonuses are subject to a 10x turnover before withdrawal.  
     - For non-deposit users, the maximum withdrawal limit is PHP 100.  
     - The bonus can only be used on SLOT & FISH games.
   - If the requirements are not met (e.g., insufficient deposit, turnover not completed), inform the player what actions are needed to qualify.

6. **Advise on necessary player actions if eligibility is not fulfilled:**
   - Deposit the minimum required amount (e.g., PHP 100 for first deposit bonus, PHP 100 weekly for VIP Salary).  
   - Complete the required turnover (playing specific games or wagering the bonus amount 10x).  
   - Wait for automatic distribution if eligible, or guide the player on how to claim in the Rewards Center if manual claim is possible.  
   - Reminder: Bonuses become available for withdrawal only after meeting the specific conditions.

7. **If issues or discrepancies arise (e.g., bonus not credited after eligibility confirmed):**  
   - Check for any notices of system delays or restrictions.  
   - Confirm with the player if they have violated any policies (e.g., suspicious activity, multiple accounts, repeated claims).  
   - Escalate to technical support or supervisor if needed.

8. **Document the interaction details and any player instructions provided.**  
   - Record deposit amounts, transaction times, and validation results.  
   - Note the player's understanding and actions taken.

## Notes
- Bonuses such as weekly VIP Salary are automatically credited every Wednesday between 22:00 and 23:59 (GMT+8) if deposit and activity requirements are met.
- The first deposit bonus is credited within 12 hours after deposit of minimum PHP 100.  
- Non-deposit users can only withdraw up to PHP 100 from the register bonus or Angpao if qualification criteria are unmet.  
- Repeated claims or violations can lead to forfeiture of bonuses and profits.

## Key points for communicating with players
- Clearly explain the minimum deposit and turnover requirements for each bonus or promotion.  
- Inform players that bonuses are automatically or manually credited based on specific conditions.  
- Emphasize the 10x turnover rule before withdrawal for eligible bonuses.  
- Remind players of the maximum withdrawal limits for non-deposit bonuses.  
- Encourage players to check the Rewards Center for available rewards and status updates.