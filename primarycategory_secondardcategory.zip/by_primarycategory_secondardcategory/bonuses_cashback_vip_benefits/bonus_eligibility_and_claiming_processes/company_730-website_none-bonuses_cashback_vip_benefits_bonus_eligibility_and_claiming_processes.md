# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player details and inquiry specifics**
   - Confirm the player’s account information, including registration details and active mobile number.
   - Identify the specific bonus or cashback the player is inquiring about (e.g., VIP Weekly Salary, first deposit cashback, Slot & Fish bet bonus).

2. **Check bonus or cashback distribution status**
   - Verify if the bonus, cashback, or rebate has already been credited to the player’s account.
   - Remember that all bonuses, cashbacks, and rebates are distributed automatically by the system; if not received, proceed to check eligibility.

3. **Review eligibility requirements for each promotion**
   - Verify if the player has met the specific criteria:
     - Minimum deposit amount within the required period.
     - For VIP Weekly Salary: at least 1 valid bet on slot or fish and a minimum deposit of 100 PHP within the week.
     - For Slot & Fish bets: placement of bets of 1500 PHP or more on Slot & Fish, with the bonus scheduled to be sent between 04:00 and 06:00 GMT+8 the next day.
     - For general bonuses: correct registration details, active mobile number, and fulfillment of criteria specified by the promotion.

4. **Assess timing and system triggers**
   - For VIP Weekly Salary:
     - Check if the player deposited at least 100 PHP during the week and placed a valid bet on slot or fish.
     - Confirm that the current day is Thursday, and the reward should be credited between 22:00 and 23:59 GMT+8.
   - For cashback and rebates:
     - Confirm if the player qualifies based on their deposit history and system detection (e.g., no repeated IPs or accounts).
     - Understand that bonuses are sent automatically by the system, typically within 12 hours for first deposit cashback.

5. **Advise the player on missing bonuses or cashback**
   - If the bonus or cashback has not been received:
     - Explain that rewards are system-distributed and that eligibility requirements must be fulfilled.
     - Suggest reviewing their last deposit and betting activities to ensure compliance.
     - Mention that delays can occur but are usually not beyond 12 hours for first deposit cashback.
     - If the player believes they meet all conditions but still did not receive the reward, advise them to check their eligibility again or contact support for further investigation.

6. **Handle edge cases or disputes**
   - If the player claims non-receipt despite fulfilling the criteria:
     - Confirm whether their account details and deposit history meet the promotion requirements.
     - Check the system logs for bonus distribution, especially for Slot & Fish bet bonuses and VIP Weekly Salary.
   - If the system shows no bonus assigned:
     - Clarify that rewards are distributed automatically and that the player is not eligible under current conditions.
   - If the player mentions repeated IPs or account sharing concerns:
     - Explain that the system detects such activities, and rewards can be confiscated if rules are violated.

7. **Provide relevant information or escalate as needed**
   - If the issue is technical or system-related, escalate to the technical team or system support.
   - If the player is eligible but still does not receive the bonus, advise them to wait up to 12 hours for first deposit cashback or check their eligibility criteria.

## Notes

- All bonuses, cashback, and rebates are distributed automatically by the system; manual crediting is not performed.
- Bonuses such as VIP Weekly Salary are credited every Thursday between 22:00 and 23:59 GMT+8, provided the player fulfills the weekly requirements.
- For Slot & Fish game bonuses, the reward is sent automatically between 04:00 and 06:00 GMT+8 the next day after each qualifying bet of at least 1500 PHP.
- Always verify the specific promotion terms and conditions and the player’s activity to ensure eligibility.

## Key points for communicating with players

- Clearly explain that rewards are system-distributed and based on meeting specific rules.
- Remind players of the importance of meeting deposit and betting requirements.
- Advise patience for automatic bonuses, especially around scheduled distribution times.
- If eligibility criteria are met but rewards are not received, recommend checking account details and system logs before escalation.