# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's VIP level and eligibility for bonuses or rewards**  
   - Check if the player’s VIP level is 4 or higher for birthday bonuses, VIP birthday bonus, VIP Weekly Salary, and Saturday Bonus.  
   - Confirm VIP status in the system or player profile.

2. **Request and verify necessary identification documents for bonus eligibility**  
   - For birthday-related bonuses (including VIP Birthday Bonus), ask the player to submit two valid IDs showing their birthdate and a selfie holding one of their IDs.  
   - Verify that the IDs are clear, readable, and display the correct birthdates.

3. **Confirm player's registration details and provided information**  
   - Ensure the username matches the account in question.  
   - Match submitted IDs and selfies with the account owner.

4. **Verify eligibility based on deposit and activity requirements**  
   - For VIP Weekly Salary: Confirm the player made a minimum deposit of 100 PHP within the week.  
   - For Saturday Bonus (Lucky Saturday): Confirm the player met the promotion-specific criteria, including minimum activity and turnover requirements as detailed in the Rewards Center promotion terms.  
   - For bonuses requiring bet minimums (e.g., Bet on Slot, Fish, or Poker Bonus): Check that the player bet more than 1,500 PHP.

5. **Handle automatic rewards and bonuses**  
   - VIP Weekly Salary: Automatically credited every Sunday between 22:00 and 23:59 (GMT+8).  
   - Saturday Bonus, birthday bonus, or VIP bonuses: If eligibility criteria are met and verification is approved, approve and process the bonus to be credited.

6. **Check for pending verifications or delays**  
   - If the bonus or reward is not received within the expected timeframe, verify whether the player met all submission, verification, and activity requirements.  
   - Remind the player to ensure their IDs and selfies are clear and correctly submitted if verification is pending.

7. **Communicate the result to the player**  
   - If eligible and verified, inform the player their bonus has been credited or will be credited shortly.  
   - If not eligible (e.g., VIP level below 4, missing or unclear documentation, insufficient deposits/activity), clearly explain the specific reason based on the requirements.

8. **Escalate cases where documentation is insufficient or unclear**  
   - Request additional or clearer documentation if necessary.  
   - If the player disputes eligibility or claims a delay, follow escalation procedures per company policy.

## Notes

- Bonuses may have turnover requirements before withdrawal; inform players accordingly if applicable.  
- Birthday bonuses and VIP rewards are typically only available on exact birthdates or VIP level thresholds.  
- Rewards like weekly salary and Saturday bonuses are system-generated; ensure minimum deposit and activity criteria are confirmed during verification.  
- Always verify that submitted IDs have visible and readable birthdates and are valid according to the current site policies.

## Key points for communicating with players

- Clearly explain the VIP level requirement (VIP 4 or above) for certain bonuses.  
- Confirm submission of two valid IDs and a selfie with a clear, readable image.  
- Emphasize the importance of meeting deposit and activity requirements to qualify for weekly or special bonuses.  
- Remind players that some bonuses are system-generated and may take time to appear in their Rewards Center.  
- Inform players of turnover requirements needed before withdrawal if applicable.