# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue** regarding bonuses, cashback, or VIP benefits to determine if they are seeking information on eligibility, claiming processes, or specific promotions.

2. **Gather necessary player information**:
   - Confirm the player's VIP level.
   - Check if the player is a new registrant or a returning customer.
   - Collect relevant details such as account ID, registration date, VIP status, deposit history, and recent activity.

3. **Determine eligibility for specific bonuses based on the player's information**:
   - **Birthday Bonus**: Confirm if the player is VIP3 or higher. If eligible, advise the player to contact customer support to receive the bonus.
   - **New Register Bonus**:
     - Verify new registration and app download.
     - Confirm registration details and app download status.
     - Check if the bonus has been credited within the typical 2-hour window.
   - **New Player First Deposit Bonus**:
     - Check if the player made their first deposit meeting the required minimum (e.g., 100 PHP).
     - Confirm if the bonus was automatically credited (up to 12 hours).
     - Ensure the player did not violate restrictions such as using the same IP, bank card, or phone number for multiple deposits.
   - **VIP Weekly Salary**:
     - Confirm if the player deposited at least 100 PHP during the week.
     - Verify the date and time of deposits to ensure they meet the weekly criteria.
     - Check if the salary was credited on Saturday between 22:00 and 23:59 GMT+8.
   - **Other Promotions**:
     - Review promotion-specific requirements related to deposits, registration, or activity.
     - Confirm if the player has fulfilled minimum deposit or play turnover requirements.
   
4. **Perform system checks for bonus distribution**:
   - Confirm automatic distribution by the system, no manual intervention is needed.
   - Advise the player to review their Rewards Center or Promotions page if bonuses are not visible.
   - Check for possible delays, which can be caused by policy reviews or other restrictions.

5. **If the bonus or reward is not received as expected**:
   - Review the player’s compliance with eligibility criteria and timing.
   - Verify if any restrictions are applicable (e.g., duplicate accounts, same IP or bank details).
   - If eligibility is confirmed but rewards are missing, advise the player that the bonus should be credited within the standard timeframe.
   - If not credited beyond the expected timeframe, escalate to the technical team with details.

6. **Explain the process or restrictions to the player**:
   - Clarify that bonuses are automatically credited when conditions are met.
   - Remind that bonuses will appear in the Rewards Center or Promotions page.
   - Inform the player that manual distribution is not possible.
   - For delays, advise to check back later or contact support if they meet all criteria.

7. **If the player does not meet eligibility requirements**:
   - Clearly communicate the specific missing criteria (e.g., lower VIP level, no qualifying deposits).
   - Guide them on how to meet those requirements to qualify for future bonuses or benefits.

8. **Close the query**:
   - Confirm the player understands the process.
   - Advise them to monitor the Rewards Center and Promotions page for the relevant bonuses.
   - Offer further assistance if needed and end the support case.

## Notes

- Bonuses such as the Birthday Bonus are exclusive for VIP3 and above; players must reach this level before claiming.
- The VIP Weekly Salary is credited every Saturday between 22:00 and 23:59 GMT+8 for players with a minimum of 100 PHP deposited during the week.
- The New Register Bonus applies only after registration and app download, credited within 2 hours; it is limited to SLOT and FISH GAMES with a 1x turnover requirement.
- Repeated deposits using the same IP, bank card, or phone may forfeit the bonuses.
- All bonuses and rebates are automatically distributed by the system, typically within 12 hours.
- If bonuses do not appear, advise players to check their Rewards Center or Promotions page, and verify eligibility.

## Key points for communicating with players

- Clearly explain that bonuses are automatic and based on meeting specific criteria.
- Remind players to review their Rewards Center for credited rewards.
- Clarify that delays can happen due to policy checks or verification processes.
- When necessary, escalate cases where rewards are not credited within the normal timeframe despite meeting all requirements.