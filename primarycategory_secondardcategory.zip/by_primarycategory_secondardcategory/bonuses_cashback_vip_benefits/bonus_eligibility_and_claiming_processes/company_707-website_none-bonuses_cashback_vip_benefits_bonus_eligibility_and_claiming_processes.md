# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify player identity and account information**  
   - Confirm the player’s account details, including registered phone number, bank card, IP address, and device information.  
   - Check for any signs of suspicious activity such as sharing IPs, using the same bank card, or multiple accounts with the same contact details, which may affect bonus eligibility (refer to FAQ: reasons bonus may not be credited).  

2. **Determine the specific promotion or bonus in question**  
   - Identify if the player is requesting information about a general bonus, cashback, VIP benefit, or a particular promotion (e.g., new member bonus, first deposit bonus, VIP Weekly Salary, Angpao bonus).  

3. **Check eligibility criteria for the relevant bonus/promotions**  
   - Confirm if the player has met the necessary actions such as:  
     - Registration and app download completion (for new register bonus).  
     - Minimum deposit requirement (e.g., 100 PHP for the first deposit bonus, 600 PHP for Angpao).  
     - Making a valid bet on slot or fish games during the qualifying period.  
     - Qualifying for VIP tiers based on deposits or activity.  
   
4. **Assess whether the bonus should be automatically credited**  
   - For bonuses like registration, first deposit, VIP Weekly Salary, or VIP Weekly Wages, the system distributes bonuses automatically once the criteria are met (refer to FAQs: automatic distribution, within specific timeframes such as 2 hours for registration bonuses, and every Tuesday for Weekly Salary/Wages).  
   - Verify if the bonus has been credited in the player's Rewards Center.  
   
5. **If the bonus has not been credited, troubleshoot**  
   - Confirm if the player meets all eligibility criteria and has completed required activities within the specified time frames.  
   - Check for common reasons why bonuses may not be credited:  
     - Same bank card, same mobile phone number, or same IP address across accounts.  
     - Failure to meet turnover or deposit requirements.  
     - Delay in system processing (up to 12 hours).  
   - If conditions are met but the bonus is not received, advise the player to wait or resubmit proof if required.  

6. **If the player claims the bonus via Bonus Center**  
   - Instruct the player to verify their Bonus Center for eligible bonuses.  
   - Guide them to click "Claim" if applicable (some promotions may require manual claiming).  
   - Confirm if the bonus appears in their account after claiming.  

7. **Explain the turnover and wagering requirements**  
   - Clarify that to withdraw any bonus-related winnings, the player must meet the specified turnover requirement (e.g., a certain multiple of the bonus amount).  
   - Advise continuing to play allowed games (slots or fish, as per promotion rules) until the requirements are fulfilled.  

8. **For the Angpao or special bonus sequences**  
   - Check the player's progress in the Rewards Center regarding deposit minimums, daily turnover of 10,000 PHP, and completion of the 7-day reward sequence.  
   - Ensure the player has visited the Rewards Center after completing the turnover to view progress and rewards. The sequence involves daily Angpao rewards from Day 1 Mini Angpao to Day 7 Mega Angpao.  

9. **Handle issues with non-receipt of VIP Weekly Salary or Wages**  
   - Confirm the player made at least one valid bet on slot or fish during the week and deposited at least 100 PHP (VIP Weekly Wages) or 100 PHP for Weekly Salary (depending on the specific benefit).  
   - If criteria are met but the bonus is not credited, advise that the bonus is automatically distributed on Tuesday, and they should check Rewards Center between 22:00 and 23:59 (GMT+8).  

10. **Document and escalate if necessary**  
    - If the issue persists after verifying all conditions and the bonuses are still not credited, document the case, including screenshots of eligibility and activity, and escalate to the system or promotions team as per company procedures.  

## Notes  
- Bonuses are generally credited automatically once conditions are met.  
- Check all eligibility criteria and system limitations before advising the player.  
- Advise players to use the official app for claiming and viewing bonuses.  
- Remind players that sharing account details, using the same bank card, or having multiple accounts sharing IPs or contact details may affect bonus eligibility.  

## Key points for communicating with players  
- Clearly explain the specific requirements for each bonus or VIP reward.  
- Emphasize the importance of meeting all eligibility and turnover conditions.  
- Inform that bonuses are automatically credited by the system within specified timeframes unless there is a violation of rules or incomplete actions.  
- Encourage patience while system processing occurs and advise to check Rewards Center regularly.