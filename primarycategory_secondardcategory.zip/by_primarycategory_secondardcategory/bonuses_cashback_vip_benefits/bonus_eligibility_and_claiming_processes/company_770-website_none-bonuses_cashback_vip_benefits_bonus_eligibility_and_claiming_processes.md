# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue related to bonuses or benefits** (e.g., Free Spin rewards, monthly bonuses, birthday bonuses, Friday bonuses).

2. **Gather necessary player information**:
   - Player's username or account ID.
   - VIP level (if applicable, e.g., VIP4 or higher for birthday and VIP-specific bonuses).
   - Any relevant verification/documents (for VIP Birthday Bonus: two valid IDs and a selfie holding a valid ID).

3. **Verify eligibility based on the specific bonus**:
   - For **Free Spin rewards**:
     - Confirm deposit of at least ₱1,000.
     - Confirm completion of daily turnover of ₱5,000.
     - Check the Reward Center after turnover to see if the reward is available.
   - For **Pay-day Monthly Bonus**:
     - Confirm the current date is the 15th of the month.
     - Verify the player is logged in between 22:00 and 23:59 GMT+8.
     - Ensure the account meets promotion conditions and has met any deposit or activity requirements.
   - For **VIP Birthday Bonus**:
     - Confirm VIP level is VIP4 or higher.
     - Verify player has submitted the necessary identification documents (two IDs + selfie with ID).
     - Check if the birthday bonus has been verified and received.
   - For **Ultimate Fun Friday Bonus**:
     - Confirm the current day is Friday.
     - Verify the player has deposited more than 200 PHP during the week.
     - Ensure the player visits the Bonus Center and clicks "Claim" within 22:00-23:59 GMT+8.
   - For **Bonus/Reward claims related to deposit and wager activity (e.g., Bet on Slot, Fish & Poker)**:
     - Confirm total bets surpass 1800.
     - Check for bonus credit scheduled next day at 18:00 (GMT+8).
   - For other bonuses (e.g., birthday, VIP weekly salary):
     - Verify VIP status and any specific requirements.
     - Confirm the bonus has been automatically or manually credited.

4. **Perform system checks**:
   - Access the player's Reward Center to verify received bonuses.
   - Check for status or pending bonuses that have not yet been credited.
   - For automatic bonuses scheduled on specific days, confirm the scheduled date has passed and the bonus has been credited.

5. **If the bonus or reward is not received**:
   - Confirm the player has met all eligibility and activity requirements.
   - Check for delays due to system processing or high traffic.
   - Advise the player to wait until the scheduled credit time if applicable.
   - If requirements are met but bonus not credited, escalate the issue or advise contacting support with proof of fulfillment.

6. **When players are eligible for benefits but have not claimed or received them**:
   - Guide them to the relevant section (e.g., Bonus Center, Rewards Center).
   - For bonuses that require manual claiming (e.g., Friday bonus), instruct to click "Claim" at the designated time.
   - For verification-based bonuses (e.g., VIP Birthday), instruct to submit missing documents or check verification status with support.

7. **For players claiming VIP Birthday Bonus**:
   - Confirm they have provided the required verification.
   - Once verified, inform them the bonus will be added to their account (may require contacting support if manual claim is necessary).

8. **Advise players on any relevant rules or conditions**:
   - Mention that bonuses such as VIP weekly salary or birthday bonuses are automatically sent on scheduled days.
   - Remind players that certain bonuses depend on depositing or betting thresholds.
   - Highlight that missed days or unmet criteria require starting the process over from the beginning for recurring bonuses.

9. **Document and log the case**:
   - Record all relevant details: player's account, bonus type, verification steps, and any issues encountered.
   - Escalate to technical or relevant team if bonuses are delayed or not credited despite compliance.

## Notes

- Bonuses such as the Pay-day Monthly Bonus are credited automatically on the 15th between 22:00-23:59 GMT+8.
- The Friday bonus is available every Friday between 22:00 and 23:59 (GMT+8); players must visit the Bonus Center and click "Claim".
- VIP Birthday Bonus is only for VIP4 and higher; verification process involves two valid IDs and a selfie.
- For Free Spin rewards, players must deposit at least PHP 1,000 and complete the daily turnover of PHP 5,000 before visiting the Reward Center to check eligibility.
- Bonuses related to deposit and wager activity (e.g., Bet on Slot, Fish & Poker) are credited the next day at 18:00 (GMT+8) to the bonus center. Ensure total bets are more than 1800.
- System delays may occur; patience is advised. If issues persist after meeting all conditions, escalate or escalate to technical support.

## Key points for communicating with players

- Clearly confirm the player's VIP level and activity requirements.
- Remind players of specific timeframes for automatic bonuses.
- Guide players to check their Reward Center or Bonus Center.
- Advise patience for processing delays.
- Escalate issues where appropriate with detailed account information and proof of eligibility.