# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Greet the player and clarify the nature of their inquiry.**  
   Ask the player if they are inquiring about bonus eligibility, claiming a bonus, cashback, VIP weekly salary, or other benefits to determine the relevant process.

2. **Verify the player's account details and identify the specific bonus or benefit they are referring to.**  
   Gather the player's username, account ID, or registration details, if needed, and clarify which bonus or benefit they are asking about (e.g., first deposit bonus, VIP Weekly Salary, birthday bonus).

3. **Check player's recent activity and deposit history.**  
   - Check if the player has completed the required deposit activities relevant to the bonus or VIP benefit.  
   - Ensure the minimum deposit conditions are met (e.g., at least 100 PHP for VIP Weekly Salary or first deposit bonuses).  
   - Verify deposit timeframes if applicable (e.g., weekly or birthday).

4. **Assess the player's VIP tier status.**  
   - Confirm the player's VIP level.  
   - Ensure the VIP tier qualifies for the specific benefit (e.g., higher VIP tiers receive higher weekly rewards).  
   - For VIP Weekly Salary bonuses, verifies if the player has achieved or maintained the required VIP tier.

5. **Verify whether the bonus conditions, such as betting activity or turnover, are fulfilled.**  
   - For bonuses requiring wagering or turnover (e.g., bonus eligibility depends on completing specific betting activities), confirm whether the player has met these conditions.  
   - Remember that bonus and cashback distribution are automatic and do not require manual claims, but certain bonuses (like claiming rewards) may need user action via the Rewards Center.

6. **Determine if the bonus or benefit has already been credited.**  
   - Check the Rewards Center or system logs to see if the bonus, cashback, or VIP Weekly Salary has been automatically credited.  
   - Note: Bonuses such as first deposit cashback and VIP Weekly Salary are distributed automatically within 12 hours if conditions are met.

7. **If the bonus or benefit has not been received but conditions are met:**  
   - Confirm the player has met all eligibility criteria, including deposits, VIP status, and betting activity.  
   - Check for any delays due to system traffic or technical issues.  
   - Instruct the player that bonuses are automatically sent; advise patience during high traffic periods.

8. **For bonuses that are claimable via the Rewards Center:**  
   - Guide the player to log into their account and navigate to the Rewards Center.  
   - Instruct how to locate the bonus and click on “Claim” if necessary.  
   - Advise the player to take a screenshot of the bonus page if they encounter issues, for support verification.

9. **For bonuses requiring additional verification or corrective action:**  
   - If the player claims they have met the requirements but no bonus is received, ask for proof (e.g., screenshot).  
   - Escalate to the relevant department if there is an apparent system error or discrepancy.

10. **Remind players about the policies regarding bonus eligibility and automatic distribution:**  
    - All bonuses, cashbacks, and rebates are sent automatically without manual claiming unless specified.  
    - Bonuses are credited within 12 hours after meeting conditions.  
    - System detection of activity such as using unique bank cards, phone numbers, or IP addresses influences bonus eligibility.

11. **Advise players on special bonuses like birthday or invite bonuses:**  
    - Birthday bonuses are available on the exact date of their birthday in the Rewards Center.  
    - Deposit invite bonuses are automatically distributed within 2 hours if eligible; verify that the invitation conditions have been met.

12. **If a player reports not receiving a bonus despite meeting all requirements:**  
    - Confirm the fulfillment of all conditions (deposit amount, VIP status, betting activity).  
    - Suggest they check their Rewards Center or wait for system processing.  
    - Offer to escalate the issue if the bonus remains undistributed after 12 hours.

13. **Close the inquiry with a summary and advice:**  
    - Remind players that bonuses are automatically credited when criteria are met.  
    - Encourage patience during high traffic periods.  
    - If issues persist, advise contacting support with relevant screenshots or proof of activity.

## Notes

- Bonuses, cashback, and rebates are distributed automatically by the system and do not require manual claiming, except where explicitly instructed (e.g., clicking “Claim” in Rewards Center).  
- VIP Weekly Salary bonuses are credited every Tuesday between 22:00 and 23:59 (GMT+8) if weekly deposit and activity requirements are fulfilled.  
- Ensure players meet the minimum deposit thresholds (e.g., 100 PHP for certain bonuses) and achieve the required VIP tier before expecting bonus distribution.

## Key points for communicating with players

- Always verify the player’s deposit history, VIP tier, and activity before providing explanations.  
- Reiterate the automatic nature of bonus distribution and the typical 12-hour processing window.  
- Remind players about specific requirements such as minimum deposits and activity levels for bonuses.  
- Encourage patience and offer escalation if discrepancies persist beyond the normal distribution window.