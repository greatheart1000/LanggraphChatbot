# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information regarding the specific bonus or benefit inquiry.**  
   - Confirm whether the player is a new player or VIP member.  
   - Ask for their registration details, including deposit history, VIP level, and activity history (bets, deposits).  
   - Verify relevant conditions such as deposit frequency, VIP tier, and gameplay activity according to the specific promotion or benefit they are inquiring about.  

2. **Determine the player's eligibility based on the promotion's criteria.**  
   - For promotions like the Free Angpao Daily: check if the player is a new download of the PLUSPH APP and VIP member.  
   - For bonuses such as the first deposit bonus, weekly salary, or birthday bonus: verify deposit amounts, VIP level (VIP3 for birthday bonuses), and VIP tier (VIP Weekly Salary requires at least 1 valid bet and a minimum deposit of 100 PHP during the week).  
   - For cashback or rebate promotions: confirm if distributions are automatic, and whether the player meets the relevant criteria.  
   - For Daily Angpao: check if logging in is within the time window (21:00-21:30 GMT+8).  
   - Ensure no violations such as multiple accounts, same IP, bank, or phone number are applicable, which could disqualify the player from eligibility.  

3. **Verify bonus or reward distribution conditions and system status.**  
   - Confirm if the bonus, cashback, or rebate is automatically sent by the system to the player's account once criteria are met.  
   - Check if the bonus/benefit has been credited within the standard period (e.g., 12 hours for first deposit bonus).  
   - For the VIP Weekly Salary: verify if the weekly bet and deposit conditions are met; if not credited, inform the player accordingly.  

4. **Check deposit activity and turnover requirements if relevant.**  
   - For players with fewer than 5 deposits since registration, confirm if they completed the 10x turnover requirement for the Free Angpao Daily (if applicable).  
   - For withdrawals related to the Free Angpao Daily: verify deposit and turnover conditions (e.g., if deposited more than 5x, the player can withdraw directly).  

5. **Explain to the player any reasons for non-receipt, if applicable.**  
   - If bonuses have not been received, ask if they have multiple accounts or share details about their bank, phone, or IP, which may lead to disqualification or reward confiscation.  
   - Clarify that bonuses are system-distributed and may take up to 12 hours to arrive once eligibility is confirmed.  
   - Educate that promotional rewards cannot be manually dispatched.  

6. **Advise the player on next steps or actions.**  
   - If eligible and bonuses have not been received within the expected time, inform the player to wait up to 12 hours or check their Rewards Center.  
   - If outstanding requirements are identified (e.g., making the necessary turnover, depositing multiple times), guide the player to fulfill these conditions.  
   - For any unusual issues (e.g., suspected account violation), escalate or escalate to the relevant department per protocols.  

7. **Document the interaction and status.**  
   - Record the player's eligibility check results, deposit and betting activity, and the bonus/reward status.  
   - Note any player requests or complaints and your recommended solutions or escalation points.  

8. **Close the case once resolved or after providing necessary information.**  
   - Confirm with the player that they understand the process or next steps.  
   - Offer additional assistance if needed.  

## Notes

- Bonuses, cashback, and rebates are automatically distributed once conditions are met; players are advised to check their Rewards Center or wait up to 12 hours.  
- Rewards such as the Daily Angpao can be claimed daily between 21:00-21:30 GMT+8, and the withdrawal eligibility depends on deposit frequency and turnover.  
- VIP status (VIP3 or higher) is required to qualify for Birthday Bonuses and some other VIP-exclusive offers.  
- Ensure all checks for multiple accounts, same IP, bank, or phone are performed, as these can lead to disqualification or reward confiscation.  

## Key points for communicating with players

- Clearly explain that bonus distributions are system-automated and have specific eligibility criteria.  
- Remind players about the importance of meeting minimum deposit, betting, or turnover requirements.  
- Inform players of the timeframes for bonus crediting (e.g., within 12 hours).  
- Warn players about possible disqualifications due to policy violations, such as multiple registration or same banking details.