# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry and determine the type of bonus or benefit they are referring to (e.g., Rescue Bonus, Birthday Bonus, Spin Bonus, VIP benefits, Monthly rewards, Angpao, etc.).**

2. **Verify the player's eligibility based on the specific bonus or benefit criteria:**
   - For Rescue Bonus:
     - Confirm the player has lost more than 100 PHP in Slot, Fish, or Arcade games.
   - For Birthday Bonus:
     - Check if the player is a VIP level 4 member.
   - For Spin Bonus:
     - Confirm the player has spun more than 50x in SLOT games (win or lose).
   - For VIP benefits or VIP-related bonuses:
     - Confirm the player has completed 2000 valid bets to qualify for VIP status.
   - For Monthly rewards:
     - Confirm the player logs in on the 3rd of the month.
   - For Monthly Kickback:
     - Confirm the player has deposited more than 100 PHP within the month.
   - For Angpao promotion:
     - Confirm the player has downloaded the PHSPIN App and is a VIP member; check deposit count if applicable.
   - For general promotions and bonuses:
     - Check if the bonus has been automatically distributed.

3. **Collect necessary player information if required for verification:**
   - For VIP birthday bonuses, obtain the username and verify identity with 2 valid IDs and a selfie with ID (if applicable).
   - For promotion-related bonuses requiring evidence, request screenshots or documentation as needed.  

4. **Check the system for automatic bonus distribution or rewards:**
   - Confirm if the bonus, cashback, or benefit has been credited to the player's account.
   - All bonuses and promotions are automatically distributed within a specified timeframe (usually within 12 hours unless specified otherwise).

5. **If bonus or reward has not been received:**
   - Verify that the player has met all eligibility criteria:
     - Minimum deposit of 100 PHP within the qualifying period.
     - Completion of required activity (e.g., number of spins, bets).
   - Ensure the player has checked the correct Rewards or Bonus Center sections.
   - Remind the player that bonuses like Rescue Bonus are automatically delivered the next day before 16:00 (GMT+8) or 16th of each month for Kickback.

6. **For bonuses that require player action (e.g., claiming from Bonus Center):**
   - Guide the player to visit the Bonus Center to claim rewards, especially for Monthly Kickback and Monthly Rewards.
   - Emphasize to claim before the specified deadline (e.g., before 10:00 PM (GMT+8) for Monthly rewards).

7. **For progressive or tiered VIP benefits:**
   - Confirm the player’s VIP level and activity status.
   - Explain the benefits available at the current VIP level, such as Upgrade Bonus, Weekly Salary, Birthday Gift, etc.
   - Advise on how to maintain or improve VIP status (e.g., make deposits, place valid bets).

8. **If the player qualifies but has not received a bonus (e.g., VIP birthday bonus):**
   - Instruct them to provide necessary verification details if they haven't already done so.
   - Confirm submission and wait for automatic distribution, or advise to check the Rewards Center.

9. **For issues or discrepancies:**
   - Collect relevant details and screenshots if needed.
   - Escalate the case following internal procedures if there is a system error or unresolved eligibility issue.

## Notes
- All promotions, bonuses, cashback, and rebates are distributed automatically and within specified timeframes. 
- Bonuses are randomly distributed according to system rules, and amounts may vary.
- VIP bonuses, including weekly salary and birthday gifts, are credited automatically if conditions are met.
- For bonuses such as Rescue Bonus, the bonus is delivered the next day before 16:00 (GMT+8).
- Players must reach the designated VIP level or activity milestones to qualify for specific benefits and bonuses.
- Ensure players understand that all bonuses are subject to the company's policies and may require verification for certain promotions.

## Key points for communicating with players
- Always verify eligibility based on concrete criteria (e.g., VIP level, deposit amounts, specific activities).
- Confirm and remind players of deadlines for claiming bonuses in the Bonus Center.
- If bonuses have not been received, double-check the player's activity and eligibility and instruct accordingly.
- Collect verification materials for VIP birthday bonuses or promotion-specific requirements when needed.
- Be clear that all bonuses and rewards are automatically distributed by the system within specified timeframes and that external claims are generally unnecessary unless an error occurs.