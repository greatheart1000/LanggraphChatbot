# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or request regarding bonuses or rewards.**  
   - Determine if the player is asking about specific bonuses (e.g., Bet on SLOT, FISH & POKER Bonus, Birthday Bonus, VIP Weekly Salary, Angpao, or other promotional rewards).  
   - Confirm the type of bonus or benefit the player seeks.

2. **Gather necessary player information.**  
   - Verify the player's username.  
   - Collect details of recent activity: deposits, bets, VIP level, and eligible criteria such as account verification status, deposit counts, and turnover.

3. **Check the player's eligibility for the specific bonus or reward.**  
   - For Bet on SLOT, FISH & POKER Bonus: confirm the player has bet more than 1500 PHP in eligible games. Bonus will be delivered automatically the next day before 4:00 PM (GMT+8).  
   - For Birthday Bonus: verify if the player's VIP level is VIP3 or higher.  
   - For Daily Bonuses, Rewards, and Lucky Spin: confirm the player has deposited at least 800 PHP and met the betting condition of 8000.  
   - For VIP Weekly Salary: ensure the player has completed at least one valid bet on slot or fish within the week, and has made a minimum deposit of 100 PHP during the week. Check VIP tier for higher rewards.  
   - For 24Pcs Angpao Daily Promotion: confirm deposit frequency (5 or more times since registration for direct withdrawal; fewer than 5 requires turnover completion).  
   - For other promotional rewards: verify the criteria as specified (e.g., account verification, ID submission, selfie, etc.).

4. **Perform system checks for bonus distribution.**  
   - Confirm eligibility based on system data; bonuses, cashback, rebates, and rewards are automatically distributed once criteria are met.  
   - If the bonus should have been credited automatically but hasn't been received, check for possible ineligibility (e.g., unmet criteria, late distribution, or account issues).

5. **If eligibility is confirmed and bonus has not been received when expected:**  
   - Advise the player that the reward will be delivered automatically if system conditions are satisfied.  
   - If the bonus is overdue or evidence of eligibility exists but reward not received, escalate for further investigation.

6. **If eligibility conditions are not met:**  
   - Clearly explain that the player does not qualify for the relevant bonus, providing specific reasons based on their activity or VIP level.  
   - For example, if the player has not reached VIP3, inform them that Birthday Bonus is only available to VIP3 or higher.

7. **Assist with documentation or verification for special bonuses.**  
   - For VIP Birthday Bonus or VIP-related rewards, request necessary documents: Username, 2 valid IDs, and a selfie with ID.  
   - Guide the player through the submission process, ensuring all documentation clearly matches account details.

8. **Provide guidance on additional requirements or edge cases.**  
   - Remind players that bonuses are automatically credited if conditions are met, but account verification and proper documentation are required for certain bonuses like birthday or VIP-related offers.  
   - Warn players that multiple IP addresses or identical bank cards may affect bonus eligibility.

9. **Communicate clearly about bonus timing and distribution.**  
   - Inform players that rewards such as VIP Weekly Salary are credited automatically every Sunday between 22:00 - 23:59 (GMT+8).  
   - For daily promotions like Angpao, explain reward timing and withdrawal conditions.

10. **Conclude the case:**
    - Confirm the player understands their current bonus status and requirements for future eligibility.  
    - Offer further assistance if needed or escalate the case if discrepancies or issues persist.

## Notes

- Bonuses, cashback, rebates, and rewards are system-distributed once eligibility criteria are met.  
- Always verify VIP status, deposit history, and activity details when applicable.  
- For bonuses requiring document submission, follow the specific verification steps, including providing username, valid IDs, and selfies as specified.  
- Be aware that certain bonuses are limited to VIP3 or higher levels, or require minimum deposits and activity thresholds.  
- If a bonus isn’t received despite meeting conditions, escalate for system review or further investigation.

## Key points for communicating with players

- Clearly state that bonuses are automatically credited once eligibility is confirmed.  
- Explain any requirements such as deposit amounts, VIP levels, or document submissions upfront.  
- Remind players of the timing of auto-distributions, especially for weekly and daily rewards.  
- Be transparent about potential delays or system checks.