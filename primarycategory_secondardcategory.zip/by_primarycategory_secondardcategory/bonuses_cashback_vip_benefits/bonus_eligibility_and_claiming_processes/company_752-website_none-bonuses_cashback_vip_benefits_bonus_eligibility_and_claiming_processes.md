# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue regarding bonuses, cashback, or VIP benefits**.  
   - Ask the player for details about the specific promotion, bonus type, or reward they are concerned with.  
   - Clarify if the issue relates to bonus receipt, eligibility, distribution timing, or claiming process.

2. **Verify the player's account details**.  
   - Check the player's account ID, VIP level, recent activity, and deposit history.  
   - Confirm if the player has completed the minimum deposit requirement (e.g., at least 100 PHP for certain bonuses).  
   - Review the player's recent bets, especially on qualifying games like slots or fish, to determine eligibility for VIP Weekly Salary or other rewards.

3. **Determine the player's eligibility based on automatic system criteria**.  
   - For bonuses and rebates:  
     - Confirm if the player is eligible for bonuses or cashback based on system records.  
     - Bonuses, cashback, and rebates are automatically sent to eligible players' accounts within a 12-hour window.  
   - For VIP bonuses, verify the player's VIP level and total bet requirements:  
     - VIP bonuses require reaching specific VIP level requirements and completing total bet targets to qualify for rank upgrade bonuses.  
     - For VIP Weekly Salary: confirm the player made at least 1 valid bet on slot or fish and deposited at least 100 PHP within the week.

4. **Check the distribution status of bonuses and rewards**.  
   - Examine if the bonus or rebate has been automatically credited to the player's account.  
   - For cashback:  
     - Confirm if it has been received automatically; if not, inform the player it might be pending or not eligible.  
     - Rebate of up to 3% is sent automatically, usually before 4:00am [GMT+8] the next day.  
   - For weekly VIP salary and event rewards:  
     - Verify if the rewards have been credited during scheduled hours (e.g., Rewards Center on Thursday 22:00-23:59 GMT+8 for the weekly salary).  
     - If not received, check if the player met all qualifying conditions.

5. **Advise the player on how to claim the bonus or reward if applicable**.  
   - For system-distributed bonuses and rebates, no manual claim is usually necessary.  
   - If a bonus must be claimed manually (e.g., promotional rewards shown in the Rewards Center), instruct the player to log in during the designated claim period and follow the claim process in the Rewards Center.  
   - For bonuses requiring documentation or verification (e.g., birthday bonuses),  
     - Ask for the relevant verification (e.g., ID, selfie) as per instructions.  
     - Ensure the player submits required screenshots if requested.

6. **Handle cases where the bonus or reward is not received or the player is ineligible**.  
   - Confirm the player’s activity history and eligibility conditions:  
     - If the player hasn't met the minimum deposit, bet, or VIP level criteria, explain accordingly.  
     - If the player did not log in on the designated day for specific bonuses (e.g., Sunday reward), inform them of the timing requirements.  
   - If the bonus is only applicable on specific dates (e.g., birthday), verify the date of birth or login date.  
   - If system delay or error is suspected, advise the player that bonuses are distributed automatically within the specified timeframe and suggest to wait or check again later.

7. **Escalate or recommend further action if needed**.  
   - If the bonus or reward was not received despite eligibility and the scheduled distribution time:  
     - Ask the player to provide relevant screenshots or proof of activity/eligibility if verification is needed.  
     - Escalate the case to the technical team or supervisor if a system error is suspected.  
   - If the player did not meet the conditions, politely inform them of the requirements for future eligibility.

8. **Close the case with a summary, confirming the current status**.  
   - Inform the player of the current status of their bonus or reward.  
   - If the bonus is pending, advise them to check back later.  
   - Provide guidance on the next steps or encourage further engagement for future rewards.

## Notes

- All bonuses, cashback, rebates, and rewards are distributed automatically within the specified timeframes once eligibility criteria are met.  
- Bonuses on specific days, such as Sunday or birthdays, require the player to log in on the designated day and meet additional requirements (e.g., verification, active VIP status).  
- VIP Weekly Salary is credited to the Rewards Center every Thursday between 22:00 and 23:59 GMT+8, contingent upon the player making at least 1 valid bet and a deposit of at least 100 PHP within the week.  
- Rewards like cashback bonuses of up to 3% are sent before 4:00am [GMT+8] the following day, automatically if eligible.  
- No manual adjustments or programming are involved; system distribution rules govern all bonus distributions.