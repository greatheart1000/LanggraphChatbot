# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry and verify their account status.**
   - Confirm if the player is a new or existing customer.
   - Collect sufficient account information for further checks (e.g., account name, email, mobile number).

2. **Verify the player's eligibility for bonuses or rewards.**
   - For new members: Ensure the account has completed KYC verification and registration steps.
   - For existing members: Confirm they are eligible according to current promotion terms.
   - Check if the player has completed any required actions to qualify for specific bonuses (e.g., registration, active status).

3. **Determine the specific bonus or reward the player is inquiring about.**
   - For the 28P Bonus code:
     - Confirm the player has a valid redemption code.
     - Check if they meet the bonus terms:
       - Limited to 1 redemption per user per month.
       - Has a linked mobile number.
       - Has deposited at least ₱100 on the event day.
       - Is KYC-verified.
     - Verify if the code is still within the redemption limit (first 1,500 redemptions).
   - For rebates:
     - Confirm whether the player has claimed any bonus (since rebate claims are not available together with bonuses).
   - For other rewards or VIP benefits:
     - Verify according to current promotional criteria or VIP level rules.

4. **Check the player's current bonus, cashback, or reward status in the system.**
   - Access the account's bonus or rewards history.
   - Verify if the bonus or cashback has been claimed or received.
   - Check any expiration periods (e.g., bonuses expire after 7 days).

5. **Perform the necessary system operations to validate and process the claim.**
   - For bonus claims:
     - Ensure all qualifying conditions are met.
     - Confirm the bonus has not been redeemed more than once this month.
     - Check if the bonus has been activated and is eligible for wagering.
   - For rebate processing:
     - Confirm the rebate is calculated daily (00:00 to 23:59 GMT+8).
     - Verify the player has completed a 1x turnover requirement before withdrawal.
   - For VIP or special reward inquiries:
     - Verify the player’s current VIP level and reward eligibility based on the latest criteria.

6. **Explain to the player the current status and any requirements for claiming or withdrawing.**
   - If eligible, instruct on how to claim the bonus via the Rewards Center.
   - If not eligible or conditions are unmet:
     - Clearly state the reason (e.g., no active bonus, unmet deposit, account verification pending, bonus expired).
     - Advise on actions needed to meet requirements in the future.
   - If the player is eligible but the bonus is not yet available:
     - Inform about timing or steps for activation.

7. **Assist with further actions or escalate if necessary.**
   - Guide the player through the process of claiming a bonus if applicable.
   - Escalate to higher support if issues involve account verification, technical errors, or unresolved eligibility doubts.

## Notes
- For all bonuses, KYC verification and a minimum deposit (e.g., ₱100) are often required.
- Bonuses are generally limited to one redemption per user per month and expire after a specific period (e.g., 7 days).
- Rebate is credited the day after calculation and cannot be claimed if a bonus has been claimed during the same period.
- Ensure clear communication that existing customers are typically not eligible for the new member bonus, and verify the display of verification or activity prerequisites when applicable.

## Key points for communicating with players
- Always confirm account verification (KYC) and deposit requirements first.
- Clarify the timing and limits for redemptions (e.g., first 1,500 redemptions, one per user/month).
- Emphasize expiration periods (e.g., bonuses expire after 7 days).
- Clearly explain that rebates cannot be claimed if a bonus has been claimed.
- When players inquire about VIP benefits, verify their current VIP level and eligibility according to current rules.