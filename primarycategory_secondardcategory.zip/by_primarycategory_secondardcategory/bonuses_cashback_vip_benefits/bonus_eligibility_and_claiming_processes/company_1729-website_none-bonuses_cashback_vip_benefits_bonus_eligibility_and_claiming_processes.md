# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify the player's account and bonus eligibility**  
   - Check if the player has completed the necessary verification steps, as bonuses are credited automatically after verification (per FAQ).  
   - Confirm that the player has not been flagged for multiple accounts from the same IP or device, as this is prohibited for bonus eligibility.

2. **Identify the specific bonus or promotion the player is interested in**  
   - Ask the player if they want to participate in a current promotion or if they have an existing bonus.  
   - If they do not see a bonus options list, instruct them to make a deposit and contact customer support if assistance is needed.

3. **Guide the player to participate in bonus offers**  
   - Instruct the player to go to the deposit section and select an amount.  
   - Advise the player to choose a bonus from the available list in the deposit menu.  
   - If the desired bonus is not visible, advise them to make a deposit and then contact support to facilitate bonus eligibility.

4. **Collect information on bonus rewards received**  
   - Confirm if the bonus was credited successfully by checking the player's bonus section or system records.  
   - Remind the player that bonuses are usually received after completing promotional steps such as following social media pages, sharing posts, or submitting screenshots via live chat (if applicable).

5. **Explain bonus restrictions and valid usage**  
   - Inform the player that bonuses can only be used on designated games (e.g., slot, jelly).  
   - Remind the player of maximum withdrawal limits (e.g., 1,000 Taka or PHP) and that bonuses are valid for a single use.  
   - Clarify that each bonus is subject to specific wagering requirements that must be met before withdrawal, with the particular multiple depending on the promotion (e.g., 10x, 25x).

6. **Check the player's wagered amount and completion of wagering conditions**  
   - Access the player's wagering status to confirm if the required turnover has been achieved.  
   - Verify that the bonus amount has been wagered the necessary number of times as per the promotion's rules.

7. **Authorize withdrawal if conditions are met**  
   - Once the wagering conditions and maximum withdrawal limit are satisfied, inform the player they can proceed with withdrawal.  
   - Ensure withdrawal is processed within the platform's policies and confirm the player understands the limits (e.g., up to 1,000 PHP).

8. **Handle cases of insufficient or incorrect information**  
   - If the player has not completed verification, inform them that bonuses are credited after verification.  
   - If the bonus has not been wagered the required times, explain that they must meet the wagering requirements before withdrawal.  
   - If the bonus is outside the permitted games or exceeds the maximum withdrawal limit, advise accordingly or escalate if necessary.

## Notes

- Bonuses are credited automatically after completing verification steps.  
- Bonuses are only usable on designated games, typically slots or specific live casino games.  
- The maximum withdrawal limit for bonus winnings is generally specified (e.g., 1,000 Taka or PHP).  
- Wagering requirements (e.g., 10x, 25x) must be fulfilled before a withdrawal can be processed.  
- Multiple accounts or using the same device/IP for bonus eligibility is prohibited.

## Key points for communicating with players

- Emphasize that bonuses are credited after verification and meeting promotional criteria.  
- Clearly explain the wagering requirements and maximum withdrawal limits related to bonuses.  
- Assist players in completing necessary steps such as making a deposit or submitting screenshots for rewards.  
- Keep the player informed about their wagering progress and when they qualify for withdrawal.