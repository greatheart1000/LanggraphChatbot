# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry and clarify the bonus or benefit in question.**
   - Example: First Deposit Bonus, VIP Weekly Salary, birthday bonus, monthly bonus, or promotion-related bonus.
   - Collect necessary preliminary details: player's username or account ID.

2. **Check the player's current account status and eligibility based on the bonus type.**
   - Verify if the player is VIP, VIP level, or eligible for specific bonuses (e.g., VIP3 for birthday bonus).
   - Confirm if the player has completed necessary activities, such as betting requirements or registration details.

3. **Review the specific eligibility criteria and conditions for the bonus.**
   - For First Deposit Bonus:
     - Confirm deposit made and check for potential disqualifiers:
       - Binding same bank card
       - No mobile phone number linked
       - Using same phone number or multiple IP addresses
   - For VIP Weekly Salary:
     - Verify if the player completed at least 1 valid bet on slot or fish within the week.
     - Check if the deposit meets any minimum threshold (if applicable).
   - For birthday bonuses:
     - Confirm the player is VIP3 and has provided valid IDs, username, and a selfie holding ID.
   - For monthly bonuses and other promotions:
     - Determine if the player logged into the Rewards Center on the 7th or eligible date.
     - Check for detection of repeated use from the same IP, bank card, or phone number.

4. **Perform system checks for distribution and processing status.**
   - Confirm bonuses, cashback, and rebates are automatically processed and sent by the system.
   - Verify whether the bonus has been credited to the player's account.
   - Note that bonuses are typically distributed within a 12-hour timeframe after eligibility confirmation.

5. **If the bonus has not been received, assess reasons based on conditions.**
   - For missing First Deposit Bonus:
     - Possible reasons include disqualification due to same bank card, mobile number, IP address, or other detection flags.
   - For other bonuses:
     - Confirm whether the player has met all prerequisites and no detection issues are present.

6. **Advise the player on necessary actions or next steps.**
   - If eligible and bonus not received:
     - Inform that the system automatically distributes bonuses and they should wait up to 12 hours.
     - Remind the player to ensure all criteria are met in future deposits or activities.
   - If not eligible:
     - Explain the specific reason based on the checks (e.g., did not complete betting requirement, disqualified due to account linking rules).
   
7. **Handle special cases requiring additional verification or player upload of documents.**
   - For birthday bonuses:
     - Instruct the player to provide username, two valid IDs, and a selfie with their ID for identity confirmation.
   - For other cases:
     - Escalate if necessary, especially if the system flags or detection triggers are involved.

8. **Document the case and resolution details.**
   - Record the player's information, reason for bonus non-receipt (if applicable), and any actions taken.
   - Follow up if required and ensure the player is aware of ongoing processes or verification steps.

## Notes
- All bonuses, cashback, and rebates are automatically distributed once eligibility criteria are fulfilled.
- Bonuses are usually credited within 12 hours of eligibility.
- Requiring players to log in to the Rewards Center or provide additional verification is essential for certain bonuses (e.g., birthday, monthly).
- Detection of same bank card, phone number, IP address, or repeated use may disqualify the player from receiving bonuses.
- For the VIP Weekly Salary and monthly bonuses, ensure activity requirements are completed before the bonus is credited.

## Key points for communicating with players
- Clearly explain that bonuses are automatically distributed by the system after eligibility is confirmed.
- Emphasize the 12-hour timeframe for bonus distribution.
- Remind players to meet all activity or registration requirements for their specific bonuses.
- Guide players to provide necessary verification documents promptly for identity-based rewards.
- Inform players about potential disqualifiers based on account linkage or detection flags.