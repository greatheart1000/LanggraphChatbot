# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player's account information**  
   - Verify the player's identity and VIP level if applicable (e.g., VIP1, VIP2, etc.).  
   - Confirm the details of the bonus or cashback the player is inquiring about, including the type (e.g., regular bonus, cashback, VIP bonus, special event promotion).

2. **Check automatic bonus awarding criteria**  
   - Confirm that bonuses are awarded automatically based on activity such as deposits, wagers, or participation in specific events.  
   - Verify if the player has met the specific requirements for the bonus in question, including deposit amounts, wagering thresholds, or activity participation.

3. **Review eligibility based on activity and thresholds**  
   - For VIP bonuses: Check if the player has wagered at least 2000 on slots or the specified amount on other games, as required for first-level VIP bonus eligibility.  
   - For weekly or monthly bonuses: Ensure the scheduled time frame has passed (e.g., after Monday noon for weekly bonuses, after midnight on the 1st for monthly bonuses).  
   - For special event promotions (e.g., milestone days, Wednesdays): Confirm the player's participation and compliance with event criteria.

4. **Verify that the bonus has been credited automatically**  
   - Check the system to see if the bonus or cashback has been credited to the player's account according to the schedule.  
   - Ensure the player qualifies under the current site configuration for ongoing rewards (e.g., active VIP status).  
   - Confirm no additional manual claim is required as bonuses are awarded automatically.

5. **If the bonus or cashback is not credited as expected:**  
   - Confirm the player has satisfied all required conditions for the specific promotion.  
   - Check for any restrictions such as inactivity, insufficient wagered amounts, or eligibility periods.  
   - If conditions are not met, inform the player accordingly and advise on how to qualify in the future.

6. **Handle special bonuses (e.g., birthday, referral):**  
   - For birthday bonuses: request valid identification (birth certificate, passport, voter ID).  
   - For referral bonuses: verify that the referred friend registered through the player's referral link and met deposit requirements.  
   - Confirm eligibility and inform the player of any additional steps if needed.

7. **Escalate or provide further assistance if:**  
   - There are technical issues preventing bonus crediting.  
   - The player claims to meet all criteria but the bonus is not credited.  
   - The player requests manual claiming or clarification beyond automatic processes.

## Notes

- Bonuses are credited automatically; players do not need to manually claim most bonuses unless instructed otherwise.  
- Maintain VIP levels and active participation to qualify for ongoing rewards like weekly/monthly bonuses.  
- Ensure compliance with specific requirements such as minimum wagering amounts (e.g., 2000 on slots for VIP bonuses).  
- Special event bonuses depend on participation and meeting event-specific criteria.

## Key points for communicating with players

- Clearly explain that bonuses are awarded automatically based on activity and meeting specific criteria.  
- Remind players to ensure their activities (deposits, wagers) meet the required thresholds for their VIP level or promotion.  
- For missing bonuses, verify eligibility and inform players about the automatic credit schedule.  
- Request additional documentation or escalate if technical issues or discrepancies are suspected.