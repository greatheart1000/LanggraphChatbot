# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or request regarding bonuses, cashback, or VIP benefits.**  
   - Verify whether the player is asking about eligibility, claiming processes, or specific bonuses like birthday bonuses, weekly salary, or Angpao daily bonuses.

2. **Determine the player's VIP level and relevant eligibility criteria.**  
   - If the player requests the Birthday Bonus, confirm they are VIP3 or above.  
   - For VIP Weekly Salary, ensure the player meets the requirement of a minimum deposit of 100 PHP within the week and maintains their VIP tier level.  
   - For Angpao Daily, check that the player is a new user registered through the official site and app, and meets deposit/turnover conditions.

3. **Request necessary identification and verification details for bonus claims that require verification.**  
   - For the Birthday Bonus or other VIP-specific bonuses, ask the player to provide:  
     - Username  
     - Two valid IDs showing their birthday or relevant verification details  
     - A selfie holding a valid ID (when applicable)  
   - Inform the player that these details are needed to distribute the bonus if applicable.

4. **Check the player's eligibility based on their VIP status, deposit history, and provided information.**  
   - Review VIP status in the player account.  
   - Verify the deposit amount for the current week (must be ≥100 PHP for VIP Weekly Salary).  
   - Confirm the account's compliance with site policies (e.g., not using repeated IP, bank card, or phone number to avoid confiscation risks).

5. **Verify the player's registration, deposit, and turnover requirements for applicable bonuses:**
   - For **First Deposit Bonus**: Ensure the deposit is ≥100 PHP, and bonus is credited automatically within 12 hours.  
   - For **Second Deposit Bonus**: Similar deposit and automatic credit process.  
   - For **New User Angpao Daily**: Confirm registration, app download, and daily deposit and turnover conditions (depositing more than 5x since registration for direct withdrawal, or completing 10x turnover otherwise).  
   - For **Birthday Bonus**: Confirm VIP3 status, and that verification details are provided.

6. **Inform the player about the bonus application and any relevant rules:**
   - Bonuses are subject to turnover (playthrough) requirements before withdrawals.  
   - Bonuses and cashback are distributed automatically when conditions are met.  
   - Bonuses may be confiscated if policy violations are detected (e.g., repeated IP, bank card, or phone number).  
   - Higher VIP tiers unlock higher rewards, including the VIP Weekly Salary.

7. **Guide the player on how to claim bonus or benefit through the platform:**
   - For **birthday bonus**: Instruct to go to the Rewards Center in the app.  
   - For **VIP Weekly Salary**: Note that it is credited automatically every Thursday between 22:00 and 23:59 (GMT+8).  
   - For **Angpao Daily**: Notify the player to check their Rewards Center for daily rewards.

8. **If verification details are required, collect and submit the information via the appropriate system or escalate if necessary.**  
   - Ensure all details are clear, legible, and compliant with verification instructions.  
   - Follow the internal process for submitting verification documents.

9. **Explain to the player that if the bonus or cashout is not received, they should check whether they met all requirements (e.g., VIP tier, deposit, turnover).**  
   - If in doubt, guide them to review their account activity or contact support for further assistance.

10. **Close the case once the player confirms receipt or understands the process, or escalate if issues prevent bonus approval.**  
    - Advise the player on next steps if their eligibility or claim process is incomplete or flagged.

## Notes
- The VIP Birthday Bonus is only for VIP3 members, and verification (ID + selfie) is required before distribution.
- The VIP Weekly Salary is only credited if the weekly deposit of ≥100 PHP is met.
- The New User Angpao Daily bonus requires registration via the site and app, with specific deposit and turnover conditions.
- Bonuses are automatically distributed; manual intervention may be required for verification or issues.
- Always confirm the player's VIP status before discussing VIP-specific bonuses or benefits.

## Key points for communicating with players
- Clarify that bonuses are subject to turnover requirements before withdrawal.  
- Confirm their VIP level for VIP-exclusive bonuses.  
- Emphasize that bonuses may be confiscated if policies are violated.  
- Guide them to the Rewards Center for claiming and checking bonuses.