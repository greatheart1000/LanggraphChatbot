# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information**
   - Confirm the player's account details, VIP level, and promotion history.
   - If the player mentions a specific bonus or reward, identify its name or type to verify eligibility criteria.

2. **Verify bonus eligibility conditions**
   - Check if the player has met the necessary requirements for the bonus or reward they are claiming, such as:
     - Minimum deposit amount (if applicable).
     - Successful completion of specific betting or wagering requirements.
     - Participation in the promotion, deposit, or activity within the specified timeframe.
   - For VIP-related bonuses, ensure their current VIP level qualifies for the reward.
   - Confirm if the promotion has any restrictions such as maximum limits or special conditions.

3. **Perform system checks for automatic crediting**
   - Use the back-office system to review whether the bonus or reward has been automatically credited.
   - Verify if the bonus is pending or has already been credited.
   - Confirm the status of referral bonuses:
     - Check that the referred player has registered via the referral link.
     - Ensure the referred player has completed their deposit and betting requirements.
   - For weekly or monthly rewards, verify the player's activity and VIP standing, as these are automatically reviewed and credited on designated days.

4. **Assess whether manual intervention is necessary**
   - If the bonus has not been credited despite the player meeting all criteria:
     - Confirm that the account information is complete and correct.
     - Check if any verification or additional review is required.
   - If verification is needed, escalate the case according to internal procedures.

5. **Inform the player of the result**
   - If bonus/ cashback / VIP benefit is credited:
     - Advise the player that the reward has been successfully credited to their account.
   - If there are restrictions or if the bonus is not credited:
     - Explain that the reward can only be claimed after fulfilling the specific requirements.
     - Clarify any restrictions affecting their eligibility, such as VIP level, deposit amount, or specific activity requirements.
   
6. **Document the interaction**
   - Record details of the verification process, findings, and any player communications.
   - Note the date, bonus type, and current status.

7. **Close the case**
   - Ensure the player understands the outcome.
   - Offer additional assistance if needed.
   - Confirm there are no further actions required.

## Notes
- All weekly and monthly rewards are automatically reviewed and credited based on VIP level and activity participation.
- Referral bonuses are credited after the referred player registers via your referral link, deposits, and completes betting, typically before 12 PM the next day.
- Bonuses are automatically credited once the deposit and betting requirements are met, with no manual intervention required unless system errors occur.
- Always ensure that the player’s account information is accurate to avoid delays in bonus crediting.

## Key points for communicating with players
- Confirm the specific bonus or reward they are referring to.
- Explain that bonuses are awarded automatically after meeting the necessary conditions.
- Inform the player that if their bonus has not been credited despite fulfilling requirements, they should check their account details and wait until the designated crediting days.
- If necessary, escalate the case for further verification or technical review.