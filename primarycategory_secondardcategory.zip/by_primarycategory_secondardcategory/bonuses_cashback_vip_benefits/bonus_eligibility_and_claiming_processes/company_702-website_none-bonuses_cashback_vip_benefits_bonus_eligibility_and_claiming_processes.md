# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue related to bonuses, cashback, or VIP benefits.**
   - Determine whether the player is asking about a specific promotion, general eligibility, claiming process, or a missing bonus.
   - Collect relevant player information: account ID, registration date, recent activity, deposit history, and VIP level.

2. **Verify the player's account status and eligibility for the specific bonus or benefit in question.**
   - Check if the player has met the basic eligibility criteria such as:
     - Registration as a new member (for register bonuses).
     - Recent activity and deposits (for bonuses like second cash-in bonus).
     - Specific game activity (slots, fish, or card bets) for Lose on Slots bonuses.
   - Confirm whether the player has linked a valid mobile phone number and used a distinct bank card if relevant.
   - For bonuses requiring account verification, ensure the account is fully verified.

3. **Assess eligibility based on specific bonus conditions as per the FAQs.**
   - For **Winning Bet Bonus**:
     - Verify the player has achieved wins on Slot, Fish, or Card bets.
     - Confirm win amounts surpass minimum thresholds (300 PHP, 600 PHP, 1000 PHP, 3000 PHP, etc.).
   - For **Lose on Slots Bonuses**:
     - Confirm losses on bets, since bonuses are triggered by losses and credited automatically.
   - For **New Register Bonus**:
     - Check if the player is a new member eligible within the specified timeframe.
   - For **Second Cash-in Bonus**:
     - Confirm the second deposit of 100 PHP was made.
     - Ensure the bonus has been credited automatically within 12 hours.
   - For **Promotions and Cashback**:
     - Verify eligibility based on deposit amount, activity, or system-detected criteria.

4. **Check the system to confirm whether the bonus, cashback, or rebate has been credited.**
   - Review the Rewards Center or account transaction history.
   - If the bonus was not credited within the expected time (e.g., 2 hours for new register bonus or 12 hours for cash-in bonus), note that as a potential issue.

5. **If eligible but bonus not received:**
   - Inform the player that bonuses and cashback are automatically distributed once eligibility criteria are met.
   - Recommend they wait up to the specified timeframes (e.g., 2 hours for registration bonus, 12 hours for second cash-in bonus, or until the next day between 04:00-06:00am for Win or Lose bonuses).
   - Ask the player to check the Rewards Center or account balance again after the recommended waiting period.

6. **If the player is ineligible due to missing criteria or verification issues:**
   - Clearly communicate the possible reasons:
     - Using the same bank card for multiple accounts.
     - Not having a linked mobile phone number.
     - Sharing the same IP address with other accounts.
     - Not meeting wagering or activity requirements.
   - Advise the player to complete required verification steps, like linking a mobile number or using a different bank card if applicable.
   - If the player’s account is unverified or incomplete, direct them to complete verification before further bonus claims.

7. **If the player claims to have met the criteria but still did not receive the bonus:**
   - Encourage the player to wait for system processing times.
   - If the bonus still does not appear after the specified time, escalate the case to technical support or escalate for further investigation.

8. **Provide guidance on how to claim bonuses or cashback manually if applicable.**
   - For bonuses like Lose on Slots, instruct them to visit the Rewards Center the next day between 04:00-06:00am to see if the bonus has been credited.
   - For cashback or rebates, advise visiting the Rewards/Cashback area to confirm manual claim options, if any.

9. **Advise players on the terms and conditions related to bonuses:**
   - Bonuses are generally subject to wagering requirements (e.g., must be turned over before withdrawal).
   - Bonuses are distributed automatically based on eligibility criteria.
   - Promotional offers may have specific time frames and maximum withdrawal amounts (e.g., 100 PHP for non-deposit new users).

10. **Document the case and inform the player of next steps if issues persist.**
    - Record any errors or system delays.
    - Suggest contacting support with relevant details if the bonus remains uncredited beyond the expected period.
    - Reiterate that system automatically distributes bonuses and that eligibility verification is essential.

## Notes

- Always verify the player's account status and recent activity before providing a resolution.
- Remind players that bonuses are automatically credited once criteria are met; manual claims are typically unnecessary.
- Confirm timing windows for automatic distribution (e.g., 2 hours for registration bonus, 12 hours for second cash-in bonus, next day 04:00-06:00 for Win/Lose bonuses).
- When players report not receiving a bonus, check for common eligibility issues, such as unlinked mobile numbers, shared IPs, or verification status.

## Key points for communicating with players

- Clearly explain that bonuses are automatically distributed once they meet the eligibility requirements.
- Remind players to check the Rewards Center or account balance after the specified timeframes.
- Advise patience and wait times for automatic bonus crediting.
- Encourage players to complete all required verification steps to ensure eligibility.
- If necessary, escalate cases that do not resolve after the designated waiting periods.