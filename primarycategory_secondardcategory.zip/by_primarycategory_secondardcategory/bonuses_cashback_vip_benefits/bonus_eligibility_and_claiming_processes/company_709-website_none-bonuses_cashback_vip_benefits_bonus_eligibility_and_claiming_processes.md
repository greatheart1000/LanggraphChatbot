# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify the player's inquiry or request regarding bonuses, cashback, or VIP benefits.**  
   - Ask the player for their current VIP level, deposit history, recent activities, and specific bonus or promotion they are referring to.  
   - Confirm which bonus or reward the player is seeking to clarify eligibility and process.

2. **Check the player's current VIP status and recent activity.**  
   - Verify VIP level upgrades. After upgrading VIP level, there is a 24-hour waiting period to receive the VIP bonus.  
   - If the player has recently upgraded and the bonus is not received within 24 hours, advise them to contact customer support for manual addition.

3. **Review the player's deposit and betting history to assess eligibility.**  
   - Confirm if minimum deposit requirements are met (e.g., deposit of at least 200 PHP for referral bonuses).  
   - Check if the player has completed the required turnover or wagering (e.g., 10x for second deposit bonus, 20x for other bonuses).  
   - Ensure account linking (bank or e-wallet) is correctly set up if applicable.

4. **Determine bonus availability and distribution status.**  
   - Understand that all bonuses, cashback, rebates, and rewards are automatically sent by the system once eligible.  
   - Verify if the bonuses or rewards have been credited in the Rewards Center or player's account balance within the expected timeframe (e.g., within 12 hours).

5. **Assess if the player has fulfilled specific promotional criteria.**  
   - For the VIP Weekly Salary bonus, check whether the player deposited a minimum of 100 PHP within the week and whether the bonus period (Saturday 22:00–23:59 GMT+8) has passed.  
   - For referral bonuses: confirm the deposit of at least 200 PHP, account linking, and sharing of referral links to qualify for Angpao bonus.

6. **If the player claims a bonus that should be system-distributed but is not received:**
   - Verify eligibility and whether the timeframe has elapsed.  
   - If eligible but bonus not credited, advise the player to contact customer support for manual assistance, especially for VIP bonuses or bonuses with a waiting period.

7. **Explain the bonus claim process or distribution details to the player:**  
   - Inform that bonuses are automatically credited once all conditions are met.  
   - For specific bonuses (like registration or second deposit bonuses), instruct the player to log in during the designated time, meet the deposit and turnover requirements, and click the claim button in the Rewards Center if required.

8. **For system-generated bonuses (e.g., cashback, rebates, VIP Weekly Salary):**  
   - Confirm that the player has met all criteria, including VIP tier requirements and minimum deposits.  
   - If the bonus has not been credited, advise to wait until the next scheduled distribution or contact support if beyond the expected timeframe.

9. **Address any discrepancies or issues:**
   - If the player reports not receiving a bonus despite meeting all criteria, instruct them to provide proof (screenshots or transaction IDs).  
   - Escalate to technical support if system errors or delays are suspected.

10. **Communicate policies and rules clearly:**  
    - Reiterate that bonuses are automatically distributed and cannot be manually pushed by staff.  
    - Remind the player that turnover requirements (e.g., 20x, 10x, or 20x of bonus amount) must be fulfilled before withdrawal.  
    - Warn about restrictions on bonus use (e.g., applicable game types).

11. **Conclude the case:**
    - Confirm with the player that all relevant information has been checked and that they understand the process.  
    - Offer further assistance if needed, and advise them to contact support if they believe eligibility criteria are met but bonuses are not received.

## Notes

- Bonuses like VIP Weekly Salary are credited automatically every Saturday between 22:00 and 23:59 (GMT+8).  
- VIP bonus waiting periods last 24 hours after the VIP level upgrade.  
- All rewards and bonuses are distributed automatically once conditions are fulfilled, and manual dispatch by staff is not possible.  
- For referral bonuses such as Angpao, ensure players deposit at least 200 PHP, link withdrawal accounts, and share their referral link.

## Key points for communicating with players

- Clearly explain the automatic nature of bonus distribution once criteria are satisfied.  
- Remind players of the required actions (e.g., deposits, linking accounts) and timeframes for bonus receipt.  
- Encourage players to contact support with proof if they believe they are eligible but haven't received their bonuses within the expected period.