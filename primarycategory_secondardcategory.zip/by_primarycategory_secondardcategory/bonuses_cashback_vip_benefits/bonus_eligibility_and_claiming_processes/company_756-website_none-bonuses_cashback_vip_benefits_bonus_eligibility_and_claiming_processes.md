# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or concern about bonuses, cashback, or VIP benefits.**  
   Determine whether the player is asking about a specific bonus (e.g., weekly salary, birthday bonus, VIP monthly salary), cashback, or VIP benefits.

2. **Request and review the player’s account information to verify eligibility.**  
   Collect necessary details:  
   - Player’s VIP level and tier (if applicable).  
   - Deposit history within the relevant period (e.g., minimum deposit of 100 PHP).  
   - Betting activity: whether valid bets have been placed according to the promotion's terms.  
   - Specific bonus requirements: such as placing a valid bet or deposit within the deadline.

3. **Check system records for automatic bonus distribution.**  
   - Confirm whether the bonus has already been credited.  
   - For scheduled bonuses:
     - For the 14th monthly bonus, verify if the date is between 22:00 and 23:59 GMT+8 on the 14th.  
     - For weekly salary bonuses, verify if the current day is Saturday between 22:00 and 23:59 GMT+8.  
     - For birthday or VIP monthly salary bonuses, confirm if the date matches the distribution schedule (e.g., birthday, 28th of each month).  
   - Check whether the bonus has been credited automatically or if it’s pending.

4. **Verify if the player fulfills all eligibility criteria for the bonus or benefit.**  
   - Minimum deposit of 100 PHP (if applicable).  
   - Valid bets placed within the promotional period.  
   - Submission of valid ID/selfie if required for verification.  
   - For VIP bonuses, confirm the player’s current VIP tier and corresponding requirements.

5. **Determine the bonus eligibility based on the verification.**  
   - If all conditions are met and the bonus is not yet credited, explain that the bonus will be automatically credited at the scheduled time.  
   - If the bonus should have already been credited but isn’t received, advise the player accordingly.

6. **If the bonus has not been received and eligibility is confirmed:**  
   - Explain that the bonus is automatically credited within the specified timeframe, and advise to check rewards center later.  
   - If there is an ongoing verification or submission of documents needed, instruct the player to provide required IDs or selfies, and escalate if verification fails or issues persist.

7. **If eligibility criteria are not met:**  
   - Clearly state the specific conditions that have not been fulfilled (e.g., insufficient deposit, no valid bets, wrong date).  
   - Advise the player on what to do to become eligible in the future, such as meeting deposit or betting requirements within the correct period.

8. **For claims related to bonus periods or deadlines (e.g., VIP Monthly Salary, VIP Weekly Salary):**  
   - inform the player about the designated claim windows (e.g., VIP Monthly Salary can be claimed during the month, and if missed, next month’s claim period applies).  
   - Guide them to log in at the designated time for future bonuses if the current period has ended.

9. **Close the case with a summary and advice.**  
   - Confirm the current status of their bonus or benefit.  
   - Offer any necessary instructions or next steps, such as submitting ID, checking the Rewards Center later, or waiting for next scheduled distribution.

## Notes

- Bonuses like weekly salary or birthday bonuses are automatically credited on scheduled days if conditions are fulfilled.  
- Verification of IDs and selfies may be required for certain bonuses; ensure they are submitted if needed.  
- Bonus distribution dates are strictly scheduled:  
  - 14th monthly bonus: between 22:00 and 23:59 GMT+8 on the 14th.  
  - VIP Weekly Salary: every Saturday between 22:00 and 23:59 GMT+8.  
  - Birthday and VIP Monthly Salary: specific dates as per schedule.  
- If a bonus claim period has ended, inform players to log in during the next period to claim their benefits.

## Key points for communicating with players

- Clearly explain applicable dates and timeframes, especially for scheduled bonus distributions.  
- Confirm the player's deposit and betting activity, as these often determine eligibility.  
- Emphasize that bonuses are credited automatically if conditions are met.  
- Guide players to submit identification if verification is required for bonus eligibility.