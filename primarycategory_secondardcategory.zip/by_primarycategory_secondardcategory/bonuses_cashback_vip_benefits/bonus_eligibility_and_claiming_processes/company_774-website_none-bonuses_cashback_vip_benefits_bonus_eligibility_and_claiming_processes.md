# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Gather player information and identify the requested benefit:**
   - Confirm whether the player is inquiring about bonuses, cashback, rebates, VIP Weekly Salary, or other VIP rewards.
   - Collect relevant details from the player, such as their account ID, current VIP level, recent deposit and betting activity, and specific promotion or reward in question.

2. **Verify player eligibility for bonuses, cashback, and VIP benefits:**
   - Check the player's recent deposit activity:
     - For bonuses such as first deposit bonus, ensure a minimum deposit of 100 PHP has been made.
     - For VIP Weekly Salary, verify that the player has completed at least one valid bet on slot or fish within the current week.
   - Check for specific promotion requirements:
     - For weekly or Sunday gifts, confirm the player has met deposit and betting criteria.
     - For referral bonuses, confirm the referral’s deposit reaches at least 200 PHP.
   - Determine if the player has completed all necessary actions (deposits, bets, referrals) to qualify for the benefit.

3. **Perform system checks to see if bonuses/rewards are credited:**
   - Log into the Rewards Center (or equivalent system module).
   - Review the player's account to confirm if the bonus, cashback, rebate, or VIP weekly salary has been automatically credited.
   - For VIP Weekly Salary:
     - Confirm if it's been credited between 22:00 and 23:59 GMT+8 on Wednesday.
     - Note: It is credited automatically if the weekly bet or deposit requirements are met; if not received, verify whether requirements were fulfilled.

4. **Determine if bonuses or rewards are pending or missing:**
   - If the reward has not been credited:
     - Check if the player has met all relevant criteria (e.g., deposit amount, wager requirements, activity during promotion period).
     - Note that delays may occur during high-volume periods; advise players accordingly.
   - If criteria are not met:
     - Explain to the player which requirements are outstanding (e.g., "You need to complete at least one valid bet on slot or fish this week" or "You have not made the minimum deposit required").

5. **Inform the player of the status and next steps:**
   - If the player is eligible and the reward has been credited:
     - Confirm that the bonus, cashback, rebate, or VIP weekly salary is in their account.
   - If the reward is not received due to unmet requirements:
     - Clearly state which obligations remain (deposit, wager, activity).
   - If the reward should have been credited but has not due to system delay:
     - Reassure the player that it is processed automatically; advise patience or inform them that it may take some time.

6. **Provide additional guidance based on findings:**
   - If the player is missing a bonus due to not meeting the requirements:
     - Guide them on how to meet the requirements (e.g., make the necessary deposit or bets).
   - If eligibility criteria are fulfilled but the reward hasn't been credited, escalate the issue to technical support or follow the current site protocol for system delays.

7. **Close the case/provider relevant support:**
   - Document whether the reward was successfully credited, delayed, or if requirements were not met.
   - Advise the player on any further actions if needed, such as rechecking later or submitting a support ticket for system issues.

## Notes
- Bonuses and rewards are automatically credited by the system once conditions are met.
- Rewards include bonuses, cashback, rebates, VIP Weekly Wages, and other VIP benefits.
- Eligibility typically depends on deposit activity, wager requirements, and specific criteria per promotion.
- During high-volume periods, delays in automatic crediting may occur; inform players accordingly.
- Rewards can be confiscated if activity is repeated on the same IP, bank, or phone number according to policies.

## Key points for communicating with players
- Always verify the specific requirements the player needs to fulfill.
- Confirm whether the reward has been credited in the Rewards Center.
- Explain clearly if conditions are not met or if delays are possible.
- Escalate systematic issues or delays beyond standard processing following current protocol.