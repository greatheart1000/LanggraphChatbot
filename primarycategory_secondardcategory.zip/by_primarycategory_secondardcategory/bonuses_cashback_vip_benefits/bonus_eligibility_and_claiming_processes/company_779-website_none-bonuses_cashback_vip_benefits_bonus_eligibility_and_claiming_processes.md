# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Identify the player's inquiry or issue regarding bonuses, cashback, or VIP benefits.**
   - Confirm if the player is asking about bonus eligibility, claiming process, or receiving specific rewards.

2. **Collect necessary information from the player to determine their eligibility:**
   - Verify registration status (must be fully registered and, if applicable, download the app).
   - Ask about the specific promotion or bonus they are referring to (e.g., First Deposit Bonus, New Register Bonus, VIP Weekly Salary, Birthday Bonus).
   - Confirm if the player has made a deposit, including the amount (minimum deposit must meet the specific promotion's requirement, e.g., 100 PHP for the First Deposit Bonus).
   - Check if the player has completed any verification steps such as ID or selfie submission (for certain bonuses).
   - Request details on recent activity, such as deposits, game plays, or bets made within the qualifying period.
   - Inquire whether the player is a VIP3 or above if the inquiry pertains to VIP-specific bonuses (e.g., Birthday Bonus).

3. **Determine bonus eligibility based on the collected information:**
   - Verify if the player’s deposit and gameplay meet the specific criteria like turnover requirements (e.g., 15x for the first deposit bonus, 20x for the New Register Bonus).
   - Check if the bonus is within the claim window (usually up to 12 hours after deposit or registration).
   - Confirm if the player has downloaded the official app (if applicable for the bonus).
   - For VIP benefits such as the Weekly Salary or Birthday Bonus, verify VIP tier status and activity during the relevant period.

4. **Check for systemic or eligibility restrictions:**
   - Use the back office/system to verify if the bonus has been automatically credited.
   - Check for signs of irregular activity: same IP address, bank card, or phone number across accounts which could lead to ineligibility or confiscation.
   - For automatic awards (like cashback or rebates), confirm if the player is eligible according to the system’s eligibility criteria.

5. **If the bonus is not received automatically and manual claiming is required:**
   - Direct the player to check the Rewards Center.
   - Guide the player to click the claim option if applicable.
   - Remind the player that bonuses are usually credited within a 12-hour window post-deposit or registration.

6. **If the player is eligible but the bonus has not been credited after the expected time:**
   - Confirm that the player has met all qualifying conditions (deposit amount, gameplay, verification, etc.).
   - Advise the player to wait up to the maximum processing time (usually 12 hours).
   - If the bonus is still missing, escalate to the relevant department or advise the player to wait for a system update.

7. **If the player is ineligible or bonus was not received due to restrictions:**
   - Explain that bonuses and rewards are system-automated and won’t be distributed if the eligibility criteria are not met.
   - Inform the player about possible reasons: incomplete registration, missing verification, not fulfilling turnover requirements, or detection of irregular activity.
   - Advise on how to meet criteria for future eligibility if appropriate.

8. **If the player questions about specific VIP benefits:**
   - Confirm VIP tier status.
   - For VIP Weekly Salary: verify activity within the week and that the player completed at least one valid bet on a slot or fish game.
   - For Birthday Bonus: confirm current VIP3 status and advise to check the Rewards Center during their birthday period.

9. **Document the case:**
   - Log the player’s details, the information provided, action taken, and current status.
   - Note any discrepancies, verification requirements, or future steps.

10. **Close the case:**
    - Inform the player of the current status (eligible, not eligible, bonus credited, or escalation needed).
    - Provide guidance for future bonus eligibility or rewards.
    - Encourage the player to contact support if they have further questions or experience issues.

## Notes

- Bonuses are automatically distributed once players meet the eligibility criteria, provided within specified timeframes (usually up to 12 hours).
- Bonuses can be revoked or confiscated if irregular activity, such as shared identifiers or multiple accounts, is detected.
- Players must meet deposit and turnover requirements to unlock bonus eligibility.
- For specific rewards like VIP Weekly Salary, activity within the week on slot or fish games is mandatory.
- Players should verify their VIP status for VIP-exclusive bonuses such as the Birthday Bonus.

## Key points for communicating with players

- Confirm eligibility criteria clearly, including deposit amounts, game activity, verification, and VIP status.
- Explain that bonuses are typically credited automatically; if not received, a systemic check is conducted.
- Remind players to check the Rewards Center for manual claims or additional information.
- Emphasize the importance of compliance with site rules to avoid confiscation of rewards or disqualification.
- Clearly communicate timeframes (e.g., 12 hours for bonus crediting).