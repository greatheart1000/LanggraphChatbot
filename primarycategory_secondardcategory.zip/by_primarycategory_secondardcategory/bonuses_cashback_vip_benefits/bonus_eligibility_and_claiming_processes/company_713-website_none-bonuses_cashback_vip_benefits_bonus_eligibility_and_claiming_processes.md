# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify Player Identity and Account Status**
   - Confirm the player's registration is fully completed and ID verification is approved.
   - Check for any account restrictions such as bans or ineligible account status that could prevent bonus eligibility (as bonuses are automatically credited if all requirements are met).

2. **Determine the Type of Bonus or Reward**
   - Identify if the player is requesting:
     - Weekly or monthly bonuses
     - Special occasion bonuses (birthday or member day)
     - Welcome bonus (e.g., First Deposit Bonus)
     - VIP weekly bonuses
     - Other ongoing promotions or cashback offers

3. **Check Bonus or Reward Criteria**
   - For automatic bonuses (e.g., weekly/monthly, birthday, member day):
     - Verify if the player has met the standard requirements:
       - Minimum deposit amount
       - Betting activity and turnover conditions as defined
       - Account not under restrictions or bonuses ineligibility due to account activity/status
     - Confirm any specific conditions for special bonuses:
       - Completing full registration
       - Depositing minimum amounts
       - Fulfilling wagering requirements
   - For VIP weekly bonuses:
     - Confirm player's current VIP level.
     - Ensure the player has maintained their VIP status and participated in relevant promotions during the week.

4. **Check Timing and Distribution Schedule**
   - Verify if the bonus is scheduled for automatic credit:
     - Usually credited after meeting requirements, no manual action needed.
   - For VIP weekly bonuses:
     - Confirm that bonuses are distributed weekly on Monday at 12:00 PM.
     - Ensure player's VIP level is active at the time of distribution.

5. **Review System and Account Data**
   - In the back-office system:
     - Confirm the player's bonus eligibility status.
     - Check the bonus credit status (pending, credited, or in progress).
     - Confirm whether the player's turnover or wagering condition is complete.
   - For bonuses that are not credited automatically or appear delayed:
     - Advise the player to wait for the scheduled distribution time.
     - If issues persist, escalate to technical support.

6. **Communicate with the Player**
   - If the bonus conditions are fulfilled and credits are pending:
     - Inform the player that bonuses are credited automatically once conditions are met.
     - Clarify that withdrawals can only happen after fulfilling all wagering or turnover requirements.
   - If the player is ineligible or conditions are not met:
     - Explain that bonuses are awarded automatically based on the current promotion rules and account status.
     - Mention that no further action is needed unless restrictions are lifted or conditions are met later.

7. **Confirm Bonus Reception and Next Steps**
   - Once credited:
     - Notify the player of successful bonus receipt.
     - Remind them of the wagering or turnover conditions to be fulfilled before withdrawal.
   - For VIP weekly bonuses:
     - Explain the bonus Tier based on VIP level if asked.
     - Reiterate the weekly distribution schedule (Monday at 12:00 PM).

8. **Handle Exceptions or Edge Cases**
   - If the player believes they should have received a bonus but it was not credited:
     - Check for account restrictions or ineligibility.
     - Verify we have clear documentation of the player's meeting all requirements.
     - Escalate to technical or promotions team if needed.
   - If the player has questions about specific amounts or bonus tiers:
     - Provide the bonus amount corresponding to the VIP level (e.g., VIP1 = 5, VIP2 = 10, etc.).

## Notes
- Bonuses are automatically credited after meeting predefined conditions.
- Withdrawal is only permitted after the completion of the required turnover.
- Players are notified via official communication within 24 hours for special bonuses like birthday or member day bonuses.
- VIP bonuses are distributed weekly on Mondays at 12:00 PM, depending on VIP level and activity.

## Key points for communicating with players
- Always verify full registration and ID verification status.
- Confirm if all bonus requirements, including deposits and wagering, are fulfilled.
- Explain that bonuses are credited automatically according to schedule and eligibility.
- Remind players of the VIP weekly bonus distribution timing and tier-dependent amounts.
- Inform players that withdrawals are only possible after fulfilling the turnover requirements.