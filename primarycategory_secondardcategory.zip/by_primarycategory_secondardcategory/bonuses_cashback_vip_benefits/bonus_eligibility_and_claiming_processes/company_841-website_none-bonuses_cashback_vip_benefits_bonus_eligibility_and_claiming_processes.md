# Bonuses, Cashback & VIP Benefits - Bonus Eligibility and Claiming Processes

## Steps

1. **Verify the player's inquiry or issue related to bonuses, cashback, or VIP benefits.**  
   - Determine whether the question concerns bonus distribution, eligibility, claiming process, or specific promotion like the First Deposit Bonus or VIP Weekly Salary bonus.

2. **Gather essential player information.**  
   - Confirm the player's account details, including account verification status, deposit history, activity within the relevant timeframe, and VIP level (if applicable).

3. **Check if the player's account meets the eligibility criteria for the specific bonus or benefit in question.**  
   - For **First Deposit Bonus**:  
     - Confirm the deposit amount is at least 100 PHP.  
     - Ensure the deposit was the player's first deposit.  
     - Verify that the deposit was made to SLOT or FISH GAMES as per terms.  
     - Check that the player’s account is verified, with no violations or suspicious activity.  
   - For **VIP Weekly Salary Bonus**:  
     - Confirm the player completed at least one valid bet on a slot or fish game within the week.  
     - Check if the current VIP tier qualifies for the weekly bonus, with higher tiers receiving higher rewards.  
   - For **bonuses linked to losses or activity rewards**:  
     - Confirm the player incurred the required losses on Slot, Fish, or Poker games, and has logged in to claim the bonus before 4:00 PM GMT+8.

4. **Assess the system-distributed bonuses based on activity logs.**  
   - Bonuses such as Rewards from the Rewards Center or Promotions page are automatically credited once the system detects eligibility criteria are met.  
   - Verify if the bonus has been credited within the standard timeframe (commonly within 12 hours).  
   - Check the Rewards Center or Promotions page to confirm the presence of the bonus or rebate.

5. **If the bonus has not been received, determine the reason.**  
   - Check whether the deposit amount, activity, or turnover requirements are unmet.  
   - Confirm no violations, multiple accounts, or suspicious activity involving the same IP address, bank card, or phone number, which may void the bonus.  
   - Verify if the player completed the required activity within the designated time window.

6. **If eligible, advise the player that the bonus has been automatically credited and is available in the Rewards Center.**  
   - Inform them to check the Rewards Center or Promotions page.  
   - For **First Deposit Bonus**:  
     - The bonus is credited within 12 hours of the deposit and can be claimed/see in the Rewards Center.  
     - The bonus equals 108% of the deposit up to 28,888 PHP with a 15x turnover requirement before withdrawal.  
   - For **VIP Weekly Salary Bonus**:  
     - The bonus is sent automatically every Monday between 22:00 and 23:59 (GMT+8) if the player completed a valid bet during the week.  
   - For **loss-based bonuses**:  
     - The reward can be claimed the following day at the Rewards Center if losses exceeded 100 PHP on Slot, Fish, or Poker games.

7. **Instruct the player on how to claim or track bonuses if necessary.**  
   - Encourage checking the Rewards Center or Promotions page regularly.  
   - Clarify that bonuses are automatically distributed but can sometimes require manual claiming if indicated.

8. **If the player reports not receiving the bonus despite meeting all criteria, escalate for system review.**  
   - Confirm all criteria (deposit amount, activity, restrictions) are fulfilled.  
   - Check for possible system or processing delays or technical issues.

9. **If the player is ineligible due to violations, malicious activity, or detection of multiple accounts with the same IP, bank card, or phone number, explain accordingly.**  
   - Clarify that bonuses are automatically forfeited if violations are suspected or rules are violated (e.g., repeated deposits from the same IP, use of multiple accounts).

10. **Document the case details and findings in the internal system.**  
    - Record deposit dates, activity logs, bonus credit timestamps, and any correspondence.

## Notes
- Bonuses such as the First Deposit Bonus are tied to specific deposit amounts and conditions—e.g., minimum 100 PHP deposit and 15x turnover.
- The VIP Weekly Salary bonus depends on activity within the week and is automatically sent on Mondays.
- Bonuses are automatically distributed; manual claiming is typically unnecessary unless specified.
- Repeated deposits from the same IP, bank, or phone number may lead to disqualification of bonuses and profits.
- Bonuses and rewards might be confiscated if prohibited actions are detected.

## Key points for communicating with players
- Always verify account details, deposit history, and activity before providing a resolution.
- Remind players that bonuses are generally credited within 12 hours after meeting eligibility.
- Inform players to check their Rewards Center or Promotions page for credited bonuses.
- Clarify that violations involving duplicate accounts or suspicious activity can void bonuses or profits.
- Guide players to log in daily or weekly to monitor their bonuses and rewards.