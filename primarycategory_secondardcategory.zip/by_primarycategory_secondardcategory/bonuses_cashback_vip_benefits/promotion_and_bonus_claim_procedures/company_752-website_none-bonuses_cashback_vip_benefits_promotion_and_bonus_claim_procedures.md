# Bonuses, Cashback & VIP Benefits - Promotion and Bonus Claim Procedures

## Steps
1. **Identify the player's inquiry**:
   - Determine if the player is asking about claiming cashback, checking unclaimed bonuses/promotions, or understanding promotion mechanics.
   - Collect necessary information: player ID, current promotion or bonus details, and specific concerns.

2. **Check the player's available rewards and unclaimed bonuses**:
   - Direct the player to the 'Reward Center' to review unclaimed promotions and bonuses.
   - Verify if the player has any pending rewards to claim that are visibly listed in the reward center.

3. **Handle cashback requests**:
   - If the player wants to claim realtime cashback, inform them they can manually claim it at the rebate center.
   - If they do not claim manually, clarify that rewards are automatically sent at 4:00 am the next day.
   - If a manual claim is needed, guide the player to the rebate center and instruct them to follow the process for claiming cashback.

4. **Address promotion and bonus distribution questions**:
   - Explain to the player that promotion bonuses are automatically distributed by the system.
   - Clarify that the amounts are random prizes and the system handles the distribution based on eligibility.
   - Confirm whether the player has met all criteria (e.g., minimum deposit, gameplay participation) for bonuses to ensure proper eligibility.

5. **Verify bonus eligibility and distribution policies**:
   - Confirm that bonuses, rebates, and rewards are automatically generated and credited by the system.
   - Make sure the player understands bonuses are only sent when eligibility criteria are met.
   - Inform that manual addition of bonuses by support is not permitted.
   - Note any specific conditions that may trigger bonus crediting, such as login actions or game activity, as per the current promotion.

6. **If the player reports missing rewards or unclaimed bonuses**:
   - Check the 'Reward Center' for unclaimed items.
   - Verify whether the rewards are still claimable or if the distribution date has passed.
   - Advise the player accordingly, including instructions to claim manually if relevant.

7. **Escalate or advise further actions if issues persist**:
   - If discrepancies are found or the reward is not visible in the 'Reward Center', escalate for further investigation.
   - Confirm that the player has fulfilled all the conditions for the bonuses or cashback.
   - Offer alternative steps if the reward is missing and cannot be claimed, such as checking again later or confirming that they meet all eligibility criteria.

## Notes
- Bonuses, rebates, and rewards are automatically generated and credited by the system based on eligibility.
- Bonuses are often distributed once eligibility criteria are met, which may involve minimum deposit amounts or gameplay participation.
- Realtime cashback can be claimed manually at the rebate center or received automatically at 4:00 am the following day.
- The 'Reward Center' is the primary resource for checking unclaimed or pending rewards.
- Manual addition of bonuses is not allowed; all distributions are system-automated.

## Key points for communicating with players
- Always confirm player’s player ID and check their rewards in the 'Reward Center'.
- Inform players about automatic bonus distribution but guide them to claim manually if necessary.
- Clarify that rewards are credited only when all eligibility criteria are met and that system processes handle all automatic distributions.
- Reassure players that cashback rewards are either manually claimable or automatically sent the next day at 4:00 am.