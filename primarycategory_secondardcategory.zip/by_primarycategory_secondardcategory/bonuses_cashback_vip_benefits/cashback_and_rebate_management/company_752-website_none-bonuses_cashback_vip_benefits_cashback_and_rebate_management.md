# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Gather player information**:
   - Verify the player's identity and account status.
   - Confirm the player's current activity regarding bonuses or rebates.
   - Determine if the player has any existing claims or pending withdrawals related to cashback or rebates.

2. **Explain the cashback and rebate policy to the player**:
   - Inform the player that every bet is eligible for an instant rebate and cashback bonus of up to 3%.
   - Clarify that cashback is earned in real-time on each bet on every game.
   - Mention that bonuses, cashback, and rebates are automatically sent by the system to their account.
   - Notify that cashback can be claimed manually at the rebate center or will be automatically sent before 4:00 AM [GMT+8] the next day if unclaimed.

3. **Check the player's claim status**:
   - Ask if the player wishes to claim their cashback manually.
   - If the player wants to claim manually:
     - Direct them to the rebate center within their account.
     - Confirm that they have correctly navigated to the rebate center.
     - Request a screenshot if necessary, to verify the claim process.

4. **Process manual cashback claim**:
   - Guide the player to click the "Claim Cashback" button in the rebate center.
   - Confirm that the claim was successful:
     - If successful, inform the player their cashback has been credited.
     - If unsuccessful, verify the reason (e.g., system error, insufficient funds, or claim window closed). Escalate if necessary.

5. **Verify automatic cashback/rebate delivery**:
   - Explain that if the player did not claim manually, the cashback will be sent automatically before 4:00 AM [GMT+8] the next day.
   - Check the player's account after this time to confirm receipt of the cashback or rebate.

6. **Address issues or discrepancies**:
   - If the player reports not receiving the cashback or rebate:
     - Confirm the last bets placed and the total wager to ensure eligibility.
     - Verify if the cashback bonus of up to 3% was applicable based on the wagering activity.
     - Check if the cashback is pending or has failed to be credited.
     - Escalate system issues according to internal procedures if the transaction appears delayed or missing.

7. **Handle edge cases and ensure compliance**:
   - Remind players that all bonuses and rebates are computer-generated and automatically allocated.
   - Clarify that manual programming or manual adjustments are not available for bonuses, rebates, or cashback.
   - If a player asks about specific time frames or limits, refer to the policy of automatic daily distribution before 4:00 AM [GMT+8].

8. **Close the case**:
   - Confirm that the player understands the cashback/rebate process.
   - Ensure the player is satisfied with their claim or explanation.
   - Document the interaction, including any screenshots or system checks.
   - Proceed to close the ticket or case per standard operational procedures.

## Notes
- Cashback and rebates are automatically sent; manual claims are optional but available.
- Incentive maximum is up to 3%; this applies to every bet.
- Rewards are credited before 4:00 AM [GMT+8] the next day if unclaimed.
- Always verify eligibility based on the latest system data and account history.

## Key points for communicating with players
- Clearly explain that cashback is real-time and automatically credited unless manually claimed.
- Assure players that their claims are processed promptly, either manually or automatically.
- Use screenshots when requesting proof of claim or errors.
- Escalate issues that cannot be resolved within standard checks.