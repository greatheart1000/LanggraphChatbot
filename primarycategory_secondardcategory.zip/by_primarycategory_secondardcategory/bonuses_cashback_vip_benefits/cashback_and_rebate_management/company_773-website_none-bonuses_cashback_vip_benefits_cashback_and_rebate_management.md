# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Gather player information regarding cashback inquiries or claims.**  
   - Confirm the player's account details and identify the player requesting cashback or rebate information.

2. **Check the player's account for any recorded cashback or rebate credits.**  
   - Log into the back office or system tools and verify if cashback or rebate has already been awarded, accrued, or pending for the player's account.

3. **Determine if the player has any pending cashback that can be claimed manually.**  
   - Identify if the cashback is marked as claimable or if it has already been automatically credited to the account or Reward Center.

4. **Explain the cashback policy to the player.**  
   - Inform the player that:  
     - Cashback is real-time and can be up to 3.60% of eligible bets.  
     - Cashback is awarded as an instant rebate on bets.  
     - Cashback can be claimed manually or will be automatically added to the Reward Center at 04:00 am the next day if not claimed manually.

5. **If the player wishes to claim cashback manually, assist with the claim process.**  
   - Guide the player to the appropriate section (e.g., Rewards Center) to claim their cashback.  
   - Confirm the manual claim if required by the system.

6. **If the cashback is not claimed manually, verify if it has been automatically credited.**  
   - Check the Reward Center for the cashback amount credited at 04:00 am the following day.  
   - Confirm if the cashback appears in the player’s account or Reward Center.

7. **Clarify the timing and conditions of cashback credits.**  
   - Inform the player that cashback awards are delivered automatically, and the relevant cashback (up to 3.60%) on eligible bets is credited either instantly or via the daily automatic process.

8. **Check for VIP Weekly Salary (if relevant).**  
   - Determine if the player is a VIP and if they are eligible for the VIP Weekly Salary, credited every Friday between 22:00 and 23:59 (GMT+8).  
   - Verify if the player makes the minimum deposit of 100 PHP within the week to qualify.  
   - Inform the player that failure to receive the salary usually indicates unmet requirements.

9. **If the player reports issues with cashback or VIP benefits, verify their account activity.**  
   - Confirm whether the required conditions (such as making a deposit or betting eligible amounts) have been met according to the current site configuration and VIP tier rules.  
   - Handle any discrepancies in the system, and escalate if necessary.

10. **Provide the player with troubleshooting guidance or escalate if needed.**  
    - If cashback or VIP payment has not been received despite meeting criteria, escalate the case following company protocols.

## Notes

- Cashback is automatically credited at 04:00 am next day if not claimed manually.  
- Ensure the player is aware that all valid bets are eligible for proportional rebates on promotional rewards.  
- Do not create new numeric conditions or rules; only follow the current site configuration and official policies.

## Key points for communicating with players

- Clearly explain the automatic and manual cashback processes and timings.  
- Confirm if the player has met the minimum deposit (e.g., 100 PHP for VIP Weekly Salary) when applicable.  
- Reassure the player that system delays or automatic credits follow the official schedule and conditions.