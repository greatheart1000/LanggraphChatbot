# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Identify the player's request or inquiry about cashback/rebate.**  
   - Determine whether the player is asking about how cashback works, how to claim it, their current cashback status, or issues related to the process.

2. **Explain the cashback/instant rebate policy and process.**  
   - Inform the player that every bet is eligible for an instant rebate and cashback bonus of up to 3.5%.  
   - Clarify that the cashback can be claimed manually by clicking the **CASHBACK** button for real-time receipt.

3. **Verify if the player has manually claimed the cashback.**  
   - Instruct the player to click the **CASHBACK** button if they wish to claim the rebate immediately.  
   - If the player reports that they have not clicked the cashback button, proceed with the system check.

4. **Perform system check for cashback eligibility and automatic dispatch.**  
   - Confirm whether the player’s bet qualifies for cashback/rebate based on current site rules and their betting activity.  
   - Check if the player has already claimed the cashback manually.  
   - Verify whether the automatic dispatch of rebates is scheduled or has occurred.

5. **Determine the status of the cashback/rebate.**  
   - If the player has clicked **CASHBACK** and received the bonus, inform the player of successful claim.  
   - If the cashback has not been claimed, confirm whether the automatic rebate has been dispatched.  
   - If the cashback is pending or not received after the scheduled dispatch time, escalate or advise accordingly.

6. **Inform the player about time limits for automatic rebate dispatch.**  
   - Make the player aware that if not claimed manually, rebates will be automatically dispatched before 16:00 GMT+8 (or 16:00 PM GMT+8), depending on the system rules.  
   - For cashback policies, the automatic dispatch occurs before 16:00 GMT+8 the next day, or before 4:00 PM GMT+8 in some variations.

7. **If the player’s inquiry relates to a delay or issue with automatic rebate delivery.**  
   - Check system logs or back office confirmations for rebate dispatch status.  
   - If eligible rebates are not credited by the specified time, escalate as per internal procedures.

## Notes
- All players are eligible for an instant rebate and cashback bonus of up to 3.5% on each bet, provided they meet the current site rules and betting activity.
- Rebate and cashback will be credited automatically if not claimed manually via the **CASHBACK** button.
- The automatic dispatch occurs before 16:00 GMT+8 on the following day (or before 4:00 PM GMT+8 if specified in certain policies).

## Key points for communicating with players
- Remind players to click the **CASHBACK** button to claim their rebate instantly.
- Clarify that if they do not claim it manually, the rebate will be dispatched automatically before 16:00 GMT+8 the next day.
- Inform players about the maximum cashback rate of 3.5% per bet.
- In case of delays or issues, verify system dispatch times and escalate if necessary.