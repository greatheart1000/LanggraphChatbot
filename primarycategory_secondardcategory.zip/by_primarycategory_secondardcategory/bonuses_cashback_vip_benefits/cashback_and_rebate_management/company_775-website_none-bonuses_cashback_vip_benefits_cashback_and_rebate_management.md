# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Verify the player's inquiry or request regarding cashback or rebate.**  
   - Collect the player's account details and any relevant identifiers to locate their account accurately.

2. **Check the player's eligibility for cashback/rebate and related bonuses.**  
   - Confirm that the player has completed any required deposits or activity, such as depositing at least 100 PHP during the week for the Lucky Thursday Bonus.  
   - Review the player's betting or activity record within the system to confirm eligibility for specific promotions or rebates.

3. **Assess the timing and status of existing rebates or cashback.**  
   - Determine whether the player has already claimed their rebate or cashback.  
   - For manual rebate or cashback claims:  
     - Check if the current time is between 00:00 and 03:00 AM (GMT+8), during which recalculations occur.  
     - If it is after 03:00 AM, advise the player to try claiming again if a previous attempt was missed.

4. **Guide the player to claim cashback or rebate via the Rebate Center, if applicable.**  
   - Instruct the player to visit the Rebate Center to claim their instant rebate or cashback bonus in real time.  
   - Confirm whether they successfully claimed the bonus through the Rebate Center.

5. **Check automatic dispatch of rebates and cashback.**  
   - If the rebate or cashback was not claimed manually:  
     - Verify within the system if the rebate has been automatically dispatched before 4:00 AM (GMT+8) the next day.  
     - If the automatic dispatch has not occurred and conditions are met, confirm with the system or escalate as needed.

6. **Handle cases where rebates or cashback are missing or not received as expected.**  
   - Ask the player for their account record and betting record to review the status.  
   - If the rebate or cashback is missing despite eligibility and proper claiming procedure:  
     - Escalate the case for further review or advise the player to check back after the scheduled automatic dispatch.

7. **Inform the player of the relevant rules and conditions.**  
   - Clarify that every bet is eligible for an instant rebate and cashback bonus up to 3.0%.  
   - Rebate and cashback are dispatched automatically by 4:00 AM (GMT+8) if not claimed manually, and manual claims are available via the Rebate Center.

## Notes

- Rebate recalculations occur daily from 00:00 to 03:00 AM (GMT+8); players should try claiming again after this period if an automatic rebate was missed.  
- The Lucky Thursday Bonus is credited once a week for deposits of at least 100 PHP and must be claimed by logging in and visiting the Rewards Center between 22:00 and 23:59 (GMT+8).  
- Bonuses, rebates, and rewards are subject to the specific eligibility conditions outlined in the promotions, including special time windows and deposit requirements.  

## Key points for communicating with players

- Remind players to visit the Rebate Center for real-time claims of cashback and rebates.  
- Inform players that if not claimed manually, rebates are automatically dispatched around 4:00 AM (GMT+8).  
- Advise players to check their betting and account records if they did not receive expected rebates or rewards.  
- Ensure players understand the timings and requirements for specific bonuses like the Lucky Thursday Bonus.