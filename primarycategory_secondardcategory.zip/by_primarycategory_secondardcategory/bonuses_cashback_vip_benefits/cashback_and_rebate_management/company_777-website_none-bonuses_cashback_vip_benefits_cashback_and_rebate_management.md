# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Greet the player and determine their query**:
   - Clarify whether they are asking about cashback/rebate, their bonuses, or VIP benefits related to cashback.
   - Confirm they are referring to cashback or rebate on bets specifically, as per the FAQs.

2. **Collect necessary information**:
   - Player's username or account ID.
   - Details of the specific bet or bets for which they want to claim cashback.
   - Whether they have already attempted to claim cashback manually.
   - The date and time of the bets, if applicable.

3. **Verify eligibility and current status**:
   - Log into the system; check the player's betting history.
   - Confirm the bets qualify for cashback (all valid bets qualify; up to 3.80% cashback in real time).
   - Check if the cashback has already been claimed manually by the player.
   - Verify if cashback has already been credited to the Rewards Center.

4. **Explain the cashback process**:
   - Inform the player that cashback is awarded on eligible bets up to 3.80% in real time.
   - Explain that cashback can be claimed manually or will be automatically credited to the Rewards Center at 10:00 AM the next day if not claimed.
   - Clarify that all valid bets are eligible for cashback, which is proportional to their wagered amount.

5. **Guide the player on claiming cashback**:
   - If the player wants to claim cashback manually:
     - Assist them in accessing the claim option in their account.
     - Confirm they understand the manual claim process.
   - If the player has not claimed manually:
     - Inform them that if they do not claim, the cashback will be automatically transferred to their Rewards Center at 10:00 AM the next day.

6. **Check for any restrictions or special conditions**:
   - Confirm the minimum deposit or other conditions related to bonuses if the inquiry involves deposit bonuses (e.g., second-deposit bonus up to 28,888 PHP with 15x turnover).

7. **Provide resolution**:
   - If the cashback has been credited or successfully claimed, inform the player accordingly.
   - If the claims are invalid (e.g., bets not eligible, or the cashback period has expired), explain the reason per the system check.
   - In case of system errors or discrepancies, advise the player to try again later or escalate as necessary.

8. **Close the case**:
   - Summarize the actions taken.
   - Confirm any follow-up steps if needed (e.g., how to check cashback status in the Rewards Center).
   - Thank the player and close the support interaction.

## Notes
- Cashback of up to 3.80% is awarded in real time on all valid bets.
- Cashback can be claimed manually or will automatically be credited to the Rewards Center at 10:00 AM the next day if not claimed.
- Always verify eligibility and whether cashback has already been credited before proceeding.
- Follow system guidelines regarding the retrieval of betting information and performing claims.

## Key points for communicating with players
- Clearly explain cashback and rebate processes, emphasizing manual claim options and automatic crediting timing.
- Ensure players understand that all valid bets are eligible and that cashback can be up to 3.80%.
- Confirm the player's understanding of the process before concluding the interaction.