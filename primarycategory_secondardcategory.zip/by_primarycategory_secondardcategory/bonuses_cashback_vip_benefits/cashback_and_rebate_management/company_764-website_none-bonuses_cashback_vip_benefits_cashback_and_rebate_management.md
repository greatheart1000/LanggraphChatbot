# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Verify the player's inquiry or concern regarding cashback or rebates.**  
   Confirm what specific information the player seeks, e.g., eligibility, timing, or amounts.

2. **Gather necessary player account details.**  
   Collect the following:
   - Player ID or account username  
   - Recent activity or bets (if needed)  
   - Confirmation of registration and app download (if related to bonuses)

3. **Inform the player that bonuses, cashback, and rebates are automatically applied.**  
   Clarify that rewards are system-credited and may not require manual claims.

4. **Check the player's account for received bonuses, cashback, and rebates:**  
   - **Bonuses (including new-player bonus):**  
     - Confirm if the player has registered on the official site and downloaded the app.  
     - Verify if the bonus has been credited (usually within about 2 hours for registration bonuses).  
     - Confirm if the bonus applies to SLOT & FISH games as specified.  
     - Check if the turnover requirement (20x) has been met before withdrawal.  
   
   - **Cashback/Rebate:**  
     - Confirm the last recalculation time—cashback is recalculated daily from 00:00 to 03:00 (GMT+8).  
     - Check if the cashback/rebate has been credited to the account (sent before 4:00 am the next day).  
     - Verify the cashback/rebate rate (up to 3%).

5. **Determine if the reward has been received within the designated timeframe:**  
   - If the reward is missing or not yet credited, advise the player accordingly:
     - For bonuses: Confirm they registered and downloaded the app during the promotion period.  
     - For cashback/rebate: Suggest waiting until after 03:00 (GMT+8) for recalculation and check again.  
   - If no issues are identified, explain that the reward system operates automatically and deposits are processed per schedule.

6. **If the player reports not receiving a bonus (e.g., Angpao or Red Envelope):**  
   - Confirm if they logged in hourly to receive the Angpao bonus daily.  
   - Remind that the bonus amount can be up to 888 PHP and requires meeting the turnover requirement before withdrawal.

7. **If the player claims a discrepancy or abnormal delay:**  
   - Verify system logs or activity history to ensure eligibility.  
   - Confirm that the player’s current activity meets bonus/rebate policy conditions.  
   - Escalate or escalate appropriately if system errors or exceptions are suspected.

8. **If the player is not eligible for a reward or the reward was not credited:**
   - Explain the automatic nature of bonus application and that non-receipt likely indicates ineligibility or timing issues.  
   - Reiterate the importance of following the promotion conditions, such as registration, app download, and meeting turnover requirements.

9. **Document all findings and inform the player of the current status, next steps, or when to check again.**  
   - Advise the player to wait until the next scheduled cashback recalculation if applicable.  
   - Offer to follow up if the reward has not been received after the suggested waiting period.

10. **Close the case after resolution or escalation as needed.**

## Notes

- All bonuses, cashback, and rebates are automatically added by the system; manual claims are not required.  
- Cashback/rebate is automatically sent before 4:00 am (GMT+8) each day, based on activity from 00:00 to 03:00.  
- Players should be aware of the 20x turnover requirement for bonuses before they can withdraw funds.  
- Recalculation of cashback rebates occurs daily during the specified window; waiting until after 03:00 (GMT+8) is advisable if rebates are not immediately visible.  

## Key points for communicating with players

- Emphasize that rewards are system-credited and usually automatic.  
- Clarify the timing of cashback/rebate processing and encourage patience if delays occur.  
- Confirm that players have met all required conditions (registration, app download, turnover).  
- Advise players to check their account after the scheduled recalculation time for cashback bonuses.