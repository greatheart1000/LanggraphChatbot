# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Receive player inquiry about cashback or rebate status**  
   - Gather necessary information from the player, such as account details and the specific issue or question regarding cashback claims or rebates.

2. **Check the current time against the system recalculation pause period**  
   - Verify if the current time falls within the daily recalculation pause from 00:00 to 03:00 (GMT+8).  
   - If the inquiry concerns cashback or rebate claims during this period, inform the player that the system undergoes a brief pause for recalculations, which occurs daily from 00:00 to 03:00 (GMT+8).  
   - Advise the player to try claiming cashback again after 03:00 AM.

3. **Confirm player's cashback/rebate claim attempt and system status**  
   - Ask if the player has attempted to claim cashback after the recalculation pause.  
   - Ensure the player understands that cashback is earned on bets, up to 3.0% in realtime, and can be manually claimed.

4. **Check if the cashback/rebate has been claimed or received**  
   - Verify if the player has successfully claimed cashback or if it has been automatically credited.  
   - Inform the player that any unclaimed cashback will be automatically credited to their account before 4:00 a.m. (GMT+8) the next day.

5. **If the cashback or rebate has not appeared, verify timing and system process**  
   - Confirm whether the claim was made after 03:00 AM and whether the cashback system had resumed.  
   - If the claim was made outside the recalculation window and the cashback is still not visible or credited by 04:00 AM, advise the player to wait until the next automatic credit.

6. **For claims during system recalculation period or delays**  
   - Inform the player that no cashback can be claimed or credited during the recalculation pause time (00:00-03:00 GMT+8).  
   - Recommend waiting a few hours and trying again after 03:00 AM.

7. **Handle cases of unsuccessful claims or system errors**  
   - If the player reports inability to claim cashback outside the pause period or there are system issues, verify in the back office if there are any ongoing technical issues.  
   - Escalate to technical support if necessary, and inform the player that their cashback will be credited automatically if unclaimed, or advise on further steps based on the system status.

## Notes

- Cashback can be claimed manually, but if unclaimed, it will be automatically sent to the player's account before 04:00 GMT+8.
- The cashback/rebate system undergoes daily recalculation pauses from 00:00 to 03:00 (GMT+8), during which claims cannot be processed.
- Always confirm the current system status and timing before providing final explanations to the player.

## Key points for communicating with players

- Clearly explain the daily recalculation pause from 00:00 to 03:00 (GMT+8) and advise to try claiming cashback after this window.  
- Remind players that unclaimed cashback is automatically credited by 4:00 a.m. the next day.  
- Avoid promising immediate manual credit outside the normal time window; instead, suggest waiting until the next automatic process if needed.