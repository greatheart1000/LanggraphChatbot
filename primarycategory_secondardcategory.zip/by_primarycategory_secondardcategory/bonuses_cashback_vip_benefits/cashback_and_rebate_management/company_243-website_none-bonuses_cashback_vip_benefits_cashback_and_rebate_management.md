# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Identify the player's query or request regarding cashback or rebates.**  
   - Confirm if the player is referring to weekly cashback or VIP rebates.

2. **Gather necessary information from the player.**  
   - Ask if they want to check their weekly cashback, VIP rebate, or reward points.  
   - For cashback or VIP rebates: inquire about the specific week or date range if relevant.  
   - For reward points: confirm they are looking to view or redeem points.

3. **Check the player's current VIP level and betting activity.**  
   - Access the back office or system to verify the player's VIP level.  
   - Confirm that the player has valid bets/losses from the previous day or week, as applicable.  
   - Ensure the player's VIP level is eligible for rebates (all levels can receive 7XM VIP rebates provided criteria are met).

4. **Verify rebate eligibility and system processing.**  
   - For VIP rebates: confirm whether the player has met the required criteria based on their valid bets and losses from the previous day.  
   - For weekly cashback: verify if the player submitted a cashback request for the previous week within the Monday to Sunday window, as unclaimed weeks are forfeited.  
   - Check if the rebate or cashback has been automatically credited after 3:00 AM (or the relevant system update time).

5. **Determine the rebate or cashback amount.**  
   - For weekly cashback: calculate 15% of valid loss bets in a week for Slots Games, based on the player's betting activity.  
   - For VIP rebates: rebates are based on the player's VIP level and previous day's bets/losses; calculate accordingly.  
   - For points and redemption: check the Rewards Center for the current points balance and available items in the Points Mall.

6. **Communicate the outcome to the player.**  
   - Inform them if the cashback or rebate has been credited successfully or if it is pending (e.g., will reflect after 3:00 AM).  
   - If the cashback/rebate is not available, explain it was either not eligible or the request was missed (e.g., missed the weekly window).

7. **Advise on future actions or next steps.**  
   - Remind the player to submit cashback requests within the weekly window.  
   - Encourage the player to maintain regular betting to qualify for ongoing rebates and cashback benefits.  
   - Guide them to the Rewards Center for reward point checks and redemptions.

8. **Close the case, ensuring the player understands the process and documentation (if needed).**  
   - Confirm all questions are answered and no further action is required from their side.

## Notes
- Cashback is only available on a weekly basis and must be requested within the current week’s window (Monday to Sunday).  
- Rebates are credited automatically after 3:00 AM once the player meets the eligibility criteria based on their previous day’s valid bets and losses.  
- All players, regardless of VIP level, can receive 7XM VIP rebates, contingent on meeting the required betting criteria.  
- Checking the Rewards Center helps players view their points balance and available redemption options.

## Key points for communicating with players
- Clarify whether they are asking about weekly cashback or VIP rebates.  
- Remind players to submit cashback requests within the designated weekly window.  
- Explain that rebates are credited automatically after 3:00 AM once eligibility is confirmed.  
- Encourage players to keep track of their betting activity and rewards through the Rewards Center.