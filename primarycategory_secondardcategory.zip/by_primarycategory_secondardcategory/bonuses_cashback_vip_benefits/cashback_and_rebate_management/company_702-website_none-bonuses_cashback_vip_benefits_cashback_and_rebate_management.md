# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Collect player information**:  
   - Verify the player's identity and account details.  
   - Ask if the player is inquiring about a specific cashback or rebate (e.g., 17th Monthly Cashback, 7th, 27th, or 17th).  
   - Confirm if the player has deposit history within the relevant month, as eligibility requires at least one deposit during that period.

2. **Explain the relevant promotion details**:  
   - Inform the player that cashback and rebate bonuses are automatically dispatched by the system unless manual claim is required.  
   - Clarify that cashback/rebate promotions occur on specific dates: 7th, 17th, and 27th of each month.  
   - If applicable, specify the maximum reward amount of 999,999 PHP.  
   - Emphasize the required time window to visit the Rewards Center: between 22:00 and 23:59 (GMT+8) on the relevant date for claiming.

3. **Verify the player's eligibility**:  
   - Check the player's deposit history for the current month. Confirm at least one deposit is recorded.  
   - Verify the player’s deposit amount if the promotion stipulates a minimum deposit (e.g., 100 PHP).  
   - Confirm the date of the visit to the Rewards Center falls within the correct window (22:00 - 23:59 GMT+8 on the 7th, 17th, or 27th).  
   - For the 17th Cashback, ensure the player visited the Rewards Center every 17th between 22:00 - 23:59 to be eligible.

4. **Determine if the bonus has been received**:  
   - Check the system records to see if the cashback/rebate has been automatically dispatched before 04:00 (GMT+8) the following day.  
   - Confirm the amount received matches the expected reward (up to 999,999 PHP).  
   - If the player claims manual reward, check if they clicked the 'CASHBACK' button in the Rewards Center during the specified window.

5. **Respond based on eligibility and system verification**:  
   - If the player is eligible and the bonus was received:  
     - Inform the player that the cashback/rebate has been successfully credited automatically or manually.  
   
   - If the player is eligible but did not receive the bonus:  
     - Explain that bonuses are dispatched automatically; if not received within the expected timeframe, the player may not be eligible.  
     - Advise the player to check back during the next promotion date.  
   
   - If the player is ineligible (e.g., no deposit history, outside the claiming window, or did not visit Rewards Center):  
     - Inform the player that they do not meet the eligibility requirements.  
     - Clarify the necessity of deposit activity and claiming during the specified times.

6. **Escalate or advise further action if needed**:  
   - If the player believes they qualify but did not receive the reward, confirm all conditions and verify deposit history plus claim timing.  
   - If discrepancies persist, escalate to the technical or promotions team with details of the player's account and actions.

## Notes
- The 17th Monthly Cashback requires visiting the Rewards Center every 17th of the month between 22:00 - 23:59 (GMT+8) if eligible.  
- The 7th, 17th, and 27th Cashback promotions are automatic but require the player to have deposit history and claim within the designated window.  
- Bonuses, cashback, and rebates are sent automatically by the system; manual claiming is only necessary to click 'CASHBACK' in the Rewards Center during the window.  
- Failure to claim within the window generally results in ineligibility for that specific month's cashback.