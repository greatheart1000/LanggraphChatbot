# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Gather player information and verify eligibility**  
   - Confirm the player's identity and account status.  
   - Check if the player has any active promotions, including cashback or rebates, and verify their eligibility based on current promotion terms.

2. **Determine the player's current cashback/rebate status**  
   - Inquire whether the player has already claimed the cashback in real-time.  
   - If the player has not claimed it, instruct the player to click on the "CASHBACK" button to claim immediately.  
   - If the player has already claimed or the system shows no pending rebate, proceed to the next step.

3. **Check automatic dispatch timing for rebates**  
   - Confirm if the rebate has been automatically dispatched, which occurs before 14:00 (GMT+8) the next day if not claimed manually.  
   - If the rebate has not been received and the current time is after the dispatch window, advise the player to wait for automatic dispatch or contact support if they believe there is an issue.

4. **Verify rebate or cashback delivery to the account**  
   - Confirm whether the bonus, cashback, or rebate was credited to the account automatically.  
   - If not received within the expected timeframe, advise the player to contact support with relevant details.

5. **Explain the rebate and cashback conditions or resolve issues**  
   - Reiterate that all bonuses, cashback, and rebates are credited automatically as part of the promotion program.  
   - If the player claims the rebate and it is not credited, or there are discrepancies, escalate the case or advise contacting support for further assistance.

6. **Inform about VIP Weekly Salary or additional rewards**  
   - If applicable, inform the player that the VIP Weekly Salary is credited every Wednesday (GMT+8) to the Rewards Center after completing at least one valid bet on eligible games during the week.  
   - Explain that higher VIP tiers unlock more rewards and bonuses, including increased salary amounts, events, and other benefits.

## Notes
- All bonuses, cashback, and rebates are system-credited automatically; manual intervention is only needed if the bonuses are not received within the expected timeframe.  
- Rebate amounts can be up to 3.9%. The rebate is available for instant claim and can also be dispatched automatically before 14:00 (GMT+8) the following day if not claimed manually.  
- Always verify the player's claim and system records before proceeding with escalations or further assistance.

## Key points for communicating with players
- Confirm whether the player has claimed their cashback in real time by clicking "CASHBACK."  
- Remind them of the automatic dispatch window before 14:00 (GMT+8) the next day.  
- Explain that all bonuses and rebates are credited automatically; manual claims are available for instant rebates.  
- Encourage players to contact support with details if the rebate or cashback is not received within the expected timeframe.