# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Gather player information regarding the rebate or cashback inquiry**:
   - Confirm the player's account details (player ID, username).
   - Ask if the player is inquiring about cashback, rebate, or VIP Weekly Salary benefits.
   - Determine if the player has any recent bets to check the eligibility status.

2. **Check the player's account for eligible bonuses, rebates, or cashback**:
   - Verify whether the cashback or rebate bonus has been credited to the player's account.
   - Remember that all bonuses, cashback, and rebates are sent automatically by the system.
   - Check if the player has missed receiving the rewards within the designated timeframe (before 4:00 AM GMT+8 the next day).

3. **For cashback or rebate inquiries**:
   - Explain that each bet is eligible for an instant rebate and cashback bonus of up to 3.8%.
   - Clarify that cashback is automatically credited to the account before 4:00 AM GMT+8 the next day, unless manually claimed.
   - Guide the player to visit the Rebate Center to claim in real time if they wish to claim manually.
   - If the cashback or rebate is not received:
     - Confirm the bet was eligible (e.g., placed within the terms).
     - Advise that if not received by the deadline, it may indicate ineligibility.
     - Ensure the player understands that the system automatically dispatches rewards.

4. **For VIP Weekly Salary or other bonuses**:
   - Explain that VIP Weekly Salary is credited every Thursday between 22:00 and 23:59 GMT+8.
   - Confirm if the player has completed the minimum deposit of 100 PHP within the week.
   - If the player claims they did not receive their VIP Weekly Salary:
     - Verify the deposit and activity history.
     - Explain that higher VIP tiers unlock higher rewards, and the incentive depends on the eligibility criteria.
     - Inform that non-receipt may mean the requirements were not met.

5. **Check system and eligibility status**:
   - If bonuses or rebates are missing and the player claims eligibility:
     - Verify system logs for automatic distribution.
     - Check if the player disputed eligibility or if there are any system errors.
   - If necessary, escalate to relevant back-office teams following internal procedures.

6. **Provide clear resolution or explanation based on findings**:
   - Confirm if the reward has been credited or dispatched automatically.
   - Clarify that if rewards are not received within the timeframe, it may be due to ineligibility based on the current rules.
   - If eligible but not received, advise the player to wait until the next dispatch or to revisit the Rebate Center to manually claim.

7. **Document the interaction**:
   - Record the player's inquiry, verification steps, and any actions taken.
   - Note if the player was advised on the timing, claiming process, or reasons for non-receipt.

## Notes

- All bonuses, cashback, and rebates are distributed automatically; manual claiming is only necessary if the system offers a real-time claim option via the Rebate Center.
- Cashback and rebate bonuses are typically issued before 4:00 AM GMT+8 the following day.
- The VIP Weekly Salary is credited every Thursday between 22:00 and 23:59 GMT+8, subject to meeting deposit requirements.
- In case of disputes or discrepancies, escalate according to internal procedures, ensuring all steps and player communications are documented.

## Key points for communicating with players

- Clearly explain the automatic distribution process and deadlines.
- Confirm whether the player has fulfilled all eligibility requirements.
- Remind players about the timeframe for claiming rewards and system dispatch timings.
- Clarify that missing rewards may be due to ineligibility or unclaimed bonuses within the designated period.