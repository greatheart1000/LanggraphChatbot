# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Gather player information**
   - Ask the player if they are inquiring about bonuses, cashback, rebates, or VIP monthly cashback.
   - Determine the specific type of benefit they are referring to (e.g., regular cashback, rebate, VIP cashback).
   - Confirm the player’s current VIP level if relevant, as VIP benefits are credited automatically on the 30th of each month between 22:00 and 23:59 (GMT+8).

2. **Check eligibility and promotion terms**
   - Verify if the player is eligible for the cashback or rebate in question.
   - Advise the player to check the promotion page for specific terms that may apply.
   - Confirm whether the benefit has been credited automatically or requires manual action.

3. **Verify potential issues with credited bonuses/rebates**
   - If the player reports not receiving bonuses, cashback, or rebates:
     - Confirm that the benefit should be automatic.
     - Remind the player to check their eligibility and promotion terms.
     - If it is a manual claim (e.g., cashback), ensure the player clicked the 'CASHBACK' button to claim it in real time.

4. **Check system recalculations and timing**
   - Inform the player that cashback/rebate recalculation happens daily from 00:00 to 3:00 AM (GMT+8).
   - If rebates/rebates are not visible after recalculation, advise the player to wait until after 3:00 AM.
   - For VIP monthly cashback:
     - Confirm the date and time (credited automatically between 22:00 and 23:59 on the 30th of each month, GMT+8).
     - Verify if the date is within this window; if not, inform the player it will be credited as scheduled.

5. **Guide the player on how bonuses and rebates work**
   - Explain that every bet is eligible for an instant rebate and cashback of up to 4%.
   - Clarify that to claim rebates manually, they must click the 'CASHBACK' button.
   - If not claimed manually, rebates are automatically dispatched by 02:00 AM (GMT+8) the next day.

6. **Address missing rebates or cashback**
   - If rebates or cashback are still not visible after system recalculation and the appropriate time:
     - Ask the player to wait until the next scheduled credit or recalculation.
     - If the problem persists beyond these checks, escalate for further investigation.

7. **Document and conclude**
   - Record the player's inquiry, verification steps taken, and any information provided.
   - Remind the player that VIP monthly cashback is credited automatically on the 30th between 22:00 and 23:59 (GMT+8).
   - Close the ticket after providing a clear update based on the above checks.

## Notes

- Bonuses, cashback, and rebates are generally credited automatically; manual claims are required only when specified.
- Rebate recalculations occur daily from 00:00 to 3:00 AM (GMT+8); advise players to check after this period if rebates are missing.
- VIP monthly cashback is credited between 22:00 and 23:59 on the 30th of each month.
- Always verify the player's VIP level and ensure they follow the current site configuration and promotion terms to determine specific eligibility and timing.

## Key points for communicating with players

- Clearly explain the automatic and manual processes involved in receiving benefits.
- Remind players to check timing windows, especially for VIP cashback.
- Encourage patience when rebates are temporarily missing due to recalculation or timing.
- Refer players to the promotion terms if eligibility issues arise.