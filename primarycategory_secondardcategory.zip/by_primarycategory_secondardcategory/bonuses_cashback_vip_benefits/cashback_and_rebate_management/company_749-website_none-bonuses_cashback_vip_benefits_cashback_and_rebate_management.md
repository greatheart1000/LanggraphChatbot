# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Verify the player's inquiry or issue related to cashback or rebate.**  
   - Confirm that the player's question pertains to cashback, rebate, or VIP benefits as specified in their communication.

2. **Gather relevant player information.**  
   - Note the player's account details, such as account ID, current VIP level, and recent activity, if necessary.  
   - Check whether the player has made recent bets and claims.

3. **Check the player's eligibility for cashback or rebate.**  
   - Confirm that the player has placed bets eligible for the cashback and rebate system, which applies to "every bet."  
   - Determine if any restrictions or special conditions are applicable; in general, all bets are eligible unless otherwise specified.

4. **Review the cashback and rebate status in the system.**  
   - Access the player's account in the back office or the relevant system interface.  
   - Verify the amount of cashback and rebate bonuses available; the system provides up to 3.0% cashback and rebate on each bet.

5. **Check if the player has already claimed the cashback bonus for the relevant period or bet.**  
   - If the cashback is unclaimed, proceed to manual claim steps; otherwise, note that the bonus has been credited automatically.

6. **Handle the cashback claim process.**  
   - If the player requests to claim cashback manually, initiate the claim in the system.  
   - Inform the player that unclaimed cashback will be automatically credited to their account before 4:00 a.m. [GMT+8] the next day if not claimed manually.

7. **Verify the automatic crediting process.**  
   - If the cashback or rebate has not appeared in the player's account after the specified time, check whether the player met the eligibility criteria, such as no account restrictions.  
   - If the bonus is still missing after the deadline, inform the player that they may not be eligible or that an issue may have occurred; escalate if necessary.

8. **Provide the player with clear information about VIP Weekly Salary (if applicable).**  
   - Confirm the player’s VIP level and recent deposit amount (minimum of 100 PHP within the week).  
   - Notify that the VIP Weekly Salary is automatically sent every Friday between 22:00 and 23:59 (GMT+8) through the Rewards Center.  
   - Clarify that if the player did not receive it, they may not have met the weekly qualification.

9. **Conclude the case.**  
   - Summarize the actions taken, confirm the player understands the process, and inform them about the automatic system crediting policy.  
   - Close the support case, noting any follow-up actions if necessary.

## Notes

- All bonuses, cashbacks, and rebates are sent automatically by the system unless the player claims them manually.  
- Cashback and rebates are capped at 3.0% and are applicable to every bet unless specific restrictions apply.  
- If a player did not receive their reward within the specified time frame, they may not be eligible, or an issue may have occurred requiring escalation.  
- For VIP Weekly Salary, only players who deposit at least 100 PHP within the week and belong to the qualifying VIP tiers will receive this benefit.

## Key points for communicating with players

- Clearly explain that cashback and rebates of up to 3.0% are applied to every bet and are credited automatically if unclaimed.  
- Inform that manual claiming is possible before the automatic credit is processed, which occurs before 4:00 a.m. [GMT+8] the next day.  
- Remind players that VIP Weekly Salary is credited automatically every Friday for qualified VIP levels and sufficient deposit activity.  
- Always verify account eligibility and recent activity when handling claims or missing rewards.