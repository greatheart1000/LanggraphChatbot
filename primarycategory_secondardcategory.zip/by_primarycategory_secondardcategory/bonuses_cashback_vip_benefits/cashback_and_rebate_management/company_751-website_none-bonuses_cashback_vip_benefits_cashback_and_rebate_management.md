# Bonuses, Cashback & VIP Benefits - Cashback and Rebate Management

## Steps

1. **Identify the player's inquiry regarding cashback or rebate:**
   - Confirm the player is asking about how to claim cashback or rebate rewards.
   - Gather necessary player information, such as player ID or username, to locate their account in the system.

2. **Check the player's betting activity and cashback status:**
   - Verify that the player has placed bets on every game, as cashback applies to all bets.
   - Confirm that cashback has been earned within the current day or specified period (if applicable).
   
3. **Determine if the player has already claimed their cashback:**
   - Access the rebate center or cashback system to review the player's cashback/rebate claim history.
   - Check if the player has already manually claimed their cashback for the current day.
   
4. **Proceed based on the claim status:**
   
   - **If the player has not claimed cashback:**
     - Inform the player they can manually claim their cashback at the rebate center.
     - Advise the player to navigate to the rebate center and click on the claim button.
     - Provide instructions or link if necessary.
   
   - **If the player has already claimed cashback or the claim is not pending:**
     - Explain that if not claimed manually, the system will automatically send the cashback at 4:00 AM the next day.
   
5. **Note the automatic cashback process:**
   - Confirm that, per site rules, any unclaimed cashback will be automatically sent at 4:00 AM next day.
   - If the player requests confirmation, verify that the automatic reward was received after 4:00 AM.
   
6. **Escalate or advise further if issues occur:**
   - If cashback rewards are not received automatically after 4:00 AM and the player claims they did not receive reward:
     - Check the system for discrepancies or delays.
     - Escalate to technical support if anomalies are detected.
   - If the cashback/ rebate details are unclear or there are system errors, escalate per internal procedures.
   
## Notes

- Cashback is earned automatically on every bet within one minute, but players must manually claim it at the rebate center if they prefer to do so sooner.
- Rewards not claimed manually will be sent automatically at 4:00 AM.
- Confirm the player’s betting activity and claim status before providing instructions or escalating issues.

## Key points for communicating with players

- Remind players that cashback is earned instantly on every bet and available for manual claim.
- Inform players that unclaimed cashback will be automatically credited at 4:00 AM the following day.
- Encourage players to claim cashback manually via the rebate center if they want immediate access.
- Always verify claim status before concluding the issue or escalating.