# Bonuses, Cashback & VIP Benefits - Wagering and Bonus Claim Procedures

## Steps

1. **Identify the player's query or issue related to bonuses or rewards**  
   Collect relevant information from the player, including their account details, the specific bonus or benefit they are referring to (e.g., referral bonus, free Angpao daily, rescue bonus, VIP bonuses, first deposit bonus), and the timing of their query.

2. **Verify player's eligibility for the specific bonus or benefit**  
   - For referral bonus: Confirm the referred player has reached a total deposit of 200 PHP and that the referral link or code was used correctly.  
   - For FREE ANGPAO DAILY: Check if the player is a new player who downloaded PHCASH APP or a VIP member, and ensure the query is within the time window (19:00-19:30 GMT+8).  
   - For Rescue Bonus: Confirm that the player lost 100 PHP or more on Slot, Fish, or Arcade games, and that the player logs in the next day before claiming.  
   - For First Deposit Bonus: Verify the player's first deposit of 100 PHP has been made, and they visit the Rewards Center within 12 hours to claim.  
   - For VIP Bonuses: Check the player's VIP level and ensure they have completed the necessary betting requirements for their rank.

3. **Confirm whether the bonus or benefit has been claimed or received**  
   - Check the player's Rewards Center or bonus account to see if the bonus has been claimed.  
   - For bonuses requiring manual claim, instruct the player to go to the Rewards Center and click "claim" if applicable.

4. **Assess if the player has met all requirements to use or withdraw the bonus**  
   - Verify turnover requirements where applicable:  
     - For bonus withdrawal eligibility, ensure the player has fulfilled the required turnover (e.g., 8x for first deposit bonus).  
     - For referral bonus, confirm the deposit and betting conditions are met before the commission is sent.  
   - If the bonus is not yet eligible due to unmet turnover, inform the player to continue playing slots or fish to fulfill the requirement.

5. **If the player's bonus or benefits are eligible but not received, troubleshoot accordingly**  
   - For missing first deposit bonus: Confirm the player claimed within 12 hours post-deposit, and meet the 8x turnover rule.  
   - For referral bonus: Verify deposit amount and that the bonus has been claimed in the Bonus Center.  
   - For free Angpao daily or rescue bonus: Ensure the player logged in the next day after losses to claim the reward before 04:00 AM.

6. **Guide the player on the next steps based on their situation**  
   - If eligible and bonus is claimed: Advise on wagering or how to meet the turnover to qualify for withdrawal.  
   - If not yet eligible: Inform them to continue playing or completing requirements, avoiding further claims until criteria are met.  
   - If the player is not qualified (e.g., multiple accounts, incomplete deposits, betting conditions unmet): Explain the specific reason based on the verification.

7. **Escalate if the issue cannot be resolved or if discrepancies are detected**  
   - For unresolved issues, such as missing bonuses despite meeting the criteria, escalate to the back office with relevant account details and evidence (screenshots, transaction IDs).  
   - Note: For issues involving eligibility or system errors, follow internal escalation procedures.

## Notes  
- Always verify the player's eligibility based on the explicit conditions specified: deposit amounts, time limits, betting requirements, or VIP level.  
- Bonuses are only available for claim within specified timeframes, e.g., the Free Angpao is available daily at 19:00-19:30 (GMT+8).  
- Encourage players to complete their turnover requirements before attempting withdrawals involving bonuses.  
- Be cautious with multiple accounts under the same IP address, as players may lose qualification for certain bonuses.  
- For all bonus types, ensure the player has met all specified conditions before confirming bonus receipt or providing further assistance.

## Key points for communicating with players  
- Clearly explain the specific requirements and time limits associated with each bonus.  
- Confirm the player's actions (e.g., deposit, login, claim) to verify compliance with the bonus rules.  
- Remind players that for withdrawal of bonus-eligible amounts, the turnover requirement must be met first.  
- Always verify discrepancies with the back office if player claims inconsistency or if bonus status is unclear.