# Bonuses, Cashback & VIP Benefits - Wagering and Bonus Claim Procedures

## Steps

1. **Gather Player Information**
   - Confirm the player's account details, including username, registered mobile number, and KYC status.
   - Verify if the player has completed KYC with a valid ID and selfie, as required for bonus eligibility.
   - Check if the player’s account is KYC-verified and the mobile number is linked, especially for promo-specific bonuses.

2. **Identify the Bonus or Cashback the Player is Claiming or Inquiring About**
   - Determine if the player is asking about:
     - The ₱28 bonus code
     - A new-user bonus (e.g., 100 PHP or 28P promo)
     - Rewards from mission-based activities or deposits
     - VIP benefits or cashback offers
   - Request relevant details, such as the promotion name or code, redemption method, or specific bonuses they want to claim.

3. **Verify Eligibility and Promotion Conditions**  
   - For ₱28 bonus code:
     - Confirm the player checks GamePH's Viber, Telegram, or Facebook at 7PM on designated days (Tuesday, Thursday, Saturday, Sunday).
     - Ensure the player is among the first 1,500 redemptions; inform about event cap and closing time.
     - Confirm the player has made a minimum deposit of ₱100 on the event day.
     - Confirm the bonus is redeemed via the in-app gift code.
     - Check if the player has only redeemed once per month.
     - Verify the account is linked with a mobile number.
     - Apply standard Terms & Conditions.

   - For new-user bonus:
     - Confirm the player has registered and verified their account, including linking a mobile number and completing KYC.
     - Ensure the deposit is at least ₱100 on the promo day.
     - Check if the bonus has been redeemed in the Rewards Center or via official channels at 7PM.
     - Confirm the bonus is used within 7 days and wagered 5x on slots before withdrawal.
     - Confirm only one redemption per user per month.

   - For rewards from mission-based activities or deposits:
     - Confirm the deposit criteria are met for the relevant reward tier.
     - Instruct the player to claim rewards in the Rewards Center.
     - Request a screenshot if verification is needed.

   - For cashback or VIP benefits:
     - Check current VIP level and applicable perks.
     - Verify if cashback or VIP benefits are subject to specific wagering or conditions per current site rules.

4. **Perform System and Account Checks**
   - Use the back office systems to confirm the deposit amount, bonus redemption status, and wagering progress.
   - Verify the bonus status (active, used, expired) and wagering requirement progress.
   - Confirm the bonus has been wagered the required 5x on slots before withdrawal, where applicable.

5. **Explain or Resolve Based on Findings**
   - If all conditions are met:
     - Inform the player that the bonus has been successfully claimed or is currently active.
     - Remind about wagering requirements (e.g., 5x on slots) and the 7-day validity period.
     - Clarify that withdrawal is permitted only after satisfying wagering and other terms.
   - If conditions are not met:
     - Clearly explain which requirements are missing (e.g., deposit amount, KYC verification, time limit, wagering multiple).
     - If the player is ineligible (e.g., exceeds redemption limit or outside event period), notify appropriately.

6. **Provide Additional Guidance as Needed**
   - Remind players to keep proof (screenshots) if requested or required.
   - Advise players to review the official Terms & Conditions for each promotion.
   - Escalate cases if discrepancies or technical issues prevent verification or claim.

7. **Close the Case**
   - Confirm the player understands the current status.
   - Document all findings, actions taken, and the player's responses.
   - Provide contact information for further assistance if necessary.

## Notes

- Bonus and promotional offers are subject to specific time-frames and limits, such as the 7-day validity and 1 redemption per user per month.
- Wagering requirements generally specify a 5x wagering in slot games before withdrawal.
- KYC verification and a linked mobile number are mandatory for many promotions.
- Check the current site configuration and official announcements for any updates to policies or times.

## Key points for communicating with players

- Confirm their eligibility based on the promotion’s specific requirements.
- Clearly explain the wagering and withdrawal conditions.
- Ensure players understand the limits such as time restrictions and redemption caps.
- Offer guidance on claiming in Rewards Center or official channels and verifying bonus status.