# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's account and recent activity:**
   - Confirm that the player has registered on the official website.
   - Check if the player has downloaded the ACESUPER Official App, if required for the bonus.
   - Ensure the player’s account details (name, phone number, bank card, IP address) do not appear in repeated use for bonus eligibility, as rewards and profits may be confiscated if multiple accounts or suspicious activity are detected.

2. **Identify the player's requested or relevant bonus/promotion:**
   - Determine if the inquiry is about the **New Register Bonus**, **First Deposit Bonus**, **Second Deposit Bonus**, **Third Deposit Bonus**, **VIP Weekly Wages**, **Angpao Promotions**, or other bonuses.

3. **For New Register Bonus:**
   - Ensure the player has registered on the official website.
   - Confirm the player has downloaded the ACESUPER Official App.
   - Verify that the bonus should be automatically credited within 2 hours after registration and app download.
   - Check if the bonus was credited:
     - If yes, instruct the player to proceed with the turnover requirements before withdrawal.
     - If not, request the player to check their Bonus Center or account, and confirm eligibility.
   - Advise the player that the bonus is automatically credited if eligible; no manual claim required.

4. **For First Deposit Bonus:**
   - Confirm the player has made the first deposit of at least 100 PHP.
   - Verify deposit through system records.
   - Ensure the player visits the Bonus Center within 12 hours of deposit to click **Claim** (if required).
   - If the bonus is credited automatically, confirm the amount matches the promotion (e.g., 69 PHP).
   - Remind the player that they need to meet the **turnover requirement** before withdrawal.

5. **For Second Deposit Bonus (39%) or Third Deposit Bonus (19%):**
   - Confirm the deposit was made and the player logged into Reward Center within 12 hours.
   - Verify deposit amount meets minimum (e.g., 100 PHP for third deposit).
   - Check if the bonus has been credited:
     - If not, instruct the player to claim it in the Reward Center.
   - Clarify that the bonus has a **turnover requirement (e.g., 15x)** before withdrawal.
   - Confirm that bonuses can only be used on **SLOT & FISH** games.
   - Remind the player about restrictions if repeated IPs, bank cards, or phone numbers are detected, rewards can be confiscated.

6. **For Special Bonuses (e.g., Angpao promotions, VIP weekly wages, monthly rewards):**
   - Confirm eligibility:
     - For weekly VIP wages, the player must complete at least 1 valid bet during the week.
     - Rewards are automatically sent every Tuesday between 22:00 and 23:59 GMT+8.
     - For ongoing promotions, check if the player has met specific activity or deposit thresholds.
   - Verify if the bonus or reward has been credited:
     - If not received, instruct the player to check the Rewards Center or promotion page.
   - Remind players that VIP or promotional rewards may be confiscated if system detects repeated use of IP, bank card, or phone.

7. **For claiming via screenshots or other proof:**
   - Instruct the player to take a screenshot of the promotion or bonus page, if requested.
   - Confirm that the player follows the instructions on the promotion page.
   - Advise that only explicit instructions in the promotion FAQ should be followed regarding claim procedures.

8. **Address eligibility issues or failure to receive bonuses:**
   - Confirm that the player completed all steps correctly:
     - Registered on the official site.
     - Downloaded the official app (if required).
     - Made the deposit (if applicable).
     - Claimed the bonus in the Bonus Center (if manual claiming is needed).
     - Met the turnover requirement before withdrawal.
   - Explain that bonuses are distributed automatically within the specified timeframe—typically up to 2 hours.
   - If rewards are not received after the timeframe, check for potential ineligibility reasons (such as multiple accounts or failure to meet criteria).
   - Advise the player to contact support if they believe they are eligible but did not receive the bonus.

9. **For withdrawals related to bonuses:**
   - Confirm all **turnover requirements** have been met.
   - Explain that bonuses are subject to wagering requirements (e.g., 15x).
   - Only allow withdrawal once all conditions are satisfied.

10. **Escalate or verify further if needed:**
    - If the player’s case involves suspected system errors, complex eligibility issues, or suspected abuse (e.g., multiple accounts, repeated IPs), escalate to the compliance or technical team accordingly.

## Notes
- Bonuses are automatically credited within approximately 2 hours after registration or deposit, provided the player is eligible.
- Ensuring the player followed all steps (registration, app download, deposit, Claim button activation) is critical.
- System detects if multiple accounts are used through shared IPs, bank cards, or phone numbers; rewards and profits may be confiscated if detected.

## Key points for communicating with players
- Always verify account activity and eligibility before explaining bonus claiming procedures.
- Remind players of the **turnover requirements** that must be met before withdrawal.
- Clarify that bonuses are often credited automatically but may require the player to click **Claim** within the Bonus Center.
- Warn about potential confiscation of rewards/profits if repeated account details or suspicious activity are detected.
- Instruct players to check Bonus Center, Rewards Center, or promotion pages for credited bonuses or rewards.