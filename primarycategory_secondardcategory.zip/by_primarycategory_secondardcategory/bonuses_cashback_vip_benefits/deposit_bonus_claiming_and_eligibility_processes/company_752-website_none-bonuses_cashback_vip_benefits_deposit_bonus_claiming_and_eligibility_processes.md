# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information and verify eligibility**:
    - Confirm the player's registration status, VIP level, and whether they meet specific bonus criteria (e.g., VIP3 for birthday bonus).
    - For birthday bonuses, verify the player's exact birthday and VIP status (must be VIP3).

2. **Identify the specific bonus or cashback the player is inquiring about**:
    - First Deposit Bonus (includes New Player First Deposit Bonus, First Deposit Bonus for specific amounts like 50 PHP or 100 PHP).
    - Second Day Cashback.
    - VIP Weekly Salary.
    - Daily Angpao Bonus.
    - Lucky Sunday Bonus.
    - Birthday Bonus.
    - Rebate and cashback promotions.
    - Maya deposit promotion or other site-specific promotions.

3. **Check the deposit details and system records**:
    - Ensure the player has made the required first deposit:
        - For First Deposit Bonus: check if the deposit amounts are 50 PHP or 100 PHP as specified.
        - Confirm deposit date and time.
        - Verify if the deposit was made within the required time frame (e.g., within 12 hours for claiming the bonus).
    - Confirm if the first deposit bonus has already been claimed or not, as bonuses can only be claimed once.

4. **Verify bonus claiming steps and requirements**:
    - For the First Deposit Bonus:
        - Confirm the player visited 'REWARDS CENTER' within 12 hours after deposit.
        - Verify if the player clicked 'Claim' in the Rewards Center.
        - Check the player's wagered amount to see if the 8x turnover requirement has been met.
    - For the Second Day Cashback:
        - Confirm the player completed their first deposit.
        - Check if the player logged in the second day after the deposit date.
        - Verify if they have claimed cashback at the Rewards Center on that day.
        - Confirm the cashback amount does not exceed the maximum (e.g., up to 999,999 PHP).
    - For VIP Weekly Salary or Weekly Wages:
        - Confirm the player has completed at least one valid bet on slot or fish within the week.
        - Check that the salary was credited automatically on Thursday between 22:00–23:59 (GMT+8).
    - For Daily Angpao or Lucky Sunday Bonuses:
        - Confirm login during the specific claim time window (e.g., 19:00-19:30 GMT+8).
        - Check deposit or activity requirements:
            - Deposit more than 5x since registration for withdrawal eligibility.
            - Or complete 10x turnover if deposited less than 5 times.
    - For birthday bonuses, confirm:
        - Exact birthday date.
        - VIP3 status.
        - Submission of required verification (IDs, selfie holding IDs).

5. **Check for the required conditions**:
    - Ensure the player has met turnover/wagering requirements (usually 8x turnover for first deposit bonus, as specified).
    - Confirm bonuses haven't been claimed or credited already.
    - For automatic distributions (cashback, salary), verify if the sum has been credited to the Rewards Center.

6. **Address claims and discrepancies**:
    - If the player is eligible and the bonus is available:
        - Provide instructions on how to claim (e.g., visit Rewards Center and click 'Claim' if not automatically credited).
        - Advise that some bonuses are automatically sent but may require manual claim.
    - If the player did not receive the bonus:
        - Check eligibility criteria again.
        - Confirm they visited Rewards Center within the required window.
        - Advise that not meeting conditions (e.g., turnover, login time, VIP level) results in ineligibility.
        - If necessary, escalate the case with a note that the player may not qualify based on current records.

7. **Escalate issues when needed**:
    - If the bonus is not credited despite meeting all conditions, escalate the case for further system review.
    - If eligibility is unclear or requires further verification, inform the player that their request will be reviewed or that additional information may be needed.

8. **Inform the player of next steps**:
    - Clarify whether the bonus or cashback will be credited automatically or if they need to manually claim it.
    - Remind the player of applicable claim time windows (such as 12 hours for deposit bonuses or specific daily claim times).
    - Confirm if any additional verification or documents are required (e.g., for birthday bonuses).

## Notes

- Bonuses such as first deposit, birthday, and VIP weekly salary require specific VIP levels and timely actions.
- Many bonuses are automatically distributed; however, for some, players must claim manually from the Rewards Center.
- Always verify the timing of deposits and claims relative to the bonus/ cashback promotional rules.
- Confirm that the turnover/wagering requirements (e.g., 8x for deposit bonuses) are met before advising the player they are eligible to withdraw winnings derived from bonuses.

## Key points for communicating with players

- Clearly explain that bonuses and cashback are subject to specific conditions and timeframes.
- Emphasize the importance of visiting the Rewards Center within the designated period to claim bonuses.
- Remind players of the turnover requirements before withdrawals can be processed.
- Confirm the player's VIP level status when applicable for VIP-specific bonuses.
- Always advise players to keep their deposits and activity within the required limits for eligibility.