# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player eligibility and determine the specific bonus they inquire about or are claiming.**  
   - Confirm the type of bonus or benefit (e.g., First Deposit Bonus, Birthday Bonus, VIP Weekly Salary, Cashback).  
   - *Supporting FAQ:* "What is the First Deposit Bonus and how does it work?", "How to claim the Birthday Bonus?", "What is the VIP Weekly Salary bonus?"

2. **Gather necessary player account information.**  
   - Ensure the player provides their username or account ID.  
   - Check if the player has completed required account verifications (e.g., uploading ID, real name, mobile phone number, linking bank card).  
   - *Supporting FAQ:* "Why might I not receive bonuses?", "What are the first deposit bonus terms and conditions?", "What are the policies regarding deposit bonuses?"

3. **Check the player’s account status for specific promotion eligibility.**  
   - Verify VIP level if relevant (e.g., VIP3 for Birthday Bonus).  
   - Confirm the VIP Weekly Salary weekly requirements: at least 1 valid bet on slot/fish games and the deposit amount (minimum 100 PHP).  
   - *Supporting FAQ:* "How does the VIP Weekly Salary bonus work?", "What is the VIP Birthday Bonus and how can I claim it?"

4. **Assess timing and conditions for automatic bonuses.**  
   - For automatic bonuses like the VIP Weekly Salary and Second Day Cashback, verify if the player has met the conditions within the specified period.  
   - *Supporting FAQ:* "When is VIP Weekly Salary paid?", "How does the Second Day Bonus work?"  

5. **Check if a bonus claim is required or automatic.**  
   - For bonuses like First Deposit Bonus, instruct the player to go to the Rewards Center and click "claim" if applicable.  
   - For automatic bonuses, confirm if the player’s account has received the bonus without manual claim.  
   - *Supporting FAQ:* "How to claim the new register bonus?", "How do I claim the new register bonus?", "How can I claim bonuses and rewards?"

6. **Confirm whether the player’s deposit or bet activity meets the requirements.**  
   - Ensure player has made the qualifying first deposit (minimum 100 PHP).  
   - Check if the turnover requirement has been fulfilled before withdrawal.  
   - For cashback and rebate bonuses, confirm that the bet activity qualifies (e.g., every bet is eligible for rebate up to 3%).  
   - *Supporting FAQ:* "What are the requirements for claiming a first deposit bonus?", "How do rebate and cashback bonuses work?"  

7. **Check system detection for restrictions or disqualifications.**  
   - Verify if there are repeated account activities from the same IP address, bank card, or phone number.  
   - If detected, inform the player that rewards and profits will be confiscated and that the bonus cannot be claimed.  
   - *Supporting FAQ:* "Why might I not receive bonuses?", "If system detects repetition involving...".  

8. **If the player claims a bonus, ensure they meet all conditions at the time of claim.**  
   - Confirm the deposit has been made and the bonus claim has been executed within the required timeframe (e.g., 12 hours for first deposit bonus).  
   - Confirm the player has met wagering or turnover requirements for withdrawal eligibility.  
   - *Supporting FAQ:* "Deposit bonus claiming and eligibility processes", "Turnover requirement must be met before withdrawal."

9. **If the bonus is not received automatically or the player reports not receiving it, advise to:**  
   - Verify account details and eligibility; ensure all conditions are met.  
   - Check the Rewards Center to manually claim or verify the bonus status.  
   - If the bonus still isn't visible or credited after the stipulated time, escalate to the back office or technical team for investigation.  
   - *Supporting FAQ:* "What if I do not receive bonuses?" "Bonuses are automatically credited once conditions are met."

10. **Explain any specific rules or warnings.**  
    - Remind the player that the system detects and disqualifies accounts using same IP, bank card, or phone number across multiple accounts.  
    - Reinforce the importance of completing wagering requirements before withdrawal.  
    - Clarify that bonuses are subject to terms and conditions, including turnover requirements and claim timeframes.  
    - *Supporting FAQ:* "What are the policies regarding deposit bonuses?"

11. **Close the case with a summary of the current status**  
    - Confirm the bonus was successfully credited or inform of any issues, restrictions, or next steps (e.g., resubmitting ID, verifying activity).  
    - Advise the player to check the Rewards Center for updates.  

## Notes

- Bonuses such as the First Deposit Bonus are automatically distributed after a qualifying deposit but must be claimed within the specified timeframe (e.g., 12 hours).  
- Verification of account completeness (real name, mobile phone, bank card linkage) is essential for bonus eligibility.  
- Repeated activity from the same IP address, bank card, or phone number may lead to confiscation of rewards and profits.  
- Players should meet turnover requirements before attempting withdrawal of bonus funds or related profits.

## Key points for communicating with players

- Clarify that bonuses are either automatically credited or require manual claim via the Rewards Center.  
- Remind players of the importance of meeting all conditions (deposit, wagering, timing).  
- Warn against using the same IP, bank card, or phone number across multiple accounts, as it affects bonus eligibility.  
- Advise to check the Rewards Center regularly for bonus updates and verification of their claims.