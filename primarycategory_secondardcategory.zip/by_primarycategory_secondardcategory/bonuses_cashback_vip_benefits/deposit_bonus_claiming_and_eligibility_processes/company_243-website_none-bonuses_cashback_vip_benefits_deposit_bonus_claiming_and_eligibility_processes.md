# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify Player Identity and Account Details**
   - Confirm the player's registered mobile number matches the one receiving the bonus-related SMS.
   - Ensure the player's personal information, including security details, are fully completed and verified in the system.
   - Check if the player's account is active and in good standing.

2. **Identify the Relevant Promotion or Bonus**
   - Determine which bonus or promotion the player is referencing, such as:
     - SMS bonus promotion
     - PayMaya deposit bonus
     - USDT deposit bonus
     - GrabPay deposit promotion
     - First Deposit Bonus (1st, 2nd, 3rd)
     - Welcome Bonus
     - Loyal Members SMS Bonus
     - Birthday Bonus
     - VIP rebates
   - Confirm the promotion name and eligibility criteria.

3. **Check Player's Eligibility for the Promotion**
   - Ensure the player fulfills specific conditions:
     - For SMS Bonus:
       - Mobile number matches registered account.
       - Bonus applies only to Slots and Fishing Games.
       - No deposit needed; player must win PHP 10,000.
     - For PayMaya Deposit Bonus:
       - Player used PayMaya to deposit PHP 100 or more in a single transaction.
       - Single IP address, mobile number, bank details, and personal info used only once per day.
     - For USDT Deposit Bonus:
       - USDT deposit made.
       - Verified phone number, linked withdrawal account, and real name on file.
       - One claim per day.
     - For GrabPay Promotion:
       - Deposit of PHP 100 or more in one transaction.
       - One claim per day, with 1x rollover to withdraw winnings.
     - For First and Second Deposit Bonuses:
       - Phone verified at deposit time.
       - GCash account number added.
       - Completed personal information.
       - Promotion box ticked during deposit.
       - No floating deposits on account.
     - For First 3 Deposits Bonus:
       - Each deposit made in order with respective bonus percentage and turnover requirement.
       - Same eligibility criteria as above.
     - For Welcome Bonus:
       - Sign-up and download the app.
       - Make at least one deposit.
       - Bonus automatically credited upon fulfilling deposit.
     - For Birthday Bonus:
       - Active depositors.
       - Submit valid ID, profile screenshot, and payment details on birthday.
       - VIPs with 30+ deposits in last 3 months may get bigger bonus.
     - For VIP rebates:
       - Meet the required VIP level.
       - Bets and losses from previous day qualify for rebate; credited after 3:00 AM.
   
4. **Determine If Player Meets the Bonus Conditions**
   - Confirm that all necessary steps above are completed successfully.
   - Check if the player has added the correct account details (Gcash, bank, withdrawal account as needed).
   - Verify that the account’s IP, mobile number, and banking info are consistent for bonus-specific conditions.

5. **Check Bonus Application and System Distribution**
   - For automatically distributed bonuses:
     - Verify system has credited the bonus.
   - For bonuses requiring manual activation:
     - Confirm the player ticked the promotion box during deposit (if applicable).
   - For SMS and other special bonuses:
     - Ensure all criteria (e.g., winning PHP 10,000, qualifying bet amounts) are met.
   
6. **Handle Insufficient Eligibility or Errors**
   - If the player has not met eligibility:
     - Explain relevant requirements clearly, e.g., complete verification, meet turnover, or deposit conditions.
   - If system has not credited the bonus:
     - Advise player to try again or check if all conditions are met.
   - If there are discrepancies or uncertainties:
     - Escalate the case according to company policy for further review.

7. **Confirm Wagering and Withdrawal Conditions**
   - For bonuses with wagering requirements:
     - Inform players of the turnover multiples (e.g., 3x, 8x, 12x).
     - Ensure betting is done on permitted games (Slots, Fishing, Poker, etc.).
   - For winnings:
     - Confirm that players have fulfilled the rollover to be eligible for withdrawal.
     - Make players aware of maximum payout limits (e.g., PHP 10,000 for SMS bonus).

8. **Document and Close the Ticket**
   - Record the detailed eligibility check outcome.
   - Note any conditions met or unmet.
   - Inform the player of the next steps or confirm bonus status.
   - Proceed to assist the player with withdrawal or further bonus-related inquiries as needed.

## Notes
- Always verify account details before processing any bonus claims.
- Bonuses are often system-credited automatically if conditions are met.
- Ensure players understand turnover and game restrictions for specific bonuses.
- For bonuses requiring manual submission (e.g., birthday, VIP rebate), confirm receipt of all documentation before proceeding.
- For bonuses with limits or maximum payouts, communicate these clearly to the player.

## Key points for communicating with players
- Clearly explain bonus eligibility criteria and requirements.
- Confirm matching contact details (mobile number, account info).
- Remind players of wagering requirements if applicable.
- Inform players of the maximum payout limits for specific bonuses.
- Escalate cases where conditions are unclear or unmet, following internal policies.