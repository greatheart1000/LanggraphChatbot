# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player's eligibility for the bonus or promotion**
   - Confirm if the player is a new or returning user, and if the promotion is currently active.
   - Check if the player has made an initial deposit of at least 100 PHP to qualify for the First Deposit Bonus.
   - Ensure the player has not already claimed the bonus if it’s a limited or exclusive promotion.
   - For VIP benefits such as the VIP Weekly Wages, verify the player’s VIP tier and if the weekly deposit requirement (minimum of 100 PHP within the week) has been met.
   - Confirm if the player qualifies for daily bonuses or Angpao promotions based on their app download status or deposit amounts.

2. **Inform the player about the specific bonus details and requirements**
   - Clearly explain the bonus amount (e.g., 68 PHP for the first deposit bonus).
   - Mention maximum bonus limits (up to 10,888 PHP for the First Deposit Bonus).
   - Describe how to claim:
     - Direct the player to visit the Rewards Center.
     - Instruct to click on the 'Claim' button within the designated period or after meeting criteria.
   - Highlight the turnover requirement of 8x for the First Deposit Bonus before any withdrawal can be processed.
   - For VIP Weekly Salary, inform that it is automatically sent every Monday between 22:00 - 23:59 (GMT+8) if requirements are met.
   - Note about automatic distribution of system rebates or weekly wages when applicable.

3. **Check for proper procedural compliance**
   - Confirm that the bonus has been credited within 12 hours of deposit if it is a first deposit bonus.
   - Verify if the system has successfully credited the bonus in the Rewards Center.
   - In case the bonus is not credited, advise the player to check their Rewards Center or re-claim if necessary.

4. **Collect relevant documentation or screenshots if required**
   - If the player reports an issue or claims that the bonus was not received, request screenshots of:
     - The promotion page showing the bonus.
     - The Rewards Center indicating available bonuses.
   - Ensure the screenshots clearly show relevant details for validation.

5. **Perform system and account checks for eligibility violations**
   - Check for repeated IP address, bank card, or phone number usage that could lead to confiscation of rewards and profits.
   - Review deposit history to confirm the deposit amount meets the minimum threshold.
   - For VIP weekly benefits, confirm the player's betting activity meets the requirement of at least 1 valid bet on slot or fish games within the week.

6. **Determine the resolution based on findings**
   - If the bonus is credited properly and all conditions are met:
     - Inform the player they can now meet the turnover requirement (8x) to withdraw.
     - Advise on how to proceed with wagering if needed.
   - If the bonus has not been credited or eligibility criteria are not met:
     - Explain clearly that the bonus will only be available after meeting the requirements.
     - Mention that bonuses are automatically distributed or accessible in the Rewards Center.
     - Confirm there are no violations such as repeated IP, bank card, or phone number usage.

7. **Advise on withdrawal conditions**
   - Remind players they must fulfill the 8x turnover requirement for the First Deposit Bonus before requesting any withdrawals.
   - Emphasize that bonuses are only available for withdrawal after the turnover condition is satisfied.
   - Inform players that violations involving repeated system entries may lead to loss of rewards and profits.

8. **Escalate or take further action if needed**
   - If there are discrepancies, system errors, or other issues beyond standard procedures:
     - Escalate to the technical or management team.
     - Instruct the player to remain patient while the issue is investigated.

## Notes
- Bonuses such as the First Deposit Bonus are automatically distributed within 12 hours of the first deposit; if not received, advise players to check their Rewards Center.
- The VIP Weekly Salary bonus is automatically credited every Monday between 22:00 and 23:59 (GMT+8) based on weekly betting activity.
- Repeated use of the same IP address, bank card, or phone number may result in confiscation of rewards and profits.
- Always verify the player's deposit amount and VIP tier before providing further assistance.
- Use clear, straightforward language when explaining the claiming process and requirements to ensure player understanding.

## Key points for communicating with players
- Remind players that bonuses are typically credited within 12 hours after deposit.
- Emphasize the 8x turnover requirement before withdrawal.
- Clarify that bonus confiscation may occur if system checks detect repeated usage patterns involving IP, bank card, or phone number.
- Reinforce that the Rewards Center is where they claim or check their bonuses.
- Explain that VIP Weekly Wages are automatically sent each Monday provided the weekly deposit activity requirement is satisfied.