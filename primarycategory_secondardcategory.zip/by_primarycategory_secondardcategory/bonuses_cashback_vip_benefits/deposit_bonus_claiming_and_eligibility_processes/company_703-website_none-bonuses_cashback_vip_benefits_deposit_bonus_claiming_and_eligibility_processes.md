# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry** regarding deposit bonuses, cashback, or VIP benefits to determine the specific process or issue they need assistance with.

2. **Verify player identity and account status** to ensure the player is active and eligible for promotion-related actions.

3. **Gather relevant information from the player**:
   - Confirm if they are claiming a new registration bonus or a deposit bonus.
   - Ask for the details of their recent deposits, including amounts and dates, if applicable.
   - Check if they participated in any specific promotion (e.g., first deposit, daily cash-in, Slot & Fish bonus).
   - For cashback inquiries, confirm the bets placed and if the cashback was automatically credited or manually claimed.

4. **Check the player's recent activity and deposit history** in the back office:
   - Confirm if they have made their first deposit of at least 100 PHP to qualify for the New Member First Deposit Bonus.
   - Verify if they utilized the download of the official app and claimed their registration bonus (up to 888 PHP ANGPAO).
   - For daily first cash-in bonuses, verify deposit amounts and transaction dates.
   - For Slot & Fish bonus claims, check if the player has bet more than 1500 PHP on relevant games and logged in before 4:00 AM GMT+8 the following day.
   - For VIP benefits, confirm the player’s VIP tier and weekly deposit amount if they are checking for the VIP weekly salary.

5. **Determine eligibility based on the applicable criteria**:
   - **New Member First Deposit Bonus**: 
     - Confirm deposit of at least 100 PHP.
     - Confirm login to Rewards Center within 12 hours.
     - Ensure the bonus is not already claimed or exceeded.
   - **New Register Bonus**:
     - Confirm registration on the official website and download of the app.
     - Confirm claim of the welcome bonus in the Rewards Center.
     - Check for meeting the 10x turnover requirement before withdrawal.
     - For non-deposit users, maximum withdrawal is 100 PHP.
   - **Daily First Cash-in Bonus**:
     - Confirm deposit amounts align with the tiered bonus structure.
     - Confirm bonus claimed in the Rewards Center.
     - Confirm the turnover requirement (10x) is met before withdrawal.
   - **Slot & Fish Bonus**:
     - Verify bet amount exceeds 1500 PHP on Slot & Fish games.
     - Confirm login before 4:00 AM GMT+8 on the following day.
     - Check if rewards have been claimed in the Rewards Center.
   - **Cashback**:
     - Confirm if the cashback was automatically credited or if the player manually claimed it.
     - Confirm the bet and wager history/eligible bets.
   - **VIP Weekly Salary**:
     - Verify the player deposited at least 100 PHP within the week.
     - Confirm if the salary was credited on Wednesday between 22:00 and 23:59 (GMT+8).
   - **General Eligibility**:
     - Check for repeated use of the same IP address, bank card, or phone number, which may lead to confiscation of rewards or profits if applicable.

6. **For eligible players**:
   - Guide the player to access the Rewards Center to claim their bonuses or rewards if not automatically credited.
   - Inform the player about the turnover requirements and the need to meet them before withdrawal.
   - Confirm that the bonus can only be used on SLOT & FISH games if applicable.
   - Inform them of the cashback being automatically sent unless manually claimed.
   - Remind players that the VIP Weekly Salary and bonuses are credited on specific days/times as per the rules.

7. **For ineligible players or if conditions are not met**:
   - Clearly explain the reason (e.g., deposit amount below minimum, login outside of claim window, turnover not met, or incomplete activity).
   - Advise on the necessary steps to fulfill the eligibility criteria if possible.
   - If suspicion of repeated use of same IP, bank card, or phone number, notify that rewards and profits may be confiscated.

8. **Escalate complicated cases or disputes**:
   - If discrepancies or issues beyond standard checks arise, escalate to the appropriate department according to the company's protocol.

9. **Close the case**:
   - Summarize the findings and inform the player of their current bonus status.
   - Confirm if further action is required or if the issue is resolved.
   - Document the interaction and any actions taken.

## Notes
- Bonuses generally require meeting a turnover of 10x before withdrawal, applicable to most bonuses including deposit and registration incentives.
- Cashback is automatically sent to the player's account unless they choose to claim it manually.
- The VIP Weekly Salary is credited automatically every Wednesday between 22:00 and 23:59 (GMT+8), contingent on meeting the deposit criteria within the week.
- The maximum withdrawal for non-deposit users claiming bonuses without additional deposits is 100 PHP.
- Promotional bonuses and rewards are only valid on specified games such as SLOT & FISH unless otherwise noted.

## Key points for communicating with players
- Clarify bonus conditions clearly, especially the turnover requirements.
- Remind players to log in to the Rewards Center within the specified timeframes.
- Explain the automatic or manual process of cashback distribution.
- Emphasize the importance of meeting deposit and betting conditions before withdrawal.
- Always verify recent activity and system records before providing conclusions.