# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information**  
   - Confirm the player's account details and verify identity if necessary.  
   - Ask if the player is requesting information about claiming a deposit bonus, VIP upgrade, or other rewards.

2. **Check the specific bonus or reward the player is requesting**  
   - Determine if the player is inquiring about the first-time deposit bonus or other promotional offers.  
   - For deposit bonuses, clarify if the player has made the minimum deposit of at least 100 units and selected the bonus option during deposit, if applicable.

3. **Verify deposit requirements for bonuses**  
   - Confirm if the deposit was made under conditions eligible for the bonus.  
   - Check if the bonus is available for specific game categories such as electronic slots and fishing games, as per the bonus terms.

4. **Assess player eligibility for deposit bonuses, cashback, or VIP benefits**  
   - For deposit bonuses: Ensure the player has fulfilled initial deposit conditions (e.g., at least 100 units for first-time bonus).  
   - For VIP upgrade or bonuses: Check if the player has achieved the specific deposit amounts or level criteria in the Member Center.  
   - For cashback or daily login bonuses: Confirm if the player has claimed previous rewards and completed necessary actions (e.g., daily login).

5. **Review bonus/wagering conditions**  
   - Verify any wagering requirements or restrictions associated with the bonus, as detailed in the bonus terms.  
   - For deposit bonuses, confirm they are limited to specified game categories and subject to rules on usage and wagering.

6. **Determine next steps based on eligibility and reward status**  
   - If the player has fulfilled all conditions and the bonus is available:  
     - Advise the player to claim the bonus/reward via the Reward Center or Promotion page.  
     - Guide the player to click on 'Member Center', then navigate to 'Reward Center' to claim their daily login bonus or promotional reward.  
   - If the bonus is not available or conditions are not met:  
     - Explain clearly which conditions are missing or unmet, referencing the bonus terms or VIP upgrade criteria.  
     - If applicable, advise the player on the steps to meet these conditions or on eligibility for future promotions.

7. **Advise on additional actions or escalations**  
   - If the player claims a bonus or reward successfully, confirm the credit and remind about wagering conditions.  
   - If the player encounters issues with claiming or eligibility, escalate to the relevant department with all collected information and documented verification steps.

## Notes
- Bonuses such as daily login rewards and promotional offers can be claimed via the Reward Center.  
- Deposit bonuses are limited to specific game categories (e.g., slots and fishing games) and may have wagering requirements.  
- First-time deposit bonus: 100% match bonus available when depositing at least 100 units and selecting the bonus option during deposit.  
- VIP upgrades require achieving certain deposit amounts or levels as specified in the Member Center.

## Key points for communicating with players
- Clearly explain the specific conditions for bonuses and VIP benefits, referencing the relevant requirements.  
- Instruct players to visit the 'Reward Center' or 'Member Center' for claiming rewards.  
- Remind players of wagering requirements and usage restrictions tied to deposit bonuses.