# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's account status and eligibility for the deposit bonus.**
   - Confirm that the player is a new member to qualify for the first deposit bonus.
   - Check whether the player has already claimed the bonus from the same IP address or device (if applicable).

2. **Instruct the player to verify their phone number before making the deposit.**
   - Ensure the player completes phone number verification prior to depositing, as this is a requirement for bonus eligibility.

3. **Guide the player to make their first deposit of more than ₱100.**
   - Confirm that the deposit amount exceeds ₱100.
   - Verify that the deposit is successful in the back office system.

4. **Ensure the player selects or confirms the promotion box during the deposit process.**
   - Advise the player to click or toggle the promotion offer box to select the deposit bonus promotion.
   - Confirm that the promotion selection is active before completing the deposit.

5. **Check for system and eligibility conditions post-deposit.**
   - Verify that the player has deposited more than ₱100 for the first time.
   - Confirm that the player's IP address or device has not previously claimed the bonus.
   - Ensure the player has correctly verified their phone number before depositing.

6. **Confirm automatic crediting of the bonus.**
   - If all conditions are met, the system will automatically credit the 77% bonus to the player's game account.
   - Notify the player that their bonus has been credited successfully.

7. **Address cases where bonus is not credited.**
   - Confirm whether the deposit meets the minimum requirement of ₱100.
   - Verify if the player has used the same IP address or device that previously claimed the bonus.
   - Check if the player failed to select or confirm the promotion box during deposit.
   - Advise the player to retry the deposit with compliance to all conditions if applicable.

## Notes
- The first deposit bonus of 77% is only available once per player, subject to IP address and device restrictions.
- Deposits from the same IP address, device, or similar accounts may be ineligible for the bonus.
- Phone verification must be completed before deposit for the bonus to be eligible.
- Bonus is automatically credited if the system detects all conditions are met during the deposit process.

## Key points for communicating with players
- Remind players to verify their phone number before depositing.
- Instruct players to select the promotion box during the deposit process.
- Confirm deposit amount exceeds ₱100.
- Explain that bonuses may be unavailable if using the same IP or device as previous claims.
- Notify players that the bonus will be credited automatically upon successful qualifying deposit and selection.