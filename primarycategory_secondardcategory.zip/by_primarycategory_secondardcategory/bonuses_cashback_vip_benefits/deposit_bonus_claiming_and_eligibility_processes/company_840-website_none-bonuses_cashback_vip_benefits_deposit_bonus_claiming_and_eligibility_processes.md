# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather initial player information**:
   - Confirm whether the player is a new or returning customer.
   - If new, verify if they are eligible for the first deposit bonus.
   - For birthday or VIP bonuses, confirm VIP level (e.g., VIP3 or higher) and birthday status.

2. **Verify deposit details and eligibility**:
   - Confirm the player has deposited the minimum required amount (e.g., at least 100 PHP for first deposit bonus).
   - Check if the deposit qualifies for the specific promotion (e.g., first deposit, second deposit, app registration).
   - For promotional eligibility (e.g., birthday bonus), ensure all required documents and validations are completed, such as submitting valid IDs and a selfie with IDs, with birth date visible.

3. **Check for system restrictions and detection**:
   - Review for potential violations, such as repeated use of the same IP address, bank card, or phone number.
   - If repeated use is detected, inform the player that rewards and profits may be confiscated.

4. **Determine the applicable bonus**:
   - For first deposit bonus:
     - Confirm amount deposited is at least 100 PHP.
     - Automatically credit a bonus of 109 PHP (up to a maximum of 29,999 PHP).
   - For second deposit bonus:
     - Verify deposit was made for a second time.
     - Automatically credit a bonus of 59 PHP (up to a maximum of 16,999 PHP).
   - For app registration bonus:
     - Confirm registration on the website and app download.
     - Bonuses are credited automatically within 2 hours post-registration.
   - For birthday or VIP bonuses:
     - Confirm eligibility based on VIP level or birthday validation.

5. **Check for bonus distribution timing and method**:
   - Review the Rewards Center:
     - Confirm if the bonus has been credited.
     - Bonuses are typically credited within 12 hours of deposit or registration.
   - Note: promotional bonuses are distributed automatically by the system; players do not need to claim manually.

6. **Explain the turnover requirement**:
   - Inform the player that a 15x turnover (or specific requirement per promotion) must be met before they can withdraw winnings.
   - Clarify that bonus funds are subject to this wagering requirement.

7. **Confirm permitted games for bonus wagering**:
   - Bonuses generally apply to SLOT and FISH games; verify that the player is engaging in these during wagering.

8. **Clarify restrictions and potential confiscation**:
   - Advise players that rewards and profits may be confiscated if repeated violations (e.g., using the same IP, bank card, or phone number) are detected.

9. **Assist with further actions if bonus is not received**:
   - Suggest the player reviews their Rewards Center or promotion details.
   - Check if all conditions are met.
   - If not credited within the expected timeframe (12 hours), escalate or escalate to review eligibility and any system anomalies.

10. **Document the case and inform the player of next steps**:
    - Record the deposit details, bonus amount, and any relevant notes on detection or eligibility.
    - Advise the player on the importance of meeting the wagering requirement before withdrawal.

## Notes
- The first deposit bonus is awarded automatically after depositing at least 100 PHP, and the bonus amount increases with higher deposits.
- All bonuses are subject to a 15x turnover requirement with a specific time frame (usually before withdrawal).
- Promotions are continuously checked for system detections of repeated use via IP, phone number, or bank card.
- The Rewards Center is the main portal for reviewing or confirming bonus credits.
- Bonuses are only applicable for SLOT and FISH games unless specified otherwise.
- Repeated violations can result in confiscation of rewards and profits.

## Key points for communicating with players
- Clearly inform players of the minimum deposit required to qualify for bonuses.
- Remind players to visit the Rewards Center within 12 hours of deposit to verify bonus credits.
- Explain the 15x turnover requirement to ensure they understand wagering obligations.
- Warn players about detection risks related to repeated use of the same IP, phone number, or bank card.
- Confirm players' VIP level or special conditions if they are claiming VIP or birthday bonuses.
- Emphasize automatic distribution of bonuses; manual claiming is typically not required.