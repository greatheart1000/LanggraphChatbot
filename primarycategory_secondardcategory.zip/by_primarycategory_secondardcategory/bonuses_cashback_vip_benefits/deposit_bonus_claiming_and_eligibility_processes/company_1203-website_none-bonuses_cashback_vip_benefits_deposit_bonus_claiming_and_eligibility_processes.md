# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player identity and eligibility**
   - Confirm that the player has a valid account and has completed any necessary verification processes.
   - Ensure the player has verified their phone number, as phone verification is a prerequisite for claiming the deposit bonus.

2. **Confirm the player's deposit attempt details**
   - Ask the player for the deposit amount and the date/time of the deposit.
   - Verify that the deposit meets the minimum threshold specified in the promotional terms (e.g., at least 500 PHP).
   - Check that the deposit was made from the same device and IP address the player used during registration or prior bonus claims, if applicable.

3. **Check if the player is eligible for the deposit bonus**
   - Verify whether the player has already claimed a deposit bonus from their current IP address or device, as bonuses are limited to one per IP or device.
   - Confirm no duplicate accounts are associated with the player, as multiple accounts may restrict bonus eligibility.
   - Ensure the player selected the promotional offer during the deposit process by checking if they ticked the Promotions box in the deposit section.

4. **Review the promotional conditions**
   - Ensure the player has deposited the minimum amount specified (e.g., 500 PHP).
   - Confirm if there are any wagering or turnover requirements (e.g., reach a certain number of valid bets or wagering multiples) before claiming or using the bonus (as per the current site policies).

5. **Confirm bonus distribution**
   - If all conditions are met, process the bonus distribution automatically to the player's account.
   - If the bonus was not received:
     - Check for common reasons such as prior bonus claims from the same IP or device, unverified phone number, or omission of selecting the promotion box.
     - Inform the player of possible restrictions and suggest re-verification or clarifications if needed.

6. **Address issues and explain restrictions**
   - If the player did not qualify, explain that bonuses are limited to one per IP address or device.
   - Clarify that multiple accounts or previous claims on the same device/IP might prevent bonus eligibility.
   - Remind the player to verify their phone number and select the promotional offer during deposit for future claims.

## Notes
- Bonuses are automatically distributed once all promotional conditions are met.
- Bonuses cannot be claimed multiple times from the same IP address if already used.
- Deposit bonuses are subject to specific conditions such as minimum deposit amounts and wagering requirements, which can vary according to current offers.

## Key points for communicating with players
- Emphasize the importance of phone number verification and selecting the promotion checkbox.
- Clarify that bonuses are limited to one per IP address or device.
- Inform players that multiple accounts or prior deposits without verification may restrict bonus access.
- Encourage players to contact support if they believe they meet all conditions but have not received the bonus.