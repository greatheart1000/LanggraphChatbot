# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify Player Eligibility**
   - Confirm the player has completed all required registration steps:
     - Bound a bank card
     - Registered with a real name
     - Verified their mobile phone number
   - Ensure the player is logging in from a unique IP address; systems automatically check for repeated IPs, phone numbers, or bank cards that could disqualify eligibility.
   - Inform the player that failure to meet these requirements may result in ineligibility for bonuses.

2. **Identify the Relevant Bonus or Promotion**
   - Determine which bonus or promotional reward the player is requesting:
     - First Deposit Bonus
     - Second Deposit Bonus
     - New Register Bonus
     - Rescue Bonus for losses
     - VIP Weekly Salary
     - Other bonuses or cashback
   - Clarify the specific terms applicable to the promotion, such as deposit amounts, bonus percentages, and maximum bonus caps:
     - For example, First Deposit of 50 PHP grants a bonus of 59 PHP; maximum bonus up to 10,999 PHP.
     - Second deposit of 100 PHP grants 49 PHP bonus; same maximum applies.
     - Register bonus up to 999 PHP; angpao bonus up to 1,888 PHP.
     - Turnover requirement: e.g., 8x or 20x depending on the bonus.
 
3. **Guide Player on How to Claim the Bonus**
   - For automatic bonuses like registration, the bonus is credited within approximately 2 hours after registration and app download.
   - For deposits:
     - Instruct the player to deposit the required amount (e.g., 100 PHP for first deposit bonus).
     - Advise to log in to the Rewards Center within 12 hours of deposit.
     - Clarify that the bonus can be claimed by clicking "Claim" in the Rewards Center if not automatically credited.
   - Confirm that bonuses are only applicable to Slot & Fish games (for registration and some bonuses).

4. **Check for Repetition or Fraudulent Activity**
   - Verify whether the system has detected repeated use of the same IP address, bank card, or phone number.
   - If repetition is detected:
     - Explain to the player that rewards and profits may be confiscated.
     - Advise on rectifying any accidental overlaps, but emphasize that illegal or suspicious use disqualifies bonuses.

5. **Inform the Player About Turnover Requirements**
   - Reinforce that the bonus is subject to a turnover (wagering) condition:
     - e.g., 8x or 20x depending on the promotion.
     - The player must meet this requirement before any withdrawal.
   - Encourage players to wager on Slot & Fish Games with the bonus if applicable, and not to initiate withdrawal before meeting requirements.

6. **Advise on Timing and Claiming Procedure**
   - Remind the player to log in to the Rewards Center within 12 hours to claim bonuses if applicable.
   - For bonus detection delays or issues, advise patience as the system credits bonuses automatically when eligible.
   - For the registration bonus, ensure the player completes registration and downloads app to receive angpao bonus up to 1,888 PHP.

7. **Address Common Issues**
   - If the player reports not receiving bonuses:
     - Check if the player has met all eligibility criteria.
     - Confirm deposit and claim actions, and ensure the player logs into the Rewards Center within the specified timeframe.
     - Note that bonuses are automatically distributed within 2 hours for registration, while deposit bonuses require manual claiming.
   - Notify that bonuses cannot be transferred or withdrawn before meeting turnover conditions.

8. **When Rejections or Disqualifications Occur**
   - Explain that violations such as using the same IP, bank card, or phone number for multiple accounts will lead to confiscation of rewards/profits.
   - Advise players to use unique devices and information to avoid disqualification.
   - If necessary, escalate to relevant departments for investigation of suspicious activity.

## Notes

- Bonuses are automatically credited within 2 hours if the player is eligible and all criteria are met.
- Bonuses only apply to Slot & Fish Games, except where explicitly stated.
- Always verify the player's registration details, deposit history, and activity logs before processing bonus claims.
- Repetition detection (IP, bank card, phone number) is critical in bonus eligibility checks.

## Key points for communicating with players

- Clearly inform players of the specific deposit amounts and the maximum bonuses they can earn.
- Emphasize the importance of claiming bonuses within 12 hours.
- Remind players that they must meet the relevant turnover requirements before withdrawal.
- Warn about potential confiscation of rewards if system rules are violated.
- Reassure that bonuses are credited automatically when conditions are fulfilled, but manual claims are available if needed.