# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or account issue related to bonuses or VIP benefits.**  
   - Determine if the player is asking about claiming a specific bonus, verifying eligibility, or encountering an issue with receiving a bonus or benefit.

2. **Gather necessary player details.**  
   - Player's registered account information (username, registered email/phone, VIP tier, deposit history).  
   - Specific bonus or promotion they are referring to (e.g., First Deposit Bonus, Second Deposit Bonus, VIP Weekly Wages).

3. **Verify player's eligibility for the specific bonus or benefit.**  
   - Check if the player has fulfilled the promotion's requirements such as:  
     - Making the qualifying deposit or activity (e.g., first deposit of at least 100 PHP, second cash-in of 100 PHP).  
     - Completing the required number of valid bets on slot or fish games within the relevant week for VIP Weekly Wages (e.g., at least 1 valid bet).  
     - Meeting additional eligibility conditions such as linking bank card, providing mobile number, or using the same IP, if applicable.

4. **Check the bonus distribution status in the system.**  
   - Confirm if the bonus has been automatically credited or if the player has claimed it manually via the Rewards Center.  
   - Verify the system-distributed date and time (e.g., within 12 hours after meeting the requirements).  
   - For VIP Weekly Wages, verify the completion of the week's bets before Tuesday between 22:00 - 23:59 (GMT+8).

5. **If the bonus or benefit has not been received when expected:**  
   - Confirm the player's compliance with the requirements:  
     - Was the deposit made within the promotion time frame?  
     - Are the wagering or turnover requirements met?  
   - Check for common issues:
     - Player's account restrictions or violations.  
     - Multiple accounts/IP addresses/binding same bank card, which may affect eligibility.

6. **If the player claims not to have received a bonus that should be automatically distributed:**  
   - Advise to check the Rewards Center for the bonus.  
   - Inform that all bonuses, cashback, and rebates are automatically distributed by the system within 12 hours after meeting requirements.  
   - Suggest the player log out, clear cache, or try accessing Rewards Center again.  

7. **If the bonus still does not appear or if the player is unsure of their eligibility:**  
   - Reconfirm their activity details and eligibility criteria.  
   - If they believe all criteria are met but still not received, escalate the case for manual review, noting:  
     - Date/time of deposit or activity.  
     - Any relevant account restrictions.  
     - Specific promotion details they attempted to claim.

8. **For players requesting clarification on different bonuses:**  
   - Clearly explain the requirements based on the promoted offer:  
     - First Deposit Bonus: Deposit at least 100 PHP, bonus sent within 12 hours, turnover required.  
     - Second Deposit Bonus: Second cash-in of 100 PHP, bonus sent within 12 hours, turnover required.  
     - New Register Bonus: Register and download the app, bonus sent within 2 hours, max withdrawal of 100 PHP if non-deposit.  
     - VIP Weekly Wages: Automatically sent every Tuesday, require 1 valid bet on slot or fish within the week.

9. **In case of discrepancies or disputes:**  
   - Verify the transaction timestamps and system logs.  
   - Confirm no violations of eligibility criteria (e.g., using same IP or bank card as other accounts if restrictions apply).

10. **Advise the player on next steps:**  
    - If eligible and bonus is not received: wait up to 12 hours, or escalate if system delay persists beyond that.  
    - If ineligible: explain clearly the specific reason based on their activity or account info.  
    - For missing or incorrect bonuses, escalate to the technical team if needed.

## Notes

- Bonuses are automatically distributed by the system if players meet all conditions; manual claiming is not required for most bonuses.  
- Remember to verify the timing of deposits and bets, especially for bonuses with time limits (e.g., within 12 hours).  
- For VIP Weekly Wages, ensure the player has completed at least one valid bet on Game Types specified within the week.  
- Always confirm whether the player has used the same bank card, phone number, and/or IP address if eligibility criteria include such restrictions, as violations may affect bonus eligibility.

## Key points for communicating with players

- Clearly explain the specific requirements for each bonus or benefit they are inquiring about.  
- Emphasize the automatic distribution system and typical 12-hour timeframe.  
- If bonuses are not received, advise patience first; escalate if all criteria are confirmed met but bonus remains unreceived after 12 hours.  
- Ensure players understand that non-eligibility reasons include account restrictions or failure to meet wagering requirements.