# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player registration and initial deposit**
   - Confirm the player has made their first deposit of at least 100 PHP.
   - Ensure the deposit was completed through an approved method.
   - Note: Rewards are automatically credited within 12 hours after deposit; check if the bonus is visible in the Rewards Center.

2. **Check bonus eligibility and available promotions**
   - Confirm if the player is eligible for the current first deposit bonus (108% up to 28,888 PHP) or second deposit bonus (58 PHP up to 16,888 PHP), based on deposit sequence.
   - Verify the player’s VIP level if they claim VIP-specific bonuses, such as the Birthday Bonus (eligible from VIP3 onwards).

3. **Instruct the player to visit the Rewards Center**
   - Ask the player to log into their account and navigate to the Rewards Center within 12 hours of their deposit.
   - Remind them that bonuses are distributed automatically and can be viewed there.
   - Emphasize that bonus distribution may take up to 12 hours.

4. **Explain the turnover requirement before withdrawal**
   - Inform the player that most bonuses require meeting a 15x turnover of the bonus amount or total deposit before withdrawals.
   - Clarify that this applies to the bonus winnings; the requirement must be fulfilled prior to claiming withdrawal permissions.

5. **Check for detection of suspicious activity**
   - Review system alerts or flags for activities such as repeated deposits from the same IP address, bank card, or phone number.
   - Note: Repeated activity may lead to confiscation of rewards and profits, and account restrictions.

6. **Confirm manual claim procedures (if applicable)**
   - Guide the player to click ‘claim’ in the Rewards Center if a manual claim is necessary or recommended.
   - Ensure the bonus is visible and correctly credited.

7. **Clarify the process for different bonuses**
   - For **first deposit bonus**:
     - Ensure the deposit was at least 100 PHP.
     - Advise the player to meet the 15x turnover requirement before withdrawal.
   - For **second deposit bonus**:
     - Confirm this is the second deposit with the specified bonus amount.
     - Engage the same verification process as above.
   - For **VIP bonuses** such as the Birthday Bonus:
     - Confirm the player has reached VIP3 status.
     - Remind that bonuses are granted as per the current program schedule.

8. **Explain bonus confiscation conditions**
   - Inform the player that if the system detects repeated use of the same IP address, bank card, or phone number, bonuses and profits may be confiscated.
   - Warn that any suspicious activity identified may lead to account restriction or ineligibility for current or future bonuses.

9. **Assist with common issues or delays**
   - If bonuses are not received within 12 hours, recheck the deposit details and system flags.
   - Advise the player to contact support with relevant evidence if delays persist.
   - Verify that all deposit conditions and eligibility criteria are met.

10. **Close the case with proper advice**
    - Remind the player: 
      - To meet the turnover requirement before withdrawal.
      - To maintain compliance with activity and account verification policies.
      - To check the Rewards Center regularly for bonus updates and status.

## Notes
- Bonuses are distributed automatically after deposit if the player meets all conditions.
- Repeated deposits from the same IP, bank card, or phone number may lead to confiscation of rewards.
- Bonuses and profits can be confiscated if suspicious activity is detected.
- The maximum bonus on the first deposit is 28,888 PHP, and on the second deposit, 16,888 PHP.
- The 15x turnover rule applies to most bonuses before withdrawal.

## Key points for communicating with players
- Clearly explain the 15x turnover requirement before withdrawal.
- Remind players to visit the Rewards Center within 12 hours of deposit.
- Warn about possible confiscation if suspicious activity is detected.
- Confirm deposit amount and eligibility for bonuses before assisting further.