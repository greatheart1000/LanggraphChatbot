# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's account and registration status**  
   - Confirm the player has registered on the official site and downloaded the PHFUN app.  
   - Check if the player is a new member or existing member eligible for specific bonuses. (FAQs: "What is the New Register Bonus and how do I claim it?", "What is the New Player First Deposit Bonus and how do I claim it?")

2. **Identify the relevant promotion or bonus the player inquires about**  
   - Determine if the player is requesting the New Register Bonus, First Deposit Bonus, VIP Birthday Bonus, or other specific bonuses.  
   - Check if the bonus is automatic or requires manual claim. (FAQs: "How do I claim new member bonuses or download bonuses?", "What is the New Player First Deposit Bonus and how do I claim it?")

3. **Gather necessary player verification details**  
   - For bonuses like VIP Birthday Bonus:  
     - Request verification documents: two valid IDs showing birthdate, a selfie holding your ID, and a screenshot of VIP rank.  
   - For other bonuses:  
     - Confirm if the player has successfully completed registration, app download, and deposit steps.

4. **Check eligibility and fulfillment of bonus conditions**  
   - Verify if the player has completed the required steps:  
     - Registration on the official site.  
     - Downloaded the PHFUN app.  
     - Made the minimum deposit (e.g., 100 PHP for first deposit bonus).  
     - Claimed bonuses via the Bonus Center or Rewards Center when applicable. (FAQs: "What are the rules for the New Player First Deposit Bonus?", "How do I claim the new member bonus after registration and app download?")  
   - Confirm if the bonus has been credited automatically or if the player needs to claim it manually.

5. **Check for any restrictions or disqualifications**  
   - Detect any suspicious activity: repeated deposits from the same IP, same bank, or same phone number.  
   - Ensure the player has not violated bonus rules or eligibility criteria such as VIP level restrictions (e.g., VIP Birthday Bonus only for VIP level 4+). (FAQs: "Bonuses and promotions are available to users who meet specific VIP level," "Rewards may be confiscated if duplicate methods are detected.")

6. **Confirm the bonus crediting status**  
   - For automatic bonuses:  
     - Verify in the system if the bonus has been credited. If not, advise patience; bonuses are typically credited within 12 hours if eligible.  
   - For manually claimed bonuses:  
     - Check if the bonus has been claimed in the Rewards Center or Bonus Center; guide the player accordingly.

7. **Explain turnover (wagering) requirements and withdrawal conditions**  
   - Inform the player that bonuses, such as the 69 PHP bonus for a 100 PHP deposit, require meeting the specified turnover requirement (e.g., 1x) before any withdrawal can be processed. (FAQs: "What are the turnover requirements?", "How does the first-deposit bonus work?")  
   - Advise the player to complete the wagering by playing eligible games (primarily SLOT and FISH for certain bonuses).

8. **Address any issues with bonus receipt or claims**  
   - If the bonus has not been credited within the expected timeframe (e.g., 12 hours), verify the player's activity history for potential disqualifications.  
   - Check for any unfulfilled requirements or incomplete steps (e.g., missing document submissions) if claiming is manual.  
   - If eligible and still not credited, escalate or advise the player to contact support with relevant proofs.

9. **Assist with VIP benefits or special bonuses**  
   - For VIP Birthday Bonus:  
     - Confirm the player has submitted all required verification documents (IDs, selfie, VIP rank screenshot).  
     - Verify VIP level is 4 or above. (FAQs: "What are the requirements for the VIP Birthday Bonus?")  
     - Upon approval, inform the player of the bonus amount based on their VIP level and that it will be credited accordingly.

10. **Provide players with instructions to claim or view bonuses**  
    - Remind players to check the Rewards Center or Bonus Center for credited bonuses.  
    - Guide them on how to claim available rewards if manual claiming is necessary.

11. **Document and close the case**  
    - Record the details of the bonus inquiry, verification steps taken, and resolution provided.  
    - Advise the player on required next steps (e.g., meet turnover, submit documents, wait for crediting).  
    - If applicable, instruct the player to recheck after the specified processing time, or escalate if issues persist.

## Notes

- Always verify the player's credentials and ensure all documentation is clear, legible, and correctly submitted before processing VIP or birthday bonuses.
- Bonuses are usually credited automatically, but manual claims require players to access the Rewards Center.
- Adhere to the specific withdrawal and wagering requirements related to each bonus, especially the 1x turnover rule.
- Monitor for suspicious activities, such as multiple accounts or same IP/phone/bank details, as these may lead to confiscations of bonuses and profits.
- For any unresolved issues or discrepancies, escalate to the appropriate support team with detailed case notes.

## Key points for communicating with players

- Clearly explain the eligibility criteria such as VIP level, deposit amount, and document submission.
- Remind players of the turnover requirement before withdrawal.
- Counsel patience if bonuses are not credited immediately, as they are usually processed within 12 hours.
- Ensure players understand the importance of submitting clear verification documents for VIP and birthday bonuses.
- Reiterate that bonuses may be confiscated if suspicious activity is detected, to maintain fairness and security.