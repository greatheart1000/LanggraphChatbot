# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather necessary information from the player**:
   - Confirm the player’s account details and verify their identity if needed.
   - Determine if the player is referring to a specific deposit bonus or promotion.
   - Ask if the player has already claimed a bonus from the same IP address or device, if relevant.

2. **Check the player's eligibility for deposit bonuses**:
   - Verify that the player has completed required verification steps, such as phone number verification.
   - Confirm that the deposit meets the specific conditions for the promotion, such as minimum deposit amount.
   - Ensure that the player has selected the proper promotion during depositing, if applicable.

3. **Review the bonus claim process on the system**:
   - Access the player's account in the back office or system.
   - Check if the bonus has been automatically credited, based on meeting the conditions.
   - If the bonus was not credited automatically, instruct the player to open the Reward Center.

4. **Guide the player to claim the bonus if not yet credited**:
   - Ask the player to open the Reward Center.
   - Instruct them to locate the relevant Bonus or Ticket.
   - Advise the player to select the Bonus or Ticket to claim.
   - Confirm if there are any on-screen instructions or additional steps for completing the claim.

5. **Verify and confirm bonus or promotion status**:
   - Confirm that the bonus has been successfully credited to the player's account.
   - Ensure that the bonus has been claimed only once per IP address or device, aligning with system restrictions.
   - Notify the player if the bonus cannot be claimed due to multiple claims from the same IP or device.

6. **Handle edge cases and policy restrictions**:
   - If the player claims multiple bonuses from the same IP/device or if the system restricts duplication, inform the player accordingly.
   - For bonus-related issues that cannot be resolved immediately, escalate to supervisory support if necessary.

## Notes
- Bonuses are automatically granted upon meeting the specified conditions, such as verifying the phone number and selecting the promotion during deposit.
- Deposit bonuses are limited to one claim per household or shared IP address.
- Ensure the player has completed all required steps before attempting to claim the bonus.
- The system automatically applies bonuses to qualified players who fulfill the conditions; manual intervention is generally not needed unless the bonus was not credited automatically.

## Key points for communicating with players
- Clearly explain that bonuses can only be claimed once per household or IP address.
- Remind players to verify their phone number and choose the promotion during deposit to qualify.
- If the bonus was not credited automatically, direct players to open the Reward Center and select their bonus to claim.
- Always verify that the player has met all deposit conditions before confirming bonus credit.