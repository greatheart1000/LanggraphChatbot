# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player eligibility and initial deposit details**
   - Confirm the player is a new or existing member based on their account status.
   - For **First Deposit Bonus**:
     - Ensure the player has made an initial deposit of at least 100 PHP.
     - Verify that this is the first deposit on the account.
   - For **Second Deposit Bonus** (if applicable):
     - Confirm the player has already completed the first deposit bonus.
     - Ensure the second deposit amount is at least 100 PHP.
   - For **VIP Birthday Bonus**:
     - Check if the player has provided all required ID materials, including 2 IDs, a selfie with IDs, and VIP level verification.
2. **Check system detection and integrity measures**
   - Scan for any indications of repeated participation involving the same IP address, bank card, or phone number.
   - If repetition or potential fraud is detected, communicate that rewards and profits will be confiscated and escalate as needed.
3. **Guide the player to the Rewards Center**
   - Instruct the player to log into the Rewards Center within 12 hours after deposit to claim applicable bonuses.
     - For **First Deposit Bonus**:
       - Recommend visiting the Rewards Center and clicking the "Claim" button.
   - Confirm the bonus will be automatically credited if all conditions are met and the player follows the proper steps.
4. **Ensure the player meets the turnover/wagering requirements**
   - Explain that a **15x turnover requirement** must be met before any withdrawal of bonus winnings (e.g., for first and second deposit bonuses).
   - For **third deposit bonus** (if applicable):
     - Confirm the minimum deposit of 100 PHP.
     - Explain that a **15x turnover** is required before withdrawal.
   - For **birthday or VIP bonuses**:
     - Clarify any additional ID or selfie submission requirements.
5. **Monitor bonus distribution timeframes**
   - Confirm bonuses are automatically credited within 12 hours after the deposit or registration.
   - For **New Register Bonus**:
     - Ensure the player downloaded the official app and registered on the site.
     - Make sure the bonus is credited within 2 hours after successful registration and download.
   - For **rescue bonus** and cashback (if applicable):
     - Rewards are sent to the Rewards Center before 4:00am GMT+8 the next day.
6. **Address player questions about specific bonuses**
   - Reiterate the maximum bonus amounts (e.g., up to 39,999 PHP for first deposit).
   - Clarify which games are eligible for specific bonuses:
     - **Slot & Fish games** are eligible for second deposit bonus and third deposit bonus.
   - Explain that multiple bonuses cannot be combined or stacked unless explicitly allowed.
7. **Warn about prohibition of Repetition and Fraud**
   - Inform players that if system detects repetition via IP, phone, or bank card, both rewards and profits will be confiscated, and the case may be escalated.
8. **Conclude the process and advise players**
   - Remind players to meet all wagering and turnover requirements before attempting a withdrawal.
   - Encourage them to contact support if the bonus does not appear within the expected timeframe or if eligibility is unclear.

## Notes
- Bonuses are automatically distributed by the system once eligibility criteria are met.
- Bonuses must be claimed within 12 hours after deposit, or they will expire.
- A 15x turnover requirement applies to all deposit bonuses before withdrawal.
- Always verify the proper documentation and IDs for VIP or birthday bonuses.
- Repeated use of the same IP, bank card, or phone number may lead to disqualification of rewards.

## Key points for communicating with players
- Clearly explain the 12-hour window to claim bonuses via Rewards Center.
- Emphasize the minimum deposit of 100 PHP for deposit-related bonuses.
- Remind players of the 15x turnover requirement before withdrawal.
- Clarify eligible game types for specific bonuses (SLOT & FISH).
- Warn about system detection of repeated accounts and associated confiscation.
- Suggest contacting support if bonuses are not received or if eligibility criteria are met but rewards are missing.