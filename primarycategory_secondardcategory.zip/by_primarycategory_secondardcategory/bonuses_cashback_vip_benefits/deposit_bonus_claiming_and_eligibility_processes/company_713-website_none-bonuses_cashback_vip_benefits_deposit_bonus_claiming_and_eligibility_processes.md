# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player's eligibility for bonuses and promotions.**
   - Confirm if the player has met specific deposit amounts, activity completion, or verification requirements as per promotion rules (e.g., providing ID, meeting minimum deposit/turnover thresholds).
   - For birthday bonuses, verify account linking to ID, and confirm it is the player's actual birthday.
   - Check if the player qualifies for specific bonuses such as the first deposit bonus, VIP weekly bonuses, or event-based bonuses (e.g., Halloween, Halloween event schedule, or Halloween rewards).

2. **Gather necessary information from the player.**
   - Collect details about their recent deposits (amount, date).
   - Ask about their VIP level if relevant for VIP bonuses.
   - For special bonuses (e.g., birthday), request verification documents if not already submitted.
   - Confirm from the player if they have already received the bonus or promotion.

3. **Check the system and campaign conditions.**
   - Verify in the back office or system whether the player has made a qualifying deposit (minimum of 100 Taka for general bonuses such as red envelopes or first deposit bonus).
   - Confirm if the deposit meets the specific promotion conditions (e.g., first deposit, VIP tier thresholds, Halloween event deposit amounts).
   - For bonuses credited automatically, check if they are credited after fulfillment of conditions within the specified period (usually within 24 hours).

4. **Determine bonus eligibility and specific bonus type.**
   - If the player qualifies for the first deposit bonus, confirm the deposit amount (must be at least 100 Taka) and verify that this is the first deposit.
   - For VIP weekly bonuses, confirm the player's current VIP tier, recharge amount, and wagering activity to verify if thresholds are met.
   - For birthday bonuses, verify the date of verification, deposit activity, and turnover requirement (e.g., 10x turnover on a 5,000 deposit).
   - For promotional events like Halloween, confirm the deposit amount against the tiered schedule and any additional rewards (e.g., crafting items).

5. **Inform the player about bonus status or next steps.**
   - If eligible and the bonus has been credited, explain that the bonus has been successfully added to their account.
   - If the bonus has not been credited but conditions are met, advise that it should be credited shortly (usually within 24 hours). If not received after this period, escalate or advise contacting support.
   - If the player is not eligible, clearly but politely explain which criteria have not been met and suggest actions to fulfill future eligibility.

6. **Handle cases with insufficient information or unmet criteria.**
   - Request additional proof, documentation, or activity details if needed.
   - If the deposit or activity does not meet the requirements, explain this based on the specific promotion rules.
   - Do not proceed further until all necessary conditions are verified or clarified.

7. **Escalate or follow up as necessary.**
   - If the bonus status cannot be confirmed or system issues are suspected, escalate the case to the relevant department.
   - Advise the player to wait a specified period if the bonus is pending and to contact support again if not received within that timeframe.

## Notes
- Bonuses are awarded automatically after fulfilling conditions; if not received, always verify deposit activity and account status.
- VIP weekly bonuses depend on recharge and wagering thresholds specific to each VIP tier.
- Birthday bonuses require verified account linkage and reaching a minimum deposit of 5,000 with 10x turnover.
- Special event bonuses, such as Halloween, follow specific deposit schedules and may include crafting items and special rewards; ensure players meet the deposit criteria for each tier.
- Red envelope distribution is limited to one claim per IP address daily; inform players about this restriction.

## Key points for communicating with players
- Always confirm deposit amounts and activity thresholds before providing any explanations about bonus eligibility.
- Clarify that bonuses are credited automatically once all criteria are met.
- Explain the timeline for bonus crediting (usually within 24 hours).
- Encourage players to submit verification documents promptly if needed for special bonuses like birthday rewards.
- Maintain polite, clear communication whether confirming eligibility or explaining ineligibility.