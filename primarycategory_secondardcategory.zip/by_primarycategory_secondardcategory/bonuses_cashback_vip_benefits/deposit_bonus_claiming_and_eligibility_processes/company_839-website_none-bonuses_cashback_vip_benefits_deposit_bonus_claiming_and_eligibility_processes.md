# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's eligibility for the bonus or promotion**  
   - Confirm that the player has registered on the official website or app.  
   - Check if the player is a new user qualifying for the First Deposit Bonus or New Register Bonus.  
   - Ensure the player's account is not flagged for using the same IP address, bank card, or phone number across multiple accounts, as ineligible activities may lead to confiscation of rewards and profits.  
   - Confirm the player has downloaded and installed the official app if required for the promotion.

2. **Gather necessary information from the player**  
   - Ask the player for their account details and registration method (website or app).  
   - Confirm the deposit amount, ensuring it is at least 100 PHP for the first deposit or as specified.  
   - Verify if the player has already claimed the bonus to avoid duplicate claims.

3. **Instruct the player on how to make the qualifying deposit**  
   - Guide the player to deposit at least 100 PHP for the first deposit bonus or follow the specific deposit amount for other bonuses.  
   - Advise the player to deposit via the designated methods supported by the system.

4. **Check the deposit and system processing**  
   - Confirm the deposit has been successfully processed in the player's account.  
   - Verify the deposit amount meets the minimum requirement and matches the promotional terms.

5. **Verify bonus automatic distribution**  
   - Check whether the bonus has been automatically credited within the specified time frame (usually within 12 hours for the first deposit bonus; approximately 2 hours for the registration bonus).  
   - If applicable, instruct the player to visit the Rewards Center and click “Claim” to receive the bonus.

6. **Confirm bonus details in the Rewards Center**  
   - Ensure the bonus appears correctly in the Rewards Center.  
   - Verify that the bonus amount aligns with the promotion rules (e.g., 68 PHP bonus for deposits of at least 100 PHP; up to 10,999 PHP maximum).  
   - Note that the bonus applies only to SLOT & FISH GAMES.

7. **Inform the player about wagering / turnover requirements**  
   - Explain that a 9x turnover must be met before initiating withdrawal attempts if applicable.  
   - Clarify that bonuses are only available for certain game types and after fulfilling these requirements.

8. **Address any issues with bonus crediting**  
   - If the bonus has not been received within the expected time, verify the player’s eligibility status and check for suspicious activity or system detection of ineligibility (e.g., multiple accounts, same IP).  
   - Advise the player that ineligibility due to these checks may result in bonus confiscation.

9. **Escalate if necessary**  
   - If the bonus is not credited, or the player suspects an error, escalate the case to the technical team with relevant details and screenshots if available.  
   - Ensure compliance with anti-fraud rules and confirm no violations occurred.

## Notes
- Bonuses are automatically distributed once the player qualifies.
- The bonus can be viewed and claimed in the Rewards Center.
- Players must meet the specified turnover (usually 9x) to be able to withdraw winnings derived from bonuses.
- Be aware of anti-fraud measures such as multiple registrations from the same IP address or using the same bank card, which can invalidate the bonus and confiscate profits.

## Key points for communicating with players
- Clearly explain the deposit and bonus eligibility criteria (e.g., minimum deposit of 100 PHP, specific game restrictions).  
- Remind players of the time frame for bonus crediting (e.g., within 12 hours or 2 hours).  
- Instruct players to check the Rewards Center for their bonus and requirements.  
- Emphasize the importance of meeting the turnover requirement (9x) before withdrawal.  
- Warn players about potential disqualification if anti-fraud rules are violated.