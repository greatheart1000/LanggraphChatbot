# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or request regarding bonuses, cashback, or VIP benefits.**  
   - Determine if the player is asking about claiming a bonus, checking eligibility, or understanding bonus conditions.  
   - Confirm whether the player is referring to deposit bonuses, cashback, rebates, or VIP weekly salary.

2. **Gather necessary player information.**  
   - Request and record:  
     - Player’s registered username or account number  
     - Deposit history relevant to bonus eligibility  
     - Device or IP address if eligibility concerns are mentioned  
     - Mobile phone number(s) associated  
     - Bank card details involved in deposits (for deposit-related bonuses)

3. **Check the player’s current bonus, cashback, or VIP status in the system.**  
   - Verify if the player is eligible for the specific bonus or promotion:  
     - First Deposit Bonus  
     - New Register Bonus  
     - Rebate or Cashback Bonus  
     - Slot & Fish Betting Bonus  
     - VIP Weekly Salary  
   - Confirm if the bonus was automatically dispatched or if manual claim is required.  
     - Bonuses like rebates and cashback are dispatched automatically or can be claimed in the Rewards Center (see step 4).  
     - Bonuses such as Slot & Fish rewards require claiming in Rewards Center within specified time frames.

4. **Guide the player to claim the bonus if applicable.**  
   - For bonuses dispatched automatically (rebate, cashback, VIP Weekly Salary):  
     - Confirm if the bonus has been received in the Rewards Center or account.  
   - For bonuses that require manual claiming (e.g., Register Bonus, First Deposit Bonus, Slot & Fish Bonuses):  
     - Direct the player to log into the Rewards Center.  
     - Instruct them to click “Claim” within the designated claim window (e.g., within 12 hours for first deposit bonuses).  
     - Ensure the player follows the step: go to Rewards Center > Claim.

5. **Check for common eligibility issues that might prevent bonus reception:**  
   - Confirm the player is not bound by restrictions such as:  
     - Using the same bank card for multiple accounts (confiscation applies).  
     - Using the same mobile phone number for multiple accounts (confiscation applies).  
     - Operating from the same or multiple IP addresses (confiscation applies).  
   - Verify that the player has completed the necessary actions:  
     - For first deposit bonuses: deposit at least 100 PHP.  
     - For new register bonuses: successfully registered and downloaded the official app.  
   - Review system logs to detect any violations or restrictions that prevent bonus eligibility.

6. **Explain possible reasons for non-receipt of bonuses with the player.**  
   - If the bonus has not been received automatically (rebates, cashback, VIP salary):  
     - The bonus might be dispatched automatically before 4:00 AM (GMT+8) or within the specified time frame.  
     - Confirm the player has performed eligible bets or deposits as required.  
   - If the bonus was supposed to be claimed manually but the player missed the claim window:  
     - Inform that the bonus or reward may no longer be available.  
   - Advise players to revisit the Rewards Center regularly for automatic bonuses and claims.

7. **Assist the player with additional steps if eligibility is uncertain or if there are problems:**  
   - If system detects violations (e.g., same IP, phone number, bank card):  
     - Inform the player that rewards have been confiscated due to eligibility rules.  
   - If the player did not meet turnover requirements before withdrawal:  
     - Explain that turnover (playthrough) requirements must be fulfilled before any withdrawal can be processed.  
   - If necessary, escalate issues that involve technical errors, suspected fraud, or expired claim windows.

8. **Confirm bonus conditions and restrictions with the player.**  
   - Bonuses such as the First Deposit Bonus are valid only for specific games like Slot and Fish.  
   - Bonuses require meeting rollover/multiplier conditions (e.g., 10x turnover for first deposit bonus).  
   - Bonuses are limited to specific amounts (e.g., up to 22,999 PHP for first deposit bonus).  
   - Bonuses are valid only within the designated claim window (generally 12 hours for certain bonuses).

9. **Advise the player on additional related benefits and restrictions:**  
   - VIP Weekly Salary is credited automatically every Thursday between 22:00-23:59 (GMT+8) if conditions are met (minimum deposit of 100 PHP).  
   - Cashback and rebate bonuses of up to 3.8% are dispatched automatically or can be claimed in real-time at the Rebate Center; if not claimed manually, they are dispatched before 4:00 AM (GMT+8).  
   - No birthday bonuses are currently offered; suggest visiting the promotions page for other available offers.

10. **Record the case details, including any issues, verification results, and actions taken.**  
    - Ensure accurate note-taking for future reference or escalation.

## Notes
- Bonuses and rewards are automatically dispersed by the system once eligibility criteria are met, generally within 12 hours.  
- Bonuses on first deposit, registration, rebates, and VIP benefits are subject to specific restrictions such as turnover requirements and game limitations.  
- Rewards related to multiple accounts are confiscated if system detects violations of IP, phone number, or bank card rules.  
- If a bonus is not received or claimable, always verify the eligibility conditions, deposit history, and system logs before escalating.

## Key points for communicating with players
- Confirm eligibility criteria and deposit amounts.  
- Guide players to Rewards Center for claims or verification.  
- Clearly explain system rules about restrictions, turnover, and claim periods.  
- Inform players about automatic dispatch times and any potential delays.