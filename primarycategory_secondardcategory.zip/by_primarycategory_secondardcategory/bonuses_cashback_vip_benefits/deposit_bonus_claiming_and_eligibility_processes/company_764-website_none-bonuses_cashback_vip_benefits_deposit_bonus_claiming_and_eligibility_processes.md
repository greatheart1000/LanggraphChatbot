# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player qualification for the bonus or promotion:**
   - Confirm the player's registration status (new or existing).
   - Check if the player has completed the necessary registration steps, including:
     - Downloading the official DreamJILI app.
     - Providing required personal details such as real name, mobile number.
   - For new players: ensure they have made their initial deposit (minimum of 100 PHP for the First Deposit Bonus).
   - Confirm the player has met specific promotion conditions, such as depositing a qualifying amount (e.g., at least 100 PHP for the First Deposit Bonus; at least 1,500 PHP for referral bonuses).
   
2. **Collect player's deposit information:**
   - Obtain details of the initial deposit, including:
     - Deposit amount.
     - Payment method used.
     - Deposit timestamp.
   - Verify that the deposit was successful and recorded correctly in the system.

3. **Check automatic bonus distribution:**
   - Confirm that the bonus is automatically credited by the system:
     - For the First Deposit Bonus: credited within up to 12 hours after deposit.
     - For the Register Bonus: credited within approximately 2 hours after registration and app download.
     - For referral or other promotions: credited as specified (e.g., Rewards Center, Rewards Module).
   - If the bonus is not received within the expected timeframe, inform the player that:
     - Bonus may not be eligible.
     - Check if the player has met all requirements.
   
4. **Verify player's account details and compliance:**
   - Ensure the player's account has completed:
     - Linking a bank card.
     - Providing a real name.
     - Possessing a valid mobile number.
   - Check for potential violations such as repeated use of the same IP address, bank card, or phone number, as rewards and profits may be confiscated if detected.

5. **Confirm eligibility window:**
   - Advise the player to visit the Rewards Center within 12 hours of their first deposit or registration for reward claims.
   - Check if the player has attempted to claim bonus outside the specified window.

6. **Assess bonus and wagering requirements:**
   - Inform the player of the necessary turnover:
     - Typically, a 9x turnover is required for First Deposit Bonuses before withdrawal.
     - A 20x turnover is required for New Register Bonuses.
   - Confirm the player has met the rollover or wagering requirements, either through the system or by reviewing betting activity.
   - Ensure the games played are eligible for bonus wagering (e.g., SLOT & FISH GAMES).

7. **Check for bonus confiscation conditions:**
   - If the system detects repeated use of the same IP address, bank card, or phone number across accounts, inform the player that rewards and profits may be confiscated.
   
8. **Address bonus claim issues:**
   - If the player provides a screenshot of the promotion page or bonus offer as proof:
     - Verify the screenshot clearly shows the bonus details.
     - Process the claim accordingly.
   - If a bonus is not received or cannot be claimed:
     - Check if all conditions are met.
     - Confirm no violations or detection of fraud.
   
9. **Escalate if needed:**
   - If the player reports issues not resolved at this point (e.g., suspected fraud, technical errors, or non-receipt after meeting conditions), escalate to the relevant department with documented details.

10. **Communicate final resolution and next steps:**
    - Inform the player of the outcome:
      - Bonus successfully credited and available after meeting rollover.
      - Any reason for denial or confiscation based on detection.
      - Advisement on completing wagering requirements.
      - Next steps or follow-up if issues persist.

## Notes

- Bonuses are distributed automatically; players do not need to manually claim them.
- Always verify that the player's account details are complete and correct to prevent confiscation risks.
- Bonuses apply only to specified game categories (e.g., SLOT & FISH GAMES).
- Rewards and profits may be confiscated if fraud or detection of repetitive account activity occurs.
- Time sensitive actions: visit the Rewards Center within 12 hours to claim bonuses or review eligibility.

## Key points for communicating with players

- Clearly explain the automatic nature of bonus distribution and required wagering.
- Remind players to complete all account verification steps.
- Inform players about the importance of meeting turnover requirements before withdrawal.
- Warn players about account activity detection that could lead to confiscation.
- Encourage players to check their Rewards Center regularly within the specified windows.