# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's initial inquiry and identify the bonus type**:
   - Confirm that the player is inquiring about the first deposit bonus or other promotional bonuses.
   - Clarify if the player is referencing the deposit bonus claim process or general eligibility requirements.

2. **Collect necessary player information**:
   - Confirm the player's account details (username or ID).
   - Determine if the player has already claimed a bonus previously, as some bonuses require no prior claims.
   - Ask if the player has bound a valid bank card, provided a mobile phone number, and linked a unique IP address.
   
3. **Check system and account eligibility criteria**:
   - Verify if the player's account has:
     - Bound a valid, unique bank card.
     - Provided and verified a mobile phone number.
     - Used a unique IP address different from any previous accounts if applicable.
     - Has not used duplication of bank card, phone number, or IP address for prior accounts or promotions.
   - Confirm whether the deposit is made via the designated platform (if specified).
   
4. **Instruct the player to make an initial deposit if not already done**:
   - The minimum deposit amount required for the first deposit bonus is usually 100 PHP.
   - Ensure the deposit is made using the appropriate method and platform.
   
5. **Notify the player about the automatic bonus crediting process**:
   - Explain that the first deposit bonus (typically 108 PHP) is automatically credited within 12 hours after the deposit, provided all eligibility requirements are met.
   - Emphasize that the bonus is credited automatically in the system, so no manual claim is necessary if all conditions are met.
   
6. **Guide the player to the Rewards Center if needed**:
   - If the bonus is not received within 12 hours:
     - Ask the player to check their Rewards Center for the bonus.
     - Confirm if the deposit meets the conditions and if their account’s eligibility criteria are still valid.
   
7. **Address potential issues with bonus receipt**:
   - If the bonus is not received:
     - Verify if the player’s account violated any eligibility rules such as using the same bank card, mobile number, or IP address.
     - Consider system delays or technical issues; advise the player to wait or resubmit if instructed.
     - If eligibility is confirmed but bonus is still unavailable, escalate to technical support or supervisor.
   
8. **Explain the wagering/turnover requirement for withdrawal**:
   - Inform the player that they must meet a turnover requirement of 15 times the bonus amount before withdrawing.
   - Ensure the player understands this condition is necessary for bonus withdrawal eligibility.
   
9. **Confirm that the player understands the conditions for bonus withdrawal and eligibility**:
   - Reiterate that they must meet all criteria, including the turnover requirement, proper account verification, and adherence to bonus rules.
   
10. **Document all checks and interactions**:
    - Record details about the deposit, eligibility verification, and any issues reported.
    - Note if further escalation or technical checks are required.

## Notes

- Always confirm that the player has followed the current platform rules, such as depositing via the designated methods and maintaining unique account details.
- Be aware that delays in bonus distribution may occur due to network or system issues.
- Ensure the player understands that re-binding or creating a new account with the same bank card, mobile number, or IP may disqualify eligibility.

## Key points for communicating with players

- Clearly explain that bonuses, including first deposit bonuses, are automatically credited within 12 hours if all eligibility conditions are met.
- Emphasize the importance of unique account information (bank card, mobile number, IP) to qualify.
- Remind players about the turnover requirement (15X of the bonus) for withdrawal purposes.
- Inform players about the possibility of system delays and advise patience or to check their Rewards Center if bonuses are not received.