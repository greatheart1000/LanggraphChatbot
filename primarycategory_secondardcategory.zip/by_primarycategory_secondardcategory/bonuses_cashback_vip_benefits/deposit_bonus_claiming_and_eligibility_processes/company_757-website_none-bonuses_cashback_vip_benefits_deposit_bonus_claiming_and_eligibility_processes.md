# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information**:
   - Confirm the player's account details.
   - Identify the specific bonus or benefit the player is requesting or has questions about (e.g., first deposit bonus, birthday bonus, VIP salary, cashback).

2. **Check eligibility criteria**:
   - Verify if the player is eligible for the requested bonus or benefit:
     - For *New Player First Deposit Bonus*: Confirm the player has made their first deposit of 100 PHP. Bonus is automatically credited within 12 hours after deposit.
     - For *Register Bonus*: Confirm registration and app download; bonus and mystery bonus are credited within 2 hours.
     - For *Birthday Bonus*: Confirm VIP3 status and that the current date matches the player's birthdate.
     - For *VIP Weekly Salary*: Confirm that the player has completed at least one valid bet on slot or fish within the week.
     - For *FREE ANGPAO DAILY bonus*: Check if the player has downloaded the NICEPH app, logged in, and deposited more than 5x since registration (if claiming for withdrawal).
  
3. **Verify claimed actions and deposit requirements**:
   - For deposit-based bonuses:
     - Confirm the amount deposited matches the minimum (e.g., 100 PHP).
     - Check if the bonus has been claimed in the 'Rewards Center' (click Claim if necessary).
     - Check for successful deposit and bonus credit confirmation in system logs.
   - For automatic bonuses (e.g., register bonus, weekly salary):
     - Confirm if the bonus has been credited automatically.
     - Check the timing (e.g., within 2 hours for register bonus, on Tuesday 22:00-23:59 for VIP weekly salary).

4. **Check bonus distribution and claims**:
   - For bonuses requiring manual claiming:
     - Ensure the player has clicked 'Claim' in the Rewards Center.
     - If not claimed, instruct the player to do so.
   - For automatic bonuses:
     - Verify bonus credit in the player's account.
   
5. **Assess turnover or wagering requirements**:
   - Confirm the player has met relevant turnover requirements before allowing withdrawals:
     - For first deposit bonus: Player must meet the specific turnover requirement (implied by the system, check the current site rules).
     - For VIP bonuses or birthday bonuses, ensure no additional wagering requirements are stated unless specified.
  
6. **Address special conditions or edge cases**:
   - If the player did not receive the bonus within the expected time window:
     - Check eligibility and deposit timestamps.
     - Confirm if the player's account meets the criteria.
     - Advise the player that non-receipt may indicate ineligibility or system delays.
   - For VIP birthday bonus:
     - Collect proper identification: username, two valid IDs showing birthdate, and a clear selfie holding the ID.
     - Verify the submission according to instructions.

7. **Provide resolution or further instructions**:
   - If eligible and bonus is credited:
     - Explain the next steps (meeting turnover requirements before withdrawal).
   - If not eligible or bonus not credited:
     - Clearly inform the player of the reasons (e.g., not meeting criteria, timing issues).
     - Advise on steps to ensure future eligibility if applicable.
   - For unresolved issues, escalate to a supervisor or check the system for technical issues.

## Notes

- Bonuses are typically automatically credited after meeting deposit and registration requirements.
- Bonuses like the VIP Weekly Salary are credited automatically every Tuesday between 22:00 - 23:59 (GMT+8) once the requirement of at least one valid bet on slot or fish is met.
- The VIP Birthday Bonus is exclusively for VIP3 and above, on the player’s birthday, with verification documentation.
- For the *FREE ANGPAO DAILY* bonus, players must log in between 20:00-20:30 (GMT+8) and meet deposit criteria if claiming for withdrawal.
- Non-deposit players can only withdraw a maximum of 100 PHP from the register bonus.

## Key points for communicating with players

- Clearly confirm their account status and the specific bonus they are claiming.
- Remind players that bonuses are subject to meet specific wagering or turnover requirements before withdrawal.
- Stress the importance of claiming bonuses promptly in the Rewards Center if required.
- Guide players through submitting any verification documents for VIP or birthday bonuses if applicable.
- Reinforce that automatic bonuses are credited within the specified timeframes and check for system delays if not received.