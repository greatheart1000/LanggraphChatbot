# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's account and collect necessary information**
   - Confirm the player's identity and account details.
   - Ask if the player has completed phone number verification, as this is required for first deposit bonuses.
   - Inquire about any ongoing bonuses or previous bonus claims to determine eligibility and avoid multiple claims from the same IP/device.

2. **Inform the player about the specific bonus or promotion they are eligible for**
   - Clarify the promotion details, such as the deposit bonus, cashback, or VIP benefit.
   - Explain that bonuses are system-generated and only claimable if the proper procedures are followed during deposit.

3. **Guide the player to the Reward Center and instruct on claiming the bonus**
   - Navigate the player to the Reward Center.
   - Select the "Bunos" section and then open the "Tickets" to see available bonuses.
   - Instruct the player to claim the desired bonus ticket (e.g., the ₱37 Download Bonus or the ₱37 new user bonus).

4. **Check the player's deposit condition**
   - Confirm that the player deposits at least ₱500 after claiming the bonus ticket.
   - Ensure the deposit is made after successfully claiming the bonus ticket, as this is a requirement.

5. **Verify completion of the wagering conditions**
   - Confirm that the player completes the designated bet threshold, e.g., a valid Slot bet of ₱2,500 (or the specified amount).
   - Check associated game activity to ensure the bet was successfully placed and meets the bonus criteria.

6. **Confirm the bonus crediting process**
   - Verify in the system that the bonus has been credited automatically once the conditions are met.
   - Remind the player that bonuses are only awarded if all conditions (ticket claim, deposit, contesting bet) are correctly completed and that the bonus is limited to one per IP/device for certain promotions.

7. **Address cases where the bonus is not credited**
   - If the bonus does not appear after all conditions are met, confirm that the player has followed all steps correctly.
   - Check for any restrictions such as IP sharing or multiple accounts.
   - If conditions are met and the bonus is still absent, advise the player to contact support with deposit details for further assistance.

8. **Record and escalate if necessary**
   - Save relevant details, including deposit proof, betting activity, and the bonus claim process.
   - Escalate the case if procedural issues or technical errors prevent bonus crediting, or if clarification on eligibility is needed.

## Notes
- Bonuses, including deposit and new user bonuses, are generally limited to one per IP address or device.
- Make sure players opt into promotions by selecting the promotion checkbox during deposit to be eligible for system-generated bonuses.
- Always advise players to read specific promotion rules, as eligibility may depend on minimum deposit amounts, verification status, and adherence to promotion terms.
- When assisting with first deposit bonuses, remind players that they must verify their phone number beforehand, as this is a prerequisite for automatic bonus application.

## Key points for communicating with players
- Confirm step-by-step adherence to claiming the bonus to avoid build-up of confusion.
- Clarify that bonuses are awarded once all conditions are met and that they are limited to one claim per IP/device where applicable.
- Encourage players to contact support with deposit proof if the bonus is not credited within a reasonable time frame.