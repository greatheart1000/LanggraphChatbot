# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify Player Identity and Eligibility**
   - Confirm the player's account is verified and has met activation requirements.
   - Check if the player is eligible for specific bonuses or benefits:
     - For the Birthday Bonus: Player must have VIP4 status.
     - For the Pay-day Monthly Bonus: Player must log in on the 15th of the month and meet the conditions.
   - Ensure the player’s account is active and in good standing.

2. **Identify the Specific Bonus or Promotion**
   - Clarify which bonus or cashback the player is inquiring about or claims:
     - First Deposit Bonus, Cashback, Pay-day Monthly Bonus, VIP Birthday Bonus, or other specific campaigns.
   
3. **Collect Necessary Player Information**
   - Ask the player to specify if they've already made the qualifying deposit or activity.
   - Confirm deposit amount, especially for first deposit bonuses (minimum PHP 150).
   - For birthday bonuses, verify VIP4 status and ask for submission of 2 valid IDs with birthdate and a selfie holding IDs (if not yet provided).

4. **Determine Bonus Crediting Method**
   - For bonuses like all bonuses, cashback, and rebates: 
     - They are automatically credited by the system.
     - If not received within the expected time frame (e.g., up to 12 hours for first deposit bonus), proceed to check eligibility.
   
5. **Check the Player’s Account for Bonus Credit or Cashback**
   - Access the player's account in the back office/system.
   - Verify whether the bonus or cashback has been credited:
     - For automatic bonuses: confirm if credited.
     - For cashback: check if clicked CASHBACK and redeemed in real time.
     - For manual claiming bonuses: instruct the player to visit the Bonus Center and click Claim.
   - Specifically, for cashback:
     - Inform the player they can claim manually via the CASHBACK button.
     - If not claimed manually, cashback is automatically credited before 16:00 GMT+8 the next day.

6. **Review Bonus Conditions and Requirements**
   - Confirm that the player has met any specific requirements:
     - Turnover (wagering/playthrough) requirements for withdrawal eligibility.
     - For first deposit bonuses: deposit of PHP 150 and subsequent wagering as per bonus terms.
     - For monthly Bonus (Pay-day): login on the 15th of the month.
     - For birthday bonuses: VIP4 status and identity verification.
   
7. **Assist with Bonus Claiming Process if Needed**
   - If the bonus hasn't been credited automatically and the player is eligible:
     - Guide them to the Bonus Center to click 'Claim'.
   - If the bonus is not available for claiming:
     - Check for eligibility issues such as not meeting deposit or wagering requirements.
     - Explain the specific conditions based on the promotion's rules.

8. **Address Issues with Unreceived Bonuses or Cashback**
   - If the bonus or rebate remains uncredited and the player believes they are eligible:
     - Verify eligibility criteria (e.g., deposit amount, activity times, VIP status).
     - Check if the bonus was credited within the advertised timeframe.
     - If eligible but not credited, escalate or advise checking for account restrictions.

9. **Inform the Player about Automatic and Manual Credits**
   - Explain that:
     - Bonuses such as cashback are automatically credited, but players can also claim manually.
     - Automatic bonuses are dispatched within 12 hours of eligibility.
     - For cashback, unclaimed rebates before 16:00 GMT+8 are credited automatically the next day.

10. **Document and Close the Case**
    - Record the player's inquiry, actions taken, and outcome.
    - Advise the player to contact support if they experience further issues or if the bonus still hasn't appeared after verifying eligibility and fulfilling the requirements.

## Notes
- Always verify the specific bonus rules and conditions, including turnover requirements, deposit minimums, and eligibility periods.
- Remind players that automatic bonuses are credited within specific time frames, typically up to 12 hours or before 16:00 GMT+8 for cashback rebates.
- For promotions requiring verification (such as birthday bonuses), ensure all necessary documentation has been submitted and approved.

## Key points for communicating with players
- Clearly explain whether bonuses are automatic or need manual claiming.
- Confirm deposit amounts and eligibility criteria.
- Emphasize the importance of meeting turnover requirements before withdrawal.
- Clarify the timeframes for automatic crediting and manual claiming.
- Guide players to the Bonus Center for claiming bonuses when applicable.
- Inform players about the VIP requirement for the Birthday Bonus.
- Offer escalation procedures if bonuses are not credited despite meeting all conditions.