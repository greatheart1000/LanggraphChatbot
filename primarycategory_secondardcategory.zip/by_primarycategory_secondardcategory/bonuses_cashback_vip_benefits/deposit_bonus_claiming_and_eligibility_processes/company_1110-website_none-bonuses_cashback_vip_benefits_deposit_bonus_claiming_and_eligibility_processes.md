# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player’s account**
   - Confirm that the player’s phone number has been verified.
   - Explain that both verification of the phone number and deposit are necessary to qualify for bonuses.
   - If the phone number is unverified, guide the player to complete verification before proceeding.

2. **Collect details about the player's deposit and bonus interest**
   - Ask whether the player intends to claim the First Deposit Bonus or the 77% promotion.
   - For the First Deposit Bonus:
     - Confirm that the player will make their first deposit.
     - During deposit, instruct the player to select the relevant deposit promotion.
   - For the 77% bonus:
     - Ensure the player verifies their phone first, then makes a deposit.
     - During deposit, confirm that the player selects the 77% bonus option.
   
3. **Check the player's current account status and eligibility**
   - Verify if the account is the player's first deposit or if it qualifies for the specific promotion.
   - Confirm if the player’s IP address or device is restricted or sharing with others who have claimed bonuses.
       - If the bonus box does not appear during deposit, inform the player that it might be due to sharing the same IP or device, as bonuses are limited to one per IP/device.
   
4. **Verify the deposit conditions**
   - Confirm the deposit was made successfully.
   - Ensure the player selected the appropriate promotional offer during deposit.
   - Check for any system restrictions related to shared IP/device that may prevent bonus crediting.
       - If restrictions apply, inform the player that they are ineligible for the bonus based on current policies.
   
5. **Confirm automatic crediting of the bonus**
   - Since bonuses are credited automatically once conditions are met, check the system to see if the bonus has been credited.
   - If the bonus has not been credited and conditions were met:
       - Advise the player to wait a few moments and refresh their account.
       - If it still does not appear, escalate to technical support or follow up for further investigation.
   
6. **Address common issues and edge cases**
   - If the player claims they didn’t see the bonus box:
     - Explain that bonuses are limited to one per IP/device.
     - Confirm if the player is using the same device/IP as someone else who has claimed the bonus.
   - If the player has made multiple deposits or attempts:
     - Clarify that only one bonus per IP/device is permitted.
   - If the bonus is not credited despite fulfilling the requirements, escalate or advise the player to contact customer support for further assistance.
   
7. **Document the case and inform the player accordingly**
   - Record any issues, restrictions, or player actions.
   - Provide clear information about the bonus status and any restrictions affecting the claim.
   - Reiterate key points:
     - Bonuses require verification, proper deposit, and selecting the promotion during deposit.
     - Bonuses are limited to one per IP/device.
     - System credits bonuses automatically once conditions are met.

## Notes
- Bonuses such as free login bonuses or birthday bonuses are currently not available.
- Always verify if the player's account and deposit meet all outlined conditions before concluding the case.
- Ensure players understand that multiple accounts sharing the same IP or device will be restricted from claiming bonuses.

## Key points for communicating with players
- Remind players that bonuses are limited to one per IP address or device.
- Clarify that bonuses are credited automatically once conditions are fulfilled.
- Inform players to complete verification and select the promo during deposit for eligibility.
- Explain that delays or missing bonuses may be due to system restrictions or device sharing and that escalation may be necessary if issues persist.