# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or issue** related to deposit bonuses, cashback, or VIP benefits. Determine if they are asking about claiming a bonus, checking eligibility, or about specific bonus details.

2. **Gather essential player information:**
   - Confirm the player's account details:
     - Account login name
     - Recent deposit activity
     - VIP level
     - Registration date (if applicable)
     - Device/IP address details
     - Bound bank card and verified mobile number

3. **Determine the type of bonus or benefit involved:**
   - First deposit bonus (e.g., 100% up to 28,888 PHP)
   - Second deposit bonus (e.g., 68% of deposit)
   - New register bonus (up to 688 PHP)
   - Birthday bonus (requires VIP 3 status and is applicable on birthday)
   - Cashback (up to 3%)
   - VIP Weekly Wages or Weekly Salary
   - Daily Angpao Bonus
   - Special VIP or event-related benefits

4. **Verify player's eligibility for the requested bonus/benefit:**
   - For **first deposit bonus**: confirm a minimum deposit of 100 PHP was made, and check that it was within the claimed timeframe (within 12 hours).
   - For **second deposit bonus**: confirm the player made a second deposit of at least 50 PHP, and that they are eligible for the 68% bonus, with deposit within the promotional period.
   - For **new register bonus**: confirm the player registered on the official website and downloaded the app; check if the bonus has been credited automatically (within two hours).
   - For **VIP Special Bonuses** (e.g., Birthday Bonus, Weekly Salary): check VIP level (VIP 3 or above), registration or activity dates, and current VIP tier status.
   - For **cashback**: determine if the player has recent bets eligible for cashback, and if their account qualifies for automatic or manual rebate.
   - For **Angpao bonuses**: verify deposit history (more than five deposits or fewer), and eligibility timing (claim window 21:00–21:30 GMT+8).

5. **Check technical and system conditions:**
   - Confirm whether the bonus has been automatically credited:
     - For **automatic credits** such as registration bonus, cashback, top-up bonuses: check the system logs or Rewards Center.
   - If manual claiming is required (e.g., clicking 'Claim' button), advise the player to do so within the relevant timeframe.
   - Ensure the player has completed the necessary **turnover (wagering) requirement** (e.g., 15x for first deposit bonus, 20x for new register bonus, or 15x for second deposit bonus) before requesting withdrawal.

6. **Identify potential issues or restrictions:**
   - Repeated activity from the same IP address, bank card, or phone number may result in confiscation of rewards and profits.
   - Bonuses are only valid if claimed within the specified time window (e.g., within 12 hours for deposit bonuses, within 2 hours for registration bonus).
   - Confirm whether the player has met the **turnover requirement**; if not, explain that withdrawals are not yet permitted until requirements are fulfilled.
   - Check for any system or account restrictions, such as unverified details or outstanding document verifications.

7. **Explain the relevant process to the player:**
   - For claimed bonuses: inform them that the bonus has been credited, or guide them to the Rewards Center to claim it.
   - For unmet conditions: advise on fulfilling deposit minimums, meeting wagering requirements, or verifying account details.
   - For system issues: escalate to technical support if bonuses are not credited automatically despite meeting conditions, or if system delays are suspected.

8. **Provide additional instructions if needed:**
   - Remind the player to download the official app for certain bonuses (e.g., registration bonus).
   - Confirm they meet the minimum deposit amounts.
   - Advise to check bonus terms and promotion-specific conditions (e.g., only applicable to SLOT and FISH games for the second deposit bonus).

9. **Advise on next steps or escalate:**
   - If the bonus has not been credited within the expected timeframe (e.g., 12 hours for deposit bonuses, two hours for registration bonus), escalate to the Promotions or Technical team.
   - If the player is ineligible due to violations or restrictions, clearly communicate the reasons.

10. **Close the case:**
    - Confirm the player understands the status of their bonus/benefit.
    - Provide guidance on how to proceed with future bonus claims or benefits.
    - Record the interaction and any player responses in the CRM system.

## Notes
- Bonuses generally require meeting deposit and turnover conditions before withdrawal.
- Bonuses are mostly credited automatically once eligibility criteria are met; manual claims may occasionally be required.
- Repetition of activity from the same IP, bank card, or phone number may lead to confiscation of rewards and profits.
- Certain benefits like VIP Weekly Wages or Birthday Bonus are contingent on VIP level (VIP 3 or higher) and specific activity thresholds.
- Help players verify their status via the Rewards Center and ensure they adhere to claim timeframes.

## Key points for communicating with players
- Clearly specify the bonus type and amount.
- Remind players of the time limits for claims.
- Emphasize the importance of fulfilling turnover requirements before withdrawal.
- Warn about activity restrictions that may result in confiscation.
- Guide players step-by-step on claiming or checking their bonus status.
- Escalate promptly if bonuses are delayed or account restrictions are suspected.