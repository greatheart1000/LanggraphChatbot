# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's intent and the specific promotion or benefit they are inquiring about** (e.g., First Deposit Bonus, VIP Birthday Bonus, Cashback, VIP Weekly Salary, Lucky Spin, etc.).  
   - *Supporting FAQs:* Any question referencing specific bonuses or benefits.

2. **Verify the player's eligibility for the requested promotion or benefit**:
   - For **First Deposit Bonus**:
     - Confirm the player has made an initial deposit of 100 PHP.
     - Ensure the bonus has not already been claimed or is not invalid due to prior use of the same bank card, phone number, or IP address.
     - Check if the player has claimed the bonus within 12 hours via the Rewards Center.
   - For **VIP Birthday Bonus**:
     - Confirm the player has reached VIP3 level.
     - Verify the player's birthdate is registered correctly.
   - For **VIP Weekly Salary**:
     - Verify the player has completed at least 1 valid bet on slot or fish games within the current week.
   - For **Lucky Spin**:
     - Confirm the player deposited a minimum of 800 PHP and completed the required turnover of 8,000 PHP every day.
   - For **Birthday Bonus**:
     - Confirm it is the player's exact birthdate and the bonus eligibility period has not expired.
   - For **All other promotions**:
     - Check specific requirements as outlined in FAQs.

3. **Collect necessary information and documentation if applicable**:
   - For **VIP Birthday Bonus**:
     - Ask the player to provide:
       - Their Username.
       - Two different valid IDs showing their birthdate.
       - A selfie of the player holding a valid ID.
     - Save submitted documents for review before approval.
   - For **Other bonuses** (e.g., First Deposit Bonus):
     - Confirm the deposit amount and timing.
     - Ensure the player has logged into the Rewards Center within 12 hours of deposit if claiming bonus at that time.

4. **Verify the player's account details and deposit status**:
   - Confirm the deposit amount (for first deposit, minimum 100 PHP).
   - Confirm the deposit was made via eligible method (e.g., check for Maya wallet if applicable).
   - Check for any detection of multiple accounts using the same IP, phone, or banking details which can disqualify the bonus or lead to confiscation.

5. **Check the status of the bonus claim in the system**:
   - For automatic distributions (e.g., New Register Bonus, VIP Weekly Salary, Birthday Bonus if VIP3):
     - Verify if the bonus has been credited automatically.
   - For manual claims (e.g., First Deposit Bonus, VIP Birthday Bonus, Lucky Spin), ensure the player has clicked the claim button within the specified time window (typically 12 hours for first deposit bonus).

6. **Determine if the player meets all conditions for claiming or enjoying the promotion**:
   - Confirm turnover requirements are fulfilled before withdrawals — for example, 10X turnover for the First Deposit Bonus.
   - For cashback and rebate promotions:
     - Check if the player has performed eligible bets and manually claimed rebate if applicable.
     - If manual claim is not made, verify system will automatically credit rebate at 4:00 AM next day.
   - For **Lucky Spin**, ensure the player completed daily turnover and visits Rewards Center to claim spin after meeting requirements.

7. **If the player qualifies**:
   - Instruct them to log into their Rewards Center.
   - Guide them to click the claim button if it is a manual claim.
   - Confirm the bonus, cashback, or benefit has been credited to their account.
   - Advise on required turnover that must be met before withdrawal.

8. **If the player does not qualify**:
   - Provide a clear explanation based on the specific reason:
     - E.g., "You have not completed the required turnover," or "Your account details do not match the eligibility criteria," or "You missed the claim window."
   - Advise on what steps they might need to take if applicable (e.g., re-try deposit, update account info).

9. **For players attempting to claim benefits improperly (e.g., multiple accounts, using same IDs, or other violations)**:
   - Explain that due to system checks, rewards may be forfeited and their account may face disciplinary action.
   - Escalate to relevant department if fraudulent activity is suspected.

10. **Record the outcome**:
   - Document whether the claim was successful or failed.
   - Note any required follow-up actions (e.g., review documents, escalate issue).

## Notes

- Always confirm that the claim is made within the designated time frame (e.g., 12 hours for first deposit bonus).
- When dealing with VIP bonuses (Birthday, Weekly Salary), ensure the VIP tier and activity requirements are satisfied.
- For bonus-related documentation submissions, verify clarity and legibility; process review promptly.

## Key points for communicating with players

- Make sure they understand the specific eligibility criteria for each promotion.
- Remind players to claim bonuses within the allotted time window.
- Clarify turnover and deposit requirements before withdrawals.
- Politely inform players why a bonus or benefit may not be credited (e.g., insufficient turnover, missed claim window, account violations).
- Encourage players to contact customer support if they believe they meet the criteria but still did not receive their benefits, providing all relevant details and documentation.