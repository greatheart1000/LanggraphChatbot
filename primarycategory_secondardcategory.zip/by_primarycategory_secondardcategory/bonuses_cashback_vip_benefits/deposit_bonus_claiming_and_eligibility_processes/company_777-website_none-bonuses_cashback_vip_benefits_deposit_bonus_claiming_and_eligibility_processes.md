# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or request related to deposit bonuses, cashback, or VIP benefits.**  
   - Determine if the player is asking about claiming a bonus or cashback, or verifying eligibility for VIP benefits.

2. **Gather essential player information relevant to deposit bonuses or promotions.**  
   - Confirm player's registration status and account details.  
   - Verify the device used (app or website), and check if the player has downloaded the official app if applicable.

3. **Check if the player is eligible for the specific bonus or benefit.**  
   - First deposit bonus: Confirm if the player is a new user and has made their first deposit of at least 50 PHP.  
   - Second deposit bonus: Confirm if the player has completed the first deposit bonus and is making a qualifying second deposit of at least 50 PHP.  
   - Third deposit bonus: Verify if applicable and eligible on current promotions.  
   - Cashback: Confirm if the player has placed valid bets since the last claim date, and whether they are seeking manual claim.  
   - VIP Weekly Wages/Salary: Check if the player has met the weekly bet requirement and VIP level.  

4. **Verify deposit details and bonus claim steps through the system.**  
   - Confirm the deposit amount to ensure it meets minimum requirements (e.g., ≥50 PHP for bonuses).  
   - Check if the bonus has already been credited or claimed.  
   - For first deposit bonuses: Ensure the player claims within 4 hours of deposit via the Rewards Center.  
   - For second/third deposit bonuses: Confirm the deposit was made and that the player claims the bonus through the Rewards Center after deposit.

5. **Perform eligibility checks based on bonus-specific rules.**  
   - Ensure the deposit was made from an account or device not previously flagged for sharing accounts or multiple accounts.  
   - Confirm the deposited funds and mobile number are correctly bound, especially if the system indicates missing information.  
   - For automatic credits, verify that the bonus was credited; for manual claims, advise the player to click Claim in the Rewards Center.

6. **Inform the player about wagering/turnover requirements.**  
   - Convey that most bonuses (e.g., first deposit, second deposit) require an 8x or 15x turnover before withdrawal, depending on the bonus type.  
   - Remind that the bonus can only be used on SLOT & FISHING games as specified.

7. **If the bonus has not credited or the player encounters issues:**
   - Check for unmet eligibility conditions (e.g., insufficient deposit, incorrect device, missing mobile number, same IP address).  
   - Advise the player to ensure all system requirements are met, including using different bank cards or devices if necessary.  
   - Confirm if the player made the deposit within the valid claim window (e.g., within 4 hours for first deposit bonus).  
   - If suspicion of eligibility issues arises, escalate to the appropriate department or advise checking system restrictions.

8. **If the player requests cashback:**
   - Confirm the bet was valid and in the eligible period.  
   - Advise that cashback is up to 3.80% of all valid bets and can be claimed manually.  
   - If not claimed, inform the player that cashback will automatically be added to the Reward Center at 10:00 AM the following day.

9. **For VIP Weekly Wages/Salary:**
   - Confirm if the player completed at least 1 valid bet on Slot or Fish games during the current week.  
   - Verify if the player's VIP level qualifies for the weekly reward.  
   - Inform the player that the reward is automatically credited to the Rewards Center every Thursday between 22:00 and 23:59 (GMT+8).  
   - If the reward is missing, advise the player to ensure they met the weekly betting criteria.

10. **Once eligibility and claim procedures are verified:**
    - Guide the player to claim bonuses via the Rewards Center if not automatically credited.  
    - Confirm the bonus has been properly credited and note the specific turnover requirement (e.g., 8x or 15x).  
    - Explain that withdrawal of winnings derived from bonuses is only possible after meeting the relevant wagering conditions.

11. **Provide closing instructions:**
    - Advise the player to complete all wagering before attempting to withdraw.  
    - Tell the player to keep records of their bonus claims and betting, especially if disputes arise.  
    - If any issues persist, escalate to the relevant department or advise for further investigation.

## Notes

- Bonuses are only applicable on SLOT & FISHING games unless otherwise specified.  
- Bonuses are credited automatically or require manual claim in the Rewards Center within the designated time window.  
- Meeting turnover requirements is essential for withdrawal eligibility.  
- System checks may identify suspicious account activity, which can result in bonus withholding or rebuttal.  
- Cashback is proportional to valid bets and can be claimed manually or automatically.  
- VIP rewards are awarded based on weekly betting activity and VIP level status.

## Key points for communicating with players

- Always verify deposit amounts and claim windows before providing instructions.  
- Remind players of turnover requirements (typically 8x or 15x).  
- Clarify that bonuses can only be used on specified games: SLOT & FISHING.  
- Emphasize the importance of meeting eligibility criteria for automatic credit or manual claiming.  
- Escalate any suspicion of account sharing or eligibility issues as needed.