# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player's eligibility for the bonus or benefit**  
   - Confirm the player is a new user or VIP, depending on the promotion.  
   - For first deposit bonuses: ensure this is their first deposit with the account.  
   - For VIP bonuses or birthdays: verify the player's VIP level and that all required documentation and verifications are completed (e.g., ID, selfie, birthday verification).  
   - For cashback: check that the bet amount qualifies and that the rebate is not already claimed or pending for the day.

2. **Gather necessary information from the player**  
   - For deposit bonuses: confirm the deposit amount, payment method, and whether the deposit meets the minimum requirement (e.g., 100 PHP for the first deposit bonus; 50+ PHP for the new member bonus).  
   - For VIP or birthday bonuses: verify identity documents, selfie with ID, and birthday information if not previously verified.  
   - For specific promotions like Spin Lucky Wheel: confirm deposit amount (e.g., minimum 800 PHP) and weekly turnover of 3,000 PHP within the timeframe.

3. **Check the player's deposit and activity history in the system**  
   - Confirm if the deposit qualifies for the specific bonus (e.g., at least 100 PHP for the first deposit bonus).  
   - Verify that no disqualifying factors apply, such as using the same bank card, phone number, or IP address as another account (for first deposit bonuses).  
   - Check whether the player has met any additional activity or turnover requirements associated with their VIP level or ongoing promotions.

4. **Determine if the bonus has already been claimed or is pending**  
   - Review Bonus Center or Rewards Center to see if the bonus is already claimed or scheduled for automatic allocation (e.g., VIP bonuses are credited automatically on scheduled days).  
   - For bonuses like birthday rewards, verify if the system has already credited the reward or if the birthday has just occurred.

5. **Proceed to claim the bonus**  
   - For deposit bonuses: instruct the player to go to **BONUS CENTER** and click **Claim**.  
   - For automatic bonuses (VIP, birthday, weekly salary): confirm the bonus is credited automatically once eligibility criteria are met and documents verified. If not, advise further investigation or escalation.  
   - For cashback or rebates: advise the player to click **CASHBACK** to claim, noting that rebates are dispatched automatically before 02:00 AM GMT+8 the next day.

6. **Confirm bonus receipt in the system**  
   - Check whether the bonus reward has been credited to the player’s account within the specified timeframe (e.g., within 12 hours for deposit bonuses).  
   - If the bonus has not been credited within the expected time, verify eligibility and potential ineligibility factors (e.g., incomplete verification, non-fulfillment of requirements).

7. **Explain the wagering or turnover requirements to the player**  
   - Clearly inform the player that the bonus amount is subject to meeting specific turnover/multiple requirements before withdrawal (e.g., the bonus and deposit must be wagered a certain number of times as per promotion rules).  
   - Remind regarding time limits for meeting these requirements, if applicable.

8. **Handle cases of ineligibility or issues**  
   - If the player is ineligible due to not meeting deposit or activity requirements, explain clearly that conditions are not fulfilled.  
   - If the bonus was not received within the designated timeframe, advise the player to check their eligibility status or submit necessary documents for verification.  
   - For disqualified factors (e.g., same bank card, phone number, IP address), inform the player of standard restrictions and policies.

9. **Advise on further actions if needed**  
   - In case of disputes or unresolved issues, escalate to the appropriate department with supporting documentation.  
   - Remind players of the importance of complying with verification procedures for bonus eligibility, especially for VIP or birthday bonuses.

## Notes

- All bonus distributions are subject to meeting specific conditions such as deposit minimums, activity periods, identity verification, and system review.  
- VIP bonuses and salaries are usually credited automatically after internal review; manual claiming is generally not required once verified.  
- Bonuses are sent within the timeframes specified (e.g., within 12 hours for deposit bonuses, during scheduled distribution days for VIP/ birthday bonuses).  
- Ensure players understand that withdrawal restrictions apply until turnover requirements are fulfilled.  

## Key points for communicating with players

- Always verify identity and deposit history before processing bonus claims.  
- Confirm that all required documents and verifications are completed for VIP and birthday bonuses.  
- Remind players that bonuses are limited by eligibility factors like same bank card, phone number, or IP address usage.  
- Encourage players to check their Bonus Center or Rewards Center for bonus status and automatically credited rewards.