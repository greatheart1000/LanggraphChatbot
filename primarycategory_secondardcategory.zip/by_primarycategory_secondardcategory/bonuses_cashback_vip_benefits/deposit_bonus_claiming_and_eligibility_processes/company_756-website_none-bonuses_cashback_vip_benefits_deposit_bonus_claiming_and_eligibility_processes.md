# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather necessary information from the player:**
   - Confirm if the player is claiming a bonus or benefit related to deposit bonuses, cashback, VIP benefits, or promotional rewards.
   - Ask if the claim pertains to the First Deposit Bonus, VIP upgrade bonus, weekly/monthly salary bonuses, birthday bonuses, cashback/rebate, or specific promotions like Progressive Bonus or Sunday’s Best.
   - Verify player identity if required (e.g., for VIP bonuses or birthday bonuses), including valid IDs or a selfie with ID.

2. **Check player's eligibility for the specific bonus or benefit:**
   - For **First Deposit Bonus**:
     - Confirm if the player is making their first deposit.
     - Ensure the deposit amount is at least 100 PHP.
   - For **VIP-related bonuses**:
     - Confirm VIP rank upgrade has been completed; if missing, advise contacting customer support.
     - Check if VIP bonuses like Weekly Salary or Monthly Salary are scheduled for the current period.
     - Validate minimum deposit requirement (e.g., 100 PHP for Weekly Salary or 500 PHP for Monthly Salary) and that the player has placed qualifying bets during the relevant period.
   - For **promo-specific bonuses**:
     - Verify that the claim is within the designated timeframe (e.g., bonuses recalibrate daily, or claim windows are open).
   - For **cashback/rebate programs**:
     - Confirm recent bets qualify for rebate up to 3.0%.
     - Check if cashback/rebate has already been claimed; if unclaimed, the system automatically credits rebates before 3:00 a.m. GMT+8.

3. **Determine if the bonus has already been credited:**
   - Check the Rewards Center for the bonus or reward status.
   - Confirm whether the bonus was automatically distributed or needs to be manually claimed.
   - For **automatic distribution bonuses** (e.g., rebates, VIP Weekly Salary), inform the player that the bonus is credited automatically if conditions are met.

4. **Assist the player with claiming the bonus if needed:**
   - For bonuses requiring manual claim (e.g., First Deposit Bonus, VIP Upgrade Bonus, birthday bonus):
     - Instruct the player to go to the Rewards Center.
     - Guide them to click on “Claim” next to the relevant bonus.
     - Verify the bonus appears in the Rewards Center after claiming.
   - For **bonuses with timing dependencies**:
     - Remind the player to wait until the recalibration or claim period (e.g., after 03:00 GMT+8 for daily recalibration, or on scheduled claim dates such as the 14th for the monthly bonus).
   - For **bonuses requiring identity verification**:
     - Advise the player to submit the necessary documents (valid ID, selfie with ID) via the requested channels before claiming.

5. **Handle specific cases where bonuses are missing or not received:**
   - If a bonus has not been credited within the expected timeframe (e.g., within 12 hours for First Deposit Bonus or after the scheduled recalibration), advise the player to:
     - Ensure all eligibility criteria are met.
     - Contact customer support if the bonus remains uncredited after waiting.
     - For VIP upgrade bonuses, advise them to wait 24 hours after upgrading and to contact support if not received.

6. **For bonus claims related to scheduled rewards (e.g., the 14th monthly bonus, VIP Monthly Salary):**
   - Confirm the player meets all eligibility requirements.
   - Inform them of the specific claim period.
   - If outside the claim window or if criteria are not met, advise waiting for the next reward cycle.
   - If eligible but bonus not received, escalate to support with relevant verification details.

7. **Provide additional instructions or guidance if the player needs to perform more actions:**
   - Ensure the player understands that some bonuses require meeting turnover/wagering requirements before withdrawal.
   - Advise on deposit methods applicable for rebates (e.g., Maya deposits are eligible for rebates up to 6%).

8. **Document the interaction and any follow-up requirements:**
   - Record the player's claimed bonus and eligibility checks in the internal system.
   - Escalate complex or unresolved cases to the relevant support team with all gathered details.
   - Advise players to check their Rewards Center regularly for updates.

## Notes
- Bonuses like Birthday, VIP Weekly Salary, and Monthly Salary are credited automatically if eligibility is confirmed.
- Cashback/rebate of up to 3.0% is typically credited automatically before 3:00 a.m. GMT+8 unless already claimed manually.
- For missing bonuses, always confirm that the player has met all specific criteria, including deposits, bets, and timeline conditions.
- Player identity verification may be necessary to receive certain bonuses like birthday or VIP benefits.

## Key points for communicating with players
- Clearly explain the eligibility requirements and timing windows.
- Remind players that bonuses often have wager or turnover conditions.
- Encourage players to check the Rewards Center after the specified claim or recalibration times.
- Confirm if documentation or additional verification is required before awarding certain bonuses.