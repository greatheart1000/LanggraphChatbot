# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or request regarding bonus or benefit eligibility or claiming.**  
   - Ask for specific details if necessary, such as the type of bonus (e.g., first deposit, birthday, registration) or benefit they refer to.

2. **Verify player's registration status and VIP level.**  
   - Check if the player has registered on the official site, downloaded the app if applicable, and their current VIP level.
   - **Note:** Birthday bonuses require VIP4 or higher. If VIP3 or lower, inform the player they need to upgrade to VIP4+.

3. **Gather necessary documentation if claiming birthday or VIP birthday bonuses.**  
   - Request two valid IDs showing birth date.
   - Request a selfie holding one of the IDs.
   - Confirm the submitted documents meet the criteria before proceeding.

4. **Check if the player qualifies for the specific bonus or benefit based on the provided information.**  
   - **First Deposit Bonus:** Confirm the player made their first deposit of 100 PHP or more.  
   - **New Player Bonus (108 PHP):** Confirm the initial registration and app download; bonus is usually sent automatically within approximately 2 hours.  
   - **Birthday Bonus:** Confirm the player is on their actual birth date and qualifies (VIP4+).  
   - **VIP Birthday Bonus:** Ensure the player has VIP4+ and has submitted the required documents.  
   - **Weekly Salary & Monthly Bonus:** Confirm the player has met the weekly or monthly activity requirements (e.g., placed a valid bet for weekly salary).  
   - **Special event bonuses:** Follow relevant specific criteria if applicable.

5. **For bonuses requiring prior actions (e.g., claiming via Bonus Center or Rewards Center):**  
   - Instruct the player to navigate to the Bonus Center or Rewards Center.  
   - Confirm if the bonus has already been automatically credited or if manual claim is needed.

6. **Check the timing details for bonus distribution:**  
   - **First deposit bonus:** Usually sent within 12 hours; advise player if not received after this time.  
   - **Registration bonuses:** Typically credited approximately 2 hours after registration and app download.  
   - **Birthday bonuses:** Distributed on the player's actual birthday, after verification.

7. **Inform the player about the turnover requirements necessary before withdrawal.**  
   - Clarify that the bonus or winnings cannot be withdrawn until the turnover requirement is met.  
   - Explain: Turnover is calculated as bonus or cash-in amount multiplied by system-specific playthrough multiplier and that it must be completed through eligible games (e.g., slots, permitted games).

8. **Advise the player on how to meet the turnover requirement.**  
   - Play eligible games until the total playthrough amount reaches the required level.  
   - Confirm the player understands that bonuses cannot be withdrawn until this condition is fulfilled.

9. **If the player has not received the bonus or benefits as expected:**  
   - Check the system logs or Rewards Center to verify bonus delivery status.  
   - If eligible but bonus not credited within the stipulated time, escalate as needed, confirming the deposit amount and other conditions.

10. **If player does not meet the requirements or eligibility:**
    - Explain the specific missing criteria (e.g., VIP level, documentation, deposit amount, timing).  
    - Guide accordingly based on the actual situation, avoiding assumptions not supported by FAQ data.

11. **For players seeking to claim bonuses that are automatic (e.g., registration bonus, weekly salary):**  
    - Confirm they have completed all prerequisites.  
    - Instruct them to check the Rewards Center or Bonuses menu for their reward.  
    - Remind that no additional action may be needed if the bonus was automatically credited.

12. **Document the interaction and any action taken.**  
    - Note the player's submitted documents, bonus claimed, and status of turnover requirement fulfillment.

13. **Close the case with appropriate advice or escalation.**  
    - If dispute or issue persists, escalate following internal procedures.  
    - If all conditions are met, advise the player to begin wagering and advancing toward withdrawals.

## Notes
- Always verify the minimum deposit requirement for bonus eligibility (e.g., 100 PHP for the first deposit bonus).  
- For birthday-related bonuses, the birthday must match the provided ID and VIP status must be VIP4 or higher.  
- Bonuses are distributed automatically or upon claim in the Rewards Center; instruct players accordingly.  
- The maximum bonus for the first deposit promotion is 1,088 PHP depending on deposit size.  
- Turnover requirement details are consistent across bonuses: the bonus amount or cash-in must be played through until the system-specific threshold is reached before withdrawal is permitted.

## Key points for communicating with players
- Clearly explain the timing and method of bonus distribution.  
- Emphasize the necessary documents and VIP status prerequisites for special bonuses.  
- Remind players of the importance of meeting turnover requirements before withdrawing bonuses or winnings.  
- Encourage patience in case of delays, and advise them to check their Rewards Center or Bonus Center regularly.