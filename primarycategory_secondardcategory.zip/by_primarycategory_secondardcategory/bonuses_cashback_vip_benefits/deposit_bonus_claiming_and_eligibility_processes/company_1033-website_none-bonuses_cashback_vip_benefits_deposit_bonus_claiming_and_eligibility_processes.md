# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information:**
   - Confirm the player's identity and ensure they are accessing their account.
   - Ask the player if they are trying to claim a deposit bonus, specifically the first deposit bonus if applicable.
   - Check if the player has already claimed a deposit bonus from the same device or IP address, as only one bonus per IP or device is allowed.

2. **Verify player eligibility and conditions:**
   - Confirm that the player has verified their phone number before proceeding with the deposit to qualify for the bonus.
   - Ensure the player is making the deposit for the first time if claiming the first deposit bonus.
   - Ask the player if they are using the same device or IP as previous bonus claims. If they are, inform them that the bonus can only be claimed once per IP/device.

3. **Check the player's current deposit and bonus status:**
   - Verify whether the player has completed the phone number verification process.
   - Check in the back office if a bonus has already been credited from the same IP address or device.
   - Ensure the player is following the correct process to claim the bonus during deposit (selecting the promotion and clicking Next).

4. **Guide the player through claiming the bonus:**
   - Instruct the player to:
     - Verify their phone number if not already verified.
     - Select the relevant promotion during the deposit process before depositing.
     - Ensure that the bonus box is visible. If it is not visible:
       - Clarify that this may be due to using the same IP or device as previous claims.
       - Remind that only one bonus per IP or device is allowed.

5. **Perform the deposit:**
   - Advise the player to proceed with the deposit by clicking Next after selecting the promotion.
   - Confirm that the deposit amount aligns with the promotion's requirements and the process is completed properly.

6. **Verify bonus credit and handling issues:**
   - Confirm that the bonus has been automatically credited to the player's account once the deposit and selection are complete.
   - If the bonus is not received:
     - Verify that the player correctly clicked the promotion box.
     - Recheck whether the player is using an IP or device that has already claimed the bonus, as only one claim per IP/device is permitted.
   - Inform the player that bonuses are only distributed once per IP or device and advise them accordingly.

7. **Final checks and closing case:**
   - Ensure the player understands the restrictions on claiming bonuses based on IP and device.
   - Advise the player to contact support if they believe they are eligible but did not receive the bonus despite meeting all conditions, noting they should verify they completed all steps correctly and are not in a restricted IP/device situation.

## Notes
- The bonus distribution is automatic after the player meets verification and selection steps.
- Bonuses are restricted to one per IP address or device.
- If a player claims the bonus from the same device or IP again, they will be ineligible for additional bonuses on that device/IP.

## Key points for communicating with players
- Confirm that the player has verified their phone number before depositing.
- Remind players that only one bonus claim per IP address or device is allowed.
- Instruct players to click the promotion box before making their deposit.
- Clarify that if the bonus box isn't visible, it may be related to IP/device restrictions.
- Emphasize that bonuses are credited automatically once all conditions are met.