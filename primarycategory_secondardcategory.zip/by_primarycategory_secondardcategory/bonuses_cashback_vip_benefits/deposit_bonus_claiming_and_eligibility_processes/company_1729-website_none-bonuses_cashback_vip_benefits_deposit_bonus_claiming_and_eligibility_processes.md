# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player identity and eligibility:**
   - Confirm that the player has registered an account.
   - Ensure the player's mobile number has been verified.
   - Check if the player has linked their e-wallet.
   - Verify that the player has followed the official social media channels (Facebook page and Telegram group).
   - Review any additional account activity criteria, such as avoiding multiple accounts from the same IP address, if applicable.

2. **Gather necessary documentation and confirmation:**
   - Request a screenshot of the social media follow verification if needed.
   - Request a screenshot of social media sharing or other activity proof if required for specific bonuses.
   - Obtain the player's consent to proceed with bonus verification.

3. **Check bonus-specific requirements and options:**
   - For deposit bonuses:
     - Confirm the deposit amount meets the minimum criteria if specified.
     - During deposit, instruct the player to select the desired bonus from the bonus list before completing the transaction.
   - For sign-up or registration bonuses:
     - Verify that the player has completed all registration and social media actions.

4. **Review the deposit and bonus application process:**
   - Instruct the player to make a deposit, ensuring mobile or bank details are verified, if required.
   - Advise the player to select the bonus option during the deposit process.
   - Confirm that the bonus was selected before completing the deposit.

5. **Confirm bonus activation and eligibility:**
   - Verify in the system that the bonus has been credited to the player's account.
   - Ensure the player has met all eligibility criteria, including:
     - Mobile number verification
     - Linking e-wallet
     - Social media follow/share
     - Selection of bonus during deposit
     - Compliance with specific bonus conditions such as minimum deposit or game restrictions.

6. **Communicate bonus policies and conditions:**
   - Inform the player of any applicable wagering requirements, for example:
     - Bonus turnover is generally 25 times the bonus amount.
     - Only certain slot games (e.g., JILI slots) are eligible for wagering.
     - Bonuses are applicable only to first deposits or specific campaigns.
     - Bonuses cannot be combined with other promotions.
   - Clarify that the bonus is entirely dependent on meeting all the specified conditions.

7. **Address issues related to bonus eligibility:**
   - If the bonus has not been credited:
     - Double-check that all steps, such as social media follow and screenshot submission, have been completed successfully.
     - Verify that the deposit amount and bonus choice were correctly processed.
   - If the player is ineligible:
     - Explain the invalidity reasons based on criteria (e.g., incomplete verification, multiple accounts, non-compliance with rules).
     - Guide the player on how to fulfill criteria for future eligibility.

8. **Escalate or advise further actions if necessary:**
   - Suggest escalation if technical issues prevent bonus claiming.
   - Advise the player to contact customer support with relevant screenshots or documentation if disputes arise.
   - Confirm any special conditions, such as contacting support for a refund on the second deposit if their first deposit was without a bonus and was lost.

## Notes

- Always verify mobile and social media actions before bonus activation.
- Bonuses are usually credited immediately upon successful completion of verification steps.
- Be aware that certain bonuses, like welcome bonuses, are automatically credited once verification is complete.
- Turnover requirements and eligible games vary per promotion and should be explained clearly if questioned.
- Additional social media actions, such as sharing or submitting screenshots, may be mandatory for certain bonuses.

## Key points for communicating with players

- Ensure players understand all the eligibility criteria, including mobile verification, social media follow, and bonus selection during deposit.
- Clarify that failure to meet conditions will result in bonus ineligibility.
- Remind players that bonuses often have wagering requirements (e.g., 25 times for deposit bonuses).
- Encourage players to retain screenshots or proof of social media actions if needed for verification.
- Reiterate that bonuses cannot be combined with other promotions and are usually limited to certain deposit types or first deposits.