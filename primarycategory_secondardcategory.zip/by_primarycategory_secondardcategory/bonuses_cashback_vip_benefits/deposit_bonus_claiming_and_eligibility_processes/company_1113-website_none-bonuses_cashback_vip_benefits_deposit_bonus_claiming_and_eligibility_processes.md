# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information**:
   - Confirm the player's account details and verify their identity as per internal procedures to ensure the account is active and verified.

2. **Identify the player's intention regarding the deposit bonus**:
   - Confirm if the player wishes to claim the deposit bonus during the current deposit.

3. **Verify phone number and account eligibility**:
   - Check if the player's phone number has been verified in their account.
   - Ensure the player meets the general bonus eligibility requirements, such as:
     - Being a first-time depositor (if applicable),
     - Meeting the minimum deposit amount, often 300 PHP,
     - Not exceeding any account or IP restrictions.

4. **Check for any IP or device restrictions**:
   - Ascertain if the player is using a unique IP address and device; bonuses are limited to claiming once per IP address or device.
   - If the player claims the bonus on the same IP or device as another account, inform them that they may not be eligible for the bonus.

5. **Assist the player in making the deposit**:
   - Guide the player to the deposit page.
   - Advise them to select the deposit promotion during the deposit flow.
   - Ensure the promotion is selected before proceeding (the bonus box must be shown; if not, the player may be on a device/IP that has already claimed the bonus).

6. **Complete the deposit process**:
   - Instruct the player to click "Next" or proceed with the deposit as per site procedure.
   - Confirm that the player has successfully made the deposit and selected the promotion.

7. **Verify bonus receipt**:
   - Check back-office systems to see if the bonus was credited:
     - If the bonus is credited, notify the player of successful claiming.
     - If not credited, verify the following:
       - The promotion was selected during deposit.
       - The account does not violate IP/device restrictions.
       - The player met all the eligibility requirements, including the minimum deposit.

8. **Address issues preventing bonus receipt**:
   - If the bonus did not appear:
     - Confirm that the player followed the correct deposit steps.
     - Inform them that bonuses may be limited to one per IP address or device.
     - Ensure they have verified their phone number.
     - Remind them that some bonuses have wagering requirements or additional conditions as specified in the terms.

9. **Explain VIP upgrade bonuses (if applicable)**:
   - Clarify that VIP upgrades are automatic and may take some time to reflect in the account.
   - Advise patience while the system updates the account status.

10. **Final checks and follow-up**:
    - Ensure the player understands any restrictions, wagering requirements, or limits related to the bonus.
    - Provide guidance on further steps if they encounter ongoing issues (e.g., contacting support with evidence of compliance).

## Notes

- Bonus eligibility is often limited to the first deposit or specific promotion periods.
- Bonuses are limited to one claim per IP address or device, so switching devices or IPs could affect eligibility.
- Wagering or playthrough requirements may apply before any winnings from the bonus can be withdrawn.
- VIP upgrade bonuses are system-applied and may require some wait time for updates.

## Key points for communicating with players

- Always verify if the promotion was selected during the deposit process.
- Remind players that bonuses are limited to one per IP address or device.
- Confirm phone number verification, as this is a standard requirement.
- Explain that delays or failure to receive bonuses could be related to device/IP restrictions or not meeting eligibility conditions.
- Encourage patience regarding VIP upgrade bonuses; they are automatic and system-driven.