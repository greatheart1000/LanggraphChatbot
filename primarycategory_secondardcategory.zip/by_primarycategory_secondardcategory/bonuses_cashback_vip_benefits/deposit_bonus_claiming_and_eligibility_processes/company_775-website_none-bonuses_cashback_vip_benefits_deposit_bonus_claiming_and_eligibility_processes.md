# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information and verify initial eligibility:**
   - Confirm the player's registration status, ensuring they have completed registration and downloaded the platform’s app if required.
   - Collect necessary identification information if applicable (e.g., Username, ID, selfie with ID) for VIP Birthday bonuses or other special benefits.
   - Check for potential ineligibility factors such as:
     - Binding the same bank card used previously
     - Not having a registered mobile phone number
     - Using the same or multiple phone numbers
     - Using the same or multiple IP addresses

2. **Verify deposit activity and bonus entitlement:**
   - Confirm if the player has made a first deposit of at least 100 PHP.
   - Check system records to verify if the deposit was successfully processed.
   - Ensure the deposit occurred within the required timeframe for bonus eligibility (e.g., within the last 12 hours for the first deposit bonus).

3. **Check automatic bonus distribution:**
   - Determine if the bonus has been automatically credited:
     - If eligible, the bonus or reward should appear in the Rewards Center within the specified processing window (commonly within 12 hours for first deposit bonuses or within 2 hours for registration bonuses).
     - If the bonus is visible, instruct the player to claim it if not automatically credited, especially if manual claiming is required.
   
4. **If bonus/reward is not received:**
   - Confirm the player has met all criteria:
     - Correct deposit amount
     - Completed all registration and download steps
     - No disqualifying factors (e.g., multiple accounts, binding same bank card, etc.)
   - Advise the player to check the Rewards Center or promotional account area.
   - If the bonus still hasn't appeared:
     - Verify the deposit qualifies for the promotion
     - Check for system delays
     - Confirm whether the deposit was made on a different account or through prohibited means that might affect eligibility.

5. **Explain the bonus conditions to the player if applicable:**
   - Clarify that bonuses are automatically credited once they meet all eligibility criteria.
   - Remind them that the bonus amount is up to 108 PHP for the first deposit (after depositing 100 PHP), with potential increases for larger deposits, up to 28,888 PHP.
   - Emphasize that withdrawal is only possible after meeting the rollover (playthrough) requirements.
   - Highlight that bonuses must be claimed within the designated timeframe (usually within 12 hours for deposit bonuses, within 2 hours for registration bonuses).

6. **Assist with bonus claiming:**
   - Guide the player to go to the Rewards Center.
   - Advise them to click 'claim' if the bonus has not automatically been credited.
   - Confirm the bonus appears in their account after claiming.

7. **Address issues related to VIP or special bonuses:**
   - For VIP Birthday bonuses:
     - Verify VIP3 status and presence of required documents (ID, selfie with ID, Username).
     - Explain that the bonus is awarded based on provided documentation and VIP status.
   - For daily Angpao or cashback programs:
     - Confirm the player has met turnover and deposit criteria.
     - Remind about time-limited claims (e.g., daily Angpao available between 21:00 and 21:30 GMT+8).
   
8. **Handle cases with potential restrictions or violations:**
   - If the player was found binding the same bank card, using the same phone number, or multiple IP addresses, advise that they may be ineligible for the bonus.
   - Inform them that system detection of such actions can prevent bonus awarding.

9. **Escalate if necessary:**
   - If the player’s issue cannot be resolved with the above steps, escalate to the technical or management team with detailed notes about the player's actions, deposit details, and eligibility checks performed.

## Notes
- Bonuses are distributed automatically by the system based on player eligibility.
- The Rewards Center is the primary area for claiming bonuses and rewards.
- The maximum deposit bonus can reach up to 28,888 PHP, depending on deposit amount.
- The initial deposit must be at least 100 PHP to qualify for the first deposit bonus.
- Turnover (wagering) requirements must be met before withdrawals are permitted.
- Bonuses are time-sensitive; players should check the Rewards Center within 12 hours (or the specified timeframe) after making the qualifying deposit.

## Key points for communicating with players
- Always verify the deposit amount and date.
- Remind players that bonuses are automatically credited if they meet all conditions.
- If not credited, instruct them to check the Rewards Center and click 'claim'.
- Clarify that violations related to account binding, phone number, or IP address can affect bonus eligibility.
- Explain the importance of meeting rollover requirements before withdrawing.
- Keep the player informed about the timeliness of bonus delivery and the need to act promptly if required.