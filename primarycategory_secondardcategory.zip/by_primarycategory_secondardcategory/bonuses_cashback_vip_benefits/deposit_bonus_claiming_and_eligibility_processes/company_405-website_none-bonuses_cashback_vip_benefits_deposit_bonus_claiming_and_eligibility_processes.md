# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's account eligibility for the specific bonus or benefit**
   - Check if the bonus is a birthday bonus:
     - Confirm that the player's account level is Level 10 or above.
     - Confirm that the account age is at least one year from registration.
   - For VIP or other deposit bonus eligibility:
     - Ensure the player has met the required VIP level or other specific criteria as per current promotion rules. (Note: VIP level details are not specified in the FAQs, so follow the current site configuration.)
   
2. **Identify the type of bonus or reward the player is requesting or has received**
   - Determine if it's a deposit bonus, cashback, daily or weekly mission reward, or birthday bonus.
   
3. **Check the player's bonus or reward status in the system**
   - Verify if the bonus or reward has been credited successfully.
   - Confirm the exact bonus amount or cashback amount credited.
   - For weekly or daily rewards:
     - Check if the rewards are finalized (weekly rewards are finalized every Tuesday and claimable Wednesday; daily rewards are calculated at midnight daily).
   
4. **Explain the applicable wagering or turnover requirements to the player**
   - Clarify that all bonuses received during events are subject to only 1X turnover before withdrawal.
   - For feedback rewards, this is 3X turnover after credits.
   - For promotional bonuses:
     - Confirm that bonuses generally require a 3X turnover before withdrawal.
     - Mention that this applies to bonus funds and any winnings derived from them.
     - Highlight that fulfilment of turnover requirements is mandatory before withdrawal.
   
5. **Verify if the player has fulfilled the turnover requirement**
   - Check the player's account activity and wagering history.
   - Confirm if the minimum turnover (e.g., 3X the bonus amount) has been achieved.
   - If not achieved:
     - Inform the player of the current progress and remaining wagering required.
     - Advise that they must meet the turnover requirement before withdrawal.
   
6. **If the player has met the turnover requirement**
   - Confirm that the bonus or winnings are eligible for withdrawal.
   - Guide the player to proceed with the withdrawal process.
   
7. **Handle cases of insufficient eligibility or incomplete requirements**
   - If the player's account does not meet the eligibility criteria (e.g., account level, registration duration):
     - Inform the player about the specific eligibility rules.
   - If the turnover requirement is not yet met:
     - Clearly explain the remaining wagering needed.
   
8. **Document and confirm all relevant information and steps with the player**
   - Record the account details, bonus/reward type, credited amount, and current wagering status.
   - Provide clear, concise instructions for any next steps or further actions needed from the player.
   
9. **Escalate or seek further assistance if necessary**
   - If any discrepancies or system issues arise:
     - Escalate to the appropriate support or technical team.
     - Advise the player to monitor their account for updates or further notifications.

## Notes
- All bonuses are subject to specific turnover (playthrough) requirements, typically 3X unless stated otherwise.
- Weekly rewards are finalized every Tuesday and can be claimed from Wednesday in the Reward Center.
- Daily rewards are calculated at midnight daily.
- Ensure players are aware of the minimum account level (Level 10) and account age (at least one year) for birthday bonuses.
- Always check the latest promotional terms in the Reward Center or official promotions page for specific conditions or exceptions.

## Key points for communicating with players
- Clearly explain the turnover requirement of 3X for bonuses before withdrawal.
- Confirm eligibility criteria such as account level and registration duration.
- Inform players about reward calculation times (midnight for daily, Tuesday for weekly).
- If in doubt, reference the current site configuration and official rules.