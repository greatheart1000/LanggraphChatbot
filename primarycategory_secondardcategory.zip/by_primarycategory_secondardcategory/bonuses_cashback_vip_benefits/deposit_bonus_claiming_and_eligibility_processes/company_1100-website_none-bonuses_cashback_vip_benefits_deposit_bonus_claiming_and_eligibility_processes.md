# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's eligibility for the deposit bonus:**
   - Confirm that the player has verified their phone number before making their first deposit.
   - Check if the player has already claimed the bonus from the same IP address or device, noting that bonuses are limited to one per IP or device.
   - Ensure the player is not attempting to claim multiple bonuses from the same IP or device if restrictions apply.

2. **Gather necessary information from the player:**
   - Confirm that the player has completed phone number verification prior to deposit.
   - Verify the player's current IP address and device details if possible, to determine if restrictions apply.
   - Ask if the player sees the promotion or bonus box; if not, note potential reasons such as IP/device restrictions or promo eligibility issues.

3. **Check in the system for bonus eligibility:**
   - Look for the bonus activation or promotion checkbox during the deposit process.
   - Verify whether the bonus box is visible and selectable.
   - Confirm that the player's account has not already participated in a similar promotion from the same IP or device.

4. **Assist the player with claiming the deposit bonus if eligible:**
   - Advise the player to check the promotion box before making the deposit.
   - Guide them to complete the deposit process, ensuring the correct promotion is selected/activated.
   - If the bonus box is not visible or not selectable, inform the player that it might be due to restrictions on IP or device, or that they may have already claimed the bonus from the same permissions.

5. **Address issues or ineligibility:**
   - If the player has already claimed a bonus from the same IP or device, explain that bonuses are limited per IP/device and that further claims may be restricted.
   - If the player deposited before verifying their phone number, clarify that bonus eligibility requires prior verification.
   - If the bonus does not credit after deposit and eligibility criteria are met, advise the player to contact support.

6. **Handle special cases or technical issues:**
   - If the promotion box does not appear, instruct the player to check if their IP or device is shared with another account or has previous bonus claims.
   - If the player cannot claim the bonus despite meeting criteria, escalate or advise to contact support for further assistance.

7. **Document and communicate with the player:**
   - Record the verification status, IP and device details, and any messages about restrictions or ineligibility.
   - Clearly explain the conditions required for bonus claiming, including the importance of phone verification and selecting the promo during deposit.

8. **Follow up if needed:**
   - If issues persist or eligibility cannot be confirmed, advise the player to contact support for further investigation.
   - Provide guidance on the importance of complying with the one bonus per IP/device rule and completing verification steps.

## Notes
- Bonuses are typically limited to one per account, IP address, and device.
- Phone verification must be completed prior to deposit to qualify for the first deposit bonus.
- The promotion box must be checked before deposit to activate the bonus.
- Failure to see the bonus box may indicate restrictions or prior claims from the same IP/device.
- If the player deposits before verifying, they may not be eligible for the bonus.
- For issues with bonus credit, support escalation might be necessary.

## Key points for communicating with players
- Emphasize the need for phone number verification before depositing.
- Clarify that each IP or device can only claim the bonus once.
- Remind the player to check the promotion box before completing the deposit.
- Inform that if they do not see the bonus option or it does not credit, restrictions or prior claims may be the cause.
- Encourage contacting support if eligibility or technical issues persist.