# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player identity and account status.**  
   - Confirm that the player has registered on the official site and downloaded the official app.  
   - Ensure the player has provided valid personal information and completed any necessary verification steps.

2. **Identify the specific bonus or promotion the player refers to.**  
   - Collect details about the bonus type (e.g., first deposit bonus, second deposit bonus, new register bonus, cashback, VIP weekly salary).  
   - Clarify which deposit or action the player has made or intends to make.

3. **Check player eligibility for the requested bonus or benefit.**  
   - Confirm the player is a new member if claiming first or second deposit bonuses.  
   - Verify that the deposit amount meets the minimum requirement (e.g., at least 100 PHP for second deposit bonus).  
   - For the new register bonus or app download bonus: ensure the bonus is credited automatically after registration and app download.

4. **Instruct the player on how to claim the bonus.**  
   - For deposit bonuses:  
     - Advise the player to go to the Reward Center after deposit.  
     - Confirm the bonus will be automatically distributed by the system within up to 12 hours.  
     - Remind them to claim the bonus in the Reward Center if necessary.  
   - For app download bonuses:  
     - Confirm the player has registered on the site and downloaded the official app.  
     - Inform them that the bonus (up to 888 PHP or similar) will be credited automatically within approximately 2 hours.

5. **Inform the player about the turnover (playthrough) requirement.**  
   - Emphasize that the bonus cannot be withdrawn until the turnover requirement is met (e.g., 15x for first and second deposit bonuses).  
   - Remind the player to use eligible games such as SLOT and FISH for meeting the requirements if specified.

6. **Advise the player on steps after claiming the bonus.**  
   - Encourage them to play through the bonus and meet the specified threshold before requesting withdrawals.  
   - Remind that bonuses are typically credited within up to 12 hours after eligibility is confirmed.

7. **Warn about suspicious or repetitive activity.**  
   - Inform the player that systematic or suspicious activities such as multiple accounts from the same IP address, bank card, or phone number can lead to confiscation of rewards and profits.  
   - Clarify that reusing the same payment methods or IP repeatedly may activate these restrictions.

8. **If the player reports non-receipt of the bonus or promotion, check system records.**  
   - Verify if the player’s registration and app download are complete.  
   - Confirm deposit amounts and timing.  
   - Ensure no violations of bonus rules or system detection of activity repetition.  
   - If eligible but bonus not credited within 12 hours, advise the player to wait or check system notifications.

9. **If the player is eligible but bonus is not credited after the typical timeframe, advise the player to:**
   - Re-login or restart the app.  
   - Check their Reward Center for the bonus credit.  
   - Ensure no violation of bonus terms such as repeated use of same IP, bank card, or phone number.

10. **In case of suspected violation or detection of prohibited activity, explain that rewards/profits may be confiscated.**  
    - Clarify that the system enforces activity rules strictly, and misconduct may lead to confiscation of all rewards and profits associated with the activity.

11. **Offer escalation if needed.**  
    - If the issue persists or the player contests the decision, escalate to the relevant department or management according to company policy.

## Notes

- Bonuses such as the first deposit (88%) and second deposit (58%) are automatically distributed after the deposit and can be claimed in the Reward Center.  
- Cashback up to 3.0% is credited real-time on bets; unclaimed cashback is automatically credited the next day.  
- VIP Weekly Salary is credited automatically every Thursday between 22:00 - 23:59 GMT+8 for players who meet the minimum deposit of 100 PHP within the week.  
- The maximum cap for the first deposit bonus is 38,888 PHP; for the second deposit, it is 28,888 PHP.  
- Bonus claims are subject to system rules, including restrictions on repeated use from the same IP address, bank card, or phone number, which may lead to confiscation.  

## Key points for communicating with players

- Always confirm the player's registration, app download status, and deposit details.  
- Clearly explain the timing (up to 12 hours for deposit bonuses, 2 hours for register bonuses).  
- Remind them of the turnover requirement (15x for deposit bonuses) before withdrawal.  
- Warn about the importance of avoiding repeated activity from the same payment methods or IPs to prevent rewards confiscation.  
- Offer assistance with system checks or escalate if necessary.