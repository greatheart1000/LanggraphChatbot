# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry and verify the type of bonus or promotion they are referring to.**  
   - Determine if the player is asking about the first deposit bonus, sign-up bonus, cashback, or VIP benefits.  
   - Confirm if the player is requesting information about deposit bonuses or if they have already made a deposit and are expecting a bonus.

2. **Request the necessary details from the player to assess eligibility.**  
   - Ask for their account details and whether they are a first-time depositor or existing player.  
   - Confirm the specific promotion they are interested in, such as the first deposit bonus or welcome bonus.

3. **Check the player's account and deposit history in the back office/system.**  
   - Verify if the player is making a qualifying deposit, ensuring the minimum deposit amount of 100 PHP has been met.  
   - Confirm whether the deposit qualifies for bonuses based on their account status (e.g., first deposit or subsequent deposits).

4. **Determine bonus eligibility based on the latest promotional terms.**  
   - Confirm that the player has fulfilled the deposit amount requirement.  
   - Verify if the bonus is still valid and if the bonus type (e.g., 100% match on first deposit) applies to this deposit.

5. **If the player is eligible, proceed to credit the bonus.**  
   - Log into the Rewards Center as the player:  
     - View and claim the applicable bonus (e.g., first deposit bonus).  
   - Confirm the bonus has been successfully credited to the player’s account.

6. **If the bonus is not credited automatically or the player reports it has not been credited, verify and troubleshoot.**  
   - Ask the player to provide a screenshot if needed.  
   - Confirm in the system that the deposit was successful and qualifies for the bonus.  
   - If the bonus is still not credited after deposit verification, escalate or refer to support for manual intervention.

7. **Inform the player of any conditions or restrictions applicable to their bonus.**  
   - Mention that bonuses are subject to specific terms such as wagering requirements, validity periods, and eligibility criteria as listed on the promotions page.  
   - Remind players that the first deposit bonus is available only once per account.

8. **If the player is not eligible (e.g., deposit below 100 PHP, or has already claimed the first deposit bonus), explain accordingly.**  
   - Clarify the minimum deposit requirement of 100 PHP.  
   - Remind that first-time deposit bonuses are only available once.  
   - If applicable, advise on other ongoing promotions or benefits they may qualify for.

9. **Close the interaction with a summary and offer further assistance if needed.**  
   - Confirm the player understands the bonus claiming process and eligibility criteria.  
   - Provide guidance on future eligibility checks or promotions.

## Notes

- Always verify the deposit amount and promotional eligibility in the system before confirming bonus credit.
- The first deposit bonus is a 100% match on the initial deposit and can be viewed and claimed in the Rewards Center after login.
- Bonuses are only available for qualifying deposits, typically requiring a minimum of 100 PHP.
- Bonuses are subject to specific terms outlined on the promotions page, including validity periods and wagering requirements.
- The sign-up bonus consists of free spins available in the Rewards Center.
- If issues arise, ensure players provide relevant evidence (screenshots) and follow escalation procedures as necessary.

## Key points for communicating with players

- Clearly explain the eligibility criteria, especially the minimum deposit amount of 100 PHP.
- Emphasize that first deposit bonuses can only be claimed once.
- Remind players to check the promotions page for detailed terms and conditions.
- Support players with troubleshooting steps, including providing screenshots if a bonus is not credited.
- Reassure players that their deposit has been verified before manually crediting bonuses if needed.