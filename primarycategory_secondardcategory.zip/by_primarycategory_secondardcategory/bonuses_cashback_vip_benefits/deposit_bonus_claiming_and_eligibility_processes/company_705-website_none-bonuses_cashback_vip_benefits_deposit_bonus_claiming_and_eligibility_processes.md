# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's inquiry or claim related to deposit bonuses, cashback, or VIP benefits** to identify the specific promotion or bonus type they are referring to.

2. **Check the player's account to determine their current status**:
   - Confirm whether the player is a new member or an existing member.
   - Check if the player has completed the necessary actions or eligibility criteria for the specific bonus (e.g., registration, deposits, VIP status).

3. **Determine the specific bonus the player is requesting**:
   - First Deposit Bonus (for new members, minimum deposit of 100 PHP, 100% bonus).
   - Second Deposit Bonus (49% bonus for new members).
   - Third Deposit Bonus (29% bonus for new members).
   - New Register Bonus (up to 1,888 PHP, credited automatically within 2 hours upon registration and app download).
   - Daily Angpao Bonus (claim at 21:00-21:30 GMT+8, with conditions for withdrawal eligibility).
   - Cashback (up to 3.0%, automatically or manually claimed).
   - Slot, Fish & Poker Betting Bonus (up to 388,888 PHP).
   - VIP Birthday Bonus (requires ID verification, limited to birthday date).
   - Monthly Rewards and VIP Bonuses (must verify VIP level and documentation).

4. **Gather necessary documentation or information from the player if applicable**, especially for bonus verification:
   - For VIP birthday bonuses, request two valid IDs showing birth date and a selfie holding an ID.
   - Confirm deposit amounts and transaction history if relevant.

5. **Assess the player's eligibility based on the promotion's criteria**:
   - Confirm minimum deposit amount (e.g., 100 PHP for first deposit).
   - Verify whether the promotion's time frame or claim period has passed.
   - Check that the player has completed any required actions within the specified window (e.g., log in to Reward Center within 12 hours, claim bonuses manually if needed).

6. **Check for potential violations or restrictions**:
   - Detect if the system has flagged repeated usage from the same IP address, bank card, or phone number.
   - Confirm whether the player has met turnover or wagering requirements (e.g., meet the turnover multiple before withdrawal, such as 10x or more depending on the bonus).
   - Verify whether the player’s account has any restrictions or flags related to previous confiscations or violations.

7. **For eligible players**:
   - Confirm the bonus has been automatically credited; if not, advise the player to check their Rewards Center.
   - If the bonus requires manual claiming (e.g., cashback, daily Angpao), instruct the player to claim the bonus through the Rewards Center or the specified time window.
   - Remind the player of turnover requirements and that they must meet them before withdrawal.

8. **If the bonus has not been credited or the player is ineligible**:
   - **Identify the reason**:
     - Not meeting deposit or turnover requirements.
     - Claim period expired.
     - Not eligible due to system flags (e.g., repeated IP, bank card, phone number).
     - Bonus not automatically credited, suggest checking again or contacting support.
   - Clearly explain the reason to the player based on the assessment above.

9. **Advise the player of the next steps if eligible**:
   - Complete any ongoing requirements (e.g., meet turnover, deposit more).
   - Wait up to 12 hours for automatic bonuses if applicable.
   - For verification (VIP or birthday), submit required documentation and wait for approval.

10. **Escalate the case if**:
    - There are discrepancies or suspected anti-fraud/system detection flags related to multiple accounts or repeated use.
    - The bonus eligibility or credit is unclear after checks.
    - The player requests exceptions or has issues accessing the Rewards Center.

## Notes
- Bonuses such as the First Deposit Bonus and New Register Bonus are automatically distributed within approximately 12 hours after deposit or registration, provided all conditions are met.
- Repeated use of the same IP address, bank card, or phone number may lead to confiscation of rewards and profits.
- Confirm that players meet the specific turnover requirements before allowing withdrawals.
- For special bonuses like VIP birthday rewards, verification with IDs is required, and bonuses are only credited on the actual birthdate.

## Key points for communicating with players
- Clearly explain the criteria for each bonus, including deposit amounts and turnover requirements.
- Inform players about automatic vs. manual bonus processes.
- Remind players about system detection of repeated usage and possible confiscation.
- Guide players to check their Rewards Center for credited bonuses and to claim bonuses that require manual action within the designated time frame.
- Keep the tone transparent and helpful, guiding through verification steps and next actions.