# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information**:
   - Confirm the player's registration date if related to new player bonuses.
   - Request the player's VIP level to determine eligibility for VIP bonuses (e.g., Birthday Bonus requires VIP3).
   - Verify the player's deposit history and activity to check eligibility for specific bonuses (e.g., first deposit, second deposit, registration bonus, Angpao, birthday).

2. **Identify the relevant bonus or promotion**:
   - Determine if the player is claiming:
     - First deposit bonus (requires a new player account, minimum deposit 100 PHP, maximum bonus 28,888 PHP, and automatic distribution within 12 hours).
     - Second deposit bonus (for players who have completed the first deposit, minimum deposit 100 PHP, bonus up to 16,888 PHP).
     - Registration bonus (post-registration, automatic within 2 hours after app download, up to 688 PHP with 20x turnover on SLOT & FISH).
     - VIP bonuses (weekly salary, birthday bonus for VIP3 levels).
     - Daily Angpao bonus (requires at least 5 deposits since registration; payout hourly).
   - Confirm the specific promotion details based on the player's status.

3. **Check eligibility conditions**:
   - Verify the deposit amount meets minimum requirements (e.g., 100 PHP for first and second deposits).
   - Confirm the bonus is applicable to the selected games—primarily SLOT & FISH.
   - For VIP bonuses, ensure the player has attained the necessary VIP level (e.g., VIP3 for Birthday Bonus).
   - For Angpao, confirm the player has made at least 5 deposits since registration.
   - Check for any restrictions related to duplicate IP addresses, bank cards, or phone numbers; repeated activity may lead to reward confiscation.

4. **Verify bonus claim process**:
   - Instruct the player to visit the Rewards Center.
   - Confirm if the bonus is listed and available for claim.
   - If eligible, advise the player to click the "Claim" button (if applicable).
   - For automatic bonuses (registration, first deposit), inform the player that the system credits bonuses within specified timeframes:
     - Up to 12 hours for first and second deposit bonuses.
     - Up to 2 hours for registration bonuses.
     - Hourly payouts for Angpao (if eligible).

5. **Check for required wagering/turnover**:
   - Confirm the player understands that a turnover of 15x (or 20x for registration bonus) must be met before withdrawal.
   - Verify if the player has fulfilled the turnover requirement:
     - Review the player's betting activity on SLOT & FISH games.
     - If turnover is incomplete, advise the player to continue playing eligible games.

6. **Inform the player about restrictions and potential forfeiture**:
   - Warn that repeated activity from the same IP, bank card, or phone number may lead to confiscation of awards or profits.
   - Clarify that bonuses are only valid for specific games (Slot & Fish).
   - Explain that bonuses are non-withdrawable until the turnover requirement is met.

7. **Assist with bonus distribution issues**:
   - If the bonus has not been credited within the expected timeframe:
     - Confirm the player has followed the claiming steps.
     - Check for possible restrictions (e.g., duplicate IP, account issues).
     - Escalate if necessary, providing screenshot evidence and detailed account activity.

8. **Conclude the process**:
   - Advise the player to continue playing on eligible games to fulfill the turnover.
   - Remind the player to check the Rewards Center regularly for new bonuses or updates.
   - Confirm the player understands the conditions for withdrawal.

## Notes

- All bonuses are automatically credited once the eligibility criteria are met, and players should check their Rewards Center.
- Bonuses are valid on SLOT & FISH games unless specified otherwise.
- The maximum bonus amounts vary by promotion, but notably, the first deposit bonus can be up to 28,888 PHP.
- Wagering (turnover) requirements must be met before withdrawal; commonly, this is 15x the bonus amount for deposited bonuses.
- Bonuses may be confiscated if activity is detected as suspicious or if eligibility conditions are violated.

## Key points for communicating with players

- Clearly explain the waiting times for automatic bonus credits (up to 12 hours or 2 hours for registration bonus).
- Remind players that meeting the turnover requirement is necessary before withdrawal.
- Warn about activities that may lead to reward confiscation, such as using the same IP or payment methods.
- Guide players to check the Rewards Center periodically for available bonuses and claim status.