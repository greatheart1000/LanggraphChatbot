# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information**:
   - Confirm the player's registration status.
   - Collect details of their deposit (amount, date, transaction ID).
   - Ask for any relevant account details such as phone number, bank card, IP address, or other identifiers to assess eligibility.

2. **Verify registration and app download**:
   - Confirm the player has successfully registered on the official website.
   - Ensure the player has downloaded the official GAMESPH app.
   - Confirm the registration or download was completed correctly; the registration bonus of up to PHP 1,888 is automatically credited within 2 hours after registration and app download.

3. **Check deposit compliance for deposit bonus**:
   - Verify that the deposit is at least PHP 100.
   - Confirm the deposit was made via a valid payment method (bank account, GCash, etc.).
   - Check that the deposit receipt confirms a successful transaction.

4. **Assess bonus eligibility based on system rules**:
   - Confirm the player has not used multiple accounts or registered with the same bank card, phone number, or IP address that could disqualify them.
   - Verify there are no violations of promotion rules or restrictions (such as being ineligible due to previous bonus claims or system restrictions).

5. **Proceed with bonus distribution**:
   - If the criteria are met, the system will automatically distribute the bonus: PHP 88 for the first deposit bonus upon deposit of PHP 100 or more.
   - For registration bonuses, ensure the bonus has been credited within 2 hours after registration and app download.

6. **Guide the player to claim the bonus**:
   - Direct the player to visit the Rewards Center.
   - Instruct the player to click 'Claim' if the bonus is not automatically credited.
   - Confirm the bonus appears within 2 hours of the deposit or registration.

7. **Handle cases of non-receipt**:
   - If the bonus is not received within 2 hours:
     - Check if the player's account meets the eligibility criteria.
     - Verify no system restrictions or disqualifications apply.
     - Advise the player that failure to receive may be due to multiple accounts, same bank card, phone number, IP address, or incomplete registration process.
     - Recommend the player to contact support with relevant transaction and account details for further investigation if needed.

8. **Document and close the case**:
   - Record all relevant details (deposit amount, transaction ID, system response, correspondence).
   - Confirm the player understands the bonus claim process.
   - Advise on wagering requirements and applicable game restrictions (bonus applies only to SLOT & FISH GAMES).

## Notes
- Bonuses are automatically distributed once eligibility criteria are met.
- Bonusses are only applicable on SLOT and FISH GAMES.
- Always verify the deposit amount and account details before proceeding.
- The maximum bonus for registration is PHP 1,888, and for the first deposit, PHP 88 is credited for deposits of PHP 100 or more.
- Bonuses are credited within 2 hours of deposit or registration.

## Key points for communicating with players
- Inform players that bonuses are automatically credited and they should check in the Rewards Center.
- Remind players that eligibility may be affected by multiple accounts, same bank card, phone number, or IP address.
- Encourage players to provide transaction details if bonuses are not received within the expected timeframe.
- Clearly explain that bonus applicability is limited to SLOT and FISH GAMES.