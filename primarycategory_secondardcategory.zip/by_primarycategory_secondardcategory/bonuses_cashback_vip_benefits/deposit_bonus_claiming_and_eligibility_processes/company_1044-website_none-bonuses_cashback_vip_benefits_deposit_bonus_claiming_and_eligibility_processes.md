# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player account information**
   - Confirm that the player's phone number is verified in the account settings. This is a required step for eligible bonuses, including deposit bonuses and the first deposit bonus.

2. **Identify the specific promotion involved**
   - Determine which deposit bonus or promotion the player is inquiring about or attempting to claim (e.g., first deposit bonus, 50% bonus, welcome bonus).
   - Confirm whether the player has selected the promotion during their deposit process.

3. **Check deposit details and promotion selection**
   - Verify if the player has made the required minimum deposit amount specified by the promotion.
   - Confirm that the player selected the promotion during the deposit. Bonuses are credited automatically if conditions are met and the promotion was selected at deposit.

4. **Review deposit and bonus claim eligibility**
   - Ensure the player has not claimed the same bonus on the same IP address or device previously, as bonuses are limited per IP and per device.
   - If the bonus was not received after meeting all conditions, inform the player to double-check:
     - Phone verification status
     - Deposit amount and selection of promotion
     - Not sharing IP or device with another bonus claimant

5. **Investigate potential IP or device limits**
   - Check the system for multiple bonus claims on the same IP address or device. If the player has already claimed the bonus on their current IP/device, they are not eligible for another bonus of the same promotion.
   - Communicate clearly that bonuses are limited per IP or device, and a different IP or device may be needed to claim another bonus if eligible.

6. **Advise the player on unreceived bonuses**
   - If the player has met all the criteria but did not receive the bonus, advise them to:
     - Re-verify their phone number if necessary
     - Ensure they made the first deposit and selected the promotion
     - Confirm that they are not using an IP/device that has already claimed the bonus
   - If issues persist, recommend contacting support for further investigation.

7. **Guide on claiming specific bonuses**
   - **First deposit bonus:** Player must verify phone number, make their first deposit, and select the promotion at deposit.
   - **50% first deposit bonus:** Player must verify phone number, make a deposit, and select the bonus during deposit.
   - **Welcome bonus:** Player receives daily tickets after registration, which must be redeemed within seven days.

8. **Handle edge cases and special conditions**
   - Bonuses are credited at deposit if conditions are met; failure to select the promotion results in no bonus.
   - Promotions are generally limited to one per IP or device; if the same IP/device has already claimed the bonus, further claims may be disallowed.
   - For any bonus not credited despite meeting the conditions, escalate to support for system investigation.

9. **Record and document the case**
   - Log all player communications and findings, including:
     - Verification status
     - Deposit details and promotion selection
     - System checks on IP/device limitations
     - Player's claims and resolutions provided

10. **Escalate if necessary**
    - If the issue involves technical system errors or unclear eligibility, escalate to technical or promotions support teams as per standard procedures.

## Notes

- Bonuses are subject to specific conditions (e.g., phone verification, deposit amount, selection of promotion).
- Bonuses are limited per IP address or device; players cannot claim the same promotion more than once on the same IP/device.
- If a player does not see the bonus box or promotion option, it may be because they've already claimed the bonus on their current IP or device.
- Always remind players to redeem any tickets or bonuses within the specified timeframes.

## Key points for communicating with players

- Confirm phone number verification before proceeding.
- Ensure the deposit was made correctly and the promotion was selected.
- Inform players about the IP/device limitations preventing multiple claims.
- If the bonus is not received despite meeting all criteria, advise contacting support and provide guidance on what information they need to gather.