# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather initial information from the player**
   - Confirm the player's registration status.
   - Ask if they have recently deposited and if they are eligible for a deposit bonus.
   - Check if the player is trying to claim the First Deposit Bonus or another promotion.
   - Record details: IP address, bank card, phone number, and transaction history to verify eligibility and prevent repeated registration issues.

2. **Verify the player's eligibility**
   - Confirm that the player has completed registration on the official website.
   - Ensure the player has made a qualifying initial deposit of at least 100 PHP.
   - Check if the deposit was made through acceptable methods and from eligible accounts.
   - Confirm that the player has not used the same IP address, bank card, or phone number involved in previous transactions if such restrictions apply.
   
3. **Check deposit and bonus claim details in the system**
   - Verify in the back office that the deposit of at least 100 PHP has been successfully processed.
   - Confirm the deposit has been credited to the player's account.
   - Check if the player has visited the Rewards Center and clicked 'Claim' within 2 hours of deposit.
   - Ensure the deposit was made on the official app or website, as applicable.

4. **Determine bonus credit status**
   - Confirm whether the bonus has been automatically credited within 2 hours after deposit.
   - Verify if the bonus amount has been credited and if it matches the policy (e.g., 88 PHP for a 100 PHP deposit).
   - Check if the player has met the applicable turnover requirement of 10X on SLOT or FISH games before attempting withdrawal.

5. **Explain to the player and resolve issues**
   - If the bonus was credited correctly, inform the player that:
     - The bonus is now active.
     - They need to meet the 10X turnover on SLOT or FISH games to withdraw.
   - If the bonus was not credited:
     - Confirm all steps have been correctly followed.
     - Remind the player that bonuses are only applicable on SLOT and FISH GAMES.
     - Check for system detection issues such as using the same registration details, IP, or payment method from previous transactions.
     - Suggest attempting the process again if appropriate, or escalate if system error persists.

6. **Advise the player about rules and limits**
   - Clarify that the first deposit bonus is only available after making a deposit of at least 100 PHP.
   - Inform them about the maximum bonus cap of 10,888 PHP.
   - Emphasize that bonuses are credited within 2 hours and require meeting the 10X turnover before withdrawal.
   - Reiterate that bonuses are only applicable on SLOT and FISH GAMES.

7. **Document and close the case**
   - Record all steps taken, including deposit verification, eligibility checks, and communication.
   - Note if the bonus was successfully credited or if further troubleshooting or escalation was needed.
   - Advise the player on next steps, such as meeting turnover requirements or contacting support if issues persist.

## Notes

- Bonuses are automatically credited upon meeting the qualifying deposit and eligibility criteria.
- The bonus applies specifically to SLOT and FISH GAMES.
- The maximum bonus amount is 10,888 PHP.
- The system automatically credits the bonus within 2 hours after the deposit, assuming all conditions are satisfied.
  
## Key points for communicating with players
- Confirm the minimum deposit of 100 PHP.
- Remind that bonuses are credited within 2 hours.
- Clarify turnover requirement of 10X on SLOT or FISH games before withdrawal.
- Ensure the player has completed all registration steps and the deposit is eligible.
- Warn against using the same registration details, IP, or payment methods involved in previous transactions if restrictions are in place.