# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify the player's identity and account registration status**:
   - Confirm the player has completed registration on the official website.
   - Check if the player has downloaded the JILIPARK Official App.
   - Ensure the player has verified their identity if required.
   - Note: Non-deposit players have a maximum withdrawal limit of 100 PHP and cannot claim deposit bonuses unless they make a deposit.

2. **Determine the type of bonus or benefit the player is requesting**:
   - Identify if the query pertains to the First Deposit Bonus, Second Deposit Bonus, New Register Bonus, Cashback, Monthly Rewards, VIP Salary, or other promotions.
   - Confirm the specific promotion involved, including any relevant time windows for claiming.

3. **Check player's deposit history and eligibility**:
   - For First Deposit Bonus:
     - Confirm the player has deposited at least 100 PHP for the first time.
   - For Second Deposit Bonus:
     - Confirm the player has completed the First Deposit Bonus and made a deposit on the second day.
     - Confirm the deposit is within the claim window (within 12 hours after the deposit).
   - For New Register Bonus:
     - Confirm registration and app download; verify deposit of at least 100 PHP.
   - For VIP benefits or birthday bonuses:
     - Check VIP level and special dates.

4. **Assess whether the bonus prerequisites are met**:
   - Ensure minimum deposit amounts are satisfied (e.g., 100 PHP for first deposit).
   - Verify that the deposit was made within the valid claim window (within 12 hours for deposit bonuses).
   - Confirm the bonus-specific conditions, such as:
     - For deposit bonuses: Bonus percentage or cap (e.g., 108% on first deposit up to 28,888 PHP).
     - For second deposit bonus: Up to 16,888 PHP, with larger deposits resulting in larger bonuses.
   - For cashback:
     - Confirm that cashback is earned in real time up to 3.0% on bets.
     - Check if cashback was manually claimed or will be automatically credited.
   - For Weekly Salary:
     - Confirm player's activity (at least one valid bet on slot or fish within the week).

5. **Retrieve and interpret system data related to bonus distribution**:
   - Check if the bonus has been automatically credited within 12 hours on the Rewards Center, or if manual claim is required.
   - For automatic bonuses, verify if the bonus appears in the player's Rewards Center.
   - For manual claim bonuses, instruct the player to go to Rewards Center and click Claim within the specified window.

6. **Explain to the player the applicable wager/turnover requirements**:
   - Inform that the bonus or cashback cannot be withdrawn until the required turnover (e.g., 15x for deposit bonuses) is met.
   - Clarify that bonuses are only usable on designated games (e.g., SLOT & FISH for certain deposit bonuses).
   
7. **Address and resolve common issues**:
   - If the bonus has not been received within 12 hours:
     - Confirm the deposit was made within the claim window.
     - Check for eligibility criteria fulfillment.
     - Inform the player that failure to meet criteria may result in no bonus credited.
   - If a player did not claim the bonus in time:
     - Explain the 12-hour claim window.
   - For cashback:
     - Ensure the cashback accumulated correctly and was properly claimed or will be auto credited.
   - For VIP, birthday, and weekly salary bonuses:
     - Confirm the player’s VIP tier and activity status.

8. **Guide the player through claiming procedures if not yet claimed**:
   - Instruct to log in to the Rewards Center.
   - Remind to click Claim within 12 hours of deposit or activity.
   - Confirm that the bonus should be credited automatically after claim or within 12 hours if system distributes automatically.

9. **Advise on necessary additional actions**:
   - If bonuses are not credited or issues persist, suggest verifying account details or completing remaining verification steps.
   - If violations or irregular activities are suspected, escalate according to company policy.

10. **Conclude with necessary disclosures and compliance reminders**:
    - Remind players of the wager requirements (e.g., 15x turnover).
    - Reiterate that bonuses may be restricted to certain games.
    - Advise players to review the full terms on the official site for detailed conditions.

## Notes

- Bonuses such as the First Deposit Bonus are credited automatically within 12 hours after the deposit, provided eligibility criteria are met.
- For deposit bonuses, always confirm the timing and windows for claiming; failure to claim within 12 hours results in ineligibility.
- Cashback is earned in real-time up to 3.0% and credited automatically before 4:00 a.m. GMT+8 unless manually claimed.
- Weekly VIP Salary and monthly rewards are credited automatically but require prior activity or meeting VIP level requirements.
- Use the Rewards Center as the primary platform for bonus claims.
- Always verify the eligibility conditions and deposit history before proceeding with a resolution.