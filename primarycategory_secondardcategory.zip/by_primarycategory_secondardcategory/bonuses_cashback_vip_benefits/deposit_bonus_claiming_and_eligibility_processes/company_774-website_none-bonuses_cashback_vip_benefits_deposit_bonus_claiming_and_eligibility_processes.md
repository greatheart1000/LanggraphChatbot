# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information:**  
   - Confirm the player's registration status on the official website.  
   - Check if the player has downloaded the PHJOIN app.  
   - Verify the deposit details, including deposit amount and method.  
   - Collect information about the player's IP address, bank card, and phone number used for deposits.

2. **Identify the applicable promotion or bonus type:**  
   - Determine if the player is eligible for the First Deposit Bonus, Second Deposit Bonus, VIP Weekly Salary, or other ongoing promotions such as Sunday Gifts or Cashback.  
   - Confirm the specific details relevant to the bonus, e.g., 69% bonus on the first deposit for new players, 129% on the second deposit, VIP tier level for salary bonuses, or weekly deposit requirements.

3. **Verify player eligibility criteria:**  
   - Check if the player meets the minimum deposit amount (e.g., at least 100 PHP for bonuses).  
   - For VIP benefits, confirm if the player’s VIP tier qualifies them for higher rewards.  
   - For weekly bonuses, verify if the player deposited at least 100 PHP within the relevant timeframe.  
   - For promotional claims like Sunday Gifts, ensure the player logs in and claims during the specified time window (e.g., Sunday 22:00 - 23:59 GMT+8).

4. **Check for activity restrictions and compliance:**  
   - Review system checks for repeated activity from the same IP, bank, or phone number.  
   - Confirm that the player has not previously used multiple accounts from the same IP, bank, or device, as rewards may be confiscated if violations are detected.  
   - Verify if the player has met the wagering or turnover requirement:  
     - For first deposit bonuses, the total turnover needed is as per the current promotion rules (e.g., a certain multiple of deposit + bonus).  
     - For VIP Weekly Salary, check if the player completed at least one valid bet on a qualifying game within the week.

5. **Determine bonus distribution and claim process:**  
   - Confirm if the bonus is automatically distributed or if the player needs to claim it manually via the Rewards Center.  
   - For manual claims, instruct the player to go to the Rewards Center and click “Claim” for the relevant bonuses.  
   - Check if the bonus has been credited within the expected timeframe (typically up to 12 hours for automatic distribution).  
   - For cashback or rebates, advise the player to click “CASHBACK” to claim in real-time, or expect automatic dispatch before 2:00 PM (GMT+8) the following day.

6. **Explain withdrawal restrictions and confiscation risks:**  
   - Remind the player that a turnover requirement must be met before withdrawal is allowed.  
   - Inform that rewards and profits may be confiscated if repeated deposits or bonuses from the same IP, bank, or phone are detected, to comply with site rules.

7. **Advise on usage limits of bonuses:**  
   - Clarify that certain bonuses, such as the Register Bonus and Angpao, are only usable on SLOT & FISH games and that for non-deposit users, the maximum withdrawal is PHP 100.  
   - For second deposit bonuses, specify game restrictions, such as usage only on SLOT and FISH games.

8. **Address any discrepancies or issues:**  
   - If the bonus is not received within the expected timeframe, advise the player to check the Promotions page or retry claiming via Rewards Center.  
   - If the player reports not meeting criteria or has concerns about eligibility, review transaction logs and activity history to verify compliance.

9. **Close the case:**  
   - Confirm all relevant checks are complete, and the player understands the conditions for withdrawing bonus funds.  
   - Offer to assist with further queries or clarifications regarding deposit, bonus, or VIP benefits.

## Notes
- Bonuses require a minimum deposit of 100 PHP to be eligible.  
- Repeated activity from the same IP, bank, or phone number may lead to confiscation of rewards and profits.  
- Turnover requirements must be met before withdrawal; specific multiples are promotion-dependent.  
- VIP Weekly Salary bonuses are automatically credited on Wednesdays if the weekly deposit requirement (at least 100 PHP) is met.  
- Cashback can be claimed instantly or automatically dispatched, with claims via “CASHBACK” button or scheduled automatic processing.  
- Bonuses are typically distributed within up to 12 hours if automatic; manual claiming is available via Rewards Center.  
- The system detects and prohibits multiple accounts from the same IP, bank, or device to prevent reward abuse.  
- Non-qualifying activity or violations may result in reward confiscation without prior warning.