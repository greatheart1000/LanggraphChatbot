# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Gather player information and verify account details**
   - Confirm the player’s identity (ID, passport, driver’s license, or birth certificate) if requesting a birthday bonus or other ID-based promotions.
   - Check the player's account status, including VIP level and current activity, to determine eligibility for specific bonuses.

2. **Identify the type of bonus or benefit the player inquires about**
   - Determine whether the player is requesting information about checking bonuses, claiming a specific bonus (e.g., birthday bonus), or understanding their eligibility for deposit or promotional bonuses.
   - Clarify if the bonus is automatic or requires manual claim.

3. **Check bonus and reward status in the system**
   - Access the player's user account dashboard.
   - Review the transaction history and bonus credits section to verify if bonuses have been credited.
   - Check for any expiry details on bonus credits.
   - If the bonus or reward is not credited automatically after meeting all conditions, proceed to next step.

4. **Verify bonus claim requirements**
   - Confirm if the bonus is automatically credited after meeting specific conditions, such as:
     - Making a minimum deposit (e.g., at least 5000 Taka for birthday bonus).
     - Completing the necessary wagering requirements (e.g., 10 times the bonus amount for birthday bonus).
   - For deposit or event-based bonuses, verify if the player has:
     - Clicked the bonus option during deposit (for first deposit bonus).
     - Met the wager amount and deposit minimums stated in the bonus terms.
   - Confirm if any documentation or additional steps are required for ID-based bonuses.

5. **Assist player in claiming bonuses, if applicable**
   - If the bonus is automatic and conditions are met:
     - Inform the player that the bonus should be credited automatically following their deposit or activity.
   - If the bonus is not credited:
     - Advise the player to submit relevant proof if the bonus is ID-based.
     - Record the account details and bonus inquiry for further follow-up.

6. **For special event, holiday, or level-up bonuses**
   - Confirm that the player’s activity and eligibility align with the specific event criteria.
   - Clarify that these bonuses are typically credited automatically based on activity, without manual claim.

7. **Check the player’s eligibility**
   - Verify deposit amounts, wagered sums, and account verification status to ensure they meet promotion criteria.
   - Review the specific bonus policy for any additional rules or restrictions.

8. **Update the player on bonus status and next steps**
   - If the bonus has been credited successfully:
     - Inform the player of the bonus credits and their expiry date.
   - If the bonus has not been credited due to unmet conditions:
     - Explain the reason based on system checks or missing requirements.
     - Advise on the steps needed to fulfill requirements for future eligibility.

9. **Escalate or follow up if needed**
   - If the bonus is not credited despite meeting conditions, escalate the case to the relevant team or support level.
   - Advise the player to contact support with proof of deposit, identity, or other relevant documents if ID verification is involved.

## Notes
- Bonuses are visible in the account dashboard, including transaction history, bonus credits, and expiry details.
- All deposit, wager, or promotional criteria must be fulfilled as per the current bonus policy.
- Bonuses such as birthday or member-day require submission of valid ID proof for eligibility.
- Bonuses are automatically credited upon fulfilling the conditions; manual requests are generally not necessary unless there are system errors.

## Key points for communicating with players
- Clearly explain that bonuses are either automatically credited or require fulfilling specific conditions.
- Remind players to keep proof ready for ID-based bonuses.
- Inform players of expiry dates and wagering requirements to avoid forfeiture.
- Be patient when handling cases of uncredited bonuses—check all conditions before escalation.