# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify Player's Account Status and Eligibility**
   - Confirm that the player has an active, verified account with completed KYC using valid ID and selfie (FAQs: claiming app download bonus, claiming welcome/noob bonus, birthday bonus, promo code usage).
   - Ensure the player is within any promotional or bonus-specific eligibility criteria, such as being a new user, birthday, or VIP level, based on the applicable bonus (FAQs: eligibility criteria, birthday bonus, VIP rescue fund).

2. **Gather Details of the Bonus or Promotion the Player Wishes to Claim**
   - Ask the player which bonus they are interested in (e.g., Daily Deposit Reward, App Download Bonus, 28P bonus, VIP benefits).
   - Confirm if the player has the necessary requirements:
     - For deposit bonuses: minimum deposit amount (e.g., ₱100 or ₱500, depending on the promotion).
     - For promo codes: player has the promo code on hand.
     - For app download bonus: player has downloaded and verified the app, placed the required bet (e.g., ₱66 ×1).
     - For special VIP benefits: check current VIP level and related conditions.

3. **Check System for Existing Claims and Bonus Status**
   - For automatic bonuses (e.g., Daily Top-Up Reward, Accumulated Top-up Bonus, VIP Rescue Fund): verify whether the bonus has already been claimed or auto-credited.
   - For manual claims (e.g., promo codes, VIP Rescue Bonus): check if the bonus has been claimed in the Rewards Center or whether the player has already redeemed it (limits like 1 redemption per user/month for 28P code).
   - Confirm if the bonus is still valid or has expired.

4. **Guide Player Through the Claim Process**
   - **For deposit bonuses:**
     - Instruct the player to make a qualifying deposit via the Deposit page.
     - For auto-credited bonuses, inform the player that the bonus will be credited to the Reward Center after deposit.
     - For bonus claiming with specific steps (e.g., app download bonus), ensure they have completed steps such as verifying account, linking mobile number, completing KYC, and placing required bets.
   - **For promo code bonuses:**
     - Advise the player to check Viber, Telegram, or Facebook at specified times (e.g., 7 PM on designated days).
     - Guide the player to redeem the code in the Rewards Center or via the app.
     - Remind them that only the first 1,500 redemptions are accepted, and one redemption per user per month applies.
     - Confirm they meet other terms like ₱100 minimum deposit (event day) and KYC verification.
   - **For automatic bonuses (e.g., Daily Top-Up Reward, VIP Rescue Fund):**
     - Inform the player that bonuses are system-generated based on their activity.
     - The bonus will appear automatically in their Reward Center after the activity requirements are met.

5. **Verify Bonus Wagering Requirements**
   - Clarify that most bonuses require wagering before withdrawal:
     - For example, the Daily Top-Up Bonus and VIP Rescue Fund typically need a 4x or 3x wager on eligible games before withdrawal.
     - Promo code bonuses often require a 5x wager on slots.
   - Ensure the player understands the necessary playthrough conditions.

6. **Advise on the Usage Time Limits**
   - Emphasize bonuses like the app download bonus must be used within 7 days of activation.
   - Inform players about expiration of unclaimed bonuses or claim periods, such as the Birthday Bonus, which has a 3-day window.

7. **Confirm Bonus Application and Next Steps**
   - Once the bonus is claimed or auto-credited:
     - Remind players to check their Reward Center for the bonus.
     - Advise players to meet any wagering requirement before attempting withdrawal.
   - For any issues, verify if the bonus has been credited or if further manual intervention is necessary.
   
8. **Escalate Issues When Necessary**
   - If the bonus has not been credited after valid deposit or claim steps, or if the player encounters system errors, escalate to technical teams with relevant details.
   - If the player is ineligible due to account or promotion limits, clearly communicate the reason.

## Notes
- Only one claim per IP address is permitted for certain bonuses like Daily Top-Up Reward.
- Mobile verification is required to qualify for most bonuses, including app download and deposit rewards.
- Bonuses such as VIP Rescue Fund are automatically credited based on game losses and need manual claiming within the specified window.
- Always verify that the player's activities meet the specific bonus conditions, such as wager multiples and game types (e.g., Slots and Fishing for deposit bonuses).

## Key points for communicating with players
- Confirm account verification (KYC) before guiding toward claiming bonuses.
- Clearly explain the wagering requirements and time limits.
- Remind players of the one claim per user or per IP address restrictions.
- Emphasize the automatic nature of some bonuses and clarify what steps are needed for manual claims.
- Always advise players to check their Reward Center for credited bonuses before proceeding with withdrawals.