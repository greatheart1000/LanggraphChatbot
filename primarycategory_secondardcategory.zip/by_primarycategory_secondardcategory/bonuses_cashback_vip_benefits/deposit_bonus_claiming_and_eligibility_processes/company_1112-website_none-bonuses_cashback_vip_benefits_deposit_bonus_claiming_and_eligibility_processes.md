# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Verify player's identity and account details**
   - Confirm the player's account is active and verified according to site procedures.
   
2. **Check the player's eligibility for the deposit bonus**
   - Ensure the player is attempting to claim the first deposit bonus.
   - Confirm that the deposit is their first deposit on the account.
   
3. **Instruct the player to verify their phone number**
   - Verify that the player's phone number is confirmed in their account.
   - If not verified, guide the player through the process of phone verification.

4. **Guide the player to select the promotion during deposit**
   - Advise the player to choose the relevant deposit bonus promotion during the deposit process.
   - Remind the player to explicitly select the promotion before proceeding.
   
5. **Assist the player with the deposit process**
   - Instruct the player to click "Next" after selecting the promotion before completing the deposit.
   - Confirm the deposit amount is correct and completed successfully.

6. **Check for potential system restrictions**
   - Confirm whether the bonus has been credited to the player's account.
   - If the bonus is not credited, verify if the deposit was made from an IP address or device that has already claimed the bonus.
   - Inform the player if the bonus cannot be claimed due to IP or device restrictions, as bonuses are limited to one per IP address or device.
   
7. **Address common issues related to non-receipt of bonus**
   - Explain that using the same IP address or device as another account can prevent bonus approval.
   - Clarify that each IP/device can claim the first-deposit bonus only once.
   - Advise to try from a different IP/device if eligible and appropriate, noting the restrictions.

8. **For other bonuses such as daily login bonuses or bonus tickets**
   - Guide the player to open the Reward Center from the account menu.
   - For daily login bonuses:
     - Instruct to select the Sign-in Task.
     - Tap on "Daily Login Free Bonus" and sign in to claim.
   - For bonus tickets:
     - Confirm the ticket is claimed on Day 1 in the Reward Center.
     - For subsequent days, instruct on claiming and using tickets on the following days.

9. **Escalate if necessary**
   - If the bonus issue persists despite following the above steps, escalate to the technical team with relevant details.
   - Record the exact circumstances, including IP address, device info, and verification status.

## Notes

- Bonuses are limited to one per IP address or device; multiple accounts on the same IP or device may not qualify for discounts or bonuses.
- The first deposit bonus can only be claimed once; subsequent deposit bonuses require different criteria.
- Always confirm that the player's phone number is verified, as this is a prerequisite for bonus eligibility.
- When in doubt or encountering system errors, escalate with detailed information for further investigation.

## Key points for communicating with players

- Remind players that bonuses are limited to one per IP address or device.
- Confirm that the promotion was selected during deposit; not choosing it may prevent bonus credit.
- Clarify that the deposit must be successfully completed after selecting the promotion.
- Emphasize that system restrictions might prevent bonus credit, especially if using the same IP/device as another account.
- Encourage players to contact support if they believe they should be eligible but did not receive the bonus, providing details about their deposit and device.