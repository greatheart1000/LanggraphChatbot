# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Receive the player's inquiry regarding deposit bonus claiming or eligibility.**  
   - Identify if the player is asking about a specific bonus (e.g., First Deposit Bonus, Welcome Bonus, Thursday Bonus, VIP Birthday Bonus, etc.).

2. **Gather necessary player information to verify eligibility and assist with claim procedures:**  
   - Confirm the player's registered username or account name.  
   - Verify the player's VIP level (if applicable, e.g., VIP 4 for Birthday Bonus).  
   - Check if the player has completed required actions (e.g., mobile number registration, real-name verification, bank card binding).  
   - Ask if the player has downloaded the official PHSPIN app, as certain bonuses require app registration.

3. **Check deposit status (if the inquiry relates to a specific bonus claim):**  
   - Confirm whether the player has made a qualifying first deposit of **180 PHP** (or specific amount if applicable).  
   - Ensure that the deposit was made through a valid method and is reflected in the system.

4. **Determine the player's eligibility for the deposit bonus:**  
   - Verify if the player has bound a bank card, registered a mobile phone number, completed real-name verification, and used different IP addresses if necessary.  
   - Check for system-detected disqualifiers: same bank card, same phone number, same/multiple IP addresses, or no mobile number registered.

5. **If the bonus is automatically credited (e.g., First Deposit Bonus, Welcome Bonus, New Player Bonus):**  
   - Confirm whether the bonus has been credited to the player's Rewards Center within the specified time frame:  
     - Typically within **12 hours** for the Welcome and First Deposit Bonuses.  
     - Within **2 hours** for New Member Bonuses.  
   - Advise the player to check the 'Reward Center.'  
   - If not received and the player is eligible, instruct to wait or recheck, or escalate if system issues are suspected.

6. **Guide the player on how to claim the bonus if it requires manual action:**  
   - Direct the player to go to 'Reward Center' or 'Bonus Center.'  
   - Instruct to click the 'Claim' button to activate the bonus.  
   - Remind that bonuses must meet the wagering or turnover requirements before withdrawal.

7. **For bonuses with specific claiming windows or deadlines:**  
   - Inform the player to claim the bonus within **3 days** for weekly or special bonuses (e.g., Thursday Bonus, Monthly Kickback).  
   - For Angpao or daily bonuses, advise claiming during the designated time window (e.g., 22:00–22:30 GMT+8).

8. **If the player inquires about specific bonuses like cashback, rescue, or rebates:**  
   - Confirm if the player has made eligible bets or deposits (e.g., for cashback up to 3.8%, or Rescue Bonus after losing over 100 PHP).  
   - For cashback: instruct to manually claim if required; otherwise, it will be automatically credited before **14:00** the next day if unclaimed.  
   - For Rescue Bonus: inform the bonus is delivered automatically the next day before **16:00** GMT+8.

9. **Check for bonus restrictions or ineligibility causes:**  
   - Reiterate that players may not qualify if they:  
     - Used the same bank card or phone number for multiple accounts.  
     - Used the same/multiple IP address.  
     - Have not completed identity verification or registered a mobile number.  
     - Have not fulfilled the specific deposit criteria.

10. **If the player did not receive the bonus despite meeting all conditions:**  
    - Advise the player to review their registration details or deposits.  
    - Check for possible system errors or disqualifiers.  
    - If eligible and still not credited, escalate to technical support or review the account status.

11. **In case the player is requesting special bonuses (e.g., VIP Birthday Bonus, VIP Weekly Salary):**  
    - Confirm the VIP status, especially VIP 4 for Birthday Bonus.  
    - For VIP Weekly Salary, verify minimum deposit of **100 PHP** within the week.  
    - For Birthday Bonus, advise contacting customer service post-VIP 4 achievement.

12. **For bonuses requiring additional documentation or verification (e.g., VIP Birthday Bonus):**  
    - Inform the player to provide required documents (e.g., IDs, selfies with IDs).  
    - Clarify that the bonus will be distributed after verification.

13. **Advise the player on optional or ongoing promotions:**
    - Encourage downloading the official PHSPIN app for seamless bonus access.  
    - Remind about the time-sensitive nature of certain bonuses, e.g., claiming within 3 days.

14. **If the player asks for further clarification or encounters an issue not covered above:**  
    - Escalate to the appropriate department or technical support with detailed account information and issue description.

## Notes
- Always verify the player’s account details before providing instructions on bonus claiming or eligibility.
- Cross-check last deposit and registration information in the system.
- Remind players to complete all required verification steps to qualify for bonuses.
- Explain that bonus distribution system automatically handles most promotions, but manual claiming is necessary for some events.
- Ensure players are aware of the turnover requirements necessary before withdrawal of bonus funds.
- If system anomalies occur, inform the player about potential processing delays and escalate.

## Key points for communicating with players
- Clearly confirm deposit amounts and verification status;
- Remind about the bonus claim process (automatic or manual);
- Reiterate eligibility requirements, especially about ID, phone number, and IP-related restrictions;
- Emphasize the importance of claiming within the specified deadline;
- Be transparent about possible reasons for ineligibility or non-receipt.