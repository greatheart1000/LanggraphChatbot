# Bonuses, Cashback & VIP Benefits - Deposit Bonus Claiming and Eligibility Processes

## Steps

1. **Identify the player's inquiry or request regarding bonuses or VIP benefits.**  
   - Determine whether the query pertains to claiming a bonus, verifying eligibility, or understanding distribution timing.

2. **Verify player's identity and account details.**  
   - Confirm the player's username and account status before proceeding with bonus-related actions.

3. **Check the specific bonus or benefit in question.**  
   - Determine which bonus the player refers to:  
     - New Register Bonus  
     - First Deposit Bonus (including for new players and VIPs)  
     - Daily Angpao Bonus  
     - VIP Weekly Salary  
     - Tuesday Surprise Gifts  
     - Monthly Generous Rewards  
     - VIP Birthday Bonus

4. **Assess the player's eligibility for the requested bonus or benefit.**  
   - For deposit bonuses:  
     - Confirm initial deposit amount (e.g., 100 PHP for new players, minimum 50 PHP for others).  
     - Check if the deposit meets the minimum required for the bonus (e.g., 100 PHP for First Deposit Bonus, 50 PHP for New Register Bonus).  
   - For cashback, VIP Salary, or event-specific bonuses:  
     - Verify activity requirements (e.g., at least one valid bet on slot or fish games within the week for VIP Weekly Salary).  
     - Confirm VIP level or status if applicable.  
     - For Birthday Bonus: ensure player's birthday verification and provided documentation.

5. **Check system and registration data for anti-fraud measures.**  
   - Review if there are repeated use of the same IP address, bank account, or phone number across multiple accounts, which may lead to confiscation of rewards or profits.

6. **Determine if the bonus distribution is automatic or manual.**  
   - Bonuses such as all system-distributed rewards or VIP Weekly Salary are automatically credited within 12 hours or on scheduled days.  
   - For automatic bonuses, inform the player that the bonus will be credited shortly.

7. **For bonuses requiring additional player action to claim (e.g., Register Bonus):**  
   - Guide the player to claim via Bonus Center or specified platform, emphasizing the automatic credits for certain bonuses like Register Bonus and Angpao.

8. **If the bonus is not credited automatically within the expected timeframe (e.g., 12 hours):**  
   - Verify player's eligibility criteria are met.  
   - Check for system detections of repeated IP, bank, or phone number usage.  
   - If all conditions are satisfied but bonus is not received, escalate or instruct the player to contact customer support with relevant verification details.

9. **For bonuses requiring proof or verification (e.g., Birthday Bonus):**  
   - Request the necessary documents:  
     - Two valid IDs, and a selfie while holding them (clear visible information).  
     - Phone number verification if needed.  
   - Advise the player that bonuses will be credited after successful verification.

10. **Explain the wagering or turnover requirements for withdrawal eligibility.**  
    - Highlight that for deposit bonuses:  
      - A 15x turnover is required before withdrawal (e.g., First Deposit Bonus, New Player Bonus).  
    - Clarify that profits from bonuses will be confiscated if turnover requirements are not met.  
    - Emphasize that bonuses and profits may be confiscated if fraud checks detect similar IP, bank, or phone numbers across accounts.

11. **If players inquire about specific promotion rules or conditions:**  
    - Refer to the exact promotion details, including timeframes, amounts, eligibility conditions, and restrictions as per FAQs.

12. **Inform the player of the timing of bonuses or rewards distributions:**  
    - All bonuses are automatically distributed by the system within 12 hours once eligibility is confirmed.  
    - Scheduled bonuses such as VIP Weekly Salary, Tuesday Surprise, and Monthly Rewards are distributed during specific times (e.g., Fridays between 22:00-23:59, or the 3rd of each month).

13. **Advise players on specific deposit methods, e.g., Maya deposit rebate (6%)**  
    - Mention that rebates are automatically applied on each recharge.  
    - Confirm that there are no deposit limits for Maya.  

14. **Address any issues related to bonus eligibility or failure to receive bonuses.**  
    - Check for possibly unmet requirements, such as deposit amount, activity, or verification.  
    - Confirm no detection of repeated IP, bank, or phone number.  
    - If all conditions are met and issue persists, escalate or recommend contacting customer support with relevant transaction details.

15. **Close the case by confirming bonus receipt or providing explanation.**  
    - If bonus received, inform the player of successful claim and next steps.  
    - If not received due to ineligibility or detection issues, clearly explain the reason and suggest actions or reapplication if applicable.

## Notes
- All bonuses are automatically credited by the system once the eligibility conditions are satisfied, usually within 12 hours.  
- Bonuses like VIP Weekly Salary and Tuesday gifts are distributed on scheduled days, and players must meet activity requirements to qualify.  
- Ensure verification documents are clear and complete when requesting proof for bonuses like Birthday Bonus.  
- Be vigilant of anti-fraud rules; rewards and profits will be confiscated if the same IP, bank, or phone number is detected across multiple accounts.

## Key points for communicating with players
- Inform players that bonuses are credit automatically; no manual claim is necessary unless specified.  
- Clarify that meeting deposit, activity, and verification requirements is essential for claiming or receiving bonuses.  
- Remind players that repeated use of the same IP, bank, or phone number can lead to rewards confiscation.  
- Encourage players to contact support if bonuses are not received within 12 hours after meeting all criteria and no fraud detection flags are present.