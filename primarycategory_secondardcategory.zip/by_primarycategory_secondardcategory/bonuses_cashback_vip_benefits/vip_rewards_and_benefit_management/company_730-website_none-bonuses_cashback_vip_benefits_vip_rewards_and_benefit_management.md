# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Receive the player's inquiry regarding their VIP Rewards or VIP Weekly Salary.**

2. **Verify the player's identity and VIP status in the system.**  
   - Ensure the player has an active VIP account with a current VIP tier.
   - Check whether the player has previously received the VIP Weekly Salary, to determine eligibility.

3. **Collect the relevant period's activity information from the player:**  
   - Confirm if the player has placed **at least 1 valid bet** on slot or fish during the week.  
   - Confirm if the player has made at least a **100 PHP deposit** within the same week.

4. **Check the player's activity against the eligibility criteria for the VIP Weekly Salary:**  
   - **If both conditions are met:**  
     - Proceed to the next step.  
   - **If either condition is not met:**  
     - Inform the player that they did not meet the requirements for the VIP Weekly Salary for that week.  
     - Do not process any reward; advise to meet the criteria next week.

5. **Confirm the timing of the weekly payout:**  
   - Verify if the request is made between **Thursday 22:00 and 23:59 (GMT+8)**.  
   - **If within the payout window:**  
     - Proceed to check if the reward has already been credited.  
   - **If outside the payout window:**  
     - Inform the player that the salary is credited only during the scheduled time frame and advise to check again during the payout window.

6. **Proceed to the system check for the reward:**  
   - Confirm whether the VIP Weekly Salary has been automatically credited to the Rewards Center on the current Thursday.  
   - **If credited:**  
     - Provide the player with the details of the reward received.  
   - **If not credited:**  
     - Inform the player that they may not have met the requirements or there was an issue.  
     - Encourage the player to review their activity and fulfill the deposit and bet requirements in the next week.

7. **Advise the player on their VIP tier impact:**  
   - Clarify that higher VIP tiers receive larger rewards, bonuses, and benefits.

8. **Guide the player on additional benefits and their management:**  
   - Explain how the VIP Weekly Salary and other benefits are automatically managed based on weekly activity and VIP tier status.  
   - Encourage the player to keep meeting weekly activity requirements to maximize their rewards.

9. **If the player reports issues or did not receive the reward despite meeting requirements:**  
   - Ask for screenshots or proof of activity, if applicable.  
   - Escalate the case to the relevant department if system issues are suspected or if further investigation is needed.

## Notes
- The VIP Weekly Salary is automatically credited every Thursday between 22:00 and 23:59 (GMT+8).  
- The reward depends on the player's activity (minimum of 1 bet on slot/fish and PHP 100 deposit during the week).  
- Higher VIP tiers receive higher rewards on the weekly salary, bonuses, and event benefits.  
- Not receiving the reward typically indicates the player did not meet the activity requirements during the week.

## Key points for communicating with players
- Clearly inform the player of the weekly timing window for the salary payout.  
- Remind them of the activity requirements: at least 1 valid bet on slot or fish and a minimum deposit of 100 PHP within the week.  
- Reinforce that rewards are automatically credited and that meeting the requirements ensures eligibility.  
- Advise patience if the reward is not immediately visible and suggest checking again during the scheduled payout time.