# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Receive player inquiry about VIP Weekly Salary or Friday Rewards.**  
   Collect the player's VIP tier and confirmation that they are asking about the payout schedule or their rewards status.

2. **Explain the payout schedule and eligibility:**
   - Inform the player that the VIP Weekly Salary is automatically credited to the Rewards Center every Tuesday between 22:00 and 23:59 (GMT+8).
   - Inform that Friday Rewards are automatically credited every Friday between 22:00 and 23:59 (GMT+8).
   - Clarify that rewards can vary depending on the VIP tier, with higher tiers receiving higher rewards.
   - Emphasize that eligibility requires meeting specific weekly requirements, such as making at least one valid bet on slot or fish games during the week.

3. **Verify player's VIP tier and activity for the relevant week:**
   - Check the VIP tier of the player in the back office or systems.
   - Confirm whether the player has completed at least one valid bet on a slot or fish game during the week (for the VIP Weekly Salary).
   - If the player inquires about the Friday reward, verify their activity during the current week as applicable.

4. **Check reward credit status in the Rewards Center:**
   - Confirm whether the VIP Weekly Salary has been credited on the upcoming Tuesday.
   - Confirm whether Friday Rewards have been credited on the upcoming Friday.
   - If the player states they did not receive their reward:
     - Ask if they completed the required valid bets during the week.
     - Check their activity records and the system logs for reward credit attempts.

5. **Identify reasons for missing payouts:**
   - If the reward was not credited:
     - Determine if the player failed to meet the weekly betting requirement (e.g., did not place a valid bet on a slot or fish game).
     - Confirm that the player's VIP tier and activity align with system records.
   - Inform the player that, based on the system, not meeting the eligibility criteria results in no reward payout.

6. **Advise the player on future eligibility:**
   - Remind the player that to receive the VIP Weekly Salary, they must complete at least one valid bet on a qualifying game during that week.
   - Explain that higher VIP tiers will yield higher rewards, bonuses, and events.

7. **Escalation or further action if necessary:**
   - If the system shows the player qualifies but the reward was not credited without a clear reason, escalate the case to technical support or relevant department.
   - Document the player's details, VIP tier, activity records, and system checks performed.

8. **Conclude the interaction:**
   - Summarize the findings to the player.
   - Provide guidance on meeting the requirements for future rewards.
   - Close the case once the explanation has been provided or escalation has been initiated.

## Notes
- Rewards are credited automatically; manual adjustments are not typically made unless system errors are identified.
- Ensure all communication emphasizes the automatic nature of payouts and the importance of meeting activity requirements.
- Players should be advised to keep records of their activity if they suspect system issues.

## Key points for communicating with players
- Clearly state the payout schedule: Tuesdays for Weekly Salary, Fridays for Friday Rewards.
- Confirm that the player has met activity requirements (at least one valid bet on slot or fish games) for that week.
- Explain that rewards depend on VIP level and system checks confirm eligibility.
- If rewards are missing despite meeting requirements, escalate the case accordingly.