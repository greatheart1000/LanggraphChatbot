# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Verify the player's VIP status and VIP Tier:**  
   - Access the player's account information in the back office or account management system.  
   - Confirm the current VIP Tier to determine applicable rewards and thresholds.

2. **Check the player's recent activity for VIP Weekly Salary eligibility:**  
   - Confirm whether the player has completed at least 1 valid bet on slot or fish within the week.  
   - Verify if the player has deposited at least 100 PHP within the week.  
   - If the player has not completed these requirements, inform them that they are ineligible for the weekly salary or bonus.

3. **Identify the weekly salary payout schedule:**  
   - Note that VIP Weekly Wages are automatically sent to the Rewards Center every Thursday between 22:00 and 23:59 (GMT+8).  
   - Confirm that the payout time has passed for the current week to check if the salary has been received.

4. **Check for the VIP Weekly Salary in the Rewards Center:**  
   - Log into the Rewards Center system or request agent access.  
   - Verify whether the VIP Weekly Salary has been credited.  
   - If credited, inform the player of their received amount based on their VIP tier and confirm the reward received.  

5. **Identify if the player did not receive the VIP Weekly Salary:**  
   - Confirm whether the player completed the minimum required bet and deposit.  
   - If the requirements were met but the salary is missing, investigate system delays or errors; escalate if necessary.  
   - If requirements were not met, explain to the player that the salary was not credited due to incomplete eligibility criteria.

6. **Assist the player with claiming the Sunday bonus:**  
   - Confirm the player logged in between 22:00 and 23:59 (GMT+8) on the Sunday in question.  
   - Verify that the player made at least 100 PHP in total deposits within the week prior to the Sunday bonus.  
   - Check if the bonus appears in the Rewards Center.  
   - If eligible, guide the player to claim the bonus within the specified time window.  
   - If not eligible or not received despite meeting criteria, inform the player accordingly.

7. **Handle edge cases or additional support needs:**  
   - If a player reports issues with receiving rewards despite meeting all requirements, escalate to technical support with relevant details.  
   - Remind players that rewards are tied to their VIP Tier and activity, and system delays may occur.

## Notes

- The VIP Weekly Wages are automatically sent every Thursday, so manual claims are generally unnecessary.  
- The Sunday bonus can only be claimed if logged in between 22:00 and 23:59 (GMT+8) and if deposits of at least 100 PHP were made in the previous week.  
- Successful verification depends on the player's activity and deposit history within the specified periods.  
- Always cross-check player activity logs and Rewards Center records before providing explanations or escalating.

## Key points for communicating with players

- Clearly inform players that VIP rewards depend on their activity and VIP tier.  
- Emphasize the weekly schedule for payments: Thursdays for wages, Sundays for bonuses.  
- Confirm whether requirements (valid bets and deposits) are met before explaining reward statuses.  
- Encourage players to contact support if they believe they are eligible but have not received rewards, providing specific details of their activity for prompt resolution.