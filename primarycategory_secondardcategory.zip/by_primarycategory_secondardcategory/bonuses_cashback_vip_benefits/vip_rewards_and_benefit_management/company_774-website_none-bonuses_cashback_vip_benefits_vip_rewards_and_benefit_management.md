# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Verify the player's inquiry** to understand if they are asking about the VIP Weekly Salary, VIP bonuses, or VIP benefits related to rewards and benefits management.

2. **Request the player to provide relevant account details**, such as:
   - Player ID or username
   - VIP tier level (if known)
   - Last deposit date and amount during the relevant week
   - Details about any recent bets made (e.g., on slots or fish), if applicable

3. **Check the player's account activity for the current week**:
   - Confirm whether the player has made a minimum deposit of 100 PHP during the week
   - Verify that the player has completed at least one valid bet (e.g., on slots or fish) in the same week

4. **Access the Rewards Center** in the back office system:
   - Confirm if the VIP Weekly Salary has already been credited for the current week
   - Check the scheduled credit time window: every Wednesday between 22:00 and 23:59 (GMT+8)

5. **Determine the player's eligibility for the VIP Weekly Salary**:
   - If the player has met the minimum deposit of 100 PHP and completed at least one valid bet, they are eligible
   - If the player has not met these requirements, inform them that they are not eligible for the current week’s reward and clarify the specific missing conditions (e.g., deposit or bet)

6. **Confirm whether the VIP Weekly Salary has been credited or is pending**:
   - If credited, inform the player of the amount received, noting that the reward amount depends on their VIP tier
   - If not credited, verify the following:
     - Whether the week’s deposit requirement was completed
     - If multiple claims from the same IP, bank card, or phone number are detected; caution that rewards and profits may be confiscated if system checks flag these

7. **Explain the rules and conditions associated with VIP Weekly Salary**:
   - It is automatically credited every Wednesday between 22:00 and 23:59 (GMT+8)
   - The reward increases with higher VIP tiers
   - Rewards can be as high as 399,999 PHP
   - Delays may occur due to high system volume

8. **If the player inquires about their VIP tier or reward amounts**, clarify:
   - Rewards are based on their current VIP tier
   - Higher tiers receive higher salaries and bonuses
   - The amount depends on their activity and VIP level

9. **Advise the player that repeated use of the same IP, bank card, or phone number may lead to confiscation** of rewards and profits, as per system checks

10. **Document the case and inform the player of the outcome**, including:
    - Eligibility status
    - Confirmation of credit or reasons for non-credit
    - Any further action required from the player or system considerations

## Notes

- The VIP Weekly Salary is credited automatically; agents do not need to manually trigger payments.
- All checks related to deposit amount, bet validity, and system flags must be completed before providing a resolution.
- If the player did not receive the reward despite meeting requirements, advise them to verify they met the weekly deposit and bet conditions and consider any system restrictions regarding multiple claims.

## Key points for communicating with players

- Clearly explain the timing of the weekly salary credit (Wednesday between 22:00 and 23:59 GMT+8).
- Emphasize the requirement of at least 100 PHP deposit and one valid bet within the week.
- Warn about system checks on IP, bank card, or phone number that may lead to confiscation if violations are detected.
- Confirm VIP tier specifics if discrepancies arise regarding reward amounts.