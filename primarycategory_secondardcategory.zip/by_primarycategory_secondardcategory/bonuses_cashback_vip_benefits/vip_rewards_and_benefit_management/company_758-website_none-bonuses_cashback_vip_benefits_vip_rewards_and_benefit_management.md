# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Identify the player’s inquiry**: Determine if the query relates to VIP Weekly Salary, VIP upgrade bonuses, or VIP benefits in general.

2. **Verify player’s VIP tier and recent activity**: Access the player's VIP level and recent activity records in the system.

3. **Check eligibility for VIP Weekly Salary**:
   - Confirm whether the player has completed at least one valid bet on slot or fish within the current week.
   - Verify that the player has made a minimum deposit of 100 PHP within the same week.
   - Ensure the activity falls within the weekly reward period (Friday 22:00 - 23:59 GMT+8).

4. **Determine if the player has received the VIP Weekly Salary**:
   - If the player has completed the qualifying activities:
     - Confirm that the VIP Weekly Salary has been automatically credited to the Rewards Center on the latest Friday within the specified time window.
     - If not received:
       - Inform the player that they may not have met the weekly requirements and advise them to ensure they completed at least one valid bet and deposited 100 PHP during that week.
   - If the player reports not receiving the salary but claims to have completed the requirements:
     - Ask for details of their weekly activity for verification.
     - Check the system records for valid bets and deposits.
     - If the system shows completion but the reward was not credited:
       - Escalate this to back-office support for manual crediting.

5. **Assist with VIP upgrade bonuses**:
   - If the player mentions a recent VIP upgrade:
     - Confirm the VIP level change in the system.
     - Check whether the upgrade bonus has been credited:
       - If within 24 hours of VIP level change, verify if the bonus has been added.
       - If not received within 24 hours, advise the player that bonuses are credited within this timeframe.
       - If still not received after 24 hours, escalate the case to support for manual addition.

6. **Inform players about other VIP rewards and benefits**:
   - Explain that higher VIP tiers receive higher rewards for the Weekly Salary, bonuses, and mysterious bonuses.
   - Clarify that all rewards are automatically sent to the Rewards Center based on activity and VIP level.

7. **If player requests further assistance**:
   - Guide them to contact customer service for manual review if necessary.
   - Collect any relevant screenshots or proof of activity if required for escalation.

## Notes

- The VIP Weekly Salary is automatically credited every Friday between 22:00 and 23:59 (GMT+8).
- Eligibility requires completing at least one valid bet on slot or fish and making a minimum deposit of 100 PHP within the week.
- VIP upgrade bonuses are credited within 24 hours after VIP level changes.
- Higher VIP tiers correspond to higher rewards for Weekly Salary, bonuses, and special events.
- Always verify system records before manually adjusting any rewards or bonuses.

## Key points for communicating with players

- Clearly inform players about the weekly schedule and eligibility requirements.
- Confirm their recent activity and VIP status before providing explanations.
- Reassure players that rewards are automatic but offer escalation options if discrepancies occur.
- Use the specific time window and minimum deposit amount (100 PHP) as key compliance points.