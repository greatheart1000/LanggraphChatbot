# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Verify player eligibility for the VIP Weekly Salary**  
   - Confirm if the player has completed at least one valid bet on slot or fish within the current week.  
   - Check the player’s VIP tier, as higher tiers provide higher rewards.  
   - Confirm if the player has made a minimum deposit of PHP 100 within the week.  
   - Ensure the player's account has no restrictions that prevent reward claims.

2. **Check the timing of the reward**  
   - Confirm whether the current day is Tuesday, as VIP Weekly Salaries are credited every Tuesday.  
   - Verify if the reward has already been credited for the current week (to handle duplicate inquiries).

3. **Review system records for VIP Weekly Salary**  
   - Access the Rewards Center to check if the VIP Weekly Salary has been automatically credited on the previous Sunday (between 22:00 and 23:59 GMT+8).  
   - Confirm the exact amount credited, if available, to ensure proper communication.

4. **Determine if the player meets the weekly requirements**  
   - If the reward is missing, verify whether the player met all conditions:  
     - Completed at least one valid bet on slot or fish during the week.  
     - Made a deposit of PHP 100 or more within the week.  
     - Has the appropriate VIP tier in the system.  
   - If any requirements are not met, inform the player that they did not fulfill the conditions for the reward.

5. **Explain to the player the process and outcome**  
   - If eligible and the reward should have been credited, confirm the timing and system status.  
   - If the reward hasn't been received despite meeting all conditions, advise the player to check back or wait until the next credit date, and escalate to technical support if necessary.

6. **Advise the player accordingly**  
   - For eligible players without the reward:  
     - Notify that the VIP Weekly Salary is automatically credited every Sunday between 22:00 and 23:59 (GMT+8).  
     - Clarify that higher VIP tiers enjoy higher rewards on salary, bonuses, events, and mysterious bonuses.  
     - Remind them to ensure they meet deposit and bet requirements weekly.  
   - For ineligible players:  
     - Explain that the reward is only credited if the weekly minimum deposit of PHP 100 is made and at least one valid bet is completed.  
     - Recommend meeting these requirements to qualify in the future.

7. **Document and close the inquiry**  
   - Record the player's VIP tier, deposit, betting activity, and system check details.  
   - If applicable, escalate to technical support for reward issues not resolvable through standard checks.  
   - Conclude the interaction with confirmation of the information provided and next steps if needed.

## Notes

- The VIP Weekly Salary is automatically credited to the Rewards Center every Sunday between 22:00 and 23:59 (GMT+8).  
- Eligibility requires at least one valid bet on slot or fish and a deposit of PHP 100 or more within the week.  
- The reward amount varies depending on the player's VIP tier, with higher tiers receiving higher rewards.  
- If the player did not receive the reward, it likely indicates the weekly deposit or betting requirements were not met.  
- Always verify the timing and system records before informing the player they did or did not receive the reward.