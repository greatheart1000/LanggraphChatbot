# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Verify the player's inquiry and identify the issue**
   - Determine if the player is asking about the VIP Weekly Salary, claiming rewards, or inquiring about VIP benefits.
   - Collect relevant player details: username, VIP tier level, recent activity, and specific questions.

2. **Check the player's activity for VIP Weekly Salary eligibility**
   - Log into the system and review the player's recent betting activity within the current week.
   - Confirm if the player has completed at least one valid bet on slot or fish during the week.
   - Verify if the player has made a minimum deposit of 100 PHP within the same week.

3. **Verify reward crediting status**
   - Check the Rewards Center for the presence of the VIP Weekly Salary credited on Friday between 22:00 and 23:59 GMT+8.
   - Confirm if the reward has been credited for the current week:
     - If credited, inform the player accordingly.
     - If not credited, proceed to troubleshooting.

4. **Troubleshoot non-receipt of VIP Weekly Salary**
   - Confirm whether the player met all the required conditions:
     - Made at least one valid bet on slot or fish during the week;
     - Deposited at least 100 PHP during the week.
   - If any condition is unmet:
     - Explain that the VIP Weekly Salary is only credited if all requirements are fulfilled.
     - Advise the player to ensure they meet the betting and deposit criteria for future weeks.

5. **Address delays or system issues**
   - If the player claims that the reward was not received despite meeting all conditions:
     - Check for any known system delays or maintenance affecting reward payouts.
     - Advise the player to wait until after the scheduled payout window.
     - Recommend clearing cache or trying again later if system issues are suspected.

6. **Inform the player of reward amount variations**
   - Clarify that the VIP Weekly Salary amount depends on the player’s VIP tier; higher tiers earn more.
   - Emphasize that rewards are automatically credited every Friday during the specified time window.
   - If the player’s VIP tier has changed recently, verify the current level and explain its impact on rewards.

7. **Guide players about claiming other rewards (e.g., third monthly rewards)**
   - Instruct players to log in and manually claim rewards in the Bonus Center.
   - Remind that the more they log in, deposit, and bet, the larger the rewards they can receive.
   - Confirm if the player has claimed the third monthly rewards or if they are eligible based on activity.

8. **Escalation procedures**
   - If issues persist after troubleshooting:
     - Inform the player that their account will be escalated for further investigation.
     - Document all findings and communications.
     - Coordinate with the technical or rewards team to resolve potential system or account issues.

## Notes

- The VIP Weekly Salary is automatically credited on Fridays between 22:00 and 23:59 GMT+8.
- The reward amount increases with higher VIP tiers.
- To qualify for the Weekly Salary, players must complete at least one valid bet on slot or fish and deposit at least 100 PHP during the week.
- Non-receipt typically indicates the player did not meet one or more of these criteria.

## Key points for communicating with players

- Clearly explain the requirements for receiving the VIP Weekly Salary.
- Emphasize that the reward is automatic and credited within the specified time window.
- Encourage players to verify their betting and deposit activity if they believe they should have received the reward.
- Be transparent about possible delays or system issues and advise on checking back after the payout window.