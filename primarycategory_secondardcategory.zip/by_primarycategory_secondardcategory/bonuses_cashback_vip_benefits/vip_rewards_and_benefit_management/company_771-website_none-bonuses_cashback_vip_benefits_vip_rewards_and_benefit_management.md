# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Initial Player Inquiry and Information Collection**
   - Ask the player for their account details and VIP tier.
   - Determine the specific benefit or reward the player is inquiring about (e.g., VIP Monthly Salary, Birthday Bonus, Weekly Salary, Cashback, VIP Rewards).

2. **Verify VIP Tier and Eligibility**
   - Check the player's current VIP tier in the system.
   - Confirm the tier-specific benefit they are requesting (e.g., VIP Monthly Salary, Weekly Salary, Cashback).
   - For benefits like **VIP Monthly Salary**:
     - Ensure the player has completed at least one valid bet on slot or fish during the relevant period.
   - For **Weekly Salary**:
     - Confirm the player deposited at least 100 PHP within the week.
     - Verify the player made at least one valid bet on qualifying games during the same week.
   - Note that higher VIP tiers yield higher rewards for these benefits.

3. **Check the Timing and Delivery Schedule**
   - For **VIP Monthly Salary**:
     - Verify if the current date is between the 15th of the month at 22:00 and 23:59 (GMT+8).
     - If the date is correct, proceed to the next step.
     - If outside this window, inform the player that the salary is typically paid on the 15th during the specified timeframe.
   - For **Weekly Salary and Rewards**:
     - Confirm if the current day is Sunday between 22:00 and 23:59 (GMT+8); otherwise, inform the player that these are paid every Sunday during this timeframe.
   - For **Birthday Bonus**:
     - Check if it has been within 24 hours post-upgrade or birthday date for crediting.

4. **Perform System Checks**
   - Access the Rewards Center and transaction logs.
   - Confirm if the requested benefit has been credited:
     - For **VIP Monthly Salary**: check if credited automatically on the 15th.
     - For **Weekly Salary**: verify if credited every Sunday.
     - For **Bonuses/Cashback**: check if the bonus has been credited within 24 hours of the upgrade or qualifying activity.
   - If the benefit is missing:
     - Verify whether the player met all requirements (e.g., valid bets, deposits).
     - Confirm if the timing aligns with scheduled payout windows.
   
5. **Address Missing Benefits**
   - If the player reports not receiving the benefit:
     - Confirm they met all eligibility criteria (valid bets, minimum deposit, VIP activity).
     - If requirements are unmet, explain that the benefit requires meeting specific criteria.
     - If requirements are met but the benefit is not credited within the scheduled window:
       - Advise the player that delays may occur due to system processing or high volume.
       - Offer to escalate or manually add the benefit if appropriate.
   - For **VIP Birthday Bonus or Cashback**:
     - If not received within 24 hours post-upgrade, instruct the player to contact customer support for manual consideration.

6. **Manual Adjustment and Escalation**
   - If the player is eligible but the benefit has not been credited after the applicable window and requirements are confirmed:
     - Escalate the case to the relevant department or follow internal procedures for manual addition.
     - Inform the player that their issue is being escalated and they will be contacted once resolved.

7. **Closing the Inquiry**
   - Confirm with the player whether they received the benefit or if their issue has been resolved.
   - Provide a clear explanation of the payout schedule and criteria if necessary.
   - Remind the player that benefits like **VIP Monthly Salary** are automatically credited as per schedule, subject to meeting conditions.

## Notes
- Always verify eligibility based on the most recent activity and system records.
- Benefits are automatically sent if all conditions are met within the designated timeframe.
- Delays may occur due to system volume; manual adjustments are handled through escalation.
- Encourage players to retain screenshots or transaction IDs if they encounter issues with crediting.

## Key points for communicating with players
- Clearly inform players about the scheduled payout times for each benefit.
- Remind players that higher VIP tiers unlock larger rewards.
- Clarify that benefits are only credited if the specific eligibility conditions are met.
- Advise players to contact support if the benefit is not received within the expected time window after confirming eligibility.