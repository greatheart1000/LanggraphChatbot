# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Identify the player's inquiry or issue regarding VIP rewards or benefits.**  
   - Determine whether the player asks about the VIP Weekly Salary bonus, Monthly Rewards, or other VIP-related bonuses.  

2. **Gather necessary information from the player.**  
   - Confirm the player's VIP level.  
   - Ask if the player has completed at least one valid bet on SLOT or FISH within the relevant period (weekly for Weekly Salary bonus, monthly for 7th Monthly Rewards).  
   - Verify the specific reward or bonus period in question (e.g., current week, 7th of the month).  
   - Check if the player has received the bonus or reward automatically or if they need to claim it manually.

3. **Check the system for bonus eligibility and status.**  
   - Log into the back-office or system interface.  
   - Confirm whether the player has completed the required bet(s) within the period.  
   - Verify whether the bonus has been credited automatically to the Rewards Center.  
   - Confirm the timing of the bonus credit:  
     - VIP Weekly Salary bonus is credited on Thursday between 22:00 and 23:59 (GMT+8).  
     - 7th Monthly Rewards are credited on the 7th of every month at 22:00 (GMT+8); the bonus is sent automatically.  
   - Check if the player qualifies for the bonus based on their VIP tier and activity.

4. **Determine the reason for any discrepancy.**  
   - If the player reports not receiving the bonus:  
     - Confirm if they completed at least one valid bet on SLOT or FISH within the period if they are inquiring about VIP Weekly Salary bonus.  
     - Verify if the current date and time are within the expected bonus credit window.  
     - Check for restrictions such as same IP address, bank card, or phone number for the Monthly Rewards, if applicable.  
     - Ensure claims are made within 3 days after the bonus has been credited (for monthly rewards).  

5. **Explain the status, requirements, or next steps to the player.**  
   - If eligible and bonus not received:  
     - Inform the player that the bonus should be credited automatically on the designated date/time window.  
     - Advise to wait until the specified time (Thursday 22:00–23:59 GMT+8 for Weekly Salary; 7th at 22:00 GMT+8 for Monthly Rewards).  
     - Suggest checking their Rewards Center or account balance again after this period.  
   - If ineligible (e.g., did not complete a valid bet, or activity outside required period):  
     - Explain the specific requirement (e.g., need to complete at least 1 valid bet on SLOT or FISH within the week/month).  
     - Recommend the player fulfill these requirements in the next eligible period.  
   - If the bonus should have been credited but is missing due to system error, escalate according to internal procedures.

6. **If the player is eligible but the bonus is not received after the expected time:**  
   - Confirm there are no restrictions or claim window issues.  
   - Advise the player to wait until the next scheduled credit, or  
   - Escalate the case to technical support if necessary.

7. **If the player confirms they have claimed or received the bonus:**  
   - Verify in the Rewards Center if the bonus appears as credited.  
   - If unclear, check for any restrictions or pending claims.  
   - Provide follow-up instructions, such as how to use or withdraw the bonus if applicable.

8. **Conclude the case with a clear summary and next steps.**  
   - Reassure the player if their bonus has been credited or explain why it was not.  
   - If needed, inform them about upcoming rewards or steps to meet requirements for future bonuses.  
   - Log the interaction and any relevant findings.

## Notes

- The VIP Weekly Salary bonus is credited automatically every Thursday between 22:00 and 23:59 (GMT+8).  
- The 7th Monthly Rewards are credited automatically on the 7th of each month at 22:00 (GMT+8) and must be claimed within 3 days.  
- Eligibility for these bonuses depends on completing at least 1 valid bet on SLOT or FISH within the specified period.  
- Higher VIP tiers receive higher bonus amounts, but all bonuses are credited automatically or sent directly to the Rewards Center.

## Key points for communicating with players

- Clearly confirm the timing and requirements for bonuses.  
- Always advise players to check their Rewards Center after the scheduled credit time.  
- Explain restrictions and claim procedures when relevant.  
- Escalate issues outside regular credit times or eligibility criteria to the appropriate support channels.