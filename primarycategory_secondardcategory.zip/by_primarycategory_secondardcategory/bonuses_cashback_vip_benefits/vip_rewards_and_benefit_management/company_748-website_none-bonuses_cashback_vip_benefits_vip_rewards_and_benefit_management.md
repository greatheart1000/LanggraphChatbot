# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Identify the player's inquiry or request related to VIP rewards, benefits, or the VIP program.**  
   - Determine if the player asks about VIP membership benefits, VIP Weekly Salary, cashback, free spins, or Angpao rewards.

2. **Verify the player's VIP status and related eligibility.**  
   - Check if the player is a VIP member; if unsure, confirm VIP tier through the account system.  
   - Confirm if the player has completed the minimum deposit requirement of 100 PHP within the current week for VIP Weekly Salary eligibility.

3. **Inquire and gather specific details if necessary.**  
   - Ask if the player wants information about VIP benefits, how to claim rewards, or eligibility requirements.  
   - Clarify what particular reward or benefit the player is referring to, e.g., VIP Weekly Salary, free spins, Angpao, or birthday gifts.

4. **Check the player's activity and system records to verify eligibility and reward status.**  
   - For VIP Weekly Salary:  
     - Confirm if the player has placed at least one valid bet on slot or fish within the week.  
     - Check if the reward was automatically credited on the previous Monday (between 22:00 - 23:59 GMT+8).  
   - For other rewards (e.g., free spins):  
     - Confirm if the player has completed 3 deposits within 3 days to unlock free spins.  
     - Verify if the free spin offer is available in Rewards Center on the 4th day.  
   - For Angpao:  
     - Confirm claim time (22:00 - 22:30 GMT+8).  
     - Check if the player downloaded the PHSPIN app and whether they are a VIP member.  
     - Confirm deposit count (5+ deposits for instant withdrawal; fewer than 5 deposits require 10x turnover).

5. **If the player is eligible and the reward should be credited or claimed:**
   - Provide instructions on how to view or claim the reward in the Rewards Center if applicable.
   - For automatic rewards like VIP Weekly Salary:  
     - Advise the player to check the Rewards Center during the next scheduled credit time.  
   - For manual claims or ongoing offers:  
     - Guide the player through the claim process step-by-step, if needed.

6. **If the player claims that they did not receive the reward:**
   - Verify system records to confirm whether the eligibility criteria were met (e.g., valid bets, deposits).  
   - If criteria were met but reward not received, escalate for further investigation.  
   - If criteria were not met, inform the player politely of the specific conditions (e.g., not placing valid bets, missing deposits).

7. **Special notes for VIP Weekly Salary:**
   - Confirm if the player has completed at least one valid bet on slot or fish within the week; if not, notify that they will not receive it until the requirement is fulfilled.  
   - Remind that the salary is credited automatically every Monday between 22:00 - 23:59 GMT+8.  
   - Higher VIP tiers yield higher rewards; this can be explained if requested but is not a requirement for standard checks.

8. **Record the interaction details and any actions taken.**  
   - Document eligibility checks, player responses, and system confirmations.  
   - Escalate cases where eligibility is unclear or technical issues occur as per internal procedures.

## Notes
- Rewards such as VIP Weekly Salary are automatically credited; players cannot manually claim them.  
- The higher the VIP tier, the larger the rewards for salary, bonus, events, and mysterious bonuses.  
- Angpao is claimable daily from 22:00 to 22:30 GMT+8; instant withdrawal applies to players with 5+ deposits since registration, otherwise, a 10x turnover is required before withdrawal.  
- For VIP free spins, players must complete 3 deposits within 3 days to unlock the offer, which can be claimed in the Rewards Center on the 4th day.  
- Always remind players to check their Rewards Center directly for updates on their rewards.

## Key points for communicating with players
- Clearly explain the conditions for each reward, emphasizing deposit and bet requirements.  
- Inform players about automatic credit times for rewards like VIP Weekly Salary.  
- Be transparent if the criteria are not met, and advise on how to qualify in the future.