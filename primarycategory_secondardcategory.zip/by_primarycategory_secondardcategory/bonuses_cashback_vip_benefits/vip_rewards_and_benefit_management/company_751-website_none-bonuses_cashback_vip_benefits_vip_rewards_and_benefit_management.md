# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Identify the player's inquiry about VIP rewards or benefits**  
   - Determine whether the player is asking about VIP Weekly Salary, monthly VIP rewards, or other VIP benefits related to bonuses, cashback, or benefit management.

2. **Confirm the player's VIP Tier and recent activity**  
   - Check the player's VIP tier to ensure they are eligible for the reward.
   - Verify recent activity, especially the completion of the necessary requirements (e.g., valid bets, deposits) according to the specific reward.

3. **Gather necessary information from the player**  
   - Ask if the player has completed the requirements:
     - For VIP Weekly Salary: Have they completed 1 valid bet on slot or fish games within the week?  
     - For monthly VIP rewards: Have they logged in and opened the Rewards Center between the specified time on the 8th of each month?  
     - For cashback or other benefits: Follow existing procedures based on the current system configuration.

4. **Check the system for reward eligibility**  
   - Review the Rewards Center system to determine if the VIP Weekly Salary was credited automatically on Sunday (for the preceding week) or Tuesday (for the current week).  
   - Confirm if the reward has been credited.  
   - Verify deposit activity if applicable (e.g., check if the player has deposited at least 100 PHP within the week for the Weekly Salary).

5. **Evaluate if the reward was successfully credited**  
   - If the reward appears in the Rewards Center, inform the player of the successful credit.  
   - If the reward is missing, verify whether the player met the requirements:
     - Did they complete at least one valid bet within the week?
     - Did they deposit the minimum required (if applicable)?
   - If the requirements are unmet, explain that the absence of the reward indicates the requirements were not fulfilled.

6. **Assist with claiming monthly VIP rewards**  
   - Advise the player to log in directly to the Rewards Center and open the Rewards tab on the 8th of each month between 22:00 and 23:59 (GMT+8).  
   - Confirm the player has claimed only once per month; multiple claims from the same IP, bank card, or phone number may result in confiscation of rewards and profits.  
   - Note that rewards are random, and the player cannot choose the specific reward.

7. **Handle edge cases and escalation**  
   - If the player insists they have fulfilled all requirements but rewards are not credited, escalate to back office support with evidence of activity (e.g., bets placed, deposit receipts).  
   - If the system indicates the reward has been credited but the player reports not receiving it, advise them to check their Rewards Center and, if needed, escalate.

8. **Document the interaction**  
   - Record the player's account details, the discussed requirements, and the system checks performed.  
   - Note any discrepancies or unresolved issues for further escalation.

## Notes

- Players must complete the required actions within the specified timeframes for rewards to be credited automatically.  
- The VIP Weekly Salary is credited every Tuesday; the previous week's rewards are available for claim on Sunday.  
- For the VIP Weekly Salary, the player must complete at least one valid bet on slot or fish games within the week; field deposit of 100 PHP is a possible additional condition, but the core requirement is the bet.  
- Monthly VIP rewards are available only on the 8th of each month and can be claimed once per player.  
- Rewards are random and may be confiscated if system rules regarding IP, bank card, or phone number detection are violated.  
- Always verify the timing and transaction records before concluding whether the reward should have been credited.