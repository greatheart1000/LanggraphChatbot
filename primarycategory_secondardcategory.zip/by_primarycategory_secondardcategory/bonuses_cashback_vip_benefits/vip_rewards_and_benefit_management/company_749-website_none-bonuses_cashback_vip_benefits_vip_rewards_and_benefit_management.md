# Bonuses, Cashback & VIP Benefits - VIP Rewards and Benefit Management

## Steps

1. **Identify the player's inquiry** regarding VIP Rewards, specifically about the VIP Weekly Salary or VIP VIP level upgrade bonus.

2. **Collect relevant player information**, including:
   - Player's VIP Tier level.
   - Player's registration details (registered mobile number, bank card information).
   - Any recent activity related to bets or VIP level change.

3. **Check the player's VIP Weekly Salary eligibility**:
   - Verify if the player has completed at least 1 valid bet on slot or fish games within the week.
   - Confirm the current day is between Tuesday (for credited rewards) and Friday (when rewards are sent).
   - Determine the current VIP Tier level to assess if the reward should be higher.

4. **Verify the weekly salary payment status**:
   - Confirm whether the VIP Weekly Salary has been credited to the Rewards Center.
   - If the salary is not credited on a Tuesday, inform the player that the reward is usually credited every Tuesday.
   - If the player claims they meet the conditions but didn't receive it, proceed to check if the bet requirement has been fulfilled.

5. **Confirm bet fulfillment**:
   - Check transaction records to verify if the player completed 1 valid bet on slot or fish game within the week.
   - If the player has not completed the bet, explain that the VIP Weekly Salary is credited only after fulfilling this requirement.

6. **Handle VIP level upgrade bonus inquiries**:
   - If the player recently upgraded VIP level, verify the waiting period for VIP bonus:
     - Confirm that at least 24 hours have elapsed since the upgrade.
   - If the bonus has not been received after 24 hours, instruct the player to contact customer support for manual addition.
   - Explain that bonuses may be withheld if eligibility checks fail, especially due to binding the same bank card, not having a registered mobile number, using the same phone number, or multiple IPs/accounts.

7. **Identify issues if the player reports missing rewards or bonuses**:
   - Check eligibility criteria, including bet completion and account details.
   - Confirm there are no violations such as multiple accounts or system restrictions.
   - If all conditions are met and the bonus is still not credited, advise the player to contact customer support for manual review.

8. **Provide the necessary guidance or escalate if needed**:
   - If the player is eligible but rewards are not received, escalate to relevant back office support for manual intervention.
   - Advise the player to ensure account details (mobile, bank card, IP) are consistent to avoid withholding bonuses.

## Notes

- The VIP Weekly Salary is credited automatically every Tuesday, and it depends on completing 1 valid bet on slot or fish games within the week.
- VIP rewards increase with higher VIP Tiers, affecting salary, bonuses, and event benefits.
- VIP level upgrade bonuses require a 24-hour waiting period; if not received, encourage players to contact support.
- Bonuses may be withheld if eligibility checks fail; typical reasons include binding the same bank card or phone, using multiple accounts, or multiple IP addresses.

## Key points for communicating with players

- Clearly inform players about the weekly salary credit schedule (every Tuesday).
- Emphasize the requirement of 1 valid bet on slot or fish games within the week.
- If rewards are missing, verify bet completion and account details before escalating.
- Remind players about the 24-hour waiting period for VIP upgrade bonuses.
- Advise players to contact customer support for manual bonus addition if the reward is not received after the waiting period.