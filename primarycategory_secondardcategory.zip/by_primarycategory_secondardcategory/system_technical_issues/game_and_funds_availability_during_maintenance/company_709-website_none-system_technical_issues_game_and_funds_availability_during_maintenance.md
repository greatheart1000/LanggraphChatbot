# System & Technical Issues - Game and Funds Availability During Maintenance

## Steps

1. **Greet the player and verify their issue.**  
   - Ask the player to specify if they are experiencing issues related to game access, funds (deposits or withdrawals), or account verification.  
   - Confirm the specific nature of their concern regarding downtime or balance visibility.

2. **Collect relevant account and transaction information.**  
   - Request details such as the player’s username, recent transaction IDs (if applicable), and the specific game or funds involved.  
   - Note their last activity or attempted transactions to help with verification.

3. **Inform the player about current or upcoming scheduled maintenance.**  
   - Clearly communicate that the platform may be undergoing scheduled maintenance, which typically lasts between 15 to 30 minutes.  
   - Explain that during this window, several functions may be temporarily unavailable, including login, deposits, withdrawals, game access, and account verification.

4. **Verify the player's account status during the maintenance window.**  
   - Check if the maintenance is scheduled or ongoing by consulting the system alerts or backend status page.  
   - Confirm whether the player’s issue relates to game balance, funds transfer, or account verification during this time.

5. **Explain the effects of maintenance on game and funds.**  
   - Inform the player that:  
     - During game maintenance, their in-game balance may be temporarily frozen.  
     - Once maintenance is completed, their game balance will be automatically restored to their wallet.  
     - All funds are securely stored during maintenance; no funds are lost or compromised.

6. **Advise on next steps based on the maintenance status.**  
   - If maintenance is ongoing or completed:  
     - Reassure the player that their funds are secured and will be restored automatically post-maintenance.  
     - Suggest waiting until the maintenance window ends and the system updates are completed.  
     - Recommend trying again after the estimated window ends (15-30 minutes).  
   - If the maintenance window is unknown or exceeds the usual duration:  
     - Advise the player to monitor official status updates or contact support if the issue persists beyond 30 minutes.

7. **Guide the player on further action if their issue persists after maintenance.**  
   - Confirm that the problem continues after the estimated maintenance window.  
   - Instruct them to check their game wallet or account balance for automatic restoration.  
   - If issues remain unresolved, escalate the case following the company's escalation protocol, or advise the player to contact support with detailed transaction or issue information.

8. **Close the interaction politely.**  
   - Thank the player for their patience and understanding.  
   - Remind them that all funds and personal data are secure during these periods.  
   - Offer assistance for any other issues and conclude the conversation.

## Notes

- Maintenance durations are typically between 15-30 minutes.  
- During maintenance, certain functions like login, deposits, withdrawals, and account verification may be temporarily unavailable.  
- All funds and personal information remain secure and unaffected during the maintenance window.  
- Balances in the game may be temporarily frozen but will be restored automatically to the wallet once maintenance ends.  
- Players should wait until the estimated maintenance time has passed before attempting to access affected services again.

## Key points for communicating with players

- Clearly explain that system or game maintenance temporarily affects game balance and fund accessibility.  
- Reassure that all funds remain safe and will be restored automatically.  
- Emphasize the typical duration (15-30 minutes) and advise patience.  
- Encourage players to wait until the maintenance window has ended before further troubleshooting.