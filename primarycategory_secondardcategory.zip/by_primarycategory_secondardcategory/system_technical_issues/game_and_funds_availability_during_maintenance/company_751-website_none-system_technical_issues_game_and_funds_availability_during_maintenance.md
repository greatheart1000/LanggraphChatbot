# System & Technical Issues - Game and Funds Availability During Maintenance

## Steps

1. **Receive the player's report or inquiry about system or game issues.**  
   - Ask the player to specify the nature of the problem (e.g., game not loading, website access issues, balance issues during maintenance).

2. **Verify the player's account status and the reported issue:**
   - Confirm whether the player is experiencing:
     - Games not loading  
     - Website access difficulties  
     - Balance frozen during game or system maintenance  
   - Request relevant details such as:
     - Specific game or system affected  
     - Exact error messages or behaviors  
     - Time when the issue was observed  

3. **Check for ongoing maintenance or system issues:**
   - Confirm whether PG Game, MG Game, or the website itself is under scheduled or unscheduled maintenance.
   - For PG Game:
     - Inform the player that during PG Game maintenance, their balance may be temporarily frozen.
   - For MG Game:
     - Notify that a technical error may cause the balance to be temporarily frozen.
   - For website access issues:
     - Verify if the player is using the official URL or one of the alternative URLs provided: phjoy11.com, phjoy22.com, phjoy33.com, phjoy44.com.

4. **For games not loading:**
   - Advise the player to refresh the page.
   - If games still do not load:
     - Confirm the player's internet connection speed and stability as a common cause.
     - Suggest trying again after some time or restarting their device/browser.

5. **For website access issues:**
   - If the website cannot be accessed:
     - Suggest the player try alternative URLs: phjoy11.com, phjoy22.com, phjoy33.com, phjoy44.com.
     - Recommend clearing browser cache or attempting from a different browser/device if issues persist.

6. **For balance issues during maintenance or errors:**
   - Inform the player that their balance may be temporarily frozen during PG Game or MG Game maintenance or if a technical error occurs.
   - Assure that:
     - All funds are secured.
     - The balance will be automatically restored once maintenance or issues are resolved.
   - Advise patience and assure them that no funds are lost.

7. **If the balance has not been restored after maintenance or system resolution:**
   - Escalate the case to the technical or finance team for further investigation.
   - Do not attempt any manual adjustments; these are automatically handled.

8. **Document all findings and actions taken:**
   - Record the player's reported issue, steps performed, system checks, and communicated information.

## Notes

- Always inform players that all funds are secured during maintenance or technical errors affecting game balances.
- Clear communication that balance restoration is automatic once maintenance or errors are resolved helps reassure players.
- If additional technical details are needed, escalate according to internal procedures; do not attempt manual fixes.

## Key points for communicating with players

- Explain that during scheduled game maintenance, their balance is temporarily frozen and will be restored automatically.
- For website access issues, provide alternative URLs recommended by the system.
- Confirm that no funds are lost during system or game maintenance.
- Advise patience while technical issues are being resolved; escalate if the problem persists beyond expected resolution times.