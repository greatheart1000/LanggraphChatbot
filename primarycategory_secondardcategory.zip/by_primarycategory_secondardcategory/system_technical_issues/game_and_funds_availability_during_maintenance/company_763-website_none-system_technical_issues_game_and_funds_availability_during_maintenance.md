# System & Technical Issues - Game and Funds Availability During Maintenance

## Steps

1. **Gather information from the player**
   - Confirm if the player is experiencing issues related to game access, balance visibility, or funds during a specific timeframe.
   - Ask for details about the game or platform they are referring to.
   - Note if the player reports technical errors, game offline status, or server maintenance notices.

2. **Check the current system status and maintenance notifications**
   - Verify if the site or specific game is listed as under maintenance or upgrade.
   - Confirm if a maintenance window is scheduled or ongoing, typically estimated at 15 to 30 minutes.
   - If maintenance is announced or ongoing, inform the player accordingly.

3. **Evaluate the player's specific issue based on their input**
   - If the player is asking about their current game or platform balance:
     - Explain that during maintenance, in-game balances may be temporarily frozen.
     - Assure the player that all funds are safe and will be automatically restored once maintenance is complete.
   - If the player reports that their MG Game is experiencing technical errors:
     - Clarify that balances may be temporarily frozen during such issues.
     - Confirm that funds are secured and will be restored automatically after the resolution.

4. **Perform back-office/system checks**
   - Confirm whether the game or platform is indeed under maintenance or affected by technical errors.
   - Ensure the system status matches the player's report (e.g., offline status, ongoing maintenance window).

5. **Communicate the status and next steps to the player**
   - If the system/game is under scheduled maintenance:
     - Inform the player of the estimated duration (typically 15-30 minutes).
     - Explain that once maintenance ends, their balance will be automatically restored.
   - If a technical error is confirmed:
     - Reassure the player that the issue is being resolved.
     - Confirm that their funds are safe and will be restored once the technical issue is fixed.
   - In case the platform or game is not under maintenance:
     - Advise the player to clear cache, refresh, or try later.
     - If issues persist, escalate to technical support for further investigation.

6. **Record the case details**
   - Log the player's report, system status findings, and actions taken.
   - Note the time of the report and any relevant details for future reference.

7. **Close the case or follow up**
   - If the issue was due to maintenance or technical error, inform the player that their account/funds are safe and will be accessible after the issue resolution.
   - Advise the player to check again after the estimated maintenance window or technical fix.
   - Offer further assistance if needed, or escalate to technical support if the issue persists beyond standard resolution times.

## Notes
- During scheduled maintenance, in-game balances may be temporarily frozen; funds are safe and will be restored automatically after maintenance ends.
- If technical errors occur, balances inside the game may be frozen temporarily, but all funds are secure, and automatic restoration occurs once the issue is fixed.
- The typical maintenance duration is estimated to be 15 to 30 minutes.
- Always verify system status before providing explanations or solutions to players.

## Key points for communicating with players
- Clearly inform players that their funds are safe and automatically restored after maintenance or technical fixes.
- Set expectations for estimated duration, typically 15 to 30 minutes.
- If an issue is identified as a technical error, reassure the player that their balance is secure and the problem is being addressed.
- Encourage players to check back after the estimated time or follow official updates.