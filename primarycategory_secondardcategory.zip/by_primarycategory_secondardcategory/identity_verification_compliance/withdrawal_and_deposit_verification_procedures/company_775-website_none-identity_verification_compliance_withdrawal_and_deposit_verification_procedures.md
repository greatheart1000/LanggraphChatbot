# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player’s request or inquiry regarding verification**
   - Identify whether the request pertains to deposit verification, withdrawal verification, or identity document submission (e.g., for password reset, VIP bonus, or account security).

2. **Request required documentation from the player based on the request type**
   - For deposit verification:
     - Ask for a screenshot of the GCash or PayMaya profile, showing sender and recipient information.
     - Request a screenshot of the inbox transaction indicating bank name and invoice number.
     - Confirm that uploaded files do not exceed 20 MB.
   
   - For withdrawal verification:
     - Request a screenshot of the transaction proof showing sender and recipient details.
   
   - For identity verification (e.g., VIP Birthday bonus, password reset):
     - Request two valid IDs that clearly display user details.
     - Ask for a selfie holding a valid ID, ensuring faces and ID details are clearly visible and readable.
     - For certain cases (e.g., claiming VIP bonus or resetting transaction password), ensure the selfie includes the player holding the ID in good lighting, with no obstructions.

3. **Verify the authenticity and clarity of submitted documents**
   - Check that both IDs and selfies are clear, legible, and meet the criteria described in the FAQs.
   - Confirm that the ID details are visible and the selfie clearly shows the player's face holding the ID.

4. **Conduct system and manual checks for completeness and compliance**
   - For deposit and withdrawal:
     - Cross-reference the provided screenshot with transaction records in the system.
     - Ensure the receipt or proof of payment shows relevant details (sender, recipient, invoice number).
     - For deposit verification, the process typically takes 30 to 45 minutes after submission.
   
   - For identity verification:
     - Compare the ID details with the account information.
     - Confirm that the selfie matches the account holder’s appearance.
   
   - For VIP Bonus verification:
     - Ensure all required documents (username, 2 IDs, selfie, profile screenshot) are provided and meet clarity standards.
     - Verify the provided information matches player records.

5. **Determine if verification is successful**
   - If all documents and information are valid and meet all criteria:
     - Proceed to approve the verification.
   - If any documents are unclear, incomplete, or do not meet requirements:
     - Notify the player and request re-submission with clearer images or additional documentation.

6. **Complete the verification process**
   - For deposit and withdrawal:
     - Once verified, authorize transaction processing or confirmation.
    
   - For VIP Birthday Bonus:
     - Verify the date; note that players are not eligible to claim the birthday bonus precisely on their birthday. Advise players to contact support on that day if needed.
     - After successful verification, credit the bonus to the player’s account.
   
   - For password reset or account security requests:
     - Confirm identity and process the request according to system protocols.
   
7. **Communicate the results to the player**
   - Clearly inform the player whether verification was successful or if additional actions are required.
   - Provide instructions for next steps if applicable (e.g., wait for bonus credit, re-submit documents).

8. **Escalate if necessary**
   - If verification fails or there are suspicious or fraudulent documents, escalate to the compliance or security team as per company policy.
   - Document all communications and received documents for record keeping.

## Notes

- Always ensure player documents are handled securely and confidentially.
- Remind players that modification of IDs or submission of false documents is strictly prohibited and may lead to account suspension or termination.
- For VIP Birthday Bonus claims, remind players that the bonus is applicable on their exact birthdate; for claims made on that day, advise contacting support if needed.
- System verification typically takes 30-45 minutes; inform players accordingly if delays occur.

## Key points for communicating with players

- Verify that all submitted images are clear and legible.
- Remind players to provide one selfie holding their ID with good lighting.
- Confirm the date of the birthday bonus claim; players are not eligible on their exact birthday without support assistance.
- Clearly explain next steps after verification, including timeframes and potential delays.