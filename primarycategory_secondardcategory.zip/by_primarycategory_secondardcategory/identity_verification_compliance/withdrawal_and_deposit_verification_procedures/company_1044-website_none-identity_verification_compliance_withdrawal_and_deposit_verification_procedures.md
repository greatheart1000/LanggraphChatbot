# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the player's request and verify the reason for the inquiry.**
   - Determine if the player is requesting verification to process a withdrawal.
   - Confirm the specific type of verification needed and whether it relates to withdrawal, deposit, or both.

2. **Request the necessary information from the player.**
   - Collect the following personal details:
     - Full name
     - Email address
     - Verified phone number
     - Registered e-wallet number (e.g., GCash, Maya)
     - Current account balance
     - Last game played
     - Username and nickname
   - Inform the player of the required documentation:
     - A screenshot of the last deposit receipt (e.g., wallet deposit slip)
     - A selfie holding a valid ID
     - A clear photo or copy of the valid ID

3. **Verify the completeness of the submitted information and documents.**
   - Check that all required fields are filled with correct and consistent information.
   - Confirm that the deposit receipt photo is clear, includes necessary details, and is from the payment method used.
   - Ensure the selfie clearly shows the player holding a valid ID.

4. **Perform system and security checks.**
   - Verify that the e-wallet number provided matches the registered e-wallet account.
   - Confirm the last deposit details with the transaction receipt.
   - Cross-check the personal details provided with account records.

5. **Review the uploaded documents for authenticity and accuracy.**
   - Approve or flag documents based on clarity, consistency, and validity.
   - If the ID or receipt appears suspicious, escalate to security or compliance for further review.

6. **Complete the verification process.**
   - If all information and documents are verified successfully, approve the verification.
   - If discrepancies or incomplete data are found:
     - Inform the player of missing or incorrect details.
     - Request additional documentation or clarification.
     - Do not proceed with withdrawal until verification is satisfactory.

7. **Process the withdrawal request (if verification is approved).**
   - Proceed with the withdrawal in the system once verification is complete.
   - Ensure all system checks are passed before finalizing the withdrawal.

8. **Notify the player of the verification outcome.**
   - If approved, confirm that the withdrawal is being processed.
   - If denied, explain the reasons clearly and provide guidance for re-verification if applicable.

9. **Escalate cases that do not meet verification standards or involve potential security concerns.**
   - Follow company escalation procedures for flagged or suspicious cases.
   - Record all actions and communications for audit and compliance purposes.

## Notes

- Always ensure that all uploaded documents are clear and legible.
- Verification may require additional documentation in some cases, such as a copy of a valid ID if requested.
- Confirm that the e-wallet account details match the registration records.
- Do not process withdrawals if any required information or documents are missing or invalid.  
- Maintain confidentiality and handle all personal data in compliance with privacy policies.

## Key points for communicating with players

- Clearly inform players of the required documents and information during verification.
- Explain that verification is part of account security and compliance procedures.
- Be patient and polite if additional information or clarification is needed.
- Emphasize that all documents are handled securely and in accordance with privacy policies.