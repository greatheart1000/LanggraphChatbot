# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the type of verification required based on the player's request**:
   - For deposits: Determine if the player is requesting deposit verification.
   - For withdrawals: Determine if the player is requesting withdrawal verification or account verification for withdrawal.

2. **Collect necessary information from the player**:
   - For deposit verification:
     - Provide your username.
     - Submit a clear screenshot or proof of the deposit transaction, including the receipt or inbox receipt for GCASH or bank deposit slip.
   - For withdrawal verification:
     - Provide your username and withdrawal name.
     - Confirm and provide contact details: email, verified phone number.
     - State current balance and last game played.
     - Provide proof of funds: screenshot of the last deposit or relevant transaction.
     - Facilitate identity verification with a selfie holding a valid ID and a clear photo of the ID.

3. **Verify deposit submissions**:
   - For GCASH deposits:
     - Check if the player has provided their username and the GCASH Inbox Receipt.
     - Confirm with the support system that the receipt has been verified.
     - If the receipt is not provided, advise the player to contact GCASH Help Center for assistance; the deposit cannot be verified or credited without it.
   - For bank deposits:
     - Confirm submission includes a screenshot of the bank deposit slip from the inbox (not transaction history).
   - For other deposits:
     - Ensure the player provides a clear proof (receipt or screenshot).

4. **Verify withdrawal requests**:
   - Confirm that the player has provided all required information:
     - Username, withdrawal name, email, and verified phone number.
     - Current balance and last game played.
     - Supporting documents: such as a screenshot of the last deposit as proof of funds, and a GCash profile screenshot if applicable.
     - Valid ID and a selfie holding the valid ID.
   - Check that contact details and ID proof are clear and legible.

5. **Perform system verification checks**:
   - Cross-reference submitted screenshots with internal records or system verification processes.
   - Confirm the last deposit, current balance, and game activity match the player's account.
   - Verify phone number status and identity documents for authenticity.

6. **Determine verification completeness**:
   - If all required information and documents are provided and verified:
     - Approve the verification.
     - Update the player’s account status to verified for withdrawals and/or deposits.
     - Notify the player of successful verification.
   - If any required documents or information are missing or unclear:
     - Notify the player of incomplete verification.
     - Request the missing or clearer documentation.
     - Do not proceed with withdrawal or deposit credit until verification is complete.

7. **Handle special cases or issues**:
   - If the player cannot provide proof (e.g., GCASH Inbox Receipt, deposit slip), inform them that deposit verification cannot be completed without it.
   - Escalate cases with discrepancies or suspected fraud to appropriate compliance or security teams.

8. **Close the verification case**:
   - Once verified, update the account and notify the player.
   - Record all verification steps and correspondence for audit purposes.

## Notes

- Always verify the completeness of the documentation before approving any withdrawal or deposit.
- Confirm that contact information and IDs are clear and match account details.
- When players cannot provide required proof, advise them on proper procedures or escalate as needed.
- Maintain clear communication about which documents are needed and why delays may occur.

## Key points for communicating with players

- Clearly explain the verification requirements based on the request.
- Emphasize the importance of providing clear, legible screenshots and valid ID.
- Inform players that failure to provide necessary documents may delay withdrawals or deposits.
- Encourage players to contact support if they encounter issues with proof submission.