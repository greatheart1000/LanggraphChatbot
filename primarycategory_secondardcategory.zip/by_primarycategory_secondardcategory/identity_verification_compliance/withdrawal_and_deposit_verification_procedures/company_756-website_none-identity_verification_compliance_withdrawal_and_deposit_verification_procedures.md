# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the reason for the verification request**
   - Determine if the player is requesting a withdrawal, deposit claim, or specific bonus such as the Birthday Bonus.
   - Confirm if the verification is related to identity, deposit, or withdrawal validation.

2. **Gather initial player information**
   - For verification of identity or bonus claims:
     - Collect the player's username, full name, and birth date.
     - Confirm the current VIP level if relevant (e.g., VIP Birthday Bonus eligibility at Iron VIP level).

3. **Request the necessary documents based on the verification type**
   - For identity verification (e.g., claiming Birthday Bonus):
     - Request two valid IDs showing the player's birthdate, ensuring both IDs are readable, laminated, and not laminated IDs are not accepted.
     - Request a selfie of the player holding one of the valid IDs, ensuring the ID is clearly visible.
     - Check if the IDs and selfie are clear and readable.
   - For deposit verification:
     - Ask the player to provide a detailed receipt or screenshot clearly showing sender and recipient information (e.g., GCash/Maya Transfer receipt or PayMaya transfer receipt).
     - For GCash, instruct the player to locate the receipt in GCash Inbox and screenshot it.
   - For withdrawal verification:
     - Ask for the Withdrawal Record from the player's account, accessible via Home > Member > Withdrawal Record, and request a clear screenshot.

4. **Perform system and document checks**
   - Verify that all submitted IDs meet the requirements:
     - IDs must be laminated, readable, and show the correct birth date.
     - The name on IDs should match the account name; if there is a mismatch:
       - Notify that additional verification is required.
       - Request alternative proof such as registered mobile number, email, recent deposit receipt, or GCash/Maya profile.
   - For deposit verification, confirm that the receipt details match the sender and recipient information on your system.
   - For withdrawal verification, ensure the screenshot shows the withdrawal details properly.

5. **Assess the sufficiency of the submitted documents**
   - If all submitted documents are clear, readable, and meet the requirements:
     - Proceed with the verification.
   - If documents are unclear, invalid, or missing:
     - Inform the player of the issue.
     - Request re-submission with clearer or additional documents.

6. **Complete the verification process**
   - For verified identity or bonus claims:
     - Mark the verification as complete in the system.
     - For Birthday Bonus:
       - Confirm that the player is eligible (birth date on file, ID provided, and account details match).
       - Issue the bonus through the Rewards Center.
     - For deposit/withdrawal:
       - Confirm the matching deposit/withdrawal record and credit/debit the account accordingly.

7. **Handle discrepancies or mismatches**
   - If name mismatch persists after initial requests:
     - Request additional proof such as recent deposit receipts, registered mobile/email, or GCash/Maya profile confirmation.
   - Escalate cases where verification cannot be confirmed with provided documents according to company policy.

8. **Notify the player of the outcome**
   - Confirm successful verification and next steps.
   - If verification fails:
     - Clearly explain the reason.
     - Advise on possible actions or re-submission procedures.

9. **Close the case**
   - Document the verification results and any relevant correspondence.
   - Update the player's account status as verified or requiring additional verification.
   - Communicate relevant follow-up information (e.g., bonus credited, deposit confirmed).

## Notes

- All document submissions should be clear and readable; especially IDs must be laminated as required.
- Always confirm if the verification is for the VIP Birthday Bonus, as this requires specific eligibility checks.
- When dealing with name mismatches, request alternative proof to verify identity.
- For deposit and withdrawal validation, ensure receipts are detailed, showing sender and recipient information and are clearly visible.
- Handle cases with insufficient documentation with courtesy and provide clear instructions for re-submission.

## Key points for communicating with players

- Clearly explain the verification requirements, emphasizing the importance of clear, readable documents and selfies.
- Inform players that mismatched names require additional proof, and specify acceptable alternatives.
- Guide players on how to obtain and submit receipts for deposits and withdrawals.
- Be polite, transparent, and supportive throughout the verification process.