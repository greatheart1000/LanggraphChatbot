# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request for deposit or withdrawal verification.**  
   - Determine whether the request pertains to deposit verification, withdrawal verification, or e-wallet account unlinking, password reset, or transaction password reset.

2. **Identify the required documentation based on the request.**  
   - For deposit verification, ask the player to provide a detailed receipt showing the sender and recipient information of their GCash or MAYA transaction, generated via their account's inbox or equivalent feature.  
   - For withdrawal verification, instruct the player to provide their withdrawal record.  
   - For e-wallet unlinking, password reset, or transaction password reset, request the necessary identification documents and selfies as specified below.

3. **Guide the player to gather the correct documentation:**
   - **Deposit Verification:**  
     - A detailed receipt including GCash or MAYA sender and recipient information, generated through the player's account inbox.  
   - **Withdrawal Verification:**  
     - A screenshot of the withdrawal record from the 'Member' > 'Withdrawal Record' section on the homepage.  
   - **ID Verification & E-wallet Unlinking:**  
     - A clear picture of a valid ID, taken with the back camera.  
     - A selfie with the valid ID held clearly in the hand, ensuring the ID details are legible and the face is visible.  
   - **Password or Transaction Password Reset:**  
     - Provide the full name, username, registered contact details (number and email), last deposit receipt, and a valid ID with selfie as described above.

4. **Verify the clarity and appropriateness of the submitted documentation:**
   - Confirm ID photos are high-quality, well-lit, and details are readable.  
   - Check that selfies include the ID and the player’s face, with no cover-up or movement.  
   - Ensure receipts or records clearly display all the necessary information.  
   - **Note:** The submitted documents must meet the photo requirements for clarity, proper focus, good lighting, and correct positioning.

5. **Perform system checks and validation:**
   - Confirm the presence and correctness of the submitted transaction or withdrawal record in the system.  
   - For deposit and withdrawal documents, ensure they contain all necessary details to proceed with approval.  
   - For e-wallet unlinking or ID verification, check the matching of ID details with account information.

6. **Assess the documentation for completeness and validity:**
   - If all required documents are accurate, clear, and complete, proceed to verify the transaction or identity in the system.  
   - If documentation is insufficient, unclear, or missing, notify the player and request re-submission with specific instructions on what needs improvement or clarification.

7. **Complete the verification process:**
   - Once verified, update the player's account status or records accordingly.  
   - For deposit or withdrawal verifications, confirm the transaction record matches the submitted documentation, then approve and process the deposit/withdrawal.  
   - For e-wallet unlinking, update the account to reflect removal of the e-wallet, and inform the player of success.

8. **Notify the player of the outcome:**
   - If verification is successful, inform the player that the process has been completed and the transaction or account change has been approved.  
   - If verification fails, advise the player of the specific issues and guide them on re-submission or further steps.

9. **Escalate cases that cannot be verified or require further investigation:**
   - For unclear or suspicious documents, escalate the case to senior support or compliance team following internal procedures.

## Notes

- Always ensure ID photos are taken with the back camera in a bright environment, with ID close to the camera, and while keeping the face visible and still during the photo.  
- Do not accept partial or blurry screenshots; all sensitive details must be clearly readable.  
- When requesting documents or selfies, clearly explain the photo requirements to the player to prevent multiple re-submissions.  
- Verify the details meticulously to prevent fraudulent activities or account mishandling.

## Key points for communicating with players

- Clearly inform players of the exact documents and images required for each verification process.  
- Emphasize the importance of quality and clarity for ID photos and selfies.  
- Reassure players that verification is a standard procedure to ensure account security and compliance.  
- Guide players patiently through re-submission if initial documentation does not meet standards.