# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive and review the player's verification request or inquiry related to deposit or withdrawal.**

2. **Determine the type of verification required:**
   - Deposit verification
   - Withdrawal verification

3. **Collect relevant information from the player:**
   - For deposit verification:
     - Request the player to provide the receipt from their payment method (GCASH INBOX receipt or MAYA receipt).
     - Ask the player to confirm their username.
   - For withdrawal verification:
     - Request a valid government ID.
     - Ask the player to submit a selfie holding the ID.
     - Obtain recent deposit proof (last deposit slip or payment receipt).
     - Confirm the contact details used for withdrawal.

4. **Verify the submitted documents:**
   - Check that the deposit receipt matches the transaction details:
     - Confirm the reference number, date, and time match records.
   - For bank transfers:
     - Ensure the bank slip is included and details match.
     - Note: Verification with the bank may not be possible if the bank slip is absent.
   - For withdrawal verification:
     - Confirm the ID is valid and that the selfie clearly shows the ID.
   
5. **Cross-check the provided information with internal records:**
   - Confirm the details on the receipt and ID match the user account details.
   - Ensure deposit records align with submitted receipts.
   
6. **Assess if verification criteria are met:**
   - For deposits:
     - Receipt and details must match the records.
   - For withdrawals:
     - Valid ID and recent deposit proof are provided.
     - Contact details correspond to the account.

7. **Proceed with verification:**
   - If all information and documents are satisfactory:
     - Approve the deposit or withdrawal.
     - Process the transaction according to standard procedures.
   - If information is incomplete or incorrect:
     - Inform the player which documents or details are missing or mismatched.
     - Advise the player to resubmit accurate and complete documents.
   
8. **Complete the verification and notify the player:**
   - Confirm when the verification is successful.
   - Communicate any further steps or approvals needed.
   - For cases requiring additional review, escalate as per internal SOP.

## Notes
- Ensure that all documents are clear and legible.
- To verify deposits, match the reference number, date, and time from the receipt with internal records.
- Bank slip verification may not be possible if not provided.
- For withdrawal verification, a selfie with the ID must be clear and ID details visible.
- Always handle player information securely and in compliance with privacy policies.

## Key points for communicating with players
- Clearly specify which documents are required.
- Explain the importance of matching details (reference number, date, time).
- Inform players that verification may take some time depending on the documents received.
- Encourage players to submit high-quality, legible documents to avoid delays.