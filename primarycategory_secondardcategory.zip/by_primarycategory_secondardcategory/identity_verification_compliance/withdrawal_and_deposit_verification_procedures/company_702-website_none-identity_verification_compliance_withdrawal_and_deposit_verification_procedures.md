# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request or inquiry regarding verification, withdrawal, deposit, or account unbinding.**

2. **Identify the specific verification or account action required:**
   - Deposit verification
   - Withdrawal account unbinding
   - Transaction password reset
   - Login or transaction password reset
   - Withdrawal or deposit verification

3. **Gather necessary information from the player based on the action:**

   - For unbinding a withdrawal account:
     - Full Name
     - Username
     - The number of the withdrawal account to delete
     - Reason for deletion
     - Clear picture of a valid ID
     - Selfie holding the ID, with the ID held close to the face

   - For deposit verification:
     - Detailed receipt showing:
       - GCash/PayMaya sender and recipient information
       - Transaction number
     - For GCash, ask the player to access their inbox to generate the invoice

   - For resetting transaction or withdrawal/transaction passwords:
     - Full Name
     - Username
     - Valid ID picture
     - Selfie holding the ID, with the ID held close to the face

   - For verification of login or other account details (if applicable):
     - Full Name
     - Username
     - Registered number
     - Registered email
     - Last deposit receipt
     - Linked wallet account information
     - Valid ID picture
     - Selfie with ID, ID held close to face
     - Video showing today's date, ID held in hand

4. **Verify the quality and clarity of submitted documents:**
   - Ensure all ID images and selfies are clear and readable
   - ID should be held close to the face in selfies and videos
   - For the video, confirm the date is visible and current

5. **Perform backend checks:**
   - Confirm that transaction records are within the 7-day window for verification
   - Check provided deposit receipts against transaction records
   - Verify that all required documents are submitted and clearly visible

6. **Assess completeness and correctness of information:**
   - If all required documents and details are provided and clear:
     - Proceed with the verification process
     - For password resets or account unbinding, support staff will verify identity and then complete the requested action
   - If any documentation is missing, illegible, or incomplete:
     - Notify the player about the deficiencies
     - Request clear, readable documents or additional proof as needed

7. **Complete verification:**
   - If verification conditions are met, update the system accordingly:
     - Unbind withdrawal account if requested and verification succeeds
     - Reset passwords as authorized
     - Approve deposit verification
   - Document all actions performed for audit purposes

8. **Communicate the outcome to the player:**
   - Confirm successful verification and completion of requested process
   - If verification fails, explain briefly why and outline any further steps they may take

9. **Close the case once the process is complete and confirmation is sent.**

## Notes

- Transaction records can only be verified within 7 days of the transaction.
- All ID and selfie images must be clear, with the ID held close to the face when required.
- For deposit verification via GCash, guide players to generate their invoice via the GCash Inbox.
- When resetting passwords or unbinding accounts, support agents must verify identity with full documentation as specified.

## Key points for communicating with players

- Emphasize the importance of clear, readable images and footage.
- Explain that verification can only be processed if all required documents are submitted within the specified timeframes.
- Reassure players that the verification process aims to be quick once all criteria are met.