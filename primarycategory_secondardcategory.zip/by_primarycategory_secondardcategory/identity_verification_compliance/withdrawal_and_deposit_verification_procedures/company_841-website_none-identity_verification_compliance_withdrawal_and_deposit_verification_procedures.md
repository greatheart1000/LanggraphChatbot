# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the purpose of the verification request**
   - Determine if the player is requesting deposit verification, withdrawal support, account recovery, password reset, VIP bonus claim, or other compliance-related processes.
   - Refer to the specific scenario to select the appropriate verification pathway.

2. **Collect necessary player information and documentation**
   - For deposit verification:
     - Request the detailed proof of payment, such as a screenshot of the GCash or PayMaya payment confirmation showing both sender and recipient information, or the in-app GCash inbox receipt.
     - Ensure the receipt clearly displays the transaction details.
   - For account recovery, withdrawal issues, or identity verification:
     - Gather the player's full name, username, registration number, email address, and main e-wallet account info (GCash or Maya).
     - Request a clear picture of a valid ID.
     - Ask for a selfie holding the ID and, if needed, a short video stating today's date.
   - For VIP birthday or special bonuses:
     - Confirm the player's full name, username, and birth date.
     - Request a valid ID and a selfie holding the ID.

3. **Verify submitted documents for completeness and clarity**
   - Check that all screenshots or photos are clear, readable, and include the necessary information:
     - Valid ID must be legible.
     - Selfies and videos must clearly show the ID and the player’s face.
   - If documents are incomplete, blurry, or fail to meet clarity standards, inform the player and request resubmission.

4. **Perform internal system verification checks**
   - Cross-reference the submitted information with existing registration details.
   - For deposit proofs:
     - Confirm that the proof of payment shows the sender and recipient information and matches recent transactions.
   - For identity and compliance checks:
     - Verify that IDs match registered names, especially if discrepancies between registration and submitted IDs are detected.
     - For account recovery or withdrawal verification:
       - Confirm ownership by matching IDs, IDs selfies, and video statements.
     - If discrepancies are found, request additional proof such as recent deposit receipts or registered mobile numbers.

5. **Assess the player's verification status and determine next steps**
   - If documents are verified successfully:
     - Proceed to approve the transaction (deposit or withdrawal), verify account recovery, or authorize bonuses.
   - If verification fails due to insufficient or invalid documents:
     - Inform the player about the failure to verify.
     - Instruct them to resubmit clearer documents or provide additional proof.
     - Escalate to the compliance or verification team if issues persist.

6. **Complete the verification process and communicate outcome**
   - Confirm verification success with the player.
   - For approved deposits/withdrawals:
     - Process the transaction in the backend system.
     - Notify the player that the verification was successful and the transaction is processed.
   - For unsuccessful verification:
     - Clearly communicate reasons (e.g., unclear documents, discrepancies).
     - Offer guidance on next steps or further assistance.

7. **Document and log all verification actions**
   - Record the submitted documents, verification decision, and any correspondence.
   - Store documentation securely and in compliance with data protection policies.

## Notes
- Verification procedures involve submitting valid identification, selfies, and sometimes videos holding the ID and stating the date for security purposes.
- Accounts with discrepancies between registered names and submitted IDs may require additional verification steps, such as providing registered mobile numbers or recent deposit receipts.
- The platform is licensed by PAGCOR and adheres to strict responsible gaming policies.
- For deposits via GCash or Maya, players must provide a proof of payment that shows the sender and recipient information, including the transaction confirmation message.
- When in doubt or encountering complex cases, escalate to the dedicated compliance team following internal protocols.

## Key points for communicating with players
- Clearly explain which documents are required and how to submit them.
- Emphasize the importance of clear, readable images to facilitate quick verification.
- Reassure players that verification helps ensure the security of their accounts and transactions.
- Set expectations regarding processing times and possible further requests for additional information.