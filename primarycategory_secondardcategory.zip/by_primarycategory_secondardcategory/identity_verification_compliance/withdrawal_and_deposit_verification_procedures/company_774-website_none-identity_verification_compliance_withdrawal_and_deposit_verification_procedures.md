# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the reason for verification request**:
   - Determine if the player is requesting a reset of withdrawal password, transaction password, or conducting deposit verification.

2. **Request the necessary information and documents from the player**:
   - For resetting withdrawal or transaction passwords:
     - Full name
     - Username
     - Registered number
     - Registered email
     - A clear photo of a valid government-issued ID
     - A selfie holding the ID with the player's name clearly visible
     - For withdrawal password reset specifically, also request the last deposit receipt and main GCash/Maya account details
   - For deposit verification:
     - Provide a detailed GCASH receipt that includes sender and recipient details (generated via GCash Inbox → QRPH invoice)
     - If using PayMaya, include the relevant receipt
     - Take a screenshot of the deposit receipt showing sender and recipient information
     - Provide the deposit record from the app if available

3. **Verify the completeness and clarity of submitted documents**:
   - Ensure all requested information is provided
   - Confirm that uploaded images/screenshots are clear, readable, and within the 20MB upload limit

4. **Check the documentation in the back office/system**:
   - For password resets:
     - Review the submitted ID and selfie to verify identity
     - Cross-check the provided details (full name, username, etc.) against the system records
   - For deposit verification:
     - Match the deposit receipt screenshot and deposit record against the transaction records
     - Confirm the GCASH or PayMaya receipt aligns with the transaction details

5. **Evaluate the verification outcome**:
   - If all documentation and information are consistent and complete:
     - Approve the verification and proceed with the requested action (e.g., password reset, deposit approval)
   - If information is incomplete, unclear, or inconsistent:
     - Inform the player of the missing or problematic details
     - Request resubmission or clarification
     - Do not proceed with account changes until verification is successfully completed

6. **Complete the process and communicate the result to the player**:
   - Confirm to the player that the verification has been successful
   - Provide next steps:
     - For password resets: instruct on how to reset passwords or that the reset has been completed
     - For deposit verification: confirm deposit has been verified and credited
   - If verification cannot be completed:
     - Explain the reasons clearly and politely
     - Advise on any further actions or additional documents needed

## Notes

- Always verify the clarity and validity of IDs and selfies.
- Ensure receipt screenshots include all relevant details.
- Maintain confidentiality and security when handling personal documents.
- Escalate issues when documentation is suspicious or insufficient.

## Key points for communicating with players

- Clearly explain what documents and information are required.
- Emphasize the importance of high-quality, clear images and screenshots.
- Confirm understanding and reassure players about the security of their documents.
- Notify players of delays if documentation is incomplete or unclear, and instruct them on next steps.