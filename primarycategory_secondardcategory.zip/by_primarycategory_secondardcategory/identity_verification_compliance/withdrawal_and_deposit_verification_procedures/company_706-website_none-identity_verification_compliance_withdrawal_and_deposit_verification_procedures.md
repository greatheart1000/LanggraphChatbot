# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request or inquiry related to withdrawal or deposit verification.**
   
2. **Determine the type of verification required based on the player's request:**
   - Deposit verification
   - Transaction password reset
   - Identity verification for account safety or compliance
   - VIP Birthday Bonus eligibility

3. **Gather necessary information from the player:**
   - For all verification types, request the player’s **Full Name** and **Username**.
   - For deposit verification, request a **detailed receipt** showing GCash/Maya sender and recipient details, with a negative (-) sign indicating payment processed to the official website.
   - For transaction password reset or identity verification, instruct the player to provide:
     - **A clear picture of a Valid ID** (such as national ID, passport, driver’s license)
     - **A selfie with the valid ID held close to the face, ensuring the ID and face are clear and readable**
   - For VIP Birthday Bonus, request the player’s **username**, **two valid IDs**, and a **selfie holding a valid ID**

4. **Verify the completeness and clarity of the submitted documents:**
   - Confirm that all ID pictures and selfies are clear, readable, and meet the requirement to hold the ID close to the face.
   - Ensure the receipt contains the necessary details and shows a negative sign confirming payment to the site.

5. **Perform system and compliance checks based on the provided documents:**
   - Check if the document images are clear and valid for verification purposes.
   - For name mismatches (if the player’s name does not match the registered platform name), inform the player that **they need to complete the relevant X3 turnover requirement** before proceeding further.
   
6. **Proceed with verification based on the document review:**
   - If all documents are valid and satisfy the requirements, mark the verification as successful in the system.
   - If documents are incomplete, unclear, or do not meet the requirements, inform the player of the issues and request re-submission.

7. **Resolve the case:**
   - For verified cases, approve the withdrawal/deposit or verification request according to internal procedures.
   - For cases requiring additional checks or clarification, escalate as necessary, or inform the player about the need for further review.

8. **Close the case:**
   - Communicate the outcome clearly to the player.
   - Provide guidance if additional steps are necessary (e.g., next deposit, additional documents, or turnover fulfillment).

## Notes

- Ensure all submitted documents, especially selfies and IDs, are in focus and legible.
- Confirm that the receipt for deposit verification clearly shows the sender/recipient information and a negative sign.
- When handling name mismatches, remind the player about the requirement to complete the X3 turnover requirement to proceed.
- Always verify the authenticity and validity of IDs and receipts before approval.

## Key points for communicating with players

- Clearly inform players of the specific document requirements per case.
- Advise players to submit high-quality, clear images—especially selfies with IDs.
- Explain if any issues are found with their submissions and what is needed to resolve them.
- Remind players that unresolved issues may delay verification or withdrawal processing.