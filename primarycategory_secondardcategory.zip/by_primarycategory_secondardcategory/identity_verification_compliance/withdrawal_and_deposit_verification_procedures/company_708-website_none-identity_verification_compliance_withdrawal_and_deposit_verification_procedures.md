# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive and understand the player's request or inquiry**  
   - Determine whether the inquiry relates to deposit verification, identity verification, or claiming a VIP or birthday bonus.

2. **Verify deposit proof if requested for deposit verification**  
   - Ask the player to provide a screenshot of the deposit receipt showing the payment method (Gcash or PayMaya), sender, and recipient details.  
   - Instruct the player to generate the receipt by logging into their GCash/Maya app, opening Inbox, and capturing a screenshot of the QRPH invoice.  
   - Ensure the screenshot clearly displays the relevant details, including sender and recipient information.  

3. **Check the submitted deposit receipt**  
   - Review the provided screenshot to confirm it contains the necessary details (sender, recipient, payment method).  
   - Approve and proceed with the deposit verification process if the receipt is complete and clear.  
   - If the receipt is unclear, incomplete, or missing required details, inform the player to resend a clear screenshot.

4. **Request identity verification documents if related to ID or account verification**  
   - Explain that a laminated, clear ID (unlaminated IDs are no longer accepted) is needed.  
   - Ask the player to submit a clear selfie holding the ID close to their face, ensuring all ID details are readable.  
   - If a video verification is required, instruct them to record a video stating today’s date while holding their ID.  
   - If a video cannot be sent, request a clear photo with the same specifications via the chat attachment feature.

5. **Verify submitted identity documents**  
   - Confirm that all ID images are clear, readable, and properly show the ID details.  
   - Make sure the selfie or video includes the player’s face and ID clearly visible.  
   - Approve the verification if all the above are satisfied; escalate or request additional proof if not.

6. **Process VIP or birthday bonus verification requests**  
   - Confirm the player has provided:  
     - Their username  
     - Two valid IDs showing their birthday (for VIP Birthday bonus)  
     - A selfie holding a valid ID  
   - Verify the clarity and readability of the IDs and selfie.  
   - Once verified, inform the player that the bonus will be credited to the Rewards Center after approval.

7. **Communicate clearly and conclude the verification**  
   - If all required documents and proofs are satisfactory, update the player's status accordingly (verified, approved, etc.).  
   - Notify the player of the successful verification or the next steps.  
   - If verification fails or additional documentation is needed, explain what is missing or unclear and request a new submission.  

8. **Close the case after completing verification procedures**  
   - Make sure all verification steps are documented and the status updated in the system.  
   - Confirm with the player that their inquiry or verification is resolved.

## Notes
- Always ensure submitted screenshots, IDs, and selfies are clear and readable.  
- For deposit receipts, require the screenshot to display the payment method (GCash/PayMaya), sender, and recipient information.  
- When requesting videos, instruct players to ensure face and ID are clearly visible and the date is stated verbally.  
- Escalate cases that involve ambiguous documents, unclear images, or suspicions of fraudulent activity for further review.

## Key points for communicating with players
- Clarify the specific documentation required (e.g., laminated ID, selfie with ID).  
- Emphasize the importance of clear and readable images.  
- Explain that verification is necessary for security and compliance purposes.  
- Clearly inform players about next steps after submission or in case of missing/incomplete documents.