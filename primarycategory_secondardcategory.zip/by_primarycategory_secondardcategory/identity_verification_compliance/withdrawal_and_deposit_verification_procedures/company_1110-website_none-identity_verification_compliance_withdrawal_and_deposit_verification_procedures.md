# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps
1. **Receive and review the player's request or inquiry related to deposit or account verification.**

2. **Verify deposit transaction:**
   - Request the player to send a screenshot of the successful deposit receipt from Gcash or Maya.
   - Ensure the receipt:
     - Is from Gcash INBOX for GCash deposits (receipts sent to GCASH INBOX).
     - Shows the deposit amount, transaction date, and time.
   - Ask the player to include their username in the screenshot for reference.
   - Submit the receipt for system verification.

3. **Check deposit receipt validity:**
   - Confirm the receipt is from Gcash INBOX (not GCASH TRANSACTION) for GCash deposits.
   - Verify the deposit details (amount, date, time) correspond to the player's transaction.

4. **Verify account and e-wallet linkages:**
   - Confirm that the player's account details are valid and registered under their name.
   - If the player claims to have linked a Gcash, Maya, or bank account, request a photo of a valid ID matching the linked account.
   - If necessary, ask the player to show the account with the linked e-wallet or bank.

5. **Check for additional verification requirements (if applicable):**
   - For account resets or identity confirmation, request:
     - Full name
     - Valid ID photo
     - Selfie holding the ID
   - Ensure all submitted images clearly show the required information.

6. **Review system feedback and verification results:**
   - If the receipt and ID verification are confirmed as valid:
     - Mark the deposit as verified.
     - Proceed with the withdrawal or deposit processing as per normal procedures.
   - If verification fails:
     - Clarify the reason (e.g., invalid receipt, mismatched ID).
     - Advise the player on corrective actions or inform them that verification could not be completed.

7. **Handle special cases:**
   - If the player has multiple linked e-wallets, ensure that any withdrawal will be processed through supported methods and linked accounts.
   - Note that accounts cannot be deleted but can have multiple linked e-wallets as per policy.

8. **Close the case:**
   - Confirm to the player that the verification process is complete.
   - Document the actions taken and verification results.
   - Escalate any unresolved issues according to internal protocols.

## Notes
- Only invoices received in the Gcash INBOX are acceptable for verification; receipts from GCASH TRANSACTION are not.
- All ID images and selfies must clearly display the relevant information for verification.
- Withdrawal requests are only processed through supported methods linked under the player's verified accounts.

## Key points for communicating with players
- Clearly inform players about the requirement to send receipts from Gcash INBOX or Maya receipts.
- Emphasize that all submitted images must be clear and show the necessary details.
- Instruct players on providing valid IDs and selfies for account verification.
- Keep explanations simple and guide players on how to supply the correct documentation to expedite verification.