# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Initiate verification request**
   - When a player requests to verify their account or update account details, inform them that the verification process requires submitting valid government-issued ID and a selfie with the ID via the platform's verification system.
   
2. **Guide the player to prepare required documents**
   - Ensure the player has one of the accepted IDs:
     - Philippine passport
     - Driver’s license issued by LTO
     - PRC ID
     - SSS ID or UMID
     - GSIS eCard
     - PhilHealth ID
     - Postal ID
     - Voter’s ID with dry seal
   - The ID must be clear, readable, and, for digital IDs, officially issued. Printed IDs may be required for certain steps.
   - Advise the player to take a clear photo of the ID (front side) without any mirroring or reflections.
   - Instruct the player to take a selfie holding the ID, ensuring the ID details are visible and readable.

3. **Guide the player to upload verification documents**
   - Instruct the player to upload the images via the platform's verification portal or app.
   - Confirm that the images are clear, non-mirrored, and meet platform guidelines.
   
4. **Confirm receipt of documents and initiate review**
   - Acknowledge the submission and inform the player that the verification typically takes between 24 to 72 hours.
   
5. **Check the verification status**
   - Use the back-office system or account management interface to monitor the verification process.
   - If the status remains "processing" after 72 hours:
     - Collect the following details from the player:
       - Registered full name
       - Mobile number
       - Submission date and time of ID documents
       - Screen recording showing the processing status
     - Contact the verification team with these details to follow up.
   
6. **Review the verification outcome**
   - If verification is approved:
     - Update the player’s account status to verified.
     - Notify the player of successful verification.
   - If verification is rejected:
     - Request the player to retake and resubmit clear images, ensuring the ID and selfie meet platform requirements.
   
7. **Handle failed verification attempts or rejected IDs**
   - Advise the player to re-upload images with better clarity, including:
     - Clear, readable ID images
     - A selfie holding the ID with proper lighting
   - Emphasize that multiple attempts may be necessary, and IDs should conform to the accepted list.
   
8. **Address verification issues and rejection reasons**
   - If verification cannot be approved:
     - Clarify that the ID must be valid, properly issued, and clearly readable.
     - Suggest re-uploading higher-quality images if necessary.
     - For persistent issues, escalate to the support team or recommend the player contact support with detailed documentation.
   
9. **Restrict deposits until verification is complete**
   - Ensure the player understands that deposits are not permitted until the KYC verification process is successfully completed.
   
10. **Close the case**
    - Once verification is successful or definitively rejected with instructions, update the case status accordingly.
    - Document all communication and verification details in the player’s account record for audit purposes.

## Notes

- The verification process takes between 24 to 72 hours from document submission.
- Multiple attempts may be necessary if verification is rejected; always ensure submitted images are clear and compliant.
- Only accepted IDs are allowed; unapproved or unclear IDs will delay the process.
- In case of delays beyond 72 hours, verify submission details and escalate to the verification team with the required information.

## Key points for communicating with players

- Clearly inform players that deposits are blocked until verification completes.
- Advise them to prepare only accepted IDs and take clear photos.
- Remind players that the process typically takes 24-72 hours, and further follow-up might be needed if delays occur.
- Encourage players to contact support with verification details if issues persist after the standard processing time.