# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Initial Player Request and Information Collection**
   - When a player requests withdrawal or deposit verification, ask for the following information to initiate identity verification:
     - Username
     - Full Name
     - Phone Number
     - Current Balance
     - Screenshot of linked e-wallet profile
     - Last deposit receipt
     - Clear photo of ID
     - Selfie holding the ID
   - Ensure all requested information is provided before proceeding.

2. **Verify Player's Submitted Documents and Details**
   - Check the provided information for completeness:
     - Confirm the screenshot of the linked e-wallet profile is clear and matches the account details.
     - Verify the deposit receipt or slip is official and legible.
     - Ensure the ID photo is clear and matches the player's details.
     - Confirm the selfie with ID is clear and shows the player holding the ID properly.
   - Cross-verify the submitted documents with the system records where applicable.

3. **Perform OTP Verification if Required**
   - To request an OTP verification code, ensure the player has provided:
     - Username, Full Name, Phone Number, Balance, screenshot of linked e-wallet profile, last deposit receipt, clear ID picture, and a selfie with ID.
   - Send the OTP verification request through the system once all information is verified.
   - Wait for the player to input the OTP code and confirm successful verification.

4. **Deposit Verification Process**
   - For deposit verification:
     - Confirm the player has provided a valid, official deposit slip or receipt.
     - If such documentation is not available, inform the player that deposits cannot be verified without proper proof.
     - Advise the player to obtain the official slip/receipt from their bank or payment provider (e.g., GCASH) and resubmit.

5. **Withdrawal Verification Process**
   - Before processing a withdrawal:
     - Verify the player has completed the account verification steps, including ID and selfie confirmation.
     - Confirm that the phone number linked to the account matches the registered number.
     - Review the screenshot of the transaction (if applicable).
     - Ensure all account details are accurate and up-to-date.
   - If all verification steps are satisfied, approve the withdrawal request.
     - If verification is incomplete or details do not match, inform the player of the specific missing or inconsistent information and request resubmission.

6. **Handling Verification Failures or Insufficient Documentation**
   - If submitted documents are unclear, invalid, or incomplete:
     - Notify the player of what is missing or needs clarification.
     - Request clearer or additional documentation within a specified timeframe.
   - If the player cannot provide valid documentation:
     - Inform them that the verification process cannot be completed, and thus, withdrawal/deposit cannot be processed until the requirements are met.

7. **Finalizing the Verification and Processing**
   - Once verification is successful:
     - Update the player's verification status in the system.
     - Proceed with the withdrawal or deposit transaction.
     - Confirm completion to the player.
   - Document all steps and correspondence for audit purposes.

## Notes
- Verification may require a screenshot of your transaction, valid ID, and confirmation of your registered phone number.
- Ensure that account details are accurate and complete all verification steps before processing withdrawals or deposits.
- If verification cannot be completed, inform the player of the specific requirements and next steps.

## Key points for communicating with players
- Clearly explain that verification involves submitting specific documents: ID, selfie with ID, deposit receipts, and screenshots.
- Emphasize the need for clear, legible images and official receipts.
- Inform players that verification is crucial for regulatory compliance and to prevent unauthorized transactions.
- Advise players that without proper documentation, deposits or withdrawals cannot be processed.