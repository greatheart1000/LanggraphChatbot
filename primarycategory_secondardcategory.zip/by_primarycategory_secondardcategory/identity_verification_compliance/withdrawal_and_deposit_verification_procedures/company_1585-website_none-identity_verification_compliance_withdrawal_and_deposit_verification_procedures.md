# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Verify the player's identity and account details before processing withdrawal requests:**

   - Confirm the player's full name matches the account information.
   - Ensure the phone number provided is verified.
   - Check that the player has submitted a clear photo of their valid ID.
   - Confirm the player has uploaded a selfie holding the ID.
   - Verify that the player has provided the last deposit receipt from GCash or Maya, if applicable.
   - Cross-check all submitted documents for clarity and authenticity.

2. **Gather required information when the player initiates a withdrawal:**

   - Collect the following details:
     - Username
     - Full name
     - Withdrawal name
     - Registered email
     - Phone number
     - Current account balance
     - Last deposit receipt from GCash or Maya (if applicable)
     - Clear ID photo
     - Selfie while holding the ID
   - Confirm that all provided information is complete and correct before proceeding.

3. **Perform system and security checks:**

   - Review the submitted documents for validity and authenticity.
   - Check for any suspicious activity or account security issues that may require re-verification.
   - Verify that the account details (phone, ID, payment info) are up-to-date.
   - Ensure the player has met any current wagering or turnover requirements relevant to their account status.

4. **Determine if all criteria for withdrawal verification are satisfied:**

   - Confirm all required documents and information are uploaded and verified.
   - Ensure the account is not flagged for suspicious activity or security review.
   - Validate that the linked account number (e.g., GCash, Maya) is correctly bound as per current configuration.
   
   - *If all criteria are met:*
     - Proceed with the withdrawal process.
   - *If any information is missing or documents are unclear:*
     - Request the player to resubmit the necessary documents or clarify the information.
     - Communicate the specific missing or problematic items.

5. **Process the withdrawal:**

   - Submit the verified information for approval according to internal procedures.
   - Confirm the completion of account security checks.
   - Notify the player that their withdrawal is being processed, providing an estimated timeframe if applicable.

6. **Handle cases requiring additional verification or issues:**

   - If the account is suspected of suspicious activity or compromised:
     - Re-verify the account as needed.
     - Escalate the case to a security team if required.
   - If verification requirements are not met:
     - Explain clearly to the player the reasons and the steps to rectify the issue.
     - Hold the withdrawal until all verification steps are completed satisfactorily.

## Notes

- Always ensure the Documents are clear, legible, and consistent with the player’s account information.
- Complete verification is required before processing any withdrawal request.
- Keep records of all submitted documents and communication in case of future audits or investigations.

## Key points for communicating with players

- Clearly inform players about the specific documents required: valid ID, selfie with ID, last deposit receipt (if applicable), and the verified phone number.
- Remind players that missing or unclear documents will delay withdrawal processing.
- Explain that security checks are standard practice to protect both the player and the platform.
- Notify players promptly of any additional verification steps or issues that need resolution before withdrawal completion.