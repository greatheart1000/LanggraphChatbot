# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request or inquiry regarding deposit or withdrawal verification.**
   
2. **Determine the type of verification required: deposit verification or transaction/password reset.**

3. **If the player is submitting proof for deposit verification:**
   
   - Ask the player to provide a screenshot or image of the relevant transaction confirmation message from GCash or PayMaya.  
   - Ensure the receipt clearly shows sender and recipient details, such as the payment method (GCash or PayMaya).  
   - Instruct the player to upload the proof image via the chat’s File option.  
   - Confirm that the uploaded file does not exceed 20MB in size.  
   
4. **Review the submitted deposit proof:**
   
   - Verify that the screenshot clearly shows sender and recipient information.  
   - Check that the receipt appears legitimate and readable.  
   - If the proof is sufficient, proceed to process the deposit system review and confirm verification status.  
   - If the proof is incomplete, blurry, or missing required details, request the player to re-upload clearer proof.  

5. **If the player requests to reset their transaction or withdrawal password:**

   - Collect the following information:
     - Full Name
     - Username
     - A valid ID picture clearly showing the player’s name
     - A selfie with the valid ID in hand
   - If the ID name does not match the player’s registered name, request additional verification such as:
     - Registered mobile number or email address
     - Recent deposit receipt
     - GCash profile (if applicable)
   
6. **Review the submitted identity verification documents:**
   
   - Confirm that the ID photo is clear and legible.
   - Ensure the selfie holds the ID clearly and matches the ID details.
   - Cross-check the provided information for consistency.
   - If the documents are insufficient or do not meet the requirements, request further verification or clarification.
   
7. **For accounts with mismatched names:**

   - Inform the player that for safety of funds, a required turnover (or turnover function) may need to be completed before withdrawal can be processed.  
   - Advise the player to complete any applicable turnover requirements if necessary, in accordance with site policies.  
   
8. **Complete the verification process:**

   - Update the player’s account status with the verification outcome in the system.  
   - If verification is successful, inform the player that their deposit or password reset request is approved and guide them accordingly.  
   - If verification is rejected or pending further review, communicate the reason and next steps clearly.  
   
9. **Close the case once verification is complete, or escalate if issues cannot be resolved.**

## Notes

- Use the File option to upload proof images and ensure files do not exceed 20MB.
- Always verify sender and recipient details when handling deposit proofs.
- Follow the current site configuration and the latest official policies when handling mismatched account names or additional verification.
- Keep communication clear and confirm with the player the requirements at each step.

## Key points for communicating with players

- Clearly explain what files or information are needed for deposit proof or ID verification.
- Confirm that uploaded files are legible and meet size restrictions.
- Be transparent about the requirements if additional verification or turnover is needed, especially in cases of name mismatches.
- Keep the player informed of verification progress and next steps.