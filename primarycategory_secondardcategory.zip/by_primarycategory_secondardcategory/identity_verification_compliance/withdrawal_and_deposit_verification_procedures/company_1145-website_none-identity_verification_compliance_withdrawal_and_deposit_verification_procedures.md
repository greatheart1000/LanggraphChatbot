# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Initiate the player verification process**:
   - Collect the player's username to identify their account.
   - Gather additional information as required, such as full name, email, phone number, and withdrawal name.

2. **Request deposit or transaction proof from the player**:
   - For deposit verification via GCash or PayMaya:
     - Ask the player to submit a screenshot of the GCash receipt from the GCash Inbox or a transaction receipt for PayMaya.
   - For other deposit methods:
     - Ensure submitted receipts clearly show transaction details.
   
3. **Verify the submitted receipts**:
   - Check that receipts are from official sources such as GCash INBOX, PayMaya, or similar.
   - Confirm the screenshot clearly displays relevant transaction information.

4. **Perform additional account validation checks if necessary**:
   - Require the player to submit a valid ID and a selfie holding the ID if needed for account validation.
   - For account verification due to login issues, request:
     - Username, nickname, withdrawal name, email, phone number.
     - Screenshot of the last deposit.
     - Valid ID and a selfie with the ID.
   - If account opening issues are present, validate by verifying all required data.

5. **Complete phone number verification**:
   - Send an OTP to the registered mobile number.
   - Instruct the player to wait 15-30 minutes if the OTP is not received.
   - Remind the player that a maximum of 5 OTP requests per day is allowed.

6. **Conduct back-office checks**:
   - Confirm receipt submission and match transaction details.
   - Cross-reference submitted personal data with account records.
   - Validate the player's identity and deposit information against system data and uploaded documents.

7. **Decide on the outcome based on verification**:
   - If all required information and documentation are verified successfully:
     - Approve the deposit or account verification.
     - Advise the player that their account or transaction is now validated.
     - If relevant, instruct on next steps for withdrawal or account access.
   - If verification details are insufficient or inconsistent:
     - Inform the player of the missing or problematic documents.
     - Request re-submission or additional documentation as necessary.
     - Escalate unresolved cases to senior support if issues persist.

8. **Document the process**:
   - Log all submitted receipts, ID copies, and correspondence.
   - Record verification results and any procedural notes.

9. **Close the case**:
   - Communicate the final decision to the player.
   - Confirm that their account or deposit has been verified or that further steps are needed.
   - Release or restrict account access based on verification status.

## Notes

- Ensure all submitted screenshots are clear and show relevant transaction details.
- Verification may involve multiple steps including submitting a valid ID, selfie, and deposit receipts.
- Handling account issues involves comprehensive data checking and may require completing all requested documentation.
- Adhere to the daily limit of 5 OTP requests for phone number verification.

## Key points for communicating with players

- Clearly explain the required documents and screenshots.
- Remind players of the limits on OTP requests.
- Encourage timely resubmission if verification is incomplete or rejected.
- Assure players that their data is handled securely and in accordance with compliance policies.