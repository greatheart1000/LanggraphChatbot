# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the purpose of the request**  
   Determine whether the player is requesting verification for a withdrawal, deposit, unbinding a withdrawal account, resetting transaction password, claiming a birthday bonus, or other compliance-related actions.

2. **Gather player information**  
   Collect necessary details based on the scenario:  
   - Full name  
   - Username  
   - For birthday bonus, also request the player's birth date  
   - Specific details such as which withdrawal account is to be unbound or deleted, or the transaction number if applicable.

3. **Request and verify the required documentation**  
   The documentation depends on the specific verification purpose:  

   - **For unbinding a withdrawal account or resetting transaction password:**  
     - Provide a clear picture of a valid ID (e.g., government-issued ID)  
     - Provide a selfie while holding the valid ID close to the face, ensuring both ID and selfie are clear and readable

   - **For claiming birthday bonus:**  
     - Provide two different valid IDs showing your birthdate  
     - Provide a selfie with valid ID

   - **For deposit verification:**  
     - Provide a screenshot of the GCASH/PayMAYA receipt showing sender and recipient information  
     - Alternatively, provide a screenshot of the GCash/PayMAYA confirmation from Transaction History

4. **Assess the documentation quality**  
   - Confirm that all images are clear, with readable text and visible facial features.  
   - Ensure all IDs and selfies meet the requirements and are legible.

5. **Verify player details against documentation**  
   - Cross-check the provided IDs and selfies for consistency and authenticity.  
   - Confirm the ID details (name, birthdate, etc.) match the account information when applicable.

6. **Proceed based on the verification outcome**  
   - **If documentation is complete and satisfactory:**  
     - Approve the request (unbinding account, resetting password, processing deposit verification, etc.)  
     - For birthday bonus, verify if the player meets VIP level (VIP3 or higher).  
   
   - **If documentation is incomplete or unclear:**  
     - Inform the player of the issue  
     - Request clearer images or additional documentation  
     - Do not proceed until documentation is satisfactory

7. **Complete the requested action**  
   - Unbind or delete the withdrawal account as per the provided details  
   - Reset the transaction password following internal procedures  
   - Approve deposit verification for pending deposits  
   - Process the birthday bonus if all conditions are met and documentation is approved

8. **Record the verification for audit purposes**  
   - Save copies of all received documentation and confirmation notes in the player’s account record

9. **Communicate the resolution to the player**  
   - Confirm successful completion of the process or explain if additional steps are required  
   - Provide relevant instructions or next steps if necessary

## Notes

- All ID and selfie images must be clear and readable for verification.  
- Birthday bonus is only available for VIP3 and above players.  
- When verifying deposits, the screenshot of the receipt must clearly show sender and recipient info, along with transaction details.  
- Escalate cases where documentation cannot be verified or if there are suspicious signs to the compliance or fraud team.  

## Key points for communicating with players

- Clearly inform players of the required documentation and the importance of clarity in images.  
- Remind VIP3 or higher players about VIP-specific benefits, such as the birthday bonus.  
- Communicate politely and explain that verification is necessary to maintain account security and compliance.