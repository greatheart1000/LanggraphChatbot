# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request or inquiry regarding deposit or withdrawal verification.**  
   - Clarify whether the request pertains to deposit verification, withdrawal account unbinding, or identity verification for bonuses or account adjustments.

2. **Determine the purpose of the verification request.**  
   - Is it for deposit verification?  
   - Is it for unbinding a withdrawal account?  
   - Is it related to claiming bonuses (e.g., VIP Birthday Bonus) or resetting transaction passwords?  
   - Is it to resolve a mismatch between ID name and account name (KYC verification)?

3. **Gather the required documentation based on the request type, using the following guidelines:**

   - **For deposit verification:**  
     - Instruct the player to provide a detailed screenshot of the deposit receipt including GCash/PayMaya sender and recipient information.  
     - Guide the player on how to access the receipt through GCash: log in, select 'Inbox', generate QRPH invoice, and take a screenshot.

   - **For identity verification (claiming bonuses or account adjustments):**  
     - Request the player to provide:  
       - Their username,  
       - Two valid IDs that clearly show their birthdate, or a clear photo of their birth certificate if ID with birthdate is unavailable,  
       - A selfie holding the valid ID with details clearly readable and visible.  
     - Ensure the ID's name matches the account, especially for bonus claims like the VIP Birthday Bonus.

   - **For unbinding or deleting withdrawal accounts:**  
     - Ask for:  
       - Full Name,  
       - Username,  
       - The specific number (e.g., bank account or e-wallet number) to delete,  
       - Reason for deletion,  
       - Valid ID (with readable details),  
       - Selfie holding the ID, ensuring clarity of all documents.

   - **For resetting a forgotten transaction password:**  
     - Collect:  
       - Full Name,  
       - Username,  
       - Valid ID image,  
       - Selfie with ID, holding it close to the face, all clearly visible.

   - **For resolving ID name mismatch (KYC verification):**  
     - Request additional info:  
       - Registered mobile number or email,  
       - Recent deposit receipt or proof,  
       - GCash profile if applicable.

4. **Validate all submitted documents for clarity and completeness.**  
   - Confirm that IDs are clear, all information is readable, and the selfie clearly shows the player holding the ID.  
   - Ensure the details match the account information or specified purpose.

5. **Perform verification checks in the back office/system:**  
   - Cross-check ID details with account information, especially for bonus eligibility or name mismatch cases.  
   - For deposit receipts, verify that the receipt includes sender and recipient info and matches the deposit details.

6. **Based on verification results, decide on the outcome:**

   - **If verification is successful:**  
     - Proceed with the requested action, such as confirming deposit, unbinding account, or approving bonus claim.  
     - Inform the player of the successful verification and next steps.  
   - **If verification is incomplete or documents are unreadable:**  
     - Notify the player that more clear or complete documents are necessary.  
     - Provide specific instructions for re-submission.

7. **Escalate cases that require additional investigation or are outside standard procedures:**  
   - Examples include suspected fraudulent documents, mismatch after multiple verifications, or technical issues.  
   - Follow company escalation guidelines as per internal protocol.

8. **Close the case with clear documentation of the verification outcome:**  
   - Record all submitted documents, verification comments, and the resolution provided in the player's account notes.

## Notes

- Always ensure all uploaded documents are clear, with visible details, to avoid delays.  
- When requesting selfies, remind players to hold the ID close to their face in the photo.  
- For bonus-related verifications, the ID must have the player's birthdate, and the selfie must clearly display the ID and player’s face.  
- Escalate any unresolved or suspicious cases according to internal compliance protocols.

## Key points for communicating with players

- Clearly explain what documents are needed and the reason for the request.  
- Guide players on how to access or take the required documentation.  
- Confirm receipt of documentation before proceeding with the verification.  
- Be prompt and transparent about the verification process timeline.