# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the purpose of the verification request**  
   - Determine whether the player is requesting a deposit verification, withdrawal verification, birthday bonus redemption, or login/transaction password reset based on the player's inquiry or action.

2. **Gather required player information**  
   - Confirm and record the following details: full name, username, registered phone number, registered email address, and specific transaction details (deposit receipt, withdrawal receipt, or relevant reference numbers).

   **For verification of deposits:**  
   - Ask the player to provide the detailed deposit receipt showing the sender (GCash/PayMaya) and recipient information.
   - Instruct the player to generate a QRPH invoice via the GCash app (if applicable) and take a screenshot of the deposit receipt displaying both sender and recipient details.
   - Request the player's Deposit Record by navigating to: Member -> Deposit Record, and have the player take a screenshot.

   **For verification of birthday bonus eligibility:**  
   - Ask the player to provide two different valid IDs showing their birthdate.
   - Request a selfie holding their ID.

   **For verification of login or transaction password reset:**  
   - Collect their full name, username, registered number, email, last deposit receipt, main GCASH/Maya account, ID photo, and a selfie holding the ID.

3. **Verify document authenticity and completeness**  
   - Ensure all uploaded images (receipts, IDs, selfies) are clear and legible.
   - Confirm the receipt or screenshot includes the required sender and recipient information, reference number, or QR invoice number.
   - Verify that file size does not exceed 20 MB.

4. **Submit verification request for processing**  
   - Forward the collected documents and details to the back office or security team according to internal procedures.
   - Ensure all requested documents are uploaded and properly attached in the system or ticket.

5. **Await verification completion**  
   - Confirm with the back office that the verification has been completed successfully.
   - If the verification is successful:
     - For deposit verifications, credit the funds accordingly and communicate confirmation to the player.
     - For birthday bonuses, process the bonus after successful identity verification.
     - For password resets, update the requested passwords once verification is confirmed.
   - If additional information or clarification is required, communicate with the player to provide the requested details.

6. **Handle cases with insufficient documentation or failed verification**  
   - Inform the player that the provided documents are incomplete or unclear.
   - Advise to submit clearer images or additional proof as instructed.
   - If verification cannot be completed within a reasonable timeframe, escalate as per internal policies.

7. **Close the case**  
   - Notify the player of the outcome: successful verification, bonus granted, password reset, or reasons for denial.
   - Record the verification outcome and any relevant notes in the case file.

## Notes
- All deposit verifications require a detailed receipt showing sender and recipient information, reference number, and QR invoice number (for GCash deposits).
- Selfies must clearly display the player holding their ID to prevent impersonation.
- Verification processes may involve manual review; be patient and follow escalation protocols if needed.

## Key points for communicating with players
- Clearly explain the documentation required for each process.
- Remind players to ensure images are clear and within size limits.
- Confirm receipt of documents and inform them of the expected processing time.
- Always maintain a polite and professional tone, especially if requests for additional information or clarification are necessary.