# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive player inquiry or request related to withdrawal or deposit verification.**
   
2. **Determine the type of verification required:**
   - Deposit verification
   - Withdrawal verification (including resetting transaction/withdrawal password or unbinding a withdrawal account)
   - Identity verification for loyalty bonuses such as VIP Birthday Bonus or general identity confirmation

3. **Collect necessary information from the player based on verification type:**
   - **For all ID-related verifications:**
     - Full Name
     - Username
     - Valid ID (ensure clarity and readability)
     - A selfie with the valid ID held close to the face
   - **For VIP Birthday Bonus:**
     - Two valid IDs (both with birthdate visible)
   - **For resetting transaction/withdrawal password:**
     - Registered number
   - **For unbinding a withdrawal account:**
     - Registered number
     - Number to delete
     - Reason for deletion
   - **For deposit verification:**
     - Deposit receipt showing sender and recipient details
     - If applicable, GCash inbox receipt with QRPH invoice or detailed payment confirmation screenshot

4. **Guide the player to take clear, compliant photos:**
   - Use the rear camera for better quality
   - Hold the ID close to the camera to focus on details
   - Choose a well-lit, bright environment
   - Ensure their face is fully visible and not covered
   - Remain still while taking the photo
   - Review the photo before submitting to confirm ID details are clear and readable

5. **Verify the submitted documentation:**
   - Check that the ID details are legible and match the player’s account information
   - Confirm that the selfie clearly shows the player holding the ID close to their face
   - For VIP and account-related verifications, ensure all required IDs and selfies are provided
   - For deposit proof, verify that receipts or screenshots clearly show the necessary transaction details

6. **Perform back-office checks:**
   - Confirm deposit receipt details against transaction records if verifying a deposit
   - Ensure all ID and selfie images meet the clarity and readability standards
   - For account unbinding, verify the correctness of the provided registered number and reason

7. **Decide on the appropriate resolution based on verification success:**
   - **If verification is successful:**
     - Proceed with the requested action (e.g., approve withdrawal, reset password, unbind account, verify deposit)
   - **If verification is insufficient or unclear:**
     - Request the player to retake and resubmit photos
     - Advise on improving photo clarity and lighting
     - Escalate if necessary, especially in cases of suspected identity fraud or discrepancies

8. **Complete the process:**
   - Update the player’s verification status in the system
   - Communicate the outcome clearly:
     - Successful verification: confirm acceptance and proceed
     - Unsuccessful verification: explain the issues and next steps
   - For bonus claims like VIP Birthday Bonus, ensure all verification steps are complete before reward distribution

9. **Close the case:**
   - Document all exchanged information and verification results
   - Record the resolution and any follow-up required
   - Notify the player of the completion or request further action

## Notes

- Always ensure that all ID images are clear and readable before submitting.
- Remind players to avoid covering their face or ID, and to use proper lighting.
- If names do not match, inform the player that they need to fulfill the current site-specific requirements, such as completing the X3 turnover requirement, for safety reasons.
- Deposit verification may require screenshot proof of payment or inbox receipts, especially for GCash/PayMaya transactions.
- When verifying deposit receipts, ensure the receipt includes sender and recipient details, and if applicable, transaction number.

## Key points for communicating with players

- Clearly instruct players on how to take compliant photos.
- Emphasize the importance of ID clarity and readability.
- Explain the reason for verification and how the process supports security and compliance.
- Provide guidance on retaking photos if initial submissions are unclear.
- Keep communication professional and reassuring, especially if verification is delayed or requires additional info.