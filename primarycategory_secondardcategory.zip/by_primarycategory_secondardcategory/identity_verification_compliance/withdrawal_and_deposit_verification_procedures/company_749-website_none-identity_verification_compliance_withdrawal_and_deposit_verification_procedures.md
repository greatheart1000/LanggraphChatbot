# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's request or inquiry regarding account unbinding, deposit verification, password reset, or VIP gift redemption**, and verify the nature of their request.

2. **Identify the specific verification type**:
   - Unbinding withdrawal account
   - Unbinding e-wallet account
   - Verifying a deposit
   - Resetting transaction password
   - Resetting withdrawal password
   - Redeeming VIP Birthday Gift

3. **Gather required information from the player based on the verification type**:
   - For unbinding withdrawal or e-wallet accounts:
     - Full name
     - Username
     - Number to delete (for account unbinding)
     - Reason for deletion (for unbinding)
     - Valid ID (clear, readable photo)
     - Selfie with valid ID (clear, readable)
   
   - For deposit verification:
     - Detailed deposit receipt with sender and recipient info (e.g., GCash/PayMaya)
     - Take a screenshot of the deposit record from the system

   - For password reset (transaction or withdrawal):
     - Full name
     - Username
     - Register number
     - Register email
     - Last deposit receipt
     - Main GCash or Maya account details
     - Valid ID (clear, readable photo)
     - Selfie with valid ID (clear, readable, ID held close to face)

   - For VIP Birthday Gift redemption:
     - Username
     - Full name
     - Registered number
     - Two valid IDs
     - Selfie holding a valid ID

4. **Verify the sufficiency and clarity of submitted documents/photos**:
   - Ensure all ID and selfie images are clear, readable, and meet the requirement of holding the ID close to the face (for selfies).

5. **Input the collected data into the verification system or back office** for validation.

6. **Perform system checks**:
   - Confirm the provided details match account records.
   - Check the deposit receipt against transaction records.
   - Verify the IDs and selfies for authenticity and clarity.

7. **Decide on the verification outcome**:
   - **If all documents and information are sufficient and clear**:
     - Proceed with unbinding the withdrawal or e-wallet account, or complete deposit verification, or reset the password, or process VIP gift redemption as applicable.
     - Communicate success and next steps to the player.

   - **If documents are insufficient or unclear**:
     - Inform the player that the documents/photos are not readable or do not meet the requirement.
     - Request re-submission with clearer images.
     - Optionally, specify which part was unclear if identifiable.

8. **Complete the process**:
   - When verification is successful:
     - Update the account records accordingly (unbind account, verify deposit, reset password, etc.).
     - Confirm the action with the player.
   - When verification fails or is incomplete:
     - Escalate if necessary per internal procedures.
     - Guide the player on next steps or additional verification requirements.

9. **Close the case**:
   - Document the verification outcome and actions taken.
   - Inform the player of the final resolution or next steps.
   - Ensure all records are properly stored for compliance and audit purposes.

## Notes

- All ID and selfie photos must be clear and readable, with ID held close to the face in selfies.
- The process for unbinding accounts or verifying deposits requires specific screenshots or photos as described.
- For password resets and VIP gift claims, multiple identification documents may be required.
- Escalate cases where documentation is insufficient or suspicious.
- Always confirm the player's identity details match existing account information before proceeding.

## Key points for communicating with players

- Clearly explain which documents each verification step requires.
- Emphasize the importance of document clarity to avoid delays.
- Inform players that incomplete or unreadable submissions will need to be resubmitted.
- Remain professional and reassuring when requesting re-submission or explaining compliance checks.