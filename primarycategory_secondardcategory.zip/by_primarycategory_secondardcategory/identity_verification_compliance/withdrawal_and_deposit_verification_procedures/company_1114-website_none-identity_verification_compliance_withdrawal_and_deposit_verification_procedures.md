# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Initiate Verification Request**
   - When a player requests withdrawal or deposit verification, inform them that certain account details and documents are required to proceed.

2. **Collect Player Information and Documentation**
   - Request the following from the player:
     - Username/User ID
     - Registered phone number
     - Linked GCash/PayMaya number and a screenshot of the account information
     - Withdrawal name
     - Email address
     - Screenshot of the last deposit receipt (specifically GCASH INBOX receipts)
     - Phone brand
     - Screenshot of SIM management from the phone
     - Photo of a valid ID and a selfie holding the ID
     - Additional details for withdrawal ownership verification:
       - Nickname
       - Balance
       - Last game played
       - Screenshot of the last deposit (GCash)

3. **Verify the Provided Documents and Information**
   - Confirm that the provided screenshots and IDs are clear and match the player's account details.
   - Ensure the last deposit receipt is from GCASH INBOX, showing amount, date, and time.
   - Check that the ID is valid and matches the selfie.

4. **Perform System Checks**
   - Cross-reference the provided information with the system records:
     - Confirm that the username and email match current account data.
     - Verify the linked GCash/PayMaya account details.
     - Match the last deposit receipt with recent transaction records.
     - Confirm ownership through the photo holding the valid ID and related details.
   - For withdrawal ownership verification, verify the following:
     - Nickname
     - Withdrawal name
     - Email
     - Phone number
     - Balance
     - Last game played
     - Screenshot of the last deposit (GCash)

5. **Address Verification Issues**
   - If any verification step is incomplete or documentation details do not match:
     - Inform the player that verification cannot proceed due to insufficient or mismatched information.
     - Request the player to resubmit clear and correct documents.
   
6. **Handle OTP Verification Failures**
   - If the player does not receive the OTP:
     - Instruct them to capture a screenshot showing the OTP issue.
     - Advise to submit this screenshot to customer support.
     - Resend OTP if appropriate, after verifying the system status and player details.

7. **Complete Verification and Authorize Withdrawal/Deposit**
   - Once all information and documents are verified as correct:
     - Approve the withdrawal or deposit process in the system.
     - Confirm success with the player and proceed with the transaction.

8. **Update Account Details or Method (if requested)**
   - For updates or changes to withdrawal methods or account details:
     - Require submission of username, full name, valid ID, and a selfie holding the ID.
     - Conduct necessary verification checks before updating the system.
     - Confirm changes with the player once approved.

9. **Close the Case**
   - Inform the player that their verification has been successfully completed.
   - Provide any additional instructions if necessary.
   - Document all verified information and actions taken for record-keeping.

## Notes
- Only GCASH INBOX receipts are accepted for deposit verification.
- Screenshots must be clear, showing relevant transaction details.
- Additional verification may be required based on the current site configuration.
- Always ensure the verification process aligns with the latest official policies.

## Key points for communicating with players
- Clearly explain which documents are needed and why.
- Emphasize the importance of clear, legible screenshots.
- Advise players to ensure the information matches their account details exactly.
- Guide players to contact support if they encounter issues with OTP or document submissions.