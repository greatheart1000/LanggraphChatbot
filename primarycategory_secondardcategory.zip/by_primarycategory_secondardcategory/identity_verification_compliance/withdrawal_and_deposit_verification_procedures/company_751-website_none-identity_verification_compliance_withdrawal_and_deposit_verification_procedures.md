# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive player request for withdrawal or deposit verification.**

2. **Identify the specific verification required based on the request:**
   - For withdrawal verification, confirm if the player has submitted the necessary documents.
   - For deposit verification, request proof of deposit (e.g., receipt).

3. **Request the required documents from the player:**
   - **For ID verification or resetting transaction password:**
     - A clear selfie holding a valid ID, ensuring all details are readable.
     - A clear picture of the valid ID, using the back camera, held close to the camera, in a well-lit environment, without moving or covering the face.
     - If applicable, confirm the player is in a bright place, not covering the face, and that the photo is clear before submission.
   - **For unbinding or changing withdrawal account:**
     - Full Name
     - Username
     - Specific number to delete (if unbinding)
     - Reason for deletion
     - Valid ID picture and selfie with ID
   - **For deposit verification:**
     - A detailed receipt from GCash/PayMaya, including sender and recipient info, showing a negative (-) sign indicating a payment was made.

4. **Verify the submitted documents:**
   - Check that all ID and selfies are clear, readable, and that the ID is held close to the face.
   - Ensure the photo environment is suitable (bright, well-focused, face visible).
   - Confirm the receipt or proof of deposit clearly shows the necessary details (e.g., sender, recipient, negative sign for GCash).

5. **Perform system checks:**
   - For withdrawal verification, confirm the player's identity and that the documents meet requirements.
   - For deposit verification, validate the receipt against the deposit record.
   - For password resets or account changes, verify the submitted information matches the account records.

6. **Assess additional requirements or conditions:**
   - If there is a discrepancy between the real name and registered name, inform the player that a 3x turnover requirement must be fulfilled before processing the withdrawal or resetting the transaction password.
   - For account unbinding or changes, ensure all required details and documents are provided.

7. **Proceed with the appropriate resolution:**
   - If documents are sufficient and verification is successful, approve the withdrawal or deposit credit, or complete the password/account change.
   - If documentation is unclear, incomplete, or does not meet requirements, inform the player and request a new submission.
   - If discrepancies or issues are found that cannot be resolved immediately, escalate according to the internal compliance procedures.

8. **Record the verification process:**
   - Save relevant screenshots, receipts, and correspondence in the player's file.
   - Log the verification outcome and any discrepancies or special conditions.

9. **Close the case once verification is complete.**

## Notes
- All ID photos must be taken with the back camera, held close to the face, and in a well-lit place, without covering the face or moving during capture.
- A companion may be requested to assist in taking ID photos to ensure clarity.
- The receipt for deposit verification must include sender and recipient info, and show a negative (-) sign indicating payment, not receipt.
- For discrepancies with account name, the player must fulfill the turnover requirement of 3x before withdrawal or password reset.

## Key points for communicating with players
- Clearly explain verification document requirements and environment expectations.
- Confirm the clarity and readability of submitted photos before processing further.
- Inform players that discrepancies or incomplete documents will result in delays.
- Always verify the receipt details accurately for deposit confirmations.
- Remind players that additional turnover or verification steps may be necessary if discrepancies are found.