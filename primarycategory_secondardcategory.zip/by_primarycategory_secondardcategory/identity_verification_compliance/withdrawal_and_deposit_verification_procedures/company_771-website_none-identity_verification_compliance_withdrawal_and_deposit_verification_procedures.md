# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player's inquiry or trigger for verification**
   - Identify whether the request pertains to deposit verification, withdrawal verification, account unbinding, password reset, or claiming a bonus (e.g., VIP Birthday Bonus).

2. **Determine the purpose of the verification request**
   - Confirm if the player is claiming a bonus, verifying a deposit, resetting a password, or unbinding an account.

3. **Request the necessary documentation based on the scenario**

   **a. For VIP Birthday Bonus & Bonus Claims:**
   - Collect from the player:
     - Full name
     - Username
     - Birthdate
     - Two valid physical IDs (each showing their name and birthdate)
     - A selfie holding both IDs clearly visible
   - Emphasize the need for IDs to be clear, readable, and with good lighting; IDs must not be taken online.

   **b. For General Deposit Verification (e.g., GCash/PayMaya):**
   - Request:
     - A detailed deposit receipt showing sender and recipient info
     - Clear images or screenshots of the deposit confirmation or transaction history
     - Reference number if available

   **c. For Password Reset or Withdrawal Account Unbinding:**
   - Obtain:
     - Full name
     - Username
     - Valid ID (photo)
     - Selfie holding the ID (for security validation)
   - If applicable, request a short video for additional security.

4. **Collect and review submitted documents**
   - Ensure all images/receipts are clear, readable, and match the account details.
   - Verify that IDs show the player's full name and birthdate (for bonuses) or the account name.
   - For selfies, confirm the face and ID details are visible and distinct.
   - For deposit proof, ensure the receipt includes sender and recipient info, and check if the transaction history or confirmation message matches the deposit.

5. **Perform system and back-office checks**
   - Confirm receipt of all required documentation.
   - Match the provided ID details with account information.
   - For deposit verification, cross-check the deposit receipt with transaction records or GCash/PayMaya history.
   - For password reset or account unbinding, verify the identity documents and self-holding photo.

6. **Assess verification status**
   - If all documents and information meet criteria:
     - Proceed to approve the request.
   - If documents are unreadable, incomplete, or do not match:
     - Notify the player to retake photographs ensuring clarity and correctness.
     - Escalate to a supervisor if necessary.

7. **Complete the verification process**
   - **For Bonus Claims:** 
     - After successful verification, add the bonus to the player's account.
   - **For Deposit Verification:**
     - Confirm deposit receipt and update transaction status.
   - **For Password Reset/Account Unbinding:**
     - Generate a new password and send instructions to the player securely.
     - Process account unbinding if confirmed, and update account settings.
   - **For deposit issues or missing transactions:**
     - Request additional proof if needed or escalate for further investigation.

8. **Communicate the outcome to the player**
   - Clearly inform whether verification was successful or if further action is necessary.
   - If rejected, specify that the provided documentation was insufficient or unreadable.
   - Provide instructions for retaking submissions or next steps.

9. **Close the case**
   - Log all submitted documents and verification results.
   - Update the system with verification status.
   - Follow up if required, especially for pending or escalated cases.

## Notes
- Always ensure documents and selfies are of high quality, with good lighting and clarity.
- IDs must match account names and details; online or digital IDs are not accepted.
- For deposit validation, screenshots should show sender and recipient details explicitly.
- Timing for bonus distribution is typically within 12 hours after verification.
- When handling sensitive documents, follow data protection and confidentiality protocols.

## Key points for communicating with players
- Clearly specify what documents are needed and how to submit them.
- Remind players to ensure their IDs and selfies are clear and visible.
- Inform players of the approximate timeline (e.g., within 12 hours) for bonus distribution or verification results.
- Encourage retaking photos if images are unclear and escalate if issues persist.