# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player inquiry or request for withdrawal/deposit verification.**  
   - Collect the player's identification details and clarify which verification process they need assistance with (e.g., account verification, bonus eligibility, mobile number verification).

2. **Verify the player's registration details.**  
   - Confirm the player's registered mobile number by requesting and checking the verification code sent via SMS.  
   - For account registration verification, ensure the player has verified their mobile number and bank details if required.  
   - Note: ID verification is generally automatic and may not be required for registration verification.

3. **Instruct the player on submitting necessary identity documentation.**  
   - Ask the player to upload clear images of a valid ID card showing their name, date of birth, and ID number.  
   - If applicable, request front and back images of the ID or smart card.  
   - For account verification, ensure the ID matches the registered details.

4. **Request additional verification if needed.**  
   - If required, instruct the player to take and submit a selfie holding their ID and, if applicable, a Smart Card photo.  
   - For bonus eligibility or further identity confirmation, advise the player to confirm their mobile number, link an e-wallet, and follow official social media pages, then submit a verification screenshot through live chat.

5. **Guide the player on sharing verification evidence via official channels.**  
   - Direct the player to use the official WhatsApp link to send their verification details or screenshots from their registered phone number.  
   - If instructed, assist the player with joining official WhatsApp or Telegram groups and sending the required information.

6. **Check the submitted documents and information.**  
   - Examine the IDs for validity, clarity, and correctness of details.  
   - Verify that the account details (name, date of birth, ID number) match across all submitted documents and platform records.

7. **Assess verification status and determine next steps.**  
   - If verification is successful:  
     - Confirm that all required steps, including mobile number confirmation, e-wallet linking, and social media following, are completed if relevant for bonuses.  
     - Advise the player that their bonus can now be credited or their account verified for withdrawals/deposits.  
   - If verification is incomplete or issues are found:  
     - Inform the player of the specific issue (e.g., poor image quality, mismatch details, unverified mobile number).  
     - Request the player to resubmit clear, correct documents or follow additional steps as needed.

8. **Ensure compliance with platform policies for withdrawals and bonuses.**  
   - Confirm the player has met all wagering/multiple requirements for withdrawals associated with bonuses.  
   - Check for any restrictions such as multiple accounts or IP address restrictions that could impact withdrawal eligibility.

9. **Finalize the verification process.**  
   - Update the player's verification status in the system accordingly.  
   - Communicate the outcome clearly—either approval or reasons for denial—and instruct on subsequent actions (e.g., attempt again, contact support).

10. **Escalate issues if necessary.**  
   - If verification issues cannot be resolved promptly, escalate to the appropriate compliance or fraud team following internal procedures.

## Notes
- Always confirm the player's identity and details in accordance with the site’s verification guidelines.
- Use official communication channels, such as WhatsApp, for secure document submission.
- Document all interactions and submitted documents for audit purposes.

## Key points for communicating with players
- Clearly explain what documents and steps are required.
- Emphasize the importance of submitting high-quality, correct images.
- Remind players that verification may restrict withdrawal options until approved.
- Encourage players to follow official channels and avoid sharing sensitive information outside approved platforms.