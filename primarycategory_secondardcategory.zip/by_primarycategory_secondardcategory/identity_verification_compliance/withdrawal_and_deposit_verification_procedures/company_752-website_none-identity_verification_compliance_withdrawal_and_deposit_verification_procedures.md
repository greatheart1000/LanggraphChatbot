# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive the player inquiry or request for verification**
   - Determine whether the request pertains to withdrawal, deposit, account unbinding, VIP bonus, password reset, or other verification needs.

2. **Identify the specific verification type**
   - Confirm if the case involves:
     - Deposit verification
     - Withdrawal account unbinding or binding
     - Transaction password reset
     - VIP birthday bonus claim
     - General ID verification
   - Refer to the FAQ related to the specific verification type to understand required documents and procedures.

3. **Gather player-provided information and documents**
   - Request the following details based on the verification type:
     - Full Name
     - Username
     - Specific account or account number to be unbound (if applicable)
     - Reason for unbinding or verification
   - Instruct the player to prepare the necessary documentation:
     - Valid ID (ensure it is clear and readable)
     - Selfie holding the valid ID, with face and ID details clearly visible
     - Deposit receipts, detailed transaction receipts, or confirmation messages for deposit verification
   - Remind players that all ID and selfie images must be clear, without alterations (e.g., no edits to ID data or date).

4. **Guide the player in taking selfies with IDs (if applicable)**
   - Advise on selfie tips:
     - Use the back camera for better quality
     - Take in a well-lit, bright place
     - Do not cover your face or ID
     - Keep the camera steady without movement
     - Ensure ID details are legible before submitting

5. **Verify the submitted documents**
   - Check the quality and clarity of ID and selfie images:
     - Confirm ID details are readable
     - Ensure selfie shows you holding your ID with a clear face and ID details
   - For deposit verification:
     - Confirm that the receipt or screenshot includes:
       - GCash/PayMaya sender and recipient info
       - Date, time, and transaction reference number
       - Confirmation message from the transaction history
      - For unbinding or password reset:
       - Verify ID and selfie are clear and that the ID is held close enough for details to be read

6. **Perform backend and system checks**
   - Cross-verify the transaction details:
     - Match deposit receipts with transaction history
     - Confirm deposit amount, date, and party details
   - For deposit verification, ensure the receipt is official and contains the required info
   - For account unbinding, validate the provided details against account records

7. **Assess the sufficiency of submitted documents**
   - If all required documents are complete, clear, and match records:
     - Proceed to approval
   - If any document is unclear, missing, or does not meet requirements:
     - Inform the player of the deficiencies
     - Request re-upload or additional verification if necessary

8. **Complete the verification process**
   - For deposit verification:
     - Approve once transaction is verified
     - Confirm deposit has been credited
   - For ID-based resets (password, unbinding, VIP bonus claims):
     - Confirm ID and selfie meet requirements
     - Proceed with account updates (unbinding, password reset, bonus claim)
   - For violations (e.g., editing ID details or date):
     - Suspend or terminate the account as per policy

9. **Communicate outcome to the player**
   - Clearly inform the player of the verification result:
     - Approved or rejected
     - Additional steps if needed
     - Expected timeline for processing

10. **Close the case and ensure documentation**
    - Save all submitted documents, screenshots, and verification notes securely
    - Update the case log with verification details and outcome

11. **Escalate if necessary**
    - If sensitive discrepancies or potential fraud is suspected, escalate to the relevant department according to internal protocols

## Notes
- Always ensure the clarity and authenticity of submitted documents; blurry or edited images will delay verification.
- Do not modify any document details or attempt to alter ID or timestamps.
- For deposit verification, only official receipts and confirmation messages are acceptable.
- Follow the current site policies for account suspension or termination if violations are identified during verification.

## Key points for communicating with players
- Emphasize the need for clear, unedited images showing both face and ID details.
- Clearly explain the requirements for deposit receipts, including GCash/PayMaya transaction confirmation visibility.
- Remind players that incomplete or unclear submissions will delay the process.
- Be professional, cooperative, and transparent about the verification timeline and outcomes.