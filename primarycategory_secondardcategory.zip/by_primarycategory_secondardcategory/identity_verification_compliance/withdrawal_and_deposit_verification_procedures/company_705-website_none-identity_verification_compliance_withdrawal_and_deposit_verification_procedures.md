# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the purpose of the verification request.**  
   Determine whether the inquiry pertains to deposit verification, withdrawal unbinding, withdrawal password reset, account name change, VIP birthday bonus claim, or account information correction.

2. **Gather required player information based on the request.**  
   For all verification cases, collect:  
   - Full Name  
   - Username  
   - Register Number and Register Email (if applicable)  
   - For deposit verification: GCash/PayMaya sender and recipient details and deposit receipt  
   - For unbinding or name change: number to unbind or change, reason for change/unbinding

3. **Request valid ID and selfie from the player.**  
   - All IDs must be valid, clear, and readable; note that unlaminated IDs are not accepted.  
   - The selfie must be held close to the face, clearly displaying the ID.  
   - For VIP birthday bonus: provide at least 2 valid IDs indicating the player’s birthday.  

4. **Verify ID and selfie clarity.**  
   - Ensure both ID and selfie images are clear and readable.  
   - If images are unclear or incomplete, instruct the player to resend clearer images before proceeding.

5. **Perform system and account checks.**  
   - Confirm whether the ID details match the registered account information.  
   - For name discrepancies:  
     - Request additional verification details if the names differ (e.g., recent deposit receipt, registered mobile/email, GCash profile).  
     - Verify that the real name matches the registered name before proceeding further.  
   - For discrepancies or mismatched names, inform the player of the requirement to complete the necessary verification or turnover requirements for safety.

6. **Additional specific verification steps based on request type:**  
   - **Deposit Verification:**  
     - Confirm receipt includes sender and recipient info and that GCash submission shows a negative sign if via GCash.  
   - **Unbinding a withdrawal account:**  
     - Confirm the reason for unbinding.  
     - Verify the ID and selfie images.  
   - **Password reset (withdrawal or transaction):**  
     - Confirm identity with ID and selfie.  
     - Proceed to allow password reset only if verification is successful.  
   - **Name change:**  
     - Confirm the provided details match the ID and additional verification.  
   - **VIP birthday bonus claim:**  
     - Verify the submission of at least 2 IDs indicating the birthday and selfie.  

7. **Make a decision based on verification results:**  
   - If all information is verified successfully:  
     - Proceed with the requested action (e.g., update details, process unbinding, reset password, verify deposit).  
   - If verification is incomplete or images are unclear:  
     - Inform the player that verification cannot be completed at this time.  
     - Request clearer images and repeat the verification process.  

8. **Complete the process / update system records.**  
   - Document all verification details and any discrepancies in the case notes.  
   - Update the account or system as required by the request.  
   - Communicate confirmation or next steps to the player.

9. **Escalate cases that cannot be resolved with standard verification.**  
   - Cases with unresolved discrepancies, suspicious activity, or missing documents should be escalated following internal fraud or compliance protocols.

10. **Close the case.**  
    - Ensure the player has understood the outcome and any further actions required.  
    - Save all verification proof and case notes in the system.

## Notes

- Always ensure IDs and selfies are clear and recent.  
- Do not process any changes or actions without proper verification to comply with regulations.  
- For safety, complete all required verification steps before proceeding with sensitive account changes or financial transactions.

## Key points for communicating with players

- Clearly inform players about the specific documents needed for each verification scenario.  
- Remind players to submit unlaminated IDs and ensure their selfies are clear and show the ID close to their face.  
- Explain that verification is required to protect their account and funds, and that procedures are in place to prevent fraud.  
- Keep communication professional, patient, and supportive throughout the process.