# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Receive verification request or deposit/withdrawal inquiry from the player.**  
   Gather initial information: player's username, the nature of the request (verification, deposit receipt, password reset, etc.).

2. **Determine the type of verification needed based on the request.**  
   Use the following criteria:
   - For identity verification or account changes (ID unbinding, password reset): request a clear photo of a valid ID and a selfie holding the ID.
   - For deposit verification (GCash/Maya): request a deposit receipt showing sender and recipient info, and a screenshot of the deposit record.
   - For birthday bonus verification: confirm username, provide 2 different valid IDs, and a selfie holding one ID.
   - For password reset: request username, a valid ID, a selfie with ID, and a video stating current date while holding ID.

3. **Request the player to submit the required documents and information.**  
   Make sure the following are provided:
   - Clear photos/images of valid ID (full name, date of birth, and other readable details).
   - A selfie holding the same ID.
   - For deposit receipts: screenshot of the deposit record and the deposit receipt from official payment channels (GCash/Maya) with sender and recipient info.
   - For verification involving a date statement: a short video stating today's date while holding the ID.

4. **Review submitted documents for compliance with requirements.**  
   Confirm that:
   - IDs are clear, valid, and readable.
   - Selfies clearly show the ID and the user.
   - Deposit receipts are from official accounts (GCash/Maya), linked to the company, with reference number and QR invoice visible, ensuring transaction details match.
   - For birthday bonuses, verify the IDs are different and both are valid, readable, and belong to the player.
   - For date verification videos, the date is clearly stated and visible.

5. **Perform system and account checks based on the verification type.**  
   - For identity and account change verifications, update the player's profile as required once documents are validated.
   - For deposit receipts, verify the transaction details using the provided deposit receipt and screenshot against the system records.
   - For birthday bonus, mark the player's account as eligible after successful verification.
   
6. **If all verification documents are valid and meet requirements:**  
   - Proceed with the requested action (e.g., account unbinding, password reset, deposit/withdrawal approval, bonus credit).
   - Clarify to the player that the verification has been successful and explain the next steps if applicable.

7. **If submission is incomplete or documents do not meet requirements:**  
   - Inform the player of the deficiencies, specifying what is missing or unclear.
   - Request a new submission with clear, readable images, correct receipt, or proper video as needed.
   
8. **If verification cannot be completed due to insufficient or invalid documents:**  
   - Clearly communicate the reasons.
   - Escalate to higher support or compliance team if necessary, following company protocols.

9. **Close the case, documenting all actions and communication in the system.**  
   - Record the submitted documents, verification results, and any notes or instructions provided to the player.

## Notes
- Ensure all submitted IDs and selfies are high-quality and readable.
- Deposit receipts must be from official sources (GCash or Maya), showing sender and recipient info, with reference number and QR invoice.
- When handling birthday bonus verifications, the ID details must be clear and IDs must be valid.
- For password resets or sensitive account changes, verifying identity with ID and selfie is mandatory.
- Use the player's username, full name, registered email, or number to assist in matching documents.

## Key points for communicating with players
- Clearly explain what documents are needed and why.
- Advise players to submit high-quality, clear images and videos.
- Reassure players that their documents are handled securely and confidentially.
- Specify the importance of official payment channels for deposit receipts.