# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Identify the Support Case and Gather Player Information**
   - Confirm the player's username.
   - Determine the context: whether the request involves deposit verification, withdrawal verification, or VIP bonus claim.
   
2. **Request Required Documentation and Information Based on the Scenario**
   - For VIP Birthday Bonus or VIP-related verifications:
     - Ask the player to provide 2 valid IDs (must be physical IDs, not online/scanned).
     - Request a selfie holding a valid ID with the birthdate clearly visible (if applicable).
     - Ensure the ID is clear, readable, and the selfie shows the player’s face and the ID clearly.
   - For deposit verification:
     - Request the deposit receipt.
     - For GCash deposits:
       - Ask the player to log in to their GCash account.
       - Instruct them to generate the QRPH invoice/receipt from Inbox.
       - Request a screenshot of the deposit receipt.
     - For PayMaya deposits:
       - Ask for sender and recipient details.
       - Obtain relevant proof of deposit (e.g., receipt or confirmation).
   - For password resets or identity confirmation:
     - Request a selfie holding ID and a video stating the current date while holding the ID.

3. **Verify the Submitted Documents and Information**
   - Check that IDs are physical, clear, and display the necessary details (e.g., birthdate for VIP bonus).
   - Confirm that the selfie and/or video clearly shows the player's face and ID.
   - For deposit receipts:
     - Verify all details, including sender and recipient information, match the transaction.
     - Ensure the receipt images are clear and complete.

4. **Perform System Checks and Validate Documentation**
   - Confirm that the ID documents match the player’s registered details.
   - For VIP bonuses:
     - Verify that the provided IDs are different and show the required information.
     - Ensure that the ID with the birthdate is provided if the bonus request requires it.
   - For deposit verification:
     - Cross-check the deposit receipt details with the transaction history if available.
     - Confirm receipt authenticity and completeness.

5. **Assess Whether the Documentation and Information Are Sufficient**
   - **If the documentation is complete, clear, and meets all requirements:**
     - Proceed with verification.
     - For VIP bonus: approve the request and distribute the bonus.
     - For deposits: process and confirm the deposit, updating the player's balance accordingly.
   - **If the documentation is incomplete, unclear, or invalid:**
     - Inform the player of the specific deficiencies (e.g., blurry images, missing information).
     - Request resubmission with clearer or complete documents.
     - Do not process the case until satisfactory documents are received.

6. **Complete the Verification and Communicate the Resolution**
   - Once verified:
     - Update the player’s account status or transaction status as appropriate.
     - Inform the player of the successful verification or bonus distribution.
   - If verification fails:
     - Clearly explain the reason (e.g., invalid documents, mismatched details).
     - Advise the player on the next steps or necessary corrections.

7. **Close the Case**
   - Document all actions taken and correspondence.
   - Confirm with the player that their issue has been resolved satisfactorily.
   - Archive the verification documentation for compliance purposes.

## Notes

- Always verify that IDs used for VIP bonuses and identity confirmations are physical IDs and clearly show required details.
- For deposit verification, ensure the receipt is clear and contains sender/recipient details for efficient processing.
- In case of discrepancies or difficulties, escalate the case to a supervisor following the internal escalation protocols.
- Do not process any bonuses or deposits without proper documentation as specified.

## Key points for communicating with players

- Clearly instruct players to submit high-quality, readable images.
- Explain the importance of providing physical IDs, not digital scans or online-only documents.
- Be transparent if documents are insufficient and specify what is needed for approval.
- Maintain professional, respectful communication throughout the verification process.