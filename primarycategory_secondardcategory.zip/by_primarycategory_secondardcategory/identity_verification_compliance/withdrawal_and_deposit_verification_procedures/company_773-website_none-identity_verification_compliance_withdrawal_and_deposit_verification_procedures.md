# Identity Verification & Compliance - Withdrawal and Deposit Verification Procedures

## Steps

1. **Initiate the verification process**
   - When a player submits a withdrawal or deposit verification request, verify the purpose of the request and confirm the identity or transaction details as needed.
   
2. **Collect relevant information from the player**
   - For identity verification, request a clear photo of a valid ID and a selfie holding the ID.
   - If the name on the ID does not match the game account name, inform the player that additional verification may be required and ask for:
     - Registered mobile number or email address,
     - A screenshot or receipt of the most recent deposit,
     - GCash profile if applicable.
   - For deposit verification, request a detailed receipt showing the sender and recipient information of GCash or PayMaya. If available, ask for a screenshot of transaction history or deposit record.
   - For unbinding an e-wallet, request:
     - The e-wallet number to delete,
     - Reason for unbinding,
     - Identity verification details (ID photo and selfie as above).

3. **Perform system and manual checks**
   - Review the submitted ID and selfie images for clarity and readability.
   - Match the ID details and submitted images with account information.
   - If there is a name mismatch on ID and account, check for the additional verification materials provided.
   - Confirm the deposit receipt details against transaction records, if available.
   - For unbinding requests, verify identity as per the submitted ID and selfie, and ensure only one e-wallet unbinding request is processed per day.

4. **Assess the sufficiency of provided information**
   - If all required information is clear, readable, and matches account details or transaction records:
     - Proceed to approve the verification or unbinding request.
     - Update the system to reflect the verified deposit, identity, or unbinding status.
   - If information is insufficient or unclear:
     - Inform the player that additional or clearer documentation is necessary.
     - Specify the required documents (e.g., clearer ID photo, receipt screenshot).
     - Request the player to resubmit the verification details.

5. **Resolve and communicate the outcome**
   - Once verification is completed successfully:
     - Notify the player of approval and any relevant updates to their account.
   - If verification cannot be completed due to missing or invalid information:
     - Explain the situation clearly,
     - Advise the player on the next steps (e.g., resubmission, additional documentation).

6. **Escalate if necessary**
   - For cases where verification issues cannot be resolved at the support level (e.g., suspected identity fraud, suspicious deposit activity):
     - Escalate to compliance or relevant department following internal procedures.

7. **Close the case**
   - Document all actions taken and communications with the player.
   - Confirm that verification or unbinding has been successfully processed or appropriately declined.

## Notes
- Ensure all ID photos are clear and readable.
- Multiple verification steps may be needed if discrepancies arise.
- Only one e-wallet unbinding request can be processed per day.
- Verification of deposit details requires a detailed receipt or screenshot showing sender and recipient information.

## Key points for communicating with players
- Clearly explain the need for specific documentation if verification fails.
- Emphasize the importance of clear, readable images.
- Be polite and informative, guiding players on how to successfully complete their verification requests.