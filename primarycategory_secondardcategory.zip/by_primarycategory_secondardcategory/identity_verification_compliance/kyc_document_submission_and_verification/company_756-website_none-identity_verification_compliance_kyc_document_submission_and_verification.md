# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the purpose of the verification request**  
   Determine if the request is for claiming a birthday bonus, VIP birthday bonus, resetting passwords, or verifying deposits, based on the player's inquiry or account activity.

2. **Inform the player of the required documents and information**  
   Clearly explain that they need to submit two valid IDs showing their birth date and a selfie holding a valid ID for birthday-related bonuses or verifications.  
   - For VIP birthday bonus: Provide username, 2 valid IDs, and a selfie holding an ID.  
   - For resetting transaction or login password: Provide full name, username, registered number, valid ID, and a selfie with the ID.  
   - For deposit verification: Provide detailed deposit receipt with sender and recipient info, or a screenshot of the transaction.

3. **Advise on ID requirements and restrictions**  
   - IDs must be physical and clearly readable; online or digital IDs are not accepted.  
   - The name on the ID must match the name registered on the player's account.  
   - IDs should be held close to the face in the selfie, ensuring clarity and readability.  
   - File size should not exceed 20 MB.

4. **Guide the player on how to prepare the images for upload**  
   - Ensure all IDs are clear, legible, and show full details, including birth date if relevant.  
   - Take a selfie while holding the ID clearly visible near the face.

5. **Assist with document submission**  
   - Instruct the player to upload the ID photos and selfie via the designated upload process, using the system's file upload feature.  
   - Confirm that all required images are uploaded and meet the clarity standards.

6. **Verify the documents and information received**  
   - Check that IDs and selfies are properly uploaded, clear, and show the required details.  
   - Confirm the name, birth date, and other information match the account details.  
   - For deposit verification, verify the deposit receipt matches the latest transaction, showing sender and recipient details.

7. **Conduct back-office verification and checks**  
   - Review the uploaded documents against account information.  
   - If a mismatch occurs, request the player to upload correct or updated IDs.  
   - If additional verification is needed (e.g., registered mobile number, email, deposit receipt), request these details accordingly.

8. **Determine the outcome** based on verification results  
   - If verification is successful:  
     - For bonuses: Apply the bonus (e.g., birthday or VIP birthday bonus).  
     - For password reset: Issue a new password or enable password reset link.  
     - For deposit verification: Confirm deposit and credit the account accordingly.  
   - If verification fails:  
     - Explain that the documents are insufficient or unclear.  
     - Ask the player to re-upload clearer images or provide valid documents.  
     - If issues persist, escalate according to company policy.

9. **Notify the player of the result**  
   - Confirm successful verification and the next steps (bonus credited, password reset completed, deposit verified).  
   - In case of failure, advise on corrective actions or escalation pathways.

10. **Close the case after successful verification**  
    - Record all relevant documents and verification details in the system.  
    - Inform the player they can now access their bonus, reset credentials, or enjoy verified deposit processing as applicable.

## Notes

- Always ensure the images are clear, well-lit, and show the entire ID and face for selfies.  
- Verification processes aim to prevent fraud and ensure compliance, so thoroughness and accuracy are critical.  
- Escalate cases where documentation is repeatedly insufficient or if suspicion of fraud arises.

## Key points for communicating with players

- Clearly explain the importance of providing valid, readable IDs and selfies.  
- Remind players that IDs must be physical and the same name as in their account.  
- Encourage players to check their documents before uploading to avoid delays.  
- Reassure that verification is a routine security measure and will expedite their account and bonus processing.