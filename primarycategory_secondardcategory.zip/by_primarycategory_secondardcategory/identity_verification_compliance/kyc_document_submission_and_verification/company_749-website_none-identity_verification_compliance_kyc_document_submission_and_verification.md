# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Initiate the verification request with the player**
   - Inform the player that they need to submit specific documents for account verification, password resets, or compliance purposes.
   - Clarify which documents are required based on the scenario (e.g., account verification, password reset, VIP birthday bonus, deposit verification).

2. **Collect player information and document requirements**
   - Verify the specific scenario to determine the necessary documents:
     - For general account verification: 
       - Full Name
       - Username
       - Picture of Valid ID
       - Selfie with a valid ID
     - For password reset requests:
       - All above, plus Registered Number, Registered Email, Last Deposit Receipt, and Main GCash/Maya Account
     - For VIP Birthday Bonus:
       - Username
       - Complete Name
       - Registered Number
       - Two Valid IDs
       - Selfie holding IDs
     - For deposit verification:
       - Detailed receipt with GCash/PayMaya sender and recipient info, transaction number, date/time, and clear screenshot
  
3. **Guide the player on document preparation and upload**
   - Instruct the player to ensure:
     - ID details are clear, readable, and all information visible
     - ID is held close to the face in selfies and selfies are clear
     - Files are in JPG, PNG, or PDF format
     - File size does not exceed 10MB (or 20MB if specifically permitted)
   - For uploading photos:
     - Ask the player to click the "File" button to browse their device
     - Select the appropriate image or document
     - Confirm that the upload is successful and the file opens correctly

4. **Verify the submitted documents**
   - Check that:
     - All required documents are provided
     - IDs and selfies are clear, with details visible and ID held close to face
     - Documents match the information provided (name, ID number)
     - For deposit verification, ensure the receipt includes all specified details (reference number, amount, date/time, GCash/PayMaya info)
  
5. **Assess if the documents are sufficient**
   - If all documents are clear and meet the stated requirements:
     - Proceed to verify them through the back office system
   - If documents are blurry, unclear, or incomplete:
     - Inform the player of the issue
     - Request re-submission with clear, legible images
     - Do not proceed until satisfactory documents are received

6. **Perform system verification checks**
   - Confirm the authenticity and validity of submitted documents via back-office tools or manual checks
   - Cross-reference submitted details with player account info
   - For deposit, verify receipt details against actual transactions
  
7. **Complete the verification process**
   - Once documents are verified and deemed acceptable:
     - Update the player’s account status to verified
     - Inform the player of successful verification
     - If relevant, proceed with enabling features such as password resets or bonus claims
  
8. **Handle cases with insufficient documentation or issues**
   - If documents are not acceptable:
     - Clearly explain the reasons (e.g., blurry image, mismatched info)
     - Instruct the player to re-submit correct documents
     - If repeated attempts fail, escalate according to company policies
  
9. **Document the verification outcome**
   - Log all actions, timestamps, and verification results in the system
   - Save copies/screenshots of submitted documents for records

## Notes
- Always emphasize the importance of clarity and readability in submitted images.
- IDs must be valid and not expired.
- For selfies, IDs should be held close to the face and in good lighting.
- The process may include a video stating today's date while holding the ID if further identity confirmation is required.
- Verification must adhere strictly to the information provided in the FAQs without adding new conditions or specifications.

## Key points for communicating with players
- Clearly inform players about the required documents and quality standards.
- Be polite and explanatory if documents are insufficient or unclear.
- Reiterate the importance of accurate, complete, and current IDs to expedite verification.
- Advise players that unresolved issues may delay or prevent account access or transaction activities.