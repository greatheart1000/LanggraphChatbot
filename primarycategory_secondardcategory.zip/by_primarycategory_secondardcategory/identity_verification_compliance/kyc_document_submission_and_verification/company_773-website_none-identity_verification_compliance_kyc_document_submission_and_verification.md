# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the player's purpose for the interaction.**
   - Determine if the player is submitting documents for identity verification, password reset, deposit verification, or claiming a bonus (including birthday bonus or gift).

2. **Gather required information based on the case.**
   - For account or password resets: Full Name, Username, Registered Number, Registered Email.
   - For deposit verification: proof of deposit receipt such as a screenshot of the GCASH/PayMaya transaction history or inbox receipt.
   - For bonus or birthday bonus verification: Full Name, Birth Date, and two valid IDs.

3. **Request necessary documentation from the player.**
   - Valid government-issued ID (e.g., passport, driver’s license, national ID). Ensure the ID images are clear and readable.
   - Selfie holding the valid ID, with the ID and player’s face clearly visible and readable.
   - For deposit verification: ask for a screenshot of the transaction receipt or in-app deposit record.
   - For password resets: request a selfie with ID and an additional video if necessary (as per verification standards).

4. **Instruct the player on how to obtain deposit proof (if applicable).**
   - GCASH/PayMaya deposits:
     - For GCASH: Log into the GCash app, open Inbox, generate the QRPH invoice, and screenshot the deposit receipt.
     - For PayMaya: Locate the transaction receipt from the transaction history or folder.
   - Confirm the receipt clearly shows sender and recipient details.

5. **Verify the clarity and authenticity of the submitted documents.**
   - Confirm the ID and selfie are clear, readable, and match each other.
   - Check that the ID contains the player's full name and birth date, and that the selfie holds the ID properly.

6. **Perform system and manual checks.**
   - Review the submitted deposit receipt or transaction screenshot for correctness and completeness.
   - Cross-reference deposit details with the system's deposit records if available.
   - For identity verification or password reset: verify ID details match the account data.
   - For bonus claims (e.g., birthday bonus or gift): confirm the date of birth matches the registration data.

7. **Decide on verification success or failure.**
   - If documents are clear, complete, and match system data:
     - Proceed to verify and update the account status or process the request accordingly.
     - Issue the new password or bonus as applicable.
   - If documentation is insufficient or unclear:
     - Inform the player politely and explain the reasons.
     - Request re-submission with clearer images or additional proof.
     - Escalate if necessary, following standard security protocols.

8. **Complete the support case.**
   - Document the verification outcome.
   - Update the player’s account with verification status.
   - Dispatch the requested password reset, bonus, or deposit confirmation.
   - Provide instructions or follow-up steps if additional actions are needed from the player.

## Notes

- Always ensure that images of IDs and selfies are clear to prevent delays.
- The verification process is designed to prevent unauthorized access and fraudulent transactions.
- When dealing with deposit receipts, confirm that the screenshot clearly shows both sender and recipient details along with the transaction amount.
- The verification of a player’s age for birthday bonuses and gifts requires a clear ID with visible birth date, and a selfie holding the ID.

## Key points for communicating with players

- Clearly explain that verification requires the submission of valid ID and selfie for security reasons.
- Emphasize the importance of clarity in images to avoid delays.
- Remind players that verification is subject to review, and additional proof may be requested if necessary.
- Inform players that documents are handled securely in accordance with privacy policies and are only used for verification purposes.