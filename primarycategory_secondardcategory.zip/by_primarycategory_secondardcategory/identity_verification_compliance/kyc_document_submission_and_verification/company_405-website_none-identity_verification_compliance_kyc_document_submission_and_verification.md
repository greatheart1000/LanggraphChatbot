# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or notification for account verification**.
   
2. **Inform the player about the required documents for KYC verification**:
   - Two clearly readable valid IDs (government-issued).
   - A selfie holding the valid ID.
   - Receipt or proof of the last deposit.
   - A selfie showing the Lodibet account username.
   - A selfie showing the email address bound to the account.
   - A selfie showing the linked e-wallet or bank account.

3. **Guide the player to prepare and submit the required documents**:
   - Advise the player to ensure all images are clear, legible, and match the account details.
   - Recommend using the official verification form or support chat (LiveChat) for document submission.

4. **Instruct the player to upload the documents via the official support channel or verification form**:
   - Confirm they have uploaded:
     - Valid IDs (both sides if applicable).
     - Selfie with ID.
     - Deposit receipt.
     - Selfie with Lodibet username.
     - Selfie with email address.
     - Selfie with linked e-wallet or bank account.

5. **Perform back-office checks upon receiving the documents**:
   - Verify that all uploaded images are clear, legible, and match account information.
   - Confirm that the IDs are government-issued and valid.
   - Check that the deposit receipt, if provided, shows an appropriate transaction.
   - Ensure selfies clearly display the required details (ID, username, email, account info).

6. **Assess if all documents meet requirements**:
   - **If yes**:
     - Approve the verification.
     - Notify the player that their account has been verified successfully.
     - Proceed with any requested actions (e.g., reset password, update info).
   
   - **If no**:
     - Contact the player for clarification or to resubmit clearer documents.
     - Explain precisely what is insufficient or unreadable.

7. **For verification requests related to updating sensitive info (e.g., changing phone number or resetting transaction password)**:
   - Repeat document collection and verification steps as above.
   - Ensure all documents are clear and match current account info.
   - Approve or request resubmission as needed.

8. **If additional documents are needed or issues are identified during verification**:
   - Escalate to the relevant department or supervisor following internal procedures.
   - Inform the player of the issue and any necessary further actions.
   
9. **Once verification is complete**:
   - Confirm to the player that their account is now verified.
   - Provide any relevant instructions or next steps as required.

## Notes

- All documents and selfies must be clear, legible, and match the account information.
- Verification involves checking the validity of IDs, deposit receipts, and correspondence in selfies.
- Use the official verification process (form/support chat) to securely submit and review documents.
- If instructions or document quality are insufficient, request resubmission immediately.
- Escalate unresolved or complex issues to the appropriate team for further review.

## Key points for communicating with players

- Clearly explain what documents are required and how to prepare them.
- Emphasize the importance of clarity and matching details.
- Guide players to use the official channels for submission.
- Be patient and professional, guiding resubmission if needed.
- Reinforce that the verification process is in place to ensure security and compliance.