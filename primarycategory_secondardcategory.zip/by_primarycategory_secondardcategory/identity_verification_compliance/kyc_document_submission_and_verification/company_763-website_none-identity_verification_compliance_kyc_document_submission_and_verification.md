# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the purpose of the inquiry or request**  
   Determine whether the player is requesting account verification, password reset (login, transaction, or withdrawal), deposit verification, or withdrawal processing, based on their communication.

2. **Gather necessary information from the player**  
   Collect the following details relevant to the verification request:
   - Full name
   - Username
   - Registered phone number and/or email
   - Last deposit receipt (amount and date)
   - Main GCash or Maya account screenshot (if applicable)
   - Details of the deposit or withdrawal (if verifying transactions)
   - Clarify which password reset (login, transaction, or withdrawal) is needed

3. **Instruct the player on document submission**  
   Explain that they must submit:
   - A clear, valid photo ID (e.g., government-issued ID)
   - A selfie holding the valid ID close to their face
   - For password resets, additionally provide a short video stating the current date while holding the ID, with all documents and videos being clear and readable

4. **Verify the clarity and completeness of submitted documents**  
   Confirm that:
   - ID images and selfies are clear, well-lit, and readable
   - The ID is held close to the face in selfies and videos, with no obstructions
   - The video states the current date and the ID details clearly

5. **Perform system and manual checks**  
   - Cross-reference the submitted ID and selfie with existing account information for consistency
   - Verify the deposit receipt against recorded transactions (ensure sender and recipient details are visible)
   - Check that the last deposit receipt matches the account's recent deposit activity

6. **Assess verification status**  
   - If all submitted documents are clear and match account data, proceed with the verification
   - If documents are unclear, incomplete, or do not match the account information, inform the player of the issue and request resubmission  
   - If discrepancies or suspicious content are detected, escalate for manual review or further investigation

7. **Complete the specific process based on the verification type**  
   - **For password reset (login, transaction, or withdrawal):**  
     After successful verification, generate and send the new password or relevant access details according to the procedure  
   - **For deposit verification:**  
     Confirm deposit receipt details in the system; process the deposit confirmation, which may take 30–45 minutes for GCash transactions  
   - **For identity verification or withdrawal approval:**  
     Complete the verification process and update the account status accordingly

8. **Communicate the outcome to the player**  
   - Confirm successful verification and next steps  
   - If verification is unsuccessful, explain the reason and guide them on resubmitting correct documents or escalating if needed

9. **Close the case**  
   - Document all actions taken and verification results  
   - Update the player's account status or resolution notes accordingly

## Notes
- Always ensure document images and videos are clear, well-lit, and unedited
- Use the back camera for higher quality images if available
- Avoid covering the face or ID during selfies and videos
- Verification processes can take 30–45 minutes for deposit-related checks
- Escalate cases with suspicious or incomplete documents for manual review

## Key points for communicating with players
- Clearly inform players of the required documents and precautions for quality submissions
- Advise players to submit all documents in one complete set to speed up verification
- Maintain a professional, patient tone when requesting resubmissions or explanation
- Emphasize confidentiality and security of their submitted documents