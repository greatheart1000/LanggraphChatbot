# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request for identity verification, password reset, deposit, or withdrawal verification.**  
   - Confirm the player's identity by requesting the necessary details relevant to the specific process (see steps 2, 4, 6, or 8).

2. **Gather required information from the player:**
   - For password resets and identity verification:
     - Full name
     - Username
     - Registered number
     - Registered email
   - For deposit or withdrawal verification:
     - Deposit receipt or withdrawal record
   - For all document submissions:
     - A valid ID (e.g., government-issued ID)
     - A selfie holding the ID (clear and readable)
   - If applicable, ask for a video stating today's date while holding the ID (optional but may be required to verify identity).

3. **Instruct the player to upload the required documents:**
   - Use the File button to attach images (max 20 MB per file).
   - Ensure images are clear, legible, and properly aligned.
   - If unable to upload files directly:
     - Suggest taking screenshots of the documents and sending them.
   - Confirm stable internet connection before proceeding.

4. **Verify uploaded documents:**
   - Check that all images are complete, clear, and readable.
   - Confirm that the ID matches the player's details.
   - For selfie or video submissions, verify the presence of the player holding the ID and, if applicable, stating today's date.

5. **Perform system or back-office checks:**
   - Cross-reference deposit receipts with transaction data (review sender, recipient, and reference details) for deposit verification.
   - Review withdrawal records by accessing the Member -> Withdrawal Record section and screenshotting the relevant information.
   - For password resets, confirm identity details match existing records.

6. **Determine verification outcome:**
   - **If all information and documents are satisfactory:**
     - Approve verification.
     - Notify the player of successful verification or password reset.
   - **If documents are incomplete, unclear, or missing:**
     - Explain the issue and request re-submission.
     - Clarify that delays may occur if proper documents are not provided.
   - **If issues persist or documentation remains insufficient:**
     - Escalate the case according to company policy.
     - Notify the player of failure to verify and suggest retrying with clearer documents.

7. **Complete the process:**
   - Update the player's verification status in the system.
   - Provide any necessary instructions or further steps (e.g., re-upload, contact support).
   - Close the case once verification is confirmed or appropriately escalated.

## Notes

- Always verify the clarity and correctness of submitted images before proceeding.
- When requesting selfie or video evidence, emphasize the importance of reading all details clearly.
- For deposit or withdrawal verification, detailed receipts showing sender, recipient, and reference numbers are essential.
- Processing may take some time depending on document quality and system checks; inform the player accordingly.

## Key points for communicating with players

- Clearly instruct them to provide high-quality, readable images.
- Remind them to ensure their internet connection is stable during uploads.
- Explain that incomplete or unclear documents could delay verification.
- Encourage them to follow instructions precisely to avoid unnecessary delays.