# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the interaction**  
   - Determine if the player is submitting deposit receipts, resetting passwords, verifying deposits/withdrawals, or recovering an account based on their inquiry.

2. **Gather required player information**  
   - For verification or password resets, request the following details from the player:  
     - Full name  
     - Registered username or registration number  
     - Registered email address  
     - Main GCash or Maya account details  
     - Last deposit receipt (if applicable)  
     - Valid ID photos (clear and readable)  
     - A selfie holding the valid ID (clear and visible)  
   - For deposit verification, ask the player to specify the deposit method (e.g., GCash, PayMaya) and the approximate date/time of deposit.

3. **Instruct the player to provide specific documentation and screenshots**  
   - Deposit verification:  
     - Provide a screenshot of the deposit receipt showing the GCash/PayMaya sender and recipient details.  
     - Guide the player to access the receipt by logging into GCash/PayMaya, then to Inbox to generate the QRPH invoice or receipt record.  
   - Password reset or account recovery:  
     - Request a clear photo of a valid ID, a selfie with the ID, and the last deposit receipt if relevant.

4. **Perform initial checks in the back office/system**  
   - Verify the submission matches the player's details (name, username, email).  
   - Check for the presence and clarity of the submitted ID images and receipts.  
   - Confirm deposit receipt details (sender/recipient info, reference or QR number) align with the transaction record.

5. **Assess whether the provided documentation is sufficient**  
   - Sufficient if:  
     - All required images are clear and readable.  
     - Deposit receipt shows sender and recipient details.  
     - Player details match the system records.  
   - Insufficient if:  
     - Any images are blurry, unreadable, or incomplete.  
     - Missing key information (ID, selfie, deposit receipt).  

6. **If verification is successful**  
   - For deposit submissions:  
     - Confirm the deposit record in the system.  
     - Acknowledge receipt of the deposit receipt or record, and update verification status accordingly.  
   - For password resets, account recoveries, or transaction password resets:  
     - Process the request, generate a new login or transaction password, and provide the player with the next steps to log in or set a new password. 

7. **If verification is unsuccessful or documentation is incomplete**  
   - Notify the player with specific instructions for re-submission.  
   - Advise on reviewing image clarity, ensuring all required details are visible, and resubmitting as needed.  
   - Do not proceed with account or transaction approval until satisfactory documentation is received.

8. **Follow-up and escalation**  
   - For complex cases, suspected fraud, or if verification cannot be completed, escalate to the appropriate team or supervisor.  
   - Inform the player of any delays or further steps needed, maintaining clear communication.

9. **Close the case**  
   - Once verification is complete, log the outcome in the system.  
   - Communicate the resolution to the player, including any next steps or confirm completion of their request.

## Notes

- Always ensure images and receipts are clear and readable before proceeding.  
- Keep all deposit receipts, ID images, and correspondence saved for record-keeping and audit trail.  
- Verification times can vary; inform players of possible delays and advise patience.  
- Password reset procedures require precise identity verification details to ensure security.

## Key points for communicating with players

- Clearly explain which documents are needed and how to generate them, especially deposit receipts from GCash or Maya.  
- Emphasize the importance of clarity and completeness in submitted images.  
- Reassure players that their information is processed securely and in compliance with verification protocols.