# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the player's request or reason for verification**
   - Determine if the request is for login password reset, transaction password reset, deposit or withdrawal verification, account verification (e.g., birthday bonus claim), or other compliance purposes.
   
2. **Inform the player of required verification documents**
   - Explain that verification involves submitting clear, physical ID photos, selfies holding the ID, and possibly additional information depending on the request.
   - Provide the specific requirements for ID photo guidelines:
     - Use the back camera, hold the ID close, ensure good lighting.
     - Make sure ID details are fully readable and not covered.
     - Do not move or cover your face.
     - Double-check clarity before submitting.
   - Clarify that IDs must be physical (not online copies) for verification.

3. **Collect the required information and documents based on the request**
   - For login password or account recovery:
     - Full name
     - Username
     - Registered number and email
     - Last deposit receipt (screen capture or record from Member > Deposit Record)
     - Primary GCASH/MAYA account
     - Clear photo of a valid ID
     - Selfie holding the ID
     - Video with ID and today's date (for password reset, if applicable)
   - For transaction password reset:
     - Full name
     - Username
     - Clear photo of a valid ID
     - Selfie holding the ID
   - For deposit or withdrawal verification:
     - Detailed deposit receipt (showing sender and recipient info) and/or deposit record, or withdrawal record (screenshots from Member > Deposit/Withdrawal Record).
   - For birthday bonus claim:
     - Full name
     - Username
     - Birth date
     - Two valid ID photos
     - Selfie holding your ID

4. **Verify the submitted documents**
   - Check that all ID photos and selfies are clear, readable, and match the provided information.
   - Ensure the selfie is with the ID held near the face.
   - Confirm that all details on the ID are legible and complete.
   - Validate that the video (if required) shows the ID and current date.

5. **Perform system and account checks**
   - For deposit/withdrawal verification, review the submitted receipts and records against transaction history.
   - For account verification (login or password reset), verify the player's details against existing account info.
   - For deposit verification, ensure the receipt/document covers the requested transaction.
   
6. **Determine if the verification is successful**
   - If all documents meet the requirements and match account details:
     - Proceed to reset the login or transaction password if requested.
     - Approve deposit/withdrawal verification.
     - Confirm eligibility for bonuses such as birthday rewards.
   - If documents are unclear, incomplete, or do not match:
     - Request the player to resubmit clearer, proper photos and videos.
     - Provide instructions on proper documentation and retake.

7. **Complete the process**
   - For password resets:
     - System will issue a new login or transaction password after successful verification.
     - Inform the player accordingly.
   - For deposit or withdrawal verification:
     - Confirm verification and update account status.
   - For bonus claims or account approval:
     - Grant applicable bonuses or verify the account for further activities.

8. **Close the case**
   - Document all verification steps and outcomes.
   - Communicate result to the player:
     - Successful verification: confirm completion and next steps.
     - Failed verification: advise on resubmission or additional steps.
   - Record the case in the system for compliance audit purposes.

## Notes
- IDs must be physical, not online images or scans.
- All submitted documents should be in focus, well-lit, and clearly readable.
- Selfies must clearly show the player holding the ID near their face.
- When requesting additional documents (video, clearer photos), specify the exact requirements.
- For deposit verification, ensure the receipt includes sender and recipient details, and if relevant, screenshots of transaction records from the account.

## Key points for communicating with players
- Clearly explain which documents are required and how to submit them.
- Emphasize the importance of clarity and correctness in the documentation.
- Notify players that verification may take some time depending on document quality.
- Reassure players that the process is for security and compliance; privacy is maintained.