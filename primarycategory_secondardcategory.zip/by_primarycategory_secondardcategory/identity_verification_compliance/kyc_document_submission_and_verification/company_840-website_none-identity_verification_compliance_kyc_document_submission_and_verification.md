# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Initiate verification request**  
   Identify whether the player is requesting identity verification, password reset, or transaction verification. Communicate clearly the required documentation based on the request type.

2. **Collect necessary player information**  
   Request the player to provide:
   - Full name
   - Username
   - Registered phone number or account identifier
   - Registered email address

3. **Determine specific documentation requirements**  
   Depending on the verification purpose:
   
   - For identity verification or password reset:
     - Request a clear photo of a valid government-issued ID
     - Request a selfie holding the ID, ensuring all details are clear and readable
   - For deposit or withdrawal verification:
     - Request a detailed deposit receipt showing GCash/Maya sender and recipient information (screenshots of inbox or QRPH invoice)
     - For withdrawal verification, request a screenshot of the withdrawal record (accessible via Profile > Withdrawal Record)

4. **Verify document clarity and completeness**  
   Confirm that:
   - The ID images are clear, with readable details
   - The selfie is clear and shows the player holding the ID close to their face
   - The receipt or screenshot is legible and includes all relevant information

5. **Check ID name consistency**  
   Ensure that the name on the ID matches the player's registered account name. If there is a mismatch:
   - Inform the player to submit an ID with the correct name
   - Do not proceed with verification until name consistency is confirmed

6. **Assess whether all required information is provided**  
   - If all necessary documentation and information are received and meet clarity standards:
     - Proceed to verify the documents in the back office/system
   - If any information or documents are missing, unclear, or invalid:
     - Notify the player of the missing/incorrect items
     - Advise the player to re-submit the required documents

7. **Perform verification through the system**  
   - Review the submitted documents for authenticity and correctness
   - Cross-check the details (name, ID, receipt, selfie)
   - For identity or password resets, confirm identity before proceeding

8. **Handle cases with mismatched or invalid documents**  
   - Reject verification and inform the player of the mismatch or issue
   - Request resubmission with correct documents if applicable
   - Escalate to a supervisor if necessary

9. **Complete verification process**  
   - If verification is successful:
     - Issue the appropriate account update:
       - Reset login password, transaction password, or approval for deposit/withdrawal verification
       - Notify the player of successful verification and next steps
   - If verification fails:
     - Explain the reason to the player
     - Advise on resubmission or further assistance

10. **Follow up if verification is delayed**  
    - If back office/system review is pending beyond typical timeframes:
      - Follow up with the support team or escalate appropriately
      - Keep the player informed about the status

## Notes

- All uploaded images must be within the file size limit of 10 MB.  
- For password resets, players are required to provide a short video stating the current date while holding their ID as an additional security step.  
- Verification of deposits via GCash/Maya requires a screenshot of the inbox or generated receipt showing sender and receiver details.  
- Name mismatch on ID and account prevents further processing until corrected.  

## Key points for communicating with players

- Clearly specify which documents are required based on their request (identity, deposit, withdrawal, password reset).  
- Emphasize the importance of clarity in uploaded images and selfies.  
- Confirm the name on the ID matches the account name to proceed with verification.  
- Guide players to resubmit documents if verification fails due to unclear images or mismatched details.  
- Keep the tone professional, supportive, and transparent about steps and next actions.