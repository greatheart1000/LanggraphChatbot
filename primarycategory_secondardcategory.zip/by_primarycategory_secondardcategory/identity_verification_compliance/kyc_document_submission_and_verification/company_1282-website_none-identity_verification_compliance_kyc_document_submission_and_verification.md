# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's verification request or inquiry related to account verification, withdrawal, or KYC compliance.**

2. **Inform the player of the required documents and information:**
   - Valid government-issued ID (front and back if required).
   - A selfie holding the ID.
   - A screenshot showing the registered phone number.
   - A screenshot showing the linked mobile wallet account (e.g., GCash or Maya).
   - The last known account balance.
   - Receipt of the last deposit (from GCash, PayMaya, or similar).

3. **Request the player to submit all required documents in a single message, including:**
   - The username.
   - The verified contact number.
   - The wallet account number (GCash or Maya).
   - The last deposit receipt showing the transaction reference number or deposit details.
   - Valid ID (photo or scan).
   - Selfie with the ID.
   - Screenshot of the registered phone number.
   - Screenshot of the linked e-wallet account and last deposit.

4. **Verify the completeness of the submission:**
   - Check that all documents and information are provided.
   - Confirm that the ID is clear and readable.
   - Ensure the selfie is clearly showing the player holding their ID.
   - Verify that the screenshots of registered phone number, wallet, and deposit receipt are clear and match the player details.

5. **Perform system and manual checks:**
   - Cross-reference the submitted documents with the player's registered information.
   - Confirm that the last deposit receipt matches the account details.
   - Verify that the phone number and wallet account correspond to the registered details.
   - Check if the submitted ID is valid and government-issued.

6. **Decide on verification success or failure:**
   - **If all requirements are met:**
     - Approve the account for withdrawal / fulfill KYC compliance.
     - Notify the player that verification has been completed successfully.
   - **If any documents or details are missing or invalid:**
     - Inform the player of the specific issues.
     - Request re-submission with corrected or additional information.

7. **In case of discrepancies or suspected fraud:**
   - Escalate the case to the wider compliance team or follow the internal escalation procedures.
   - Do not approve the verification until issues are resolved or further verification is performed.

8. **Close the case once verification is approved or appropriately rejected, documenting all actions taken.**

## Notes

- All required documents must be submitted in a single message for efficiency.
- The verification must confirm the identity, registered contact details, and last deposit receipt as per the explicit requirements.
- Handling of the player's data must comply with privacy and security policies.

## Key points for communicating with players

- Clearly explain the document requirements and submission instructions.
- Emphasize the need for all documents to be clear and legible.
- Advise players to avoid editing or modifying documents before submission.
- Confirm receipt of all submissions and inform players of the verification timeline.
- Be polite, clear, and informative throughout the process.