# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request for identity verification or account security check.**  
   - Determine the reason for verification (e.g., account access, password reset, deposit/withdrawal verification).  
   - Clarify with the player if needed.

2. **Collect the required information and documents from the player.**  
   - Full Name  
   - Username  
   - Registered Number and Registered Email (for login password reset)  
   - Last deposit receipt (if applicable)  
   - Main GCash or Maya account details (if applicable)  
   - For ID verification: a clear photo of a valid ID and a selfie holding the ID close to the face.  
   - For deposit verification: detailed receipt including sender and recipient info, screenshot from GCash transaction history or inbox, and screenshot of deposit record from the member section.  
   - For security checks: a video stating today's date while holding the ID (if required).

3. **Ensure all submitted files conform to the size limit.**  
   - Files must not exceed 10 MB.

4. **Verify the clarity and readability of the submitted ID and selfies.**  
   - ID should be legible with details clearly visible.  
   - Selfie should show face and ID clearly, with ID held close to the face, in a bright area, without cover or movement.  
   - For selfies with ID, use the back camera for better quality.  
   - Encourage players to check details before submitting.

5. **Review submitted documents for completeness and correctness.**  
   - Confirm all required documents are submitted and meet the criteria.  
   - If any documents are unclear, instruct the player to retake and resubmit.

6. **Perform back-office system checks.**  
   - Confirm receipt of the documents within the system.  
   - For deposit verification, check the provided receipts against transaction records.  
   - For identity verification, cross-verify ID and selfie with the account information.  
   - For security checks, verify the video and documents.

7. **Determine if the documents and verification steps meet the requirements.**  
   - If all checks pass:  
     - Proceed to approve the verification, grant access, or approve withdrawal/deposit as appropriate.  
   - If checks fail or documents are insufficient or unclear:  
     - inform the player that additional or clearer documents are needed and specify the requirements.

8. **Communicate the resolution to the player.**  
   - Confirm successful verification or explain reasons for rejection/request for re-submission.  
   - Advise on steps to provide clearer documents if needed.

9. **Close the case once verification is complete and the appropriate action has been taken.**  
   - Record the verification outcome for compliance and audit purposes.

## Notes

- Always remind players to ensure their documents are clear, readable, and within the 10 MB file size limit.  
- Use bright lighting and avoid covering the face or ID when submitting selfies.  
- For deposit verification, receipts should be detailed and include sender and recipient info, transaction history, or deposit record screenshots.  
- For security steps involving videos, the player must state today's date clearly while holding their ID.

## Key points for communicating with players

- Emphasize the importance of clear, legible documents and selfies.  
- Guide players to hold their ID close to the face and check details before sending.  
- Clearly specify document requirements for different verification scenarios.  
- Be patient and provide clear instructions if re-submission is necessary.