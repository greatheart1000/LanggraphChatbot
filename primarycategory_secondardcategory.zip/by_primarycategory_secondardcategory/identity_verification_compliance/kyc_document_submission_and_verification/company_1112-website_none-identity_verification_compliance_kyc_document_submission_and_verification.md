# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive player request for verification or withdrawal**, including inquiries about KYC documentation or deposit/withdrawal verification.

2. **Identify the type of verification required**:
   - Ownership verification for withdrawals and deposits
   - Deposit verification
   - Withdrawal verification

3. **Collect necessary information from the player**:
   - For verification of withdrawal ownership: request Player's **Username, Nickname, Withdrawal name, Email, Proof of phone number, screenshot of the last GCASH deposit (receipt), GCASH profile, Selfie holding a valid ID, and a clear photo of a valid ID**.
   - For deposit verification: request **Username** and **GCASH Inbox Receipt (or MAYA receipt)**.
   - For withdrawal verification: request **Username, Nickname, Withdrawal name, Email, verified phone number, balance, last game played, screenshot of last deposit, Selfie holding valid ID, and a clear photo of valid ID**.

4. **Instruct the player to provide the required documents or images based on the scenario**:
   - For GCASH or MAYA deposit: ask for the **GCASH inbox receipt screenshot**.
   - For withdrawal: ask for the **screenshot of the last deposit**, valid **ID photos**, and other registration details.

5. **Verify the submitted documents and information**:
   - Confirm the presence of the **proof of deposit or withdrawal receipt** (e.g., GCASH Inbox Receipt).
   - Check that the **selfie** holding the valid ID is clear and matches the ID.
   - Confirm that the **ID** photo is clear and valid.
   - Cross-check provided details such as **username, email, phone number** against system records.

6. **Perform system checks to verify deposits**:
   - For GCASH deposits: verify the deposit in the system using the **Inbox Receipt** and **username**.
   - For bank transfers: verify deposit via **bank deposit slip screenshot** if provided.

7. **Evaluate whether the submitted documents and information are sufficient**:
   - If all requested documents and details are complete and verify successfully:
     - Proceed with approving the verification.
     - Update the customer’s account status to verified if applicable.
   - If information is missing or verification fails:
     - Inform the player that the verification cannot be completed due to incomplete or invalid documents.

8. **Address special cases or warnings**:
   - If the player cannot provide requested receipts or IDs, advise them on possible next steps, such as contacting GCASH Help Center for receipt assistance.
   - If the player’s documents do not match or are blurry, request clearer images.
   
9. **Communicate the outcome to the player**:
   - Confirm successful verification and inform if any further action or additional documentation is needed.
   - Inform of any delays or issues if verification is unsuccessful.

10. **Close the case once verification is confirmed or declined**:
    - Document all steps taken.
    - Update system records as necessary.
    - Notify the player of the final status.

## Notes

- Always request a **clear photo of a valid ID** and **selfie holding the ID** for identity confirmation.
- Use the **proof of deposit receipt (GCASH Inbox Receipt)** to verify deposit transactions.
- For deposit verification, **submit the inbox receipt and username**; the deposit will be credited after review.
- For withdrawal verification, ensure all required details and documents are provided; delays may occur if info is missing.
- Remind players that if receipt images are blurry or missing, they may need to contact the GCASH Help Center or relevant support channels.

## Key points for communicating with players

- Clearly specify which documents are required for each process.
- Emphasize the importance of providing clear, legible images.
- Advise players on contacting the respective service provider (e.g., GCASH Help Center) if receipts are missing or unclear.
- Be transparent about potential processing delays if documentation is incomplete or requires further verification.