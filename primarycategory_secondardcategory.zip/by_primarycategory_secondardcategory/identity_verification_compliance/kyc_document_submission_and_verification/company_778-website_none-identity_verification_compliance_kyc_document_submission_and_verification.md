# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request**:
   - Determine if the request is related to verifying a deposit/withdrawal, resetting login or transaction passwords, claiming the VIP Birthday Bonus, or another security process.

2. **Gather required player information**:
   - Full name
   - Username
   - Registered number
   - Registered email address
   - Main GCash/Maya account details (if applicable)

3. **Request and verify the player’s documentation**:
   - For identity verification, password resets, or claiming bonuses, require:
     - Two valid, clear IDs
     - A selfie holding a valid ID (clear and readable)
   - For deposit/withdrawal verification, ask the player to:
     - Access the corresponding record in the Member area:
       - Deposit Record for deposits
       - Withdrawal Record for withdrawals
     - Take a screenshot of the record, ensuring the reference number and transaction details are visible

4. **Request deposit or withdrawal proof as applicable**:
   - For deposit verification:
     - Obtain a detailed receipt showing sender and recipient information for GCash or Maya
     - For GCash, the receipt should be from the GCash Inbox, including the transaction reference or QR invoice number if available
   - For withdrawal verification:
     - Use the screenshot of the withdrawal record with reference number

5. **Verify the submitted documents**:
   - Check clarity and readability of IDs and selfies
   - Confirm that the deposit or withdrawal receipt includes all required details
   - For password resets, ensure the player has provided all necessary information:
     - For login password reset: full details plus last deposit receipt; for transaction password reset: similar info plus ID and selfie
     - Follow security steps such as submitting the last deposit receipt and the main GCash/Maya account info

6. **Conduct back-office checks**:
   - Review the documents and screenshots for consistency and completeness
   - Verify that the deposit receipts align with system records, if applicable
   - For password resets, ensure the provided information matches the account data and security steps are followed

7. **Make a verification decision**:
   - If all documentation and details are sufficient and verified, proceed with the requested action:
     - Approve deposit or withdrawal verification
     - Reset login or transaction password
     - Distribute VIP Birthday Bonus
   - If documentation is incomplete, unclear, or inconsistent:
     - Inform the player of the issue
     - Request additional or clearer documents
     - Escalate if necessary

8. **Complete the process and communicate with the player**:
   - Notify the player of the verification result
   - Provide further instructions if needed (e.g., wait for approval, resubmit documents)
   - Close the case or proceed to the next step in the security procedures

## Notes
- Always ensure screenshots are clear and all details are visible.
- For security-related verifications, follow the specified sequences to prevent unauthorized access.
- Verification of deposit and withdrawal receipts requires documentation showing sender and recipient info.
- The VIP Birthday Bonus requires the player to provide their username, two valid IDs, and a selfie holding a valid ID, especially on their birthday date.

## Key points for communicating with players
- Clearly instruct players on the specific documents needed.
- inform players that verification may take some time depending on document clarity.
- Emphasize the importance of providing clear, readable images to expedite processing.
- Keep communication professional, courteous, and secure.