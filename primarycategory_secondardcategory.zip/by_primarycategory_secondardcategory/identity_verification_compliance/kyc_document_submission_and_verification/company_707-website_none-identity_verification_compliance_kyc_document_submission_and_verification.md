# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive player inquiry or request related to account verification, password reset, or deposit verification.**

2. **Determine the nature of the request:**
   - a. Identity verification or account recovery.
   - b. Password reset (login or transaction).
   - c. Deposit verification.
   
3. **If the request is for account verification or recovery:**
   - Collect from the player:
     - Full Name
     - Username
     - Registered Number
     - Registered Email
     - Last Deposit Receipt (if available)
     - Main GCash or Maya account details
     - Clear image of a valid ID
     - Selfie holding the ID
   - Ensure:
     - All ID details are readable.
     - Selfie clearly shows the face and ID.
     - Files are attached with a maximum size of 20MB.
   
4. **If the request involves resetting passwords:**
   - For **login password reset**:
     - Collect:
       - Full Name
       - Username
       - Registered Number
       - Registered Email
       - Last Deposit Receipt
       - Main GCash or Maya account
       - Clear image of a valid ID
       - Selfie holding the ID
   - For **transaction password reset**:
     - Collect:
       - Full Name
       - Username
       - Clear image of a valid ID
       - Selfie holding the ID
   - Verify the provided documents are clear and match the account information.
   
5. **If the request is deposit verification:**
   - Ask the player to provide:
     - A screenshot of the detailed GCASH/PayMAYA deposit receipt showing sender and recipient information.
     - Alternatively, a screenshot of the deposit record from their transaction history.
   - Confirm the receipt clearly displays relevant sender and recipient details.
   
6. **Perform system and back-office checks:**
   - Upload received documents and images into the verification system.
   - Review ID images and selfies for clarity and consistency.
   - For deposit verification, review the submitted receipt against the transaction history or deposit records.
   
7. **Determine if verification is sufficient:**
   - If all documents are clear, complete, and match the account information:
     - Approve the verification.
     - If applicable, issue a new transaction password manually (type it, do not copy/paste).
     - Inform the player of successful verification or password reset.
   - If documents are incomplete, unclear, or mismatched:
     - Inform the player to resubmit clear and valid documents.
     - Clarify specific issues preventing verification.
   
8. **In case of inability to verify due to missing or poor-quality documents:**
   - Explain the verification failure clearly.
   - Advise the player to complete the required submission with acceptable documents.
   - Escalate to a supervisor if the case requires manual review or special handling.

9. **Follow up and document all actions:**
   - Record date, time, documents received, and verification result in the case log.
   - Keep communication clear and professional, emphasizing the need for clear ID selfies and deposit proof.
   
10. **Close the case:**
    - Once verified or the issue is resolved:
      - Update the system status.
      - Notify the player of the outcome.
      - Provide instructions for next steps if applicable (e.g., password setup or account recovery).

## Notes
- Ensure all IDs and selfies are clear and readable, especially when requested for password resets or verification.
- For deposit proof, the receipt must include sender and recipient details to be valid.
- Verification may involve video checks or additional document requests if initially unclear.
- For security, avoid copying and pasting passwords; always type the new password manually.
- In all communications, clarify the importance of submitting valid, clear documents to expedite processing.

## Key points for communicating with players
- Emphasize the need for clear images: "Please make sure your ID and selfie are clear and readable."
- Guide players to locate deposit receipts in their app transaction history or inbox.
- Explain that verification requires matching details on their ID with account information.
- Reassure players that their documents are secure and used solely for verification purposes.
- Inform players that resolution may take some time depending on document clarity and system checks.