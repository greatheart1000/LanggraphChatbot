# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request**  
   Determine whether the player is submitting documents for account recovery, password reset, claiming a bonus (e.g., Birthday Bonus), withdrawal verification, deposit verification, or VIP birthday bonus.  

2. **Gather required player information based on the verification reason**  
   - For login/password reset: collect full name, username, registered number, registered email, last deposit receipt, main GCash/PayMaya account details, and a valid ID (clear picture).  
   - For bonus claims (Birthday, VIP Birthday): obtain full name, username, birth date, and the relevant documents.  
   - For deposit/withdrawal verification: request proof of payment (transaction confirmation screenshot, deposit receipt, or deposit record).  
   - For transaction password reset or verification: request full name, username, valid ID, and a selfie with the ID.  

3. **Instruct the player to prepare and submit documents**  
   - Ensure the images/photos are clear and legible.  
   - For IDs, ensure they show the full name and birthdate as required.  
   - For selfies, ask the player to hold the ID near their face to confirm ownership.  
   - For VIP or special bonuses, verify that IDs are laminated (if required) and that the birthdate is legible.  

4. **Request document submission through the approved channels**  
   - Advise the player to upload the images via the designated support portal or communication channel.  
   - For deposit proof from GCash/PayMaya, instruct the player to capture and submit a screenshot of the transaction confirmation or inbox receipt.  
   - If a short video or additional verification (e.g., stating the current date while holding ID) is requested, guide the player accordingly.  

5. **Verify the submitted documents before proceeding**  
   - Check that the ID images are clear and contain the required details (full name, birthdate).  
   - Confirm that selfies are clear, show the player holding the ID, and match the submitted details.  
   - For deposit proofs, ensure the transaction confirmation shows the sender, recipient, and amount clearly.  
   - For VIP or bonus claims, verify ID validity (e.g., laminated, legible birthdate).  

6. **Perform back-office system checks**  
   - Match submitted information against existing account records (name, username, birthdate).  
   - Cross-reference deposit amounts and transaction details with the system records.  
   - Validate the authenticity of the documents and their conformance to the requirements.  

7. **Decide on approval or additional verification**  
   - If documents pass verification, proceed to authorize the request (e.g., reset password, process bonus, approve withdrawal).  
   - If documents are unclear, incomplete, or do not match records, communicate the issue to the player and request re-submission or clarification.  

8. **Complete the process according to the verification outcome**  
   - For approved verifications:  
     - Issue the password reset, bonus, withdrawal, or other relevant resolution.  
     - Inform the player about the successful verification and next steps.  
   - For rejected verifications:  
     - Explain the reason (e.g., unclear ID, mismatched information).  
     - Instruct the player on how to resubmit correct documents if applicable.  

9. **Record all interactions and verification results in the system**  
   - Log the submitted documents, verification decisions, and communication notes for future reference.  

10. **Follow up if necessary**  
   - For pending verification or additional information requests, remind the player to submit the required documents promptly.  
   - Escalate cases that require further investigation or support escalation according to the internal procedures.  

## Notes
- Always ensure the player’s information matches the submitted documents; mismatched details will delay or prevent approval.  
- Clear, legible, and recent images improve verification speed and success rate.  
- Use the same verification standards for all players to maintain compliance and fairness.

## Key points for communicating with players
- Clearly inform players of the documents required for each type of verification.  
- Emphasize the importance of submitting clear and readable images.  
- Explain the verification process steps and expected timeframes.  
- Advise players to check that all submitted IDs show their full name and birthdate visibly.  
- Be patient and professional when handling re-submissions or clarifications.