# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request for account verification or password reset.**  
   - Clarify the type of verification needed (e.g., login password, transaction password, withdrawal password, birthday bonus eligibility, or KYC verification).  
   - Confirm the specific scenario with the player.

2. **Request the necessary identification documents from the player based on the scenario.**  
   - For login password reset: Full Name, Username, Registered Number, Registered Email, Last Deposit Receipt, Main Gcash/Maya Account, Picture of Valid ID, Selfie with ID.  
   - For transaction or withdrawal password reset: Full Name, Username, Picture of Valid ID, Selfie with ID.  
   - For birthday bonus redemption: Username, 2 Valid IDs, Selfie while holding a valid ID.  
   - For general KYC verification (including deposit verification or additional identity checks): Photo of Valid ID, Selfie with ID, and any relevant deposit receipts or screenshots.

3. **Instruct the player to ensure all submitted documents are clear and readable.**  
   - Emphasize that both the ID and selfie must be clearly visible.  
   - The ID should be held close to the face in selfies, with the ID number and personal details legible.  
   - If requesting deposit receipts, ensure they clearly display the sender and recipient details.

4. **Guide the player to submit the documents via the designated support channel** (e.g., support ticket, chat upload, or email), according to company procedures.

5. **Verify the submitted documents.**  
   - Confirm that all required documents are provided and are clear and readable.  
   - Check that the selfie includes the player holding the ID close to the face, with the current date or current time if visible, as required for identity confirmation.

6. **Perform back-office checks.**  
   - Cross-reference the submitted details against account data (Full Name, Username, Registered Number, Email).  
   - Confirm that the ID matches the provided information.  
   - For deposit verification, review the receipt or screenshot showing sender and recipient information, ensuring the payment details are consistent with the account linked to the platform.

7. **Assess the verification result.**  
   - If all documents are satisfactory and verification is successful:  
     - Proceed to reset the password or process the specific request as applicable.  
     - Send the new password or confirmation instructions to the player securely.  
   - If documents are unclear, incomplete, or do not match account details:  
     - Inform the player that the verification failed.  
     - Request re-submission with clearer images or additional documentation if necessary.

8. **Escalate issues that cannot be resolved through standard verification to the appropriate department** (e.g., suspected fraud, incomplete documents).  
   - Do not finalize the verification process until all issues are resolved.

9. **Close the ticket or case** once verification and processing are complete.  
   - Confirm with the player that their request has been successfully fulfilled.  
   - Remind the player of relevant rules or next steps if applicable.

## Notes
- Always ensure the security of sensitive documents during submission and transmission.  
- If delays occur due to network fluctuations, inform the player and advise additional methods (like using PayMaya as an alternative deposit method, if relevant).  
- Deposit verifications require screenshots clearly showing sender and recipient from the payment platform, ensuring the payment account is linked to the platform.

## Key points for communicating with players
- Emphasize the importance of clarity and readability of submitted images.  
- Remind players to hold IDs close to their face and include the current date or visible timestamp if requested.  
- Reassure players that verification is routine and designed to ensure account security and compliance.