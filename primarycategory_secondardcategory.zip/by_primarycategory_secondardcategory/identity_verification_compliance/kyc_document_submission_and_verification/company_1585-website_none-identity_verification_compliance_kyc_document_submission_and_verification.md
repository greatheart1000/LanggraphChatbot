# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or inquiry related to account or deposit verification.**

2. **Determine the type of verification needed:**
   - For deposit verification, inform the player they need to provide the deposit receipt (GCASH or MAYA) with sender and recipient information.
   - For account verification for withdrawal or security purposes, inform the player they need to submit specific documents, including username, full name, mobile number, Gcash/Maya profile link, last deposit receipt, clear ID picture, and a selfie with the ID.

3. **Instruct the player on document submission:**
   - Collect the following from the player:
     - Deposit receipt image (e.g., InBox receipt for GCash deposit)
     - A clear picture of their ID
     - A selfie holding the ID
     - Gcash or Maya profile link
     - Last deposit receipt for deposit verification
     - Username and full name
     - Mobile number

4. **Ensure the player submits all required documents and information:**
   - Confirm the receipt image is clear and legible
   - Verify the ID picture and selfie are clear
   - Confirm the profile links are correct

5. **Perform verification checks in the back office/system:**
   - Match the submitted documents and information with existing account details
   - For deposit verification, verify the deposit receipt matches the transaction (sender, recipient info)
   - For account verification, ensure the ID and selfie are valid and match the account holder's details
   - Confirm the profile links and contact details are verified and active

6. **Evaluate the completeness and validity of the submitted documents:**
   - If all required documents are provided and verified:
     - Mark the account or deposit as verified in the system
     - Inform the player the verification is successful
     - Proceed with any withdrawal processing or security clearance as needed

   - If any document is missing or invalid:
     - Notify the player of the specific missing or unacceptable item
     - Request resubmission or clarification as necessary
     - Do not proceed until all criteria are met

7. **Escalate or take additional actions if necessary:**
   - If suspicious activity or discrepancies are detected, escalate according to the company's security protocol
   - If the player cannot provide acceptable proof within a given timeframe, refuse verification and inform the player accordingly

## Notes

- Always prioritize clarity in instructions and remind players to provide high-quality, legible images.
- Verification for deposit involves submitting the receipt with sender and recipient details to help process the deposit.
- Verification for account details for withdrawal requires submitting a valid ID, a selfie with the ID, and profile links.
- The process aims to ensure security compliance and enable smooth withdrawal processing.

## Key points for communicating with players

- Clearly specify the documents needed for each verification type.
- Emphasize the importance of clear and legible images.
- Explain that incomplete submissions will delay the verification process.
- Keep communication professional and reassuring to ease players' concerns.