# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or inquiry regarding KYC or account verification.**  
   - Determine the specific verification or document submission required (e.g., deposit verification, withdrawal, OTP, or account reset).

2. **Inform the player of the documents and information needed based on the verification type:**

   - **For deposit verification:**
     - Deposit Record (deposit slip or bank receipt)
     - Payment Receipt
     - Ensure the date and time match the transaction
     
   - **For withdrawal verification or processing:**
     - Full name or withdrawal name
     - Nickname
     - Phone number
     - Linked payment method details (e.g., GCash number)
     - Last deposit slip or transaction details
     - A selfie with a valid ID

   - **For OTP Verification (account verification):**
     - Username
     - Full name
     - Phone number
     - Balance
     - Screenshot of linked e-wallet profile
     - Last deposit receipt
     - Clear ID photo
     - Selfie with ID card

   - **For resetting transaction password:**
     - Same documents as account verification: username, full name, phone number, balance, linked e-wallet screenshot, last deposit receipt, clear ID photo, and selfie with ID.

3. **Request the player to submit the required documents through the supported communication channels (e.g., email, upload portal, live chat).**

4. **Verify the authenticity and completeness of the submitted documents:**
   
   - Check that the Deposit Record and Payment Receipt are provided and their date and time match the transaction.
   - Confirm that the player's full name, withdrawal name, and phone number match the information on the documents.
   - Verify the ID photo and selfie format for clarity and legibility.
   - For deposit verification, ensure the last deposit receipt is available if needed.
   
   - **Special notes:**
     - For deposit verification, documents must match transaction details; documents with mismatched dates/times cannot be accepted.
     - For OTP or account reset verification, the player must provide all listed information and documents.

5. **Initiate the back-office system checks:**
   
   - Review the submitted documents for validity and consistency.
   - Confirm the details match records (e.g., last deposit slip, linked e-wallet profile).
   - If any document is missing, unclear, or inconsistent, communicate to the player that verification cannot proceed until resolved, and advise on re-submission.

6. **Proceed with the verification process:**
   
   - If all documents and information are correct and valid, process the verification in the system.
   - For deposit verification, approve the deposit based on matching records.
   - For withdrawal, confirm the provided details before approving the transaction.
   - For OTP or account reset, generate and send the OTP or reset confirmation.
   
7. **Wait for the system or backend to complete the verification:**
   
   - Inform the player that verification is in progress and processing times may vary.
   - Do not disclose specific time estimates unless informed by current site rules.

8. **On completion of verification:**
   
   - Notify the player of the verification outcome.
   - If successful, proceed with deposit, withdrawal, OTP, or account reset as requested.
   - If unsuccessful, explain courteously that verification could not be completed and advise on potential next steps (e.g., re-submission, further information needed).

## Notes

- Always handle document submissions securely and maintain confidentiality.
- In cases of conflicting or suspicious documents, escalate according to internal compliance procedures.
- Ensure communication is clear about any missing or inadequate documentation required for further action.

## Key points for communicating with players

- Clearly specify the exact documents and information needed for each verification type.
- Remind players to ensure all documents are clear and match their account details.
- Inform players that verification times vary and depend on the completeness and authenticity of submitted documents.
- Keep players informed about the status and outcome of their verification process.