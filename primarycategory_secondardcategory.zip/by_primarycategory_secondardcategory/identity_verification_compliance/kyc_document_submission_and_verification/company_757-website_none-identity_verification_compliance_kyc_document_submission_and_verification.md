# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the request**  
   Determine if the player is submitting documents for password reset, deposit verification, withdrawal/transaction password reset, claiming a birthday bonus, VIP birthday bonus, or other compliance purposes. The specific reason will guide the required documents and verification process.

2. **Inform the player of the required documents and photo submission guidelines**  
   - Clearly explain that the player must submit:
     - A valid ID (or two IDs for birthday bonuses)
     - A selfie holding the valid ID (ID held close to the face)  
   - Stress the importance of clarity and readability in the photos.
   - Share tips:
     - Use the back camera
     - Take photos in a bright environment
     - Ensure the ID and face are visible; do not cover the face
     - Do not move during photo capture
     - Bring the ID closer to the camera for focus
   - Advise checking the photos for clarity and readability before submission.

3. **Collect necessary information based on the verification type**  
   For all processes, ask the player for:
   - Full Name
   - Username
   - Registered number and email (if applicable)
   - Recent deposit receipt or deposit record (if related to deposit verification or password reset)
   - Main GCash/Maya account (if applicable)  
   For password reset or transaction password reset:
   - Request a picture of valid ID and a selfie with ID
   For deposit verification:
   - Request a detailed receipt or a screenshot showing sender, recipient, amount, date/time, along with the deposit invoice or record.  
   For birthday bonus or VIP bonuses:
   - Request birth date
   - Require two valid IDs showing the birthdate
   - Ask for a selfie with the IDs

4. **Verify the submitted photos for clarity and correctness**  
   - Check that all ID and selfies are clear, readable, and the ID is held near the face.
   - Confirm details such as name, ID number, and birth date are visible and legible on the ID images.

5. **Assess whether all required information and documents are received and proper**  
   - If all documents are provided and clear, proceed to the next step.
   - If any documents or information are missing or unclear:
     - Notify the player politely.
     - Request resubmission with clearer photos and complete details.
     - Do not proceed until proper documentation is received.

6. **Perform the verification in the back office/system**  
   - Cross-check the submitted ID details with the player’s account information.
   - For deposit verification, confirm deposit details with the provided receipt or screenshot.
   - For password resets, verify the provided deposit record or related information.
   - For birthday and VIP bonuses, verify the IDs’ birthdate details.

7. **Make a decision based on verification outcome**  
   - If all details and documents are valid and match information in the system:
     - Approve the request (password reset, deposit verification, bonus claim, etc.)
     - Communicate to the player that their verification was successful and explain next steps.
   - If there are discrepancies, unreadable documents, or inconsistencies:
     - Explain the issue to the player.
     - Request additional or clearer documentation.
     - Do not proceed until verification is complete.

8. **Complete the process and update system status**  
   - Record the verification outcome in the system.
   - Issue the password reset, deposit confirmation, or bonus claim accordingly.
   - For sensitive cases or uncertain verifications, escalate to a supervisor or compliance team per company policy.

9. **Communicate the result to the player**  
   - Clearly inform the player of success or failure.
   - Provide instructions or next steps if needed (e.g., how to proceed with password reset or deposit claim).
   - Ensure players understand the importance of clear, legible documentation.

## Notes
- Always verify that ID and selfie photos are clear and that the ID is held close to the face.
- For deposit verification, ensure the receipt shows sender and recipient details matching the transaction.
- For birthday or VIP bonuses, the two ID documents must both include the birthdate and be clear.
- Escalate cases with suspicious or invalid documentation according to internal policies.

## Key points for communicating with players
- Emphasize the importance of clarity and readability in photos.
- Clearly explain the specific documents needed based on the verification purpose.
- Be patient and polite, and guide players to resubmit if necessary.
- Reiterate that incomplete or unclear documentation will delay verification.