# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or inquiry related to account verification, password reset, or bonus claim.**

2. **Determine the specific purpose of the verification:**
   - Account verification or account unlock
   - Resetting login or transaction passwords
   - Claiming or redeeming birthday or VIP bonuses

3. **Inform the player of the required documents and information based on their request:**
   - For account verification or unfreezing a locked account:
     - Full Name
     - Username
     - Registered Number
     - Email
     - Clear photo of a valid ID
     - Selfie with the ID, with the ID held close to the face
     - If applicable, a video stating the current date while holding the ID may be required
   - For resetting passwords (login or transaction):
     - Full Name
     - Username
     - For login password reset: Registered Number, Email, Last Deposit Receipt, Main GCash/Maya Account
     - For transaction password reset: Valid ID photo and selfie with ID
   - For claiming or redeeming birthday or VIP birthday bonus:
     - Full Name
     - Username
     - Birth Date
     - Two valid IDs (IDs must clearly show the player’s name and birth date; no online images or xerox copies accepted)
     - Selfie while holding one of the valid IDs
   
4. **Guide the player to prepare the necessary documents:**
   - Confirm that all ID and selfie photos are clear, readable, and focused
   - Ensure IDs are physical (not online images or xerox copies)
   - Advise the player to hold the ID close to their face in selfies

5. **Request the player to submit all required documents and information through the designated verification channel (e.g., via the Rewards Center or support ticket).**

6. **Verify the submitted documents and information:**
   - Check that all files are clear, readable, and match the information provided
   - Confirm that the IDs include the player’s name and birth date where applicable
   - For selfies, verify that the ID is held close to the face and the face is clearly visible
   
7. **Perform additional checks if necessary:**
   - If the verification involves a video (e.g., stating today's date while holding the ID), confirm the correctness and clarity
   - Escalate to the appropriate department if documents are illegible or incomplete

8. **Based on the verification outcome:**
   - **If documents are satisfactory:**
     - Proceed with account verification, unfreezing, or process the password reset as requested
     - Notify the player of successful verification and next steps
     - For bonus claims, authorize the bonus and inform the player it will be credited after processing
   - **If documents are insufficient or invalid:**
     - Inform the player of the specific issues (e.g., unclear ID, missing info)
     - Advise the player to resubmit clearer documents
     - If the player cannot provide the required documents, explain that assistance cannot be provided until the requirements are met

9. **Complete the case:**
   - Record all actions, submissions, and verification results
   - Communicate clearly with the player regarding the status of their request
   - Close the ticket or update the support system accordingly

## Notes

- Always ensure that players understand that IDs must be physical and clearly visible; online images or xerox copies are not accepted.
- Selfies must show the ID held close to the face with clear visibility of both the face and ID details.
- For account unlocking, a video stating the current date while holding the ID may be required, as per the latest verification procedures.
- The entire process aims to confirm player identity securely and efficiently, following the conditions in the FAQs.

## Key points for communicating with players

- Emphasize the importance of clear, readable photos of IDs and selfies.
- Clarify that IDs must be physical, not online or xerox copies.
- Explain that verification is required for account unlocking, password resets, and bonus claims.
- Advise players to prepare all required documents before submission to avoid delays.
- Reassure players that their data is handled securely during verification.