# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request.**  
   Determine if the player is submitting documents for identity verification, password reset, deposit verification, birthday bonus claim, or VIP bonus redemption, based on their inquiry or case.

2. **Gather player information.**  
   Collect the following details from the player:  
   - Full name  
   - Username  
   - Registered number (if applicable)  
   - Registered email (if applicable)  
   - Last deposit receipt (if relevant)  
   - Main GCash or PayMaya account (if relevant)  
   - Date of birth (for birthday bonus eligibility)  

3. **Instruct the player to prepare the necessary documents.**  
   Depending on the scenario, request the player to submit the following:  
   - **Valid ID(s):** Ensure IDs are physical (not online images), clearly visible, and the name matches the account name.  
   - **Selfie holding the ID:** The player must hold the ID near their face, with their face clearly visible.  
   - **Additional images or videos (if required):** For password resets or verification, a video stating the current date while holding the ID may be necessary.  

4. **Specify the document requirements based on the verification purpose:**  
   - **For identity verification, password resets, or updating personal data:**  
     - Provide clear, readable images of valid ID(s) and a selfie with the ID.  
   - **For birthday bonus claim:**  
     - Valid for VIP4 or higher players, claim only on correct birth date.  
     - Submit two valid IDs, a selfie with an ID, and ensure IDs are clear and readable.  
   - **For deposit verification (GCash/PayMaya):**  
     - Submit a detailed receipt showing sender and recipient info, ensuring clarity.  
   - **For deposit or withdrawal verification in general:**  
     - Provide relevant screenshots or receipts according to instructions.

5. **Verify the submitted documents:**  
   - Check that the IDs are physical and match the player's account name.  
   - Confirm all images are clear, legible, and not edited or online screenshots.  
   - For selfie images, verify the person's face matches the ID, and the ID is held clearly near the face.  
   - For videos, ensure the player states the current date and holds their ID visibly.  

6. **Perform system checks or back-office review:**  
   - Confirm the consistency of the submitted documents with existing account data.  
   - Cross-verify receipt details for GCash/PayMaya deposits.  
   - For password reset requests, assess the completeness of document submission.  

7. **Determine verification success or failure:**  
   - **If the documents are clear, valid, and match the account details:**  
     - Approve the verification.  
     - Proceed with relevant process (e.g., credit bonus, reset password, approve deposit).  
   - **If the documents are unclear, invalid, or do not match:**  
     - Inform the player about the failure and request resubmission with clearer images.  
     - Explain that verification requires clear, singular, physical ID images, and proper selfies.

8. **Handle special cases:**
   - For birthday bonus claims, ensure the player is eligible on their actual birthday and has provided all required documentation.  
   - For VIP bonuses or special promotions, verify the player's VIP level and document sufficiency before crediting the bonus.

9. **Complete the process and communicate the outcome:**  
   - Confirm to the player whether verification was successful or not.  
   - If successful, proceed with crediting bonuses, resetting passwords, or approving deposits.  
   - If unsuccessful, advise on resubmission or alternative steps, including escalation if needed.

10. **Escalate for further review if necessary:**  
    - Cases with inconsistent or suspicious documents should be escalated according to the company’s compliance protocols.

## Notes

- Always ensure the ID photos and selfies are clear, with no obstructions or edits.  
- For identity verification, the ID must be physical and match the account name exactly.  
- The selfie must clearly show the player holding the ID near their face.  
- When requesting additional verification (video or multiple images), inform the player of the importance of adhering to instructions for quick processing.  

## Key points for communicating with players

- Clearly explain the requirements: quality, type, and format of documents.  
- Emphasize that IDs must be physical and match the account name.  
- Remind players that verification documents are used solely for identity confirmation and compliance.  
- Be patient and polite, especially if resubmission is necessary.  
- Escalate cases with conflicting or suspicious documents to the compliance team immediately.