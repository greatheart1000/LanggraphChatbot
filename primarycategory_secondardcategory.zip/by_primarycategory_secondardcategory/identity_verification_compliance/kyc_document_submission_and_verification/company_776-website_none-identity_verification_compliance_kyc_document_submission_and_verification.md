# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Determine the reason for the verification request**  
   - Identify whether the player is submitting documents for account recovery, password reset, identity verification, or claiming the Birthday Bonus (see FAQs 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23).  
   - Confirm the player's eligibility, e.g., for the Birthday Bonus, ensure VIP3 status or higher.

2. **Request the necessary documentation from the player**  
   - Ask the player to submit:  
     - Full name  
     - Username  
     - Valid ID (clear, readable, physical ID, not photocopy or online ID)  
     - Selfie holding the ID (clear, face visible, ID close to face)  
     - For password resets or account recovery: additional items such as registered number, registered email, last deposit receipt, or a video stating the current date (see FAQs 1, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23)  
   - For the Birthday Bonus, also request two valid ID photos showing date of birth.

3. **Verify the submitted documents**  
   - Confirm that the ID is a physical, readable document showing full name and birthdate or relevant details (see FAQs 13, 17, 23).  
   - Ensure ID photos are clear, and selfies clearly depict the player's face and ID (see FAQs 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 18, 19, 20, 21, 22, 23).  
   - If a video is requested (for password reset or account recovery), confirm the player states the current date clearly while holding the ID in the video (see FAQs 10, 11, 12).

4. **Check for compliance with document requirements**  
   - Ensure that the ID provided is not an online or photocopy version; it must be a physical document (see FAQs 13, 17).  
   - Verify that all images are legible, and details are visible and match the player's account information.  
   - For identity verification related to the Birthday Bonus, confirm both ID sides are provided and the selfie holds a valid ID showing the birthdate (see FAQs 4, 5, 6, 7, 8).

5. **Conditionally request additional verification if needed**  
   - For account recovery or password reset, additional documentation such as deposit receipts, registered mobile number, or email may be requested if necessary to confirm ownership (see FAQs 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22).  
   - For unbinding or complex cases, more verification steps may be required to ensure security.

6. **Perform back-office verification**  
   - Confirm that all submitted documents match the registered account details (name, birthdate).  
   - Check that the ID is valid, physical, and readable.  
   - Validate the selfie and video (if submitted) to ensure they meet the clarity and timing requirements.

7. **Decide on approval or rejection**  
   - If all documents are correct and verified, approve the verification request and proceed with the intended process: password reset, account recovery, bonus claiming, or identity confirmation.  
   - If documentation is insufficient, unclear, or invalid, inform the player of the missing or problematic items and guide them to resubmit with better quality.  
   - For ID discrepancies (e.g., name mismatch), inform the player to provide correct documentation.

8. **Complete the process and communicate outcome**  
   - For successful verifications:  
     - Confirm the process completion — e.g., password reset, bonus credited, account recovered.  
     - For bonus claims, notify the player that the bonus will be distributed automatically or within the specified timeframe (up to 12 hours for Rewards Center, see FAQs 4, 6).  
     - For account or security recovery, advise the player to log in or follow through with the next step.
   - For unsuccessful verification:  
     - Clearly explain the reasons based on the checks.  
     - Offer the player an opportunity to resubmit correctly.

9. **Close the case or escalate if necessary**  
   - If the verification involves suspicion of fraud or cannot be validated, escalate the case according to internal security protocols.

## Notes
- Always ensure all submitted images are clear and legible, and IDs are current and valid.  
- The verification process must follow the policies for responsible gaming and account security, and all validations must be based on the provided documentation matching the player's details.

## Key points for communicating with players
- Clearly explain what documents are needed and why.  
- Remind players that IDs must be physical and not photocopies or online images.  
- Inform players about the verification timeline — usually up to 12 hours for bonus distribution after verification.  
- Encourage players to submit high-quality images to avoid delays or rejection.