# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive verification request or inquiry from the player**.  
   - Confirm whether the player is seeking to verify identity, deposit, or withdrawal.

2. **Gather all required information from the player**, based on the verification type:  
   - For general identity verification:  
     - Username  
     - Full name  
     - Phone number  
     - Current balance  
     - A screenshot of the linked e-wallet profile (if applicable)  
     - Last deposit receipt (if applicable)  
     - Government-issued ID  
     - Selfie holding ID  
   - For deposit verification:  
     - Deposit record  
     - Payment receipt from GCASH or MAYA (if applicable)  
     - Ensure reference number, date, and time match on both documents  
     - Include username in the submission  
   - For withdrawal verification:  
     - Withdrawal record  
     - Related receipts  
     - Clear photo ID  
     - Selfie holding ID  
     - Screenshot of linked e-wallet profile (if applicable)  
     - Last deposit receipt (if applicable)  

3. **Request and confirm submission of documents**.  
   - Instruct the player to send all required documents via the designated support submission channel.  
   - Emphasize the importance of including their username on all documents to prevent delays.

4. **Perform initial checks in the system / back office**.  
   - Verify that the provided documents contain the correct username.  
   - Confirm that deposit and payment receipts (if applicable) match in reference number, date, and time.  
   - For deposit verification, ensure the deposit record and receipt are consistent.  
   - For withdrawal verification, verify the withdrawal record and related receipts.

5. **Evaluate documentation sufficiency**.  
   - Check if all required documents are submitted and are clear and legible.  
   - Confirm the user's identity and transaction details are adequately verified by the provided documents.  
   - If any documents are missing, unclear, or do not match, inform the player and request clearer or additional documents.

6. **Proceed with verification completion or escalate if necessary**.  
   - If all documents are verified and match the required criteria, mark the verification as successful.  
   - If unable to verify due to missing or inconsistent details, escalate according to internal policies or inform the player of the need for further clarification or documentation.

7. **Notify the player of the verification outcome**.  
   - Confirm successful verification and update system records.  
   - If verification fails, explain the reasons and advise on next steps (e.g., resubmission, additional documents).

8. **Close the case** once verification is completed or rejected.  
   - Make sure all actions and communications are documented thoroughly.

## Notes

- When submitting deposit receipts from GCASH or MAYA, departments must retrieve the deposit receipt, include the username, and send through the designated submission channel for verification.  
- Verify that all submitted documents include matching reference numbers, dates, and times to avoid delays.  
- Without an official receipt, deposit verification cannot be completed.

## Key points for communicating with players

- Always instruct players to include their username on every document submission.  
- Clarify that the submission must be clear and legible to avoid delays.  
- Inform players that verification may take some time depending on the completeness and clarity of their documents.