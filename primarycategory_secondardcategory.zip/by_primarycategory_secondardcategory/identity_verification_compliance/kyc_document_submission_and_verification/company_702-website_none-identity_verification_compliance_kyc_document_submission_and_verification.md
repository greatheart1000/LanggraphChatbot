# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Initiate the verification request**:
   - When a player needs to verify their identity, inform them that they are required to submit the necessary documents for KYC verification.
   - Clarify that the documents must be clear, readable, and within the maximum file size limit of 10MB.

2. **Collect required information and documentation from the player**:
   - Request the player to provide:
     - Full Name
     - Username
     - For identity verification:
       - A clear picture of a valid ID (e.g., government-issued ID)
       - A selfie holding the valid ID close to the face, ensuring all details are visible
     - For resetting passwords (if applicable):
       - Also request Registered Number, Registered Email, Last Deposit Receipt, and their Main GCash/Maya Account (if involved)
       - Alternatively, for specific reset processes, ask for a video stating the current date with the ID, if necessary
   - Remind the player to ensure all uploaded images are clear and do not exceed 10MB.

3. **Verify the completeness and quality of submitted documents**:
   - Check that the ID and selfie images are:
     - Clear and readable
     - The ID is held close to the face in selfies, with all details visible
   - Confirm that all requested information has been provided.

4. **Perform system and manual checks**:
   - Upload the documents into the verification system or back-office platform.
   - Confirm that the documents match the player’s details (Full Name, Username).
   - Verify that the ID type is valid and the images meet quality requirements.

5. **Determine the verification outcome**:
   - If all documents are clear, readable, and match the player's details:
     - Approve the verification.
     - Notify the player that their identity has been successfully verified.
   - If any documents are unclear, incomplete, or do not meet the requirements:
     - Inform the player that the verification is unsuccessful due to the quality or completeness issues.
     - Advise them to resubmit clear images or additional documentation if needed.

6. **Handle special cases and additional steps**:
   - If the verification is pending or requires escalation:
     - Communicate expected timeframes for review.
     - Escalate to the appropriate department if further review is necessary.
   - If a player needs to reset their password or transaction password:
     - Follow the same document submission process, emphasizing the need for ID and selfie with ID images.
     - Confirm with the player that all required documentation has been received and is satisfactory.

7. **Close the case**:
   - Once verification is approved:
     - Update the player’s account status accordingly in the system.
     - Notify the player of successful verification and next steps (if any).
   - If verification fails:
     - Explain clearly the reason (e.g., unclear images, missing info).
     - Guide the player on how to resubmit correct documents or contact support if needed.

## Notes
- Always ensure the images are within the 10MB limit.
- The ID must be held close to the face for selfies, and all details must be clear.
- In case of doubt about document authenticity, escalate according to internal compliance procedures.

## Key points for communicating with players
- Clearly instruct players to provide high-quality, readable images.
- Remind players that verification will only proceed with correctly formatted and complete documentation.
- Inform players of the typical review times and escalation procedures if needed.