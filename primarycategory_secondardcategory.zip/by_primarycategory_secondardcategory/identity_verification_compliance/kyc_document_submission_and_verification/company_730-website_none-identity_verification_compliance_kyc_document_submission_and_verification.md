# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or inquiry regarding identity verification, KYC, or password reset.**
   
2. **Verify the player's identity requirements based on their request**:
   - If the player is requesting **KYC document submission or account verification**, inform them of the required documentation.
   - If the player is requesting **reset of login or transaction passwords**, proceed with relevant verification steps as outlined below.

3. **Collect necessary identification information and documents**:
   - For **KYC account verification**:
     - Physical valid ID (not an online copy)
     - Clear selfie with the ID held close to face, ensuring all details are readable
     - Main GCash/Maya account screenshot
   - For **password resets (login or transaction)**:
     - Full Name
     - Username
     - Valid ID (photo or scan)
     - Selfie with ID held close to face
     - For login password resets:
       - Registered Number and Email
       - Last Deposit Receipt
       - Main GCash/Maya account screenshot
     - For transaction password resets:
       - No additional documents required beyond ID and selfie, but ensure clarity and readability

4. **Instruct the player to submit clear, readable images of all required documents**:
   - All ID and selfie images must be clear and in focus.
   - The ID should be held close to the face in selfies to verify identity.
   
5. **Perform initial review of submitted documents**:
   - Check if all documents are clear, readable, and meet the specific requirements.
   - Confirm that the ID matches the player's account details.
   - Ensure selfies clearly show the ID and the player's face.

6. **Evaluate document verification**:
   - If all documents are correct, clear, and meet requirements:
     - Proceed to verify in the system.
     - If additional verification is needed (e.g., name discrepancy), inform the player that further checks may be required.
   - If documents are unclear or incomplete:
     - Inform the player to resubmit clearer copies.
     - Provide specific guidance on what is missing or unclear.

7. **Complete system verification process**:
   - Verify the provided ID and selfies within the back-office system.
   - Confirm all details match the player's account.
   - Check for any discrepancies, especially in name or identification details.

8. **Approve or reject the verification request**:
   - If approved, notify the player that their identity verification or password reset is successful.
   - If rejected:
     - Explain that verification failed due to unclear documents or discrepancies.
     - Advise the player on next steps, which may include resubmission or additional documentation.

9. **For deposit verification**:
   - Require a detailed receipt showing the sender and recipient information (GCash/PayMaya).
   - Confirm receipt accuracy in the system to process the deposit.

10. **Escalate cases with discrepancies or incomplete documentation for further review**:
    - If discrepancies cannot be resolved through initial verification, escalate to the relevant department for further review.

11. **Close the case once the verification or password reset is successfully completed or declined**:
    - Record all actions.
    - Communicate clearly with the player regarding the outcome.
    - Provide further instructions if applicable (e.g., resubmission, additional info).

## Notes

- Always ensure all documents are clear, readable, and held close to the face in selfies.
- Confirm that the ID used is physical (not online copies).
- Be explicit with players about the need for clarity and detail in documents.
- If there are name discrepancies or other issues, additional verification steps may be necessary.

## Key points for communicating with players

- Clearly explain the required documents for each process.
- Remind players to take clear, focused pictures, especially holding their ID close to their face.
- Inform players that verification may take some time depending on the clarity of submitted documents.
- Be patient and polite, especially if requesting resubmission of documents.