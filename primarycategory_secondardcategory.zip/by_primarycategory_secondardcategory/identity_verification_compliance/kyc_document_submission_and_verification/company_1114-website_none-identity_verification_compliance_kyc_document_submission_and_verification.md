# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or query related to identity verification, deposit verification, or withdrawal.**
   - Determine the purpose: deposit verification, account verification, withdrawal, or password reset.

2. **Gather necessary information from the player based on the request.**
   - For deposit verification (GCASH or MAYA):
     - Confirm the player has a successful payment receipt from GCash or MAYA.
     - Instruct the player to submit the receipt from GCash INBOX, as receipts from GCash Transaction are not accepted.
     - Ensure the receipt shows the amount, transaction date, and time.
   - For account verification or withdrawal:
     - Collect username, registered email, phone number, and valid proof of identity (ID).
     - For withdrawal requests, confirm the account details (bank account number or GCash account linked and verified).
   - For verification or password reset:
     - Request full name, a valid ID, and a selfie with the ID.

3. **Instruct the player to submit the required documentation through the designated platform or upload system.**
   - Emphasize that receipts must be from GCash INBOX and display the necessary details.
   - For ID verification, the ID must be valid and clear.

4. **Verify the submitted documents:**
   - Check that the receipt is from GCash INBOX and shows the amount, date, and time.
   - Confirm that the ID and selfie are clear and valid.
   - For transaction records, screenshots of successful payments or receipts should be provided if needed.

5. **Perform system and back-office checks:**
   - Verify that the details match the account information.
   - Confirm that the submitted documents meet the outlined requirements.
   - For withdrawal, ensure the linked account in the profile is correctly registered and verified.

6. **Decide on the outcome based on verification results:**
   - If documents are valid and all details are correct:
     - Proceed to credit the deposit or verify the account accordingly.
     - Inform the player that verification was successful and, if applicable, funds have been credited.
   - If documents are invalid, incomplete, or do not meet requirements:
     - Explain the specific issue to the player.
     - Request resubmission of correct documents if applicable.
     - Escalate to the relevant department if there are discrepancies or suspicion of fraud.

7. **Close the case once verification is complete:**
   - Confirm with the player that their issue has been resolved.
   - Document the verification process and outcome in the system.

## Notes
- Only receipts from GCash INBOX are accepted for deposit verification; receipts from GCash Transaction are not.
- For deposit verification, ensure the receipt clearly displays the transaction amount, date, and time.
- For account verification and password resets, the player must provide a selfie with a valid ID.
- Verification may include providing transaction records such as receipts or screenshots of successful payments.
- Accurate and verified account details are essential for successful withdrawals.

## Key points for communicating with players
- Always specify that receipts must be from GCash INBOX and show the correct details.
- Remind players to submit clear, legible images of their IDs and selfies.
- Clarify that unverified or incomplete documentation will delay processing.
- Be clear about escalation if suspicions arise or documents do not meet the requirements.