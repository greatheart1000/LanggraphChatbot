# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive player's request or query regarding KYC verification**.
   
2. **Determine the type of verification required**:
   - If the player needs to reset their login or transaction password, proceed with steps 3–5.
   - If the player is submitting documents for deposit verification, proceed with steps 6–8.
   - If the player is regarding identity verification for account access or compliance, proceed with steps 9–11.

3. **Collect required player information and documents**:
   - Full name
   - Username
   - Registered number
   - Registered email (if applicable)
   - Main GCash/Maya account (if applicable)
   - Last deposit receipt (if resetting login/transaction password)
   - A clear photo of a valid ID
   - A selfie holding the ID
   - For password resets, also gather a short video stating today's date while holding the ID.

4. **Verify completeness and clarity** of submitted images:
   - Ensure all images are clear, readable, and that IDs and selfies are legible.
   - Confirm that the ID is held close to the face in selfies.
   - For the video, confirm it states the current date and shows the ID clearly.

5. **Perform system verification and checks**:
   - Cross-check submitted information against existing account records.
   - Confirm that the last deposit receipt matches recent deposits.
   - Review uploaded deposit receipts or screenshots showing sender and recipient details if verifying deposits or withdrawals.
   - When necessary, generate and review the transaction invoice (e.g., via GCash/PayMaya Inbox).

6. **Evaluate whether all required documentation and information are sufficient**:
   - If all images are clear and all information is provided, proceed with approval.
   - If any document or detail is unclear, request the player to resubmit the necessary information with guidance on clarity.

7. **Process the verification or reset request**:
   - For identity verification (e.g., ID photo, selfie, video), verify that all requirements are met.
   - For deposit or withdrawal proof, confirm receipt details and match with transaction records.
   - For password resets, verify the matching details and documents.

8. **Complete the necessary system actions**:
   - Issue a new login or transaction password (if applicable).
   - Approve deposit/withdrawal verification.
   - Confirm identity verification approval.
   - If verification fails, inform the player of the specific reasons and instruct on re-submission.

9. **Inform the player of the results**:
   - If verification is successful, confirm completion and any next steps.
   - If additional documents are needed, specify exactly what is missing or unclear.
   - Advise on waiting times if applicable, following your site’s standard processing times.

10. **Escalate cases that cannot be verified due to discrepancies or insufficient documentation**:
    - Follow company protocol for escalation.
    - Inform the player that further review is needed and what steps may follow.

## Notes

- Always ensure images are high quality; blurry or incomplete images delay verification.
- When requesting document resubmission, clarify the specific issues, e.g., clarity, completeness, or matching details.
- For password resets, ensure the player provides all verification elements listed (ID photo, selfie, video).
- Deposit proofs must clearly show GCash/PayMaya sender and recipient details, and screenshots should be under 20MB.

## Key points for communicating with players

- Clearly explain what documents are needed for each verification step.
- Remind players to submit clear and readable images.
- Avoid requesting unnecessary information; only ask for what is outlined in the SOP.
- Keep explanations concise and professional, emphasizing security and compliance standards.