# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the purpose of the verification request**  
   - Determine if the player is submitting documents for account verification, deposit verification, password reset, birthday bonus claim, VIP bonus claim, or other compliance-related processes, based on the player's inquiry or request.

2. **Inform the player of required documentation**  
   - Clearly communicate which documents they need to submit, according to the purpose:  
     - For account or identity verification: Full Name, Username, Valid ID (clear photo), Selfie with ID.  
     - For deposit verification: Detailed deposit receipt or screenshot showing sender and recipient info, date/time, and amount.  
     - For password resets: Similar to account verification with additional details as needed (register number, email, last deposit receipt, main GCash/Maya account).  
     - For birthday or VIP bonuses: Full Name, Username, Birth Date, Valid IDs, Selfie holding IDs.  

3. **Guide the player on image upload procedures**  
   - Instruct the player to click the File button to select images from their device.  
   - Remind them that images must be clear, readable, and not exceed 20MB in size.  
   - Advise capturing ID using the back camera, in a well-lit area, close to the camera, and ensuring all details are visible.  
   - For selfies, ensure the ID is held close to the face, and the face is clearly visible.  
   - Optionally, recommend having someone else take the photo for best clarity.

4. **Player uploads documents**  
   - Verify that the player has uploaded all required images: ID, selfie, deposit receipt/screenshot, as applicable.  
   - Confirm that the images meet the clarity and readability standards.  
   - If images are unclear or do not meet requirements, instruct the player to re-upload clearer images.

5. **Perform preliminary checks in the system**  
   - Confirm that the uploaded images properly show the required information (ID details, date and time on receipts, sender/recipient info).  
   - Ensure all images are uploaded successfully and within the size limit.  
   - Cross-verify the submitted details with the existing account information (name, username, email, etc.).

6. **Coordinate verification in back office**  
   - Forward the images and relevant details to the verification team or automate system checks, according to company procedures.  
   - Check for clear ID images, matching details, valid deposit receipts, and self-identification.

7. **Determine verification outcome**  
   - **If all documents are clear, readable, and match account details:**  
     - Approve the verification and update the player's account status accordingly.  
     - Notify the player of successful verification with any next steps.  
   - **If documents are unclear, mismatched, or incomplete:**  
     - Inform the player to re-upload clearer images or provide additional documentation.  
     - Escalate if necessary, following internal escalation protocols.

8. **Special conditions and exceptions**  
   - For players requiring verification of deposit receipts, ensure the receipt contains sender/recipient info, date, and amount.  
   - For VIP or birthday bonuses, verify that IDs and selfies meet the specified requirements.  
   - For discrepancies or missing info, communicate clearly with the player to gather further proof or re-upload images.

9. **Complete the verification process**  
   - Once verified, communicate the result to the player and finalize updates in the system.  
   - If verification fails, inform the player of the reason and advise on corrective actions or next steps.

## Notes
- Always ensure that all ID images and selfies are clear and fully visible; photos should be taken in well-lit environments and without obstruction.  
- Selfies should be taken with ID held close to the face, with the ID details clearly visible.  
- Deposit receipts should be screenshots from official transaction histories showing all relevant details (sender, recipient, date, amount).  
- During password reset requests, in addition to document submission, the player might need to provide a video stating today's date holding their ID for security confirmation.

## Key points for communicating with players
- Emphasize the importance of clear, legible images to avoid delays.  
- Remind players that IDs must be valid and document details should not be obscured.  
- Clearly explain each step they need to follow for uploading images.  
- Keep explanations consistent with official process requirements to ensure clarity and compliance.