# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive player inquiry or notification about KYC verification requirement**:  
   - Verify that the player needs to complete KYC verification for account verification, deposit, bonus claim, or other compliance purposes (supported by FAQs).

2. **Explain the KYC requirements to the player**:  
   - Inform the player that they must provide:
     - A clear photo of their valid government-issued ID (front and back if applicable),
     - A selfie holding their ID.  
   - Emphasize that all personal information must match the account details exactly, and the documents must be readable and valid (supported by FAQs: "To complete KYC verification, you need to provide: Front of your valid ID card, Back of your valid ID card, Selfie holding your ID card”).

3. **Guide the player on preparing documents**:  
   - Confirm that the ID is a physical, government-issued document (e.g., Driver's license, Passport, Voter's ID, etc.) and not a digital ID.
   - Advise ensuring all images are clear, complete, and well-lit.

4. **Assist the player in uploading documents**:  
   - Direct players to access the verification upload section in their account profile settings.
   - Instruct them to upload the front of the ID, back of the ID (if required), and a selfie showing the ID.
   - Remind them that all information must be accurate and visible.

5. **Check the initial submission for compliance**:  
   - Ensure uploads are clear, readable, and meet format requirements.
   - Confirm that the name and details in the documents match the account information.
   - If self-reported info or documents do not match, advise the player to re-upload correct images.

6. **Inform the player of the estimated processing time**:  
   - Let them know that the verification process takes approximately 24 to 72 hours, depending on system volume ("KYC verification process takes 24 to 72 hours to complete").

7. **In case of upload issues or failed verification attempts**:  
   - Advise:
     - Closing and reopening the app or clearing cache/history if uploading via mobile or desktop.
     - Restarting the app or reinstalling if on mobile.
     - Waiting 1-2 hours before reattempting, as the system may be processing.
   - Confirm that the player has granted all necessary permissions on mobile devices before uploading photos ("KYC can only be completed by the user themselves. After installing the app on mobile, allow the required permissions").

8. **Follow-up on verification status**:  
   - After the processing period, check the approval status in the backend system.
   - If the verification is approved, notify the player and confirm their account is now verified.
   - If rejected, review the rejection reason; typically, poor image quality, mismatched info, or unclear documents cause rejection.

9. **If rejected, instruct the player on re-submission**:  
   - Advise them to re-upload clear images, ensuring all details are visible and match their account info.
   - If needed, ask for new documents or better quality images.

10. **Handle special cases or updates**:  
    - For players needing to change their verified ID or profile info, advise to submit updated documents through the same process, ensuring they meet all initial requirements.
    - For verification of additional documents (if applicable), guide them accordingly.

11. **Confirm completion of verification**:  
    - Once approved, notify the player that their account is verified.
    - Encourage them to complete any related actions such as claiming bonuses or enabling withdrawal options if applicable.

## Notes

- The verification process requires user-initiated uploads; agents should not attempt to verify documents manually.
- All personal information and documents must match the account details exactly to be accepted.
- The process may take longer during high-volume periods but typically ranges from 24 to 72 hours.
- Repeated submissions and poor-quality images can delay verification; advise players to follow guidelines carefully.

## Key points for communicating with players

- Clearly explain the required documents: valid ID and selfie holding the ID.
- Emphasize the importance of clarity and matching details.
- Remind players about the processing timeframe (24–72 hours).
- Guide them on troubleshooting upload issues (clear cache, restart app, permission settings).
- Reassure players that they will be notified upon status update.
- Inform players that verification is self-initiated and cannot be expedited.

---