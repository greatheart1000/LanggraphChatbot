# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request for verification or withdrawal, or identify the need for account ownership confirmation.**  
   - This may include requests for password reset, withdrawal, account reactivation, or verification for deposit or withdrawal purposes.

2. **Gather necessary information from the player:**
   - For deposit verification:
     - Game username
     - Screenshot of the GCASH/PayMAYA receipt from the app Inbox
   - For account ownership or identity verification:
     - Registered username
     - Full name
     - Valid ID picture (e.g., government ID)
     - Selfie holding the ID
     - Linked account details (such as GCASH/PayMAYA numbers)
     - Last deposit or game activity receipt or screenshot (for withdrawal purposes)
     - Email address
     - Phone number

3. **Advise the player to prepare the required documentation or information:**
   - Ensure the screenshots are clear and show the relevant details.
   - When submitting receipts, avoid using old QR codes.
   - For ID and selfie submissions, ensure the ID is valid and the selfie is clearly holding the ID.

4. **Instruct the player to submit the documents/receipts:**
   - Support team can request players to send the screenshots or files via the designated support communication channel.
   - For deposit receipts, specifically:
     - Send the screenshot of the GCASH/PayMAYA receipt from the Inbox along with the username.
   - For identity and ownership verification:
     - Send valid ID, selfie with ID, and any requested account details.

5. **Back-office verification process:**
   - Confirm receipt of all required documentation.
   - Check that screenshots clearly display transaction details or ID information.
   - Cross-verify submitted information with existing account data.
   - For deposit verification:
     - Ensure the receipt matches the transaction details.
   - For identity verification:
     - Confirm ID validity and match with registered details.
   - For ownership verification:
     - Verify account details such as username, linked accounts, and ownership proof.

6. **Decide if the provided documentation is sufficient:**
   - **If all required information is complete and clear:**
     - Approve the verification.
     - Update the player's account status to verified.
     - Notify the player of successful verification.
   - **If information is incomplete, unclear, or missing:**
     - Request the player to resend clearer images or missing details.
     - Do not proceed until complete and satisfactory documentation is received.

7. **Handle edge cases or additional verification steps:**
   - If required, escalate cases where documentation quality is insufficient or suspicion of fraud arises.
   - Follow internal protocols for further verification, such as manual review or escalation.

8. **Close the case once verification is complete:**
   - Confirm that the player's account is verified or their request has been processed.
   - Communicate the outcome clearly to the player.

## Notes
- Always ensure screenshots are clear and transaction details are visible.
- Do not accept outdated QR codes or unclear documents.
- Multiple types of verification (deposit, identity, ownership) may require different sets of documents as specified.
- Escalate cases where documentation cannot be verified or if fraud suspicion exists.

## Key points for communicating with players
- Clearly instruct on what documents or screenshots are needed.
- Emphasize the importance of clarity and correct image orientation.
- Reiterate the requirement to avoid outdated QR codes and ensure all information is legible.
- Keep communication professional, transparent, and supportive throughout the process.