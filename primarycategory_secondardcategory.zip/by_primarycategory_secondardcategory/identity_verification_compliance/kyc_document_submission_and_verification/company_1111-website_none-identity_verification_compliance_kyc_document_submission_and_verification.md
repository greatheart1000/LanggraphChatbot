# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request**  
   - Determine whether the player is submitting documents for withdrawal verification, deposit verification, password reset, or other compliance checks based on their inquiry or system trigger.

2. **Gather necessary information and documents from the player**  
   - For withdrawal verification, request the following:
     - Username
     - Withdrawal recipient name (name to which the withdrawal will be issued)
     - Contact email
     - Phone number
     - Current account balance
     - Last game played
     - Screenshot of the last deposit
     - A selfie of the player holding a valid ID
     - A copy of the valid ID
   - For GCASH deposit verification, request:
     - Screenshot of the receipt from GCASH INBOX (not GCASH Transaction)
     - Ensure the receipt shows the deposit amount, date, and time
   - For reset transaction password, request:
     - Full name
     - Valid ID photo
     - Selfie holding the ID

3. **Verify the provided documents and information**  
   - Check that the screenshots or photos are clear and show all necessary details (e.g., deposit amount, date/time, ID validity)
   - Ensure that the receipt is from GCASH INBOX, as receipts from GCASH Transaction are not accepted
   - Confirm that the selfie clearly shows the player holding a valid ID
   - Review the ID proof for validity and clarity

4. **Perform back-office/system checks**  
   - Confirm the player's details match the submitted documents (e.g., name, contact info)
   - Verify the deposit receipt details against the transaction
   - For withdrawal verification, cross-check the provided details with account records, including last deposit and last game played

5. **Assess the completeness and validity of the submission**  
   - If all required documents are clear, complete, and match system records:
     - Proceed to approve the verification
   - If any document is missing, unclear, or invalid:
     - Request the player to resubmit the missing or unclear items

6. **Complete the verification process**  
   - Update the player's account status to verified in the system
   - Inform the player of successful verification and any next steps (e.g., withdrawal processing, account reset)

7. **Handle cases of insufficient or invalid documents**  
   - Clearly communicate to the player the specific reasons (e.g., blurry receipt, invalid ID)
   - Guide them to re-submit correct and clear documents
   - If verification cannot be completed, escalate or advise on next steps following company policies

## Notes

- Only receipts from GCASH INBOX are accepted; receipts from GCASH Transaction are not valid for verification.
- Provide clear instructions and polite guidance if documents need to be re-uploaded.
- Always verify document details to prevent fraud or errors.
- Escalate cases where documents are suspicious, tampered with, or repeatedly invalid.

## Key points for communicating with players

- Confirm the exact documents needed for each verification type
- Emphasize that screenshots must be clear and show all required details
- Clarify that only receipts from GCASH INBOX are accepted
- Politely notify players when they need to re-submit documents or when verification is successful