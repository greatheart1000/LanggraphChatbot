# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the purpose of the player's inquiry or request for verification.**  
   - Determine if the player is submitting documents for account verification, password reset, withdrawal, deposit verification, claiming bonuses, or other compliance-related processes, based on their inquiry or request.

2. **Request the required documentation from the player.**  
   - Gather all relevant details as per the specific process:
     - Full Name
     - Username
     - Registered Number and/or Registered Email (if applicable)
     - Last Deposit Receipt (for password or withdrawal resets)
     - Main GCash or Maya account (if applicable)
     - Valid ID(s): ensure they are laminated, clear, and readable
     - Selfie with valid ID(s): ID held close to face, clear and well-lit
     - For VIP or birthday bonus claims: two valid IDs, and a selfie holding both IDs
   - Explain to the player that all documents must be clear, legible, and not covered.

3. **Verify the clarity and authenticity of submitted identification documents.**  
   - Confirm ID is laminated, recent, and in focus.
   - Check that ID details are fully visible and readable.
   - Ensure the selfie/photo shows the ID held close to the face without covers or obstructions.
   - Advise the player to use the back camera, avoid movement during the photo, and be in a bright environment.

4. **Check if all required documents are provided.**  
   - If any document or information is missing or unclear:
     - Inform the player of the missing or unreadable items.
     - Request resubmission with clear, focused images.
   - If all documents are complete and clear, proceed to the next step.

5. **Perform system and back-office verification.**  
   - Cross-reference provided details with the player’s account information.
   - Confirm that ID matches the player’s registered details where applicable.
   - For deposit proof: verify screenshots of payment proofs showing transaction details, sender, recipient, and confirmation messages.
   - For deposit or transaction resets: ensure provided proof and self-identification documents meet the criteria.

6. **Assess the validity of the submitted documents.**  
   - Confirm IDs are not unlaminated or expired.
   - Check that selfies show the ID and face clearly, with no covers.
   - Validate the authenticity of the documents against the company’s accepted ID requirements.
   - For VIP or birthday bonus: verify that the date range is correct and the ID details are readable.

7. **Decide on the approval or further action.**  
   - If all documents are valid and verified:
     - Complete the verification process in the system.
     - For account verification: mark the account as verified and notify the player.
     - For password or transaction resets: update the account with the verified status and proceed accordingly.
     - For bonus claims: approve and add the bonus to the player’s account.
   
   - If any document is invalid or incomplete:
     - Explain the reason to the player.
     - Request re-submission with the correct or clearer documents.
     - If repeated issues persist, escalate for manual review.

8. **Finalize the process and communicate result.**  
   - Confirm verification success or failure.
   - Provide clear instructions on next steps (e.g., waiting time, re-submission).
   - Encourage the player to ensure future submissions are clear and compliant.
   - Close the case after the process is completed or escalated.

## Notes

- All ID submissions must be recent, laminated, and with focused, well-lit images.
- Selfies or photos with ID must be clear, with the ID held close to the face, showing all details.
- For VIP birthday bonus or claims, provide two valid IDs and a selfie holding both IDs.
- Deposit proof should include a screenshot showing full transaction details from GCash or PayMaya.
- When verifying deposit details, ensure the screenshot includes sender/receiver info and confirmation messages.
- If the player cannot provide clear, compliant documents after multiple requests, escalate to the compliance team.

## Key points for communicating with players

- Always request high-quality, focused images showing all details.
- Explain why certain requirements are necessary for security and compliance.
- Be polite and clear about the need for re-submission if documents are unclear or invalid.
- Remind players that IDs must be laminated and recent, and selfies must clearly show both face and ID.
- Reassure players that verification is a routine process to protect their account and funds.