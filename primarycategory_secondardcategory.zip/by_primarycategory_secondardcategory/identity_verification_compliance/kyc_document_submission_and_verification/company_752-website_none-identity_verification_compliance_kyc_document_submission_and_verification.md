# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or trigger for identity verification or account assistance related to resetting passwords or confirming identity.**  
   *Note: This includes password resets for login, withdrawal, or transaction purposes, and account verification requests.*

2. **Explain the required documentation and verification steps to the player, emphasizing the importance of clear and readable images.**  
   - For password resets (login, transaction/withdrawal): request Full Name, Username, Registered Number, Registered Email, Last Deposit Receipt, Main GCash/Maya account details, Picture of Valid ID, and Selfie with a valid ID.  
   - For account verification or issues: require a clear selfie holding a valid ID, a video stating today's date while holding the ID, and possibly deposit/transaction records.

3. **Instruct the player to prepare and submit the following documents and information:**
   - Valid ID showing their full name and, if applicable, birthdate.
   - A selfie holding the ID close to the face, ensuring all ID details are clear.
   - For specific cases (e.g., birthday bonus, password reset if names don’t match), request additional documentation such as deposit receipts, email screenshots, profile screenshots, or ID showing the birthdate.

4. **Verify that the submitted images and documents meet the quality standards:**
   - Check that ID details are clear and readable.
   - Confirm that selfies clearly show the player holding the ID close to the face.
   - Ensure all documents are well-lit, in focus, and without obstructions.

5. **Assess if all necessary documents are provided and meet quality standards:**  
   - If **all required documents are received and clear**, proceed to the verification process.
   - If **any required documents are missing or unclear**, inform the player politely of the specific deficiencies and request re-submission. Only proceed once complete, clear documents are provided.

6. **Perform back-office checks or system verification:**
   - Confirm the player's identity by matching the ID details with their account information.
   - Verify the submitted deposit receipts against the transaction record in the deposit history (if applicable).
   - For password resets, confirm the provided details align with account data.
   - For birthday bonuses, verify the ID shows the correct birthdate.

7. **Complete the verification process in the system:**
   - If identity is confirmed, update the account status or perform the requested action (e.g., reset password, unbind wallet, verify deposit).
   - If verification fails, explain the reason to the player and request further documentation or additional proof if necessary.

8. **Notify the player of the outcome:**
   - If successful, inform them that the process is complete and provide any new passwords or confirmation details.
   - If unsuccessful, explain the reason clearly, and if applicable, advise on next steps or escalation procedures.

9. **Record all submitted documents and correspondence securely for audit purposes.**  
   - Save images, screenshots, and relevant details in the player's account history or support ticket.

10. **Close the case or indicate completion in your support system.**

## Notes

- Always ensure ID and selfie images are clear and readable; use the rear camera and good lighting.
- For password resets involving name mismatches, additional documentation such as deposit receipts, email screenshots, and profile screenshots are necessary.
- Verification is required for resetting passwords, unbinding wallets, claiming bonuses, or resolving deposit/withdrawal issues.
- If requested documents are insufficient or unclear, do not proceed until proper documentation is provided.
- Maintain privacy and securely handle all personal documents submitted by players.

## Key points for communicating with players

- Clarify the exact documents needed and why clarity is important.
- Remind players to ensure their ID details are readable and the selfie clearly shows their face and ID.
- Be patient and polite, especially when requesting re-submission of documents.
- Explain that verification is a standard process to ensure account security and compliance.