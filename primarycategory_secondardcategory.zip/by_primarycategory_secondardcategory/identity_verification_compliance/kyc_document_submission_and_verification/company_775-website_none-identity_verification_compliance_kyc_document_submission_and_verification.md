# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request.**  
   - Determine if the player is required to verify their identity for account verification, birthday bonuses, deposit verification, password resets, or withdrawal claims.

2. **Request the necessary documents from the player based on the verification purpose.**  
   - For identity checks and password resets:  
     - Full name  
     - Username  
     - Registered number  
     - Valid ID photo (clear, accessible, and physical—not online only, laminated preferred)  
     - Selfie holding the valid ID (ensure all ID details are readable, face is visible, in a bright place, camera's back camera preferred)  
   - For deposit verification:  
     - Detailed deposit receipt including sender and recipient info (e.g., GCash/PayMaya)  
     - Screenshots or images of the transaction inbox showing the deposit (e.g., GCash inbox)  
   - For birthday bonuses or VIP claims:  
     - Two valid IDs (IDs must match account name, clear, laminated)  
     - Selfie holding the IDs  
   - For password resets (login or transaction):  
     - Last deposit receipt (if applicable)  
     - Main GCash/Maya account details  

3. **Verify the clarity and authenticity of submitted documents.**  
   - Confirm that all ID images are clear, readable, and unmodified (no altering dates or names).  
   - Ensure selfies show the player clearly holding the ID without obstruction or movement.  
   - Confirm ID is a physical, laminated document (if applicable), not an online image only.  

4. **In case of deposit verification, confirm receipt and transaction details.**  
   - Review the deposit receipt for sender and recipient info.  
   - Check the screenshot or inbox image of the deposit transaction if provided.  
   - Verify that the information matches the deposit records.  

5. **Perform system checks and validation.**  
   - Upload or attach the documents into the verification system, ensuring file size does not exceed 20 MB.  
   - Cross-verify submitted information against the player's account data.  

6. **Evaluate the submitted documents and information.**  
   - If all documents are clear, readable, and meet the requirements, proceed with verification.  
   - If any document is unclear, incomplete, or does not meet the specifications, request the player to resubmit clearer images.  

7. **Complete the verification process in the back-office system.**  
   - Mark the account as verified once all conditions are satisfied.  
   - If additional verification (e.g., video or live confirmation) is required, request it per site rules.  

8. **Communicate the outcome to the player.**  
   - If verification is successful, inform the player that their account is now verified and any restrictions are lifted.  
   - If verification fails due to document issues, explain clearly what needs to be fixed or resubmitted.  
   - Guide the player on how to proceed with resubmission if needed.  

9. **Handle special cases such as disputes or suspected fraud.**  
   - Escalate cases with suspicious documents or inconsistent information to the relevant compliance or security team as per internal protocols.  

10. **Close the case once verification is complete or all issues are resolved.**  
    - Confirm that the player understands their verification status and next steps.  
    - Update the player's account status accordingly.  

## Notes

- All ID photos should clearly display all ID details, and selfies must include the player holding the ID in a well-lit, steady shot.  
- IDs must be laminated and physically present; online or digital IDs are not accepted unless explicitly confirmed otherwise.  
- Keep all received documents confidential and ensure data compliance during storage and handling.  

## Key points for communicating with players

- Clearly explain the required documents and take care to specify that IDs must be physical, laminated, and clearly readable.  
- Remind players to use the back camera for ID selfies and ensure good lighting and stability.  
- Emphasize that submission of clear, unaltered documents speeds up the verification process.  
- Inform players if additional verification (video, live ID check) may be necessary.