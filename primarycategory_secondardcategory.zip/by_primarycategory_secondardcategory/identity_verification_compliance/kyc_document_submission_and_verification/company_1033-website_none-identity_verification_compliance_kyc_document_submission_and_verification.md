# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player’s request or inquiry regarding KYC or deposit verification.**  
   - Clarify what specific verification the player needs (e.g., deposit verification, account verification for withdrawal).  
   - Identify the transaction details if relevant (e.g., deposit amount, payment method).

2. **Determine the required documents based on the player's request.**  
   - For GCASH deposit verification: request the GCASH INBOX RECEIPT and username.  
   - For account verification (withdrawals or account updates): request a valid government ID, a selfie with the ID, recent deposit slip or receipt, and confirmation of linked payment method.  
   - If the player is verifying deposit documents: inform them to include reference number, date, and time on all documents to ensure matching details.

3. **Instruct the player on how to submit the documents.**  
   - For deposit receipts:  
     - Take a screenshot of the receipt from GCASH INBOX or PayMaya.  
     - Include their username in the submission.  
     - Send the screenshot and username to support for verification.  
   - For account verification:  
     - Collect supporting documents as per the required fields, ensuring all information matches their account details.  
     - Optional: request a GCASH profile or a selfie with the ID if relevant.

4. **Verify the submitted documents for completeness and correctness.**  
   - Check that all required documents are provided:  
     - For GCASH deposits: the receipt, username, matching reference number, date, and time.  
     - For account verification: ID, selfie, deposit receipt, linked payment confirmation, and any optional documents.  
   - Confirm that all information matches what is on the player's account system.

5. **Perform system and manual checks.**  
   - Review the deposit receipt details against the transaction in GCASH (if accessible).  
   - Verify the ID and selfie match the player's account in the system.  
   - Confirm supporting documents are clear and legible.  
   - Ensure all details on the documents and data entered are consistent.

6. **Decide on the verification outcome based on findings:**  
   - If all required documents are provided, valid, and match the system data:  
     - Approve the verification.  
     - Notify the player that their documents have been successfully verified.  
   - If documents are insufficient, invalid, or mismatched:  
     - Inform the player of the specific issue (e.g., missing receipt, mismatched details).  
     - Request re-submission or additional proof if applicable.

7. **In case of missing or unverifiable data:**  
   - Clearly communicate that a deposit cannot be verified without an official GCASH receipt or required documentation.  
   - Suggest contacting GCASH customer support to obtain a proof of the transaction if the receipt is unavailable.  
   - Do not proceed with verification until all conditions are met.

8. **Complete the process by updating the player’s verification status in the system.**  
   - Mark the verification as successful or failed based on the review.  
   - Escalate any unresolved issues to the appropriate team if necessary.

## Notes
- Verification requires documents that are complete, legible, and match the player's account details.  
- For GCASH deposits, official receipt proof is mandatory for deposit verification; without it, deposit verification cannot proceed.  
- Always handle player data securely and in compliance with privacy policies.  

## Key points for communicating with players
- Clearly explain the specific documents required for their verification case.  
- Guide players on how to take proper screenshots or photos of receipts and IDs.  
- Inform players that verification is only complete after successful review of their documents and system checks.  
- Emphasize the importance of matching details (reference number, date, time, account info) for successful verification.