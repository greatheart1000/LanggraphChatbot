# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request**
   - Determine if the player is resetting a password, verifying identity for account recovery, claiming a bonus (e.g., Birthday Bonus), or fulfilling promotional requirements.
   - Clarify the specific process they are undertaking (e.g., password reset, bonus claim).

2. **Inform the player of the required documents**
   - Explain that verification requires:
     - Full Name
     - Username
     - Registered Number and Email
     - Valid physical ID (e.g., passport, driver’s license, or other accepted ID)
     - A selfie holding the valid ID
     - Additional documents if applicable (e.g., last deposit receipt for account recovery)

3. **Guide the player to prepare the documents**
   - Instruct the player to take clear, readable photos of:
     - The valid physical ID (front and, if applicable, back)
     - A selfie clearly holding the ID, with their face visible
   - Ensure the images are high quality, well-lit, and do not exceed 20 MB in file size

4. **Assist the player in uploading documents**
   - Direct the player to use the designated upload feature (e.g., File button) to submit their images
   - Confirm that the correct files are uploaded, and that the ID images are clear and the selfie clearly shows their face and ID

5. **Verify the submitted documents**
   - Check that:
     - The ID is a physical document (not online-only)
     - All details, including name and date of birth, are clearly readable
     - The selfie is clear and shows the player holding their ID properly
   - Confirm that all required documents are provided; if not, inform the player of the missing items

6. **Initiate the verification process in the back office/system**
   - Upload the documents into the verification system or relevant customer verification platform
   - Review the images for clarity, authenticity, and compliance with requirements

7. **Decide the verification outcome**
   - If documents are accepted:
     - Update the player's account status to verified
     - Communicate that their account is now verified or the specific process (e.g., password reset, bonus claim) can proceed
   - If documents are insufficient or unreadable:
     - Contact the player to resubmit clearer images
     - Explain the specific issue and instruct on how to rectify it
     - Do not proceed until acceptable images are received

8. **Complete the process**
   - For account recovery or password reset:
     - Send the player the new login or transaction password after successful verification
   - For bonus or promotional eligibility:
     - Confirm the player meets all criteria (e.g., correct ID, selfie, valid details)
     - Credit the bonus accordingly and inform the player of successful issuance

9. **Close the case**
   - Log the verification results
   - Record any notes about the documents submitted and the outcome
   - Update the player’s status in the system as verified or requiring re-submission

## Notes
- Always ensure the images are clear, legible, and within the size limit
- Verification is mandatory for optional actions like password resets, bonus claims, or account recovery
- Additional verification steps may be required if inconsistencies or suspicious activity are identified

## Key points for communicating with players
- Clearly inform players about the specific documents required and the purpose of verification
- Guide them through the upload process step by step
- Emphasize the importance of clear, readable images
- Be patient and polite when requesting re-submission if needed