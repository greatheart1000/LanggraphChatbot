# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request.**  
   Determine if the player is initiating a withdrawal, updating account information, or verifying account activity such as a deposit or login. This can be based on the player's query or system prompts.

2. **Gather required information from the player.**  
   Collect the following details:
   - Username and withdrawal name (if applicable)
   - Full name, email, and phone number registered on the account
   - Current account balance and last game played
   - Details of the recent deposit (e.g., screenshot of the last deposit receipt from GCash or PayMaya)
   - A selfie of the player holding a valid ID
   - A copy of a valid ID (photo or scan)
   - If verifying a GCASH deposit not reflected in the account, instruct the player to provide a screenshot of the GCASH INBOX receipt (excluding receipts from other sources)

3. **Verify the completeness of the submitted documentation and information.**  
   Confirm that:
   - All requested documents (selfie with ID, ID copy) are provided and clear
   - The deposit receipt (if applicable) is from GCASH INBOX and clear
   - All the details such as username, email, phone number, balance, and last game are provided

4. **Perform system checks and document validation.**  
   - Verify receipt authenticity if applicable, ensuring screenshots are from GCASH INBOX
   - Confirm that the submitted documents meet the required standards for verification (clear, valid ID, matching details)
   - Check if the account details (name, contact info, ID) align with the submitted documents

5. **Determine the verification outcome.**  
   - **If all documentation and information are complete and valid:**  
     - Mark the account as verified in the system
     - If it’s a withdrawal request, ensure all required info is verified before approval
     - If updating account info, process the update following internal procedures
   - **If documentation is incomplete, unclear, or inconsistent:**  
     - Request the player to resubmit clear and valid documents
     - Provide specific guidance on what is missing or unclear

6. **Proceed with additional checks if unusual login or suspicious activity is detected.**  
   Require the player to provide:
   - Username, nickname, full name, email, and phone number
   - Current balance and last game played
   - Screenshot of the last deposit
   - Selfie holding a valid ID and a copy of the ID
   - Confirm identity before allowing further account activity or transactions

7. **Notify the player of the verification status.**  
   - **If verified successfully:**  
     Explain that their account is verified and they can proceed with their withdrawal, update, or login.
   - **If verification fails:**  
     Inform the player of the failure and advise on the next steps, which may include resubmitting documents or contacting support.

8. **Close the case.**  
   Record all verification details, document submissions, and outcomes in the system. Communicate final confirmation or required actions to the player.

## Notes
- Only receipts from GCASH INBOX are accepted for deposit verification; receipts from other sources are not valid.
- All documents must be clear and legible.
- Verification may be used to lift withdrawal restrictions and confirm account ownership.
- Update account details only after successful verification, based on support review.

## Key points for communicating with players
- Clearly inform players that only receipts from GCASH INBOX are accepted for deposit verification.
- Advise players to provide clear, legible screenshots for smoother processing.
- Explain that verification is essential for withdrawal processing or account updates.
- Remind players to hold a valid ID and include a selfie for identity confirmation when requested.