# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or inquiry related to identity verification, account recovery, deposit, or withdrawal.**  
   - Clarify the purpose of the verification (e.g., account recovery, deposit, withdrawal).

2. **Gather the required information from the player based on the verification context**:
   - For account recovery or password reset:
     - Basic account identifiers: username and registered contact email or phone number.
     - Government-issued ID photo.
     - A selfie holding the ID.
     - Any additional supporting details requested (such as last deposit or wallet details).
  
   - For deposit or withdrawal verification:
     - A screenshot of the last deposit receipt (specifically for GCASH deposits, from GCASH INBOX).
     - Valid ID (government-issued ID).
     - A selfie with the ID.
     - For withdrawal verification:
       - Ensure the provided deposit receipt matches the latest deposit.
       - Confirm the account details of the user's e-wallet (GCash, Maya, PayMaya), if applicable.

3. **Instruct the player to provide the specific documents and information as per the verification type**:  
   - For GCASH deposits, verify that receipts are from GCASH INBOX only and clearly show amount, date, and time.  
   - For deposit verification, ensure the screenshot of the deposit slip includes all necessary details.  
   - For ID verification, make sure the ID is clear and valid, and the selfie clearly shows the player holding the ID.

4. **Review submitted documents and information**:
   - Check the clarity of the ID and selfie images.
   - Confirm the receipt details match the player's transaction history.
   - Verify that the GCASH receipt is from GCASH INBOX.
   
5. **Perform system checks and validation**:
   - Cross-reference provided deposit/receipt details with the system records.
   - Confirm the submitted ID matches the user's account details.
   - Verify the selfie is appropriate and clearly shows the player with the ID.

6. **Determine the verification outcome**:
   - If all documents and information are correct and match the system records:
     - Approve the verification.
     - Proceed with the player's request (e.g., account recovery, deposit credit, withdrawal processing).
  
   - If any document is unclear, missing, or does not match:
     - Inform the player about the discrepancy.
     - Request re-submission with clearer images or additional proof if necessary.
     - If verification cannot be confirmed, escalate the case according to standard procedures or reject the request with an explanation.

7. **Complete the process**:
   - For verified cases:
     - Record the verification outcome in the system.
     - Notify the player of successful verification.
     - Proceed with the requested action (e.g., account recovery, deposit credit, withdrawal).
   - For rejected or pending cases:
     - Clearly communicate the reason to the player.
     - Advise on the next steps or escalation, if applicable.

## Notes
- Only receipts delivered to GCASH INBOX are accepted for GCASH deposit verification; receipts outside this format cannot be processed.
- During verification, ensure all screenshots clearly show the relevant details (amount, date, time).
- Do not proceed with any transaction or account action until proper verification is completed and approved.

## Key points for communicating with players
- Explain clearly what documentation is required.
- Guide players on how to correctly capture and submit screenshots.
- Emphasize that only receipts from GCASH INBOX are accepted for GCASH deposit verification.
- Be polite and professional, especially if documents need to be resubmitted.