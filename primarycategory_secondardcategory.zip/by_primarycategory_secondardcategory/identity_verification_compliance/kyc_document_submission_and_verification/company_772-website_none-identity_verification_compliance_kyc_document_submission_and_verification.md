# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the reason for the verification request**  
   - Determine if the player is submitting documents for account recovery, password reset, deposit verification, or claiming a promotion (e.g., VIP Birthday Bonus), based on their inquiry or request.

2. **Gather required information from the player**  
   - Confirm the following details:
     - Full name
     - Registered username
     - Registered number and email address
     - Main GCash/Maya account (if applicable)
     - Last deposit receipt or screenshot (if relevant)
     - Player's ID details (name, date of birth) for certain offers
   - Clarify which documents the player is submitting, such as:
     - Two valid government IDs (with clear, readable details)
     - A selfie holding the ID(s)
     - For deposit verification: detailed receipt showing sender and recipient info

3. **Instruct the player on document requirements**  
   - Ensure all ID images are:
     - Clear and readable
     - Properly lit, ideally with good lighting and in a bright location
     - With the ID held close to the face in selfies
   - For ID verification or password reset:
     - All IDs submitted must be valid; laminated IDs are preferred, unlaminated IDs may not be accepted
     - Selfies must include the player holding the ID
   - For age-specific offers (e.g., Birthday Bonus):
     - IDs must show the birth date clearly
     - Provide two valid IDs, with at least one showing date of birth

4. **Verify the completeness and correctness of the submitted documents**  
   - Check that:
     - All images are clear, legible, and match the provided details
     - Names and birth dates on IDs match the account details (if applicable)
     - The selfie clearly shows the player holding the ID
     - If multiple IDs are required (e.g., birthday bonus), all are provided and meet the criteria

5. **Assess if the documentation meets the requirements**  
   - If documents are complete and compliant:
     - Proceed to review the submitted information in the back-office system
   - If documents are incomplete, blurry, unclear, or missing required info:
     - Inform the player politely and clarify the missing or faulty elements
     - Request re-submission with clearer images

6. **Perform the verification in the back office/system**  
   - Check that the provided IDs and selfies:
     - Match the account holder's details
     - Meet the specific requirements for the reason (e.g., age verification, deposit proof)
   - For deposit verification:
     - Confirm the receipt shows sender and recipient info, and the amount/date match the transaction
   - For birthday-related verifications:
     - Confirm IDs with birthdate

7. **Decide on the verification outcome**  
   - If verification is successful:
     - Proceed with the process (e.g., validating deposit, approving password reset, issuing bonus)
   - If verification fails:
     - Explain the reason clearly and politely
     - Advise on the next steps, which may include re-submitting clearer documents or additional verification if necessary

8. **Complete the process and notify the player**  
   - Confirm successful verification
   - Inform the player of the next steps or that their request (e.g., password reset, deposit verification, bonus claim) is approved
   - For special cases (e.g., VIP Birthday Bonus), ensure all requirements are met before crediting the bonus

## Notes
- Always ensure documents are recent and match the account details provided by the player.
- Use the current site rules and verification criteria; no assumptions or additional requirements should be made.
- Escalate cases where documents are suspicious, incomplete, or invalid for further investigation.

## Key points for communicating with players
- Clearly explain the document requirements and importance of clarity
- Politely request re-submission if documents do not meet standards
- Ensure the player understands the verification process and expected timelines
- Maintain professionalism and confidentiality throughout the process