# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive the player's request or notification for KYC verification or withdrawal processing.**  
   - Confirm the reason for the request (e.g., withdrawal, account verification, password reset).

2. **Gather required information from the player.**  
   - Collect the following details:
     - Username/Nickname  
     - Full Name  
     - Registered Email Address  
     - Phone Number (linked to the account)  
     - E-wallet number used for withdrawal (e.g., Gcash, PayMaya)  
     - Current account balance  
     - The last game played and, if applicable, a screenshot of the last deposit receipt  
     - A valid government-issued ID  
     - A selfie holding the ID  
     - Any other information linked to the gaming account if specifically requested

3. **Verify completeness of provided information and documents.**  
   - Ensure all required details are received:
     - Username, full name, email, phone number, e-wallet number  
     - Valid government-issued ID  
     - Selfie with ID  
     - Last deposit receipt (if applicable)

4. **Perform system checks and matching procedures.**  
   - Confirm that the details match the registered information in the back office/system.  
   - Check that the ID and selfie are clear and valid.  
   - If a withdrawal or verification request involves a deposit receipt, verify that the receipt matches the last deposit.

5. **Assess the sufficiency and validity of submitted documents and information.**  
   - If all documents and details are complete and meet the criteria, proceed to verification.  
   - If any required document is missing or unclear, inform the player of the specific missing/inadequate items and request re-submission.

6. **Complete the verification process.**  
   - Use the platform’s verification procedures to approve the documents, matching ID and selfie, and confirming account ownership and compliance.

7. **Apply the verification outcome:**  
   - If verification is successful:
     - Update the player's account status to verified and allow withdrawal or account actions as required.  
   - If verification fails:
     - Notify the player of the failure reason (e.g., documents not clear, details mismatch)  
     - Advise on re-submission or further steps as per company policies

8. **Close the case or update the ticket.**  
   - Document the verification outcome and any notes on the process.  
   - Communicate the result to the player promptly.  
   - Escalate to higher support or compliance if issues cannot be resolved at your level.

## Notes

- Always ensure the provided ID is valid, government-issued, and clearly visible in the selfie.  
- When screenshots are required (e.g., deposit receipt), verify that the image is clear and legible.  
- Follow the current site configuration and official instructions for verification thresholds and escalation procedures.

## Key points for communicating with players

- Clearly explain which documents are needed and how to submit them if asked.  
- Be patient and polite, especially if players need to re-submit documents.  
- Confirm the details you have collected before proceeding, to avoid delays.  
- Keep all verification communication confidential and secure.