# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the player's request or reason for verification**  
   - Determine if the player is requesting account verification, password reset, transaction password reset, withdrawal password reset, or other KYC-related procedures based on their inquiry.

2. **Inform the player of document requirements**  
   - Explain that verification requires:  
     - A valid government-issued laminated ID (clear and readable)  
     - A selfie holding the ID close to the face (ID details clearly visible)  
     - An optional video stating today's date while holding the ID (if requested for extra verification)  
     - Additional information such as registered mobile number, email address, last deposit receipt, or main GCash/Maya account may be requested if discrepancies exist (e.g., name mismatch).

3. **Request the player to prepare and upload necessary documents**  
   - Ask the player to submit:  
     - A clear photo of their valid ID (laminated preferred)  
     - A clear selfie of themselves holding the ID (ID held close to the face)  
   - If applicable, request a video stating the current date while holding the ID.

4. **Verify the clarity and validity of submitted documents**  
   - Check that the ID is laminated and all details are visible and readable  
   - Confirm that the selfie clearly shows the player's face and the ID held near it  
   - Ensure the video (if provided) clearly states the date while holding the ID

5. **Conduct system and manual checks**  
   - Review that all necessary information has been provided  
   - Cross-reference details such as name, username, registered number, email, last deposit receipt, and main GCash/Maya account if required  
   - Assess if there are discrepancies, such as name mismatches  
   - For name mismatches, inform the player that they need to fulfill additional conditions (e.g., complete the X1 turnover requirement) for safety

6. **Perform identity verification via back-office or automated systems**  
   - Confirm the documents meet the requirements and are genuine  
   - Verify that the ID photos are legible and match account details

7. **Handle discrepancies or insufficient documentation**  
   - If documents are unclear, incomplete, or non-compliant (e.g., non-laminated ID), advise the player to resubmit clear, valid ID documents in the required format  
   - If the player cannot provide the required documents, explain that verification cannot proceed and the account may be subject to restrictions as per company policy

8. **Complete verification process**  
   - Once documents are verified as valid and meeting requirements, update the player's account status accordingly in the system  
   - For password resets or account updates, trigger the corresponding system actions to generate new credentials or unlock accounts

9. **Notify the player of result and next steps**  
   - If verification is successful, inform the player that their account is verified and any requested password resets or changes will be processed  
   - If additional verification is needed, advise on further steps or resubmission  
   - If verification fails, clearly explain the reason and advise on possible reapplication

10. **Close the case**  
    - Document all actions taken, including document submissions, checks performed, and verification results  
    - Communicate the final status and advice to the player (e.g., account verified, password reset completed, or rejection with reason)

## Notes

- Always ensure uploaded images are clear, readable, and complete.  
- Laminated IDs are preferred; non-laminated IDs are not accepted.  
- For name discrepancies, enforce the additional verification condition (X1 turnover requirement).  
- For security, request a video with the current date when deemed necessary or required by the procedure.

## Key points for communicating with players

- Clearly explain the document requirements and the need for clarity and readability.  
- Emphasize that IDs must be laminated and all details visible.  
- Inform players that verification may involve manual review and could take some time.  
- Guide players on how to improve their submissions if documents are insufficient or unclear.