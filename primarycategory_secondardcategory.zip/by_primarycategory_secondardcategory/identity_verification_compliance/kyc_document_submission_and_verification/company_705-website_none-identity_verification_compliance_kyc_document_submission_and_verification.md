# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Receive player inquiry or request for verification**  
   - Identify the type of verification the player requires (e.g., password reset, deposit verification, withdrawal account change, identity verification).  
   - Clarify with the player the specific documents and information needed based on their request.

2. **Inform the player of the required documentation**  
   - For identity verification, instruct the player to prepare:  
     - A clear picture of a valid ID (e.g., government-issued ID).  
     - A selfie with the valid ID, ensuring the ID is held close to the face.  
   - For password resets or account changes, additional details may be required, such as:  
     - Full Name, Username, Registered Number, Registered Email, Last Deposit Receipt, Main GCash/Maya account details.  
   - For deposit proof, advise the player to generate a screenshot from their GCash account, showing the deposit receipt with a negative (-) sign.  
   - For changing withdrawal accounts, request the number to delete and the reason for deletion.

3. **Instruct the player how to upload photos and documents**  
   - Guide the player:  
     - Click the File button to open their device's image folder.  
     - Select the appropriate image to upload.  
     - Ensure each file does not exceed 20MB in size.  
   - Confirm the player understands the need for clear, readable images.

4. **Verify the received documents and information**  
   - Check that all images are clear and readable, especially the ID and selfie with ID.  
   - Confirm that the ID is valid and the ID holder’s face matches the selfie.  
   - For deposit receipts, ensure the receipt shows a negative (-) sign to verify payment was processed correctly.  
   - For password or account reset requests, verify all details such as Name, Username, Register Number, Email, and the quality of ID and selfie images.

5. **Perform system checks and document validation**  
   - Confirm that the images and data meet the requirements established in the previous step.  
   - If images are unclear, incomplete, or do not match the provided information, notify the player to resend clearer images.

6. **Escalate or proceed based on verification outcome**  
   - If all documents are verified successfully, proceed to approve the request:  
     - Reset passwords or perform account modifications as specified.  
     - Update withdrawal account details or complete deposit verification.  
   - If documents are insufficient or fail verification:  
     - Inform the player about the specific issues.  
     - Advise on resubmission with clearer or correct information.

7. **Complete the process and communicate outcomes**  
   - Confirm to the player that their verification has been successfully completed, or provide clear instructions if further action is needed.  
   - For successful verification, proceed with account updates (e.g., password reset, withdrawal account change, deposit confirmation).  
   - For failed verification, advise the player on next steps, which may include resubmission or escalation.

8. **Record and close the case**  
   - Save all submitted documents and communication logs.  
   - Mark the verification case as completed in the system.  
   - Follow internal protocols for documentation and reporting if required.

## Notes

- Ensure all ID and selfie images are clear and readable for the verification to proceed smoothly.  
- Always inform players that document images must be of good quality and that a selfie with ID should clearly show their face and the ID.  
- For deposit verification, the receipt must include a negative (-) sign to confirm the payment.  
- When requesting additional documents or resubmissions, be polite and specific about what needs improvement.

## Key points for communicating with players

- Clearly explain the document requirements based on their specific verification case.  
- Emphasize the importance of clarity and readability in submitted images.  
- Mention the maximum file size of 20MB for uploads.  
- Remind players that verification documents will be reviewed before any account changes are made.