# Identity Verification & Compliance - KYC Document Submission and Verification

## Steps

1. **Identify the player’s purpose related to verification**:
   - Determine if the player requires verification for account login, transaction reset, deposit verification, withdrawal verification, or account unbinding.
   - Clarify exactly what document or information the player is asked to submit based on their request.

2. **Inform the player of document requirements**:
   - Advise the player to prepare the following:
     - A laminated, clear, and readable government-issued photo ID.
     - A selfie holding the ID with their face clearly visible.
     - For deposit or transaction verification: a screenshot of the deposit receipt showing sender and recipient information.
   - Emphasize that all ID images and selfies must be clear, readable, and properly held for verification.

3. **Guide the player to obtain the necessary receipts**:
   - For GCash deposits:
     - Log in to the GCash account.
     - Open the Inbox to generate a QRPH invoice.
     - Take a screenshot of the deposit receipt showing sender and recipient.
   - For PayMaya deposits:
     - Open PayMaya app.
     - Take a screenshot of the deposit receipt showing sender and recipient details.

4. **Instruct the player to submit verification documents**:
   - Receive the ID photo and selfie.
   - Receive the deposit receipt screenshot (if applicable).
   - Ensure all images are clear and readable before proceeding.

5. **Verify the submitted documents**:
   - Check that the ID is laminated, valid, and clearly shows the full name and photo.
   - Confirm the selfie clearly holds the ID and shows the face.
   - For deposit verification:
     - Verify that the receipt shows the sender and recipient information, including the GCash or PayMaya account details.
   - Confirm all images are of high quality and properly held for verification.

6. **Perform back-office verification**:
   - Cross-check submitted details with the account data to ensure consistency.
   - For deposit verification:
     - Confirm the receipt matches the transaction in the GCash or PayMaya inbox or transaction history.
     - Await approval before processing the deposit.
   - For identity or password resets:
     - Verify the player's full name, username, registered number, email, and last deposit receipt.

7. **Complete the verification process**:
   - If documents and information are verified successfully:
     - Proceed with the requested operation (e.g., password reset, deposit confirmation, unbinding account).
     - Inform the player that verification was successful and next steps are being taken.
   - If documents are unclear, invalid, or incomplete:
     - Notify the player of the issue.
     - Request re-submission with clearer images.
   
8. **Final steps and closure**:
   - Once verified:
     - Issue the new password or confirm the deposit/withdrawal.
     - Update the player's account status accordingly.
   - Inform the player of any additional steps or processing times if needed.

## Notes
- Only laminated, government-issued IDs that are clearly readable are accepted.
- Selfies must clearly hold the ID and face; blurry or unheld IDs are invalid.
- Deposit receipts must show sender and recipient details; screenshots must be clear.
- Processing times may vary; ensure transparency with the player about verification duration.
- When in doubt, escalate to the compliance or verification department for further review.

## Key points for communicating with players
- Clearly explain all document requirements and the importance of high-quality images.
- Guide the player through the process of generating receipts if needed.
- Confirm their understanding and inform them of expected processing times.
- Be patient and polite, especially if re-submission is required.