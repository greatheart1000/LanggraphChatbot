# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player’s withdrawal inquiry and verify the request details**
   - Ask the player for the withdrawal method (e-wallet or bank account).
   - Request the withdrawal amount.
   - Ensure the player provides their transaction password before proceeding.

2. **Check the player’s withdrawal eligibility**
   - Confirm the player has completed any necessary turnover requirements.
   - Verify the account has no irregular betting activity or suspicious behavior (e.g., same IP, same bank, same phone).
   - Ensure the withdrawal amount complies with the method-specific limits:
     - For GCASH and GCash: allowed from 500 PHP to 20,000 PHP.
     - For PayMaya and other methods: confirm the respective limits if specified.
     - For amounts below 500 PHP, advise using PayMaya for smoother processing, as GCASH does not support below 500 PHP.

3. **Determine the withdrawal method status and available options**
   - If the player chooses GCash/GCASH:
     - Check if GCash withdrawals are available; if temporarily unavailable, advise switching to Maya (PayMaya) or other methods.
     - Confirm the withdrawal amount is within 500 PHP to 20,000 PHP.
   - If the player opts for alternative methods (PayMaya, USDT, Online Bank Transfer):
     - Proceed with standard process for the selected method.

4. **Process the withdrawal request**
   - Submit the withdrawal request through the back-office system.
   - Inform the player that once confirmed, the status will be “transferring,” meaning the request is approved and awaiting payout.
   - Note: Normal processing time is 3-5 minutes; delays may happen during high transaction volumes or system maintenance.

5. **Monitor and communicate withdrawal status**
   - Advise the player to check the withdrawal record:
     - Instruct to go to the Home page, click Member, then select Withdrawal Record.
     - Recommend taking a screenshot of the record for future reference or proof.
   - If the status shows “transferring,” inform the player that the payment is with the finance team to complete the transfer.
   - If delays persist beyond the normal 3-5 minutes, or if the withdrawal remains pending for longer:
     - Reassure the player that the funds are secure.
     - Suggest waiting or re-initiating the option to re-submit the request if necessary.

6. **Handling GCash withdrawal issues and unavailability**
   - If GCash is temporarily unavailable due to operator issues:
     - Notify the player about the outage.
     - Recommend using Maya (PayMaya), other e-wallets, or online banking as alternative methods.
     - For already initiated GCash withdrawals, advise allowing 30-45 minutes for processing.
   - If a GCash withdrawal fails or is delayed:
     - Verify the amount falls within 500-20,000 PHP.
     - Suggest switching to an alternative method if issues persist.
   - If the withdrawal is canceled during audit:
     - Confirm with the player that funds are returned to the wallet.

7. **Resolutions for delays, failures, or issues**
   - If the withdrawal shows a status other than successful:
     - Check your system for delays or processing backlogs.
     - Encourage the player to wait up to 45 minutes, especially if the status is “transferring.”
     - Request a screenshot of the withdrawal record for further investigation if needed.
     - Escalate cases involving recurrent failures or system issues to the appropriate department.

8. **Final confirmation and closure**
   - Once the withdrawal is marked as completed, inform the player.
   - Advise to keep the screenshot of the withdrawal record for their reference.
   - Offer assistance if the player has any further concerns regarding the withdrawal.

## Notes

- Always ensure players understand that normal withdrawal processing is within 3-5 minutes, but delays may occur due to high transaction volume or system maintenance.
- Remind players to wait 30-45 minutes if they initiated a GCash withdrawal and it has not been processed yet.
- Verify that the withdrawal aligns with the current limits for each method.
- If players encounter technical issues with GCash, advise switching to Maya (PayMaya) or other available alternatives.
- Encourage players to share withdrawal records or screenshots for faster support resolution.

## Key points for communicating with players

- Confirm the withdrawal method and amount, ensuring they meet the set limits.
- Inform players that withdrawal status “transferring” indicates approval and pending payout.
- Explain common delays and reassure that funds are secure during processing.
- Guide players to check their withdrawal record via Member > Withdrawal Record.
- Advise switching to alternative methods if GCash is unavailable or delays occur.
- Always request a screenshot of the withdrawal record if further investigation is required.