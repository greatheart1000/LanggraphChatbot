# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and Verify Player's Withdrawal Request**
   - Collect player's username.
   - Request the player to submit a screenshot of the withdrawal transaction.
   - Confirm that the player has provided correct account details and associated payment information.

2. **Check Player's Account Status**
   - Verify that the player's account is fully verified, including:
     - Phone number verification.
     - Uploading valid ID and selfie if required.
   - Ensure no irregular activities are flagged during account review.
   - Confirm any necessary turnover or wagering requirements (if applicable).

3. **Assess Submission Completeness**
   - Ensure the player has submitted all required documentation and transaction screenshots.
   - If documentation is incomplete or details are incorrect:
     - Inform the player about missing or incorrect information.
     - Request the correct or additional documentation.
   - If all information is correct and complete:
     - Proceed to submit the withdrawal request for processing.

4. **Place Withdrawal Request in the Queue**
   - Confirm that the withdrawal request has been received and entered into the system.
   - Inform the player that withdrawals are processed on a first-come, first-served basis.
   - Advise the player to avoid spamming messages to prevent delays.

5. **Monitor Withdrawal Processing Status**
   - Check transaction status in the system:
     - Status will be 'in progress' while being processed.
     - Delays may occur during high transaction volume.
   - If the withdrawal is pending or taking longer than expected (up to 24 hours maximum):
     - Instruct the player to wait patiently.
     - Suggest logging out and logging back in after about 5 minutes to refresh the status.
   
6. **Handle Possible Delays or Issues**
   - If delays extend beyond 24 hours, or the withdrawal gets stuck:
     - Verify if the account or transaction is under review, security check, or additional verification.
     - Confirm that no discrepancies or incomplete verifications are causing the delay.
   - If issues persist, instruct the player to:
     - Send a screenshot of their transaction and their username.
     - Contact support for further assistance.

7. **Inform Player about Withdrawal Completion**
   - Once the withdrawal is processed:
     - Confirm the funds have been credited to the player's linked GCash, Maya, or other e-wallet account.
     - Mention that processing times depend on transaction volume.
   - Advise the player to check their linked account for the credited amount.

8. **In Case of Withdrawal Failure or Rejection**
   - Check for common failure reasons:
     - Incorrect or unverified account details.
     - Mismatched information during verification.
     - Pending review or security verification.
     - Exceeding withdrawal limits.
   - Notify the player of the specific issue and guide on resolving it:
     - Complete any pending verification steps.
     - Update account details if necessary.
     - Re-submit the withdrawal if resolved.

9. **Cancellation of Withdrawal Requests**
   - Inform the player that withdrawal requests in 'Processing' or 'Transferring' status cannot be canceled until fully completed.
   - Advise waiting for the process to finish.

10. **Maintain a Record of All Interactions**
    - Log all relevant player reports, screenshots, and system responses.
    - Use these records for future reference or escalation if needed.

## Notes
- Withdrawals are processed in order and can take up to 24 hours; delays during high volume are normal.
- During system review or account verification, delays may extend beyond 24 hours.
- Support should emphasize patience and avoid spamming messages, which can hinder the process.
- Ensure all account verification steps are completed before requesting withdrawal.
- Always verify that the player’s payment details are correct to avoid delays or failure.

## Key points for communicating with players
- Inform players that withdrawals are processed on a first-come, first-served basis, with a maximum of 24 hours processing time.
- Advise patience during high transaction volume and when delays occur.
- Remind players to ensure their account is fully verified before requesting withdrawal.
- Encourage players not to spam support messages, as it can slow down processing.
- Instruct players to send screenshots of their transactions and account details if they experience delays or issues.
- Confirm once the withdrawal has been credited and advise checking linked accounts like GCash or Maya.