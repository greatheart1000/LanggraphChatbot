# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player's withdrawal inquiry or issue report.**  
   - Determine whether the player is requesting a withdrawal, reporting a failed withdrawal, or raising a delay concern.

2. **Verify player's account and withdrawal details.**  
   - Ask for the player's full name, username, and the specific withdrawal account involved.  
   - Request relevant evidence such as a screenshot of the withdrawal record or transaction receipt if available.

3. **Check the withdrawal status in the system.**  
   - Access the player's withdrawal record via the member portal:  
     - Homepage > Member > Withdrawal Record  
   - Confirm current status:  
     - Pending, transferring, failed, canceled, or completed.

4. **Evaluate common withdrawal scenarios and conditions:**

   - **If the withdrawal status is 'transferring':**  
     - Inform the player that their withdrawal has been approved and funds are being transferred. Explain that processing typically occurs within 3–5 minutes but can be delayed during high volume.  
   
   - **If the withdrawal has failed:**  
     - Explain that the funds will automatically be returned to their game account.  
     - Advise the player to submit a new withdrawal request once the funds are replenished.  
     - Confirm if the player has used GCash or PayMaya and whether the failure was due to monthly limits or other reasons.  
     - For GCash:  
       - If it reached the monthly limit, recommend applying for an additional GCash account.  
       - For withdrawal amounts below 500 PHP, suggest using PayMaya for smoother processing.  
   
   - **If the withdrawal was canceled:**  
     - Inform the player that funds are automatically returned to their game account and advise reattempting after any issues are resolved.  
   
   - **If the withdrawal is pending or in transfer:**  
     - Clarify that the transaction is in progress; processing time may vary during surges or system issues.  
     - If delays exceed the usual processing time, escalate to technical support with evidence.

5. **Check for specific payment method limits and issues:**

   - **GCash:**  
     - Confirm if the withdrawal amount is between 500 PHP and 20,000 PHP.  
     - If the amount is below 500 PHP, recommend PayMaya as an alternative.  
     - If GCash is temporarily unavailable or experiencing system issues, advise using PayMaya or wait until GCash service resumes.  
   
   - **PayMaya:**  
     - Ensure withdrawal amounts meet current site policy and are within limits.

6. **In case of system issues or suspected failures:**

   - Advise the player to wait 30–45 minutes for GCash withdrawals during system instability.  
   - Suggest switching to PayMaya or alternative methods if delays persist or if GCash service is unavailable.  
   - Remind the player that their funds are safe and system issues usually resolve shortly.

7. **If a withdrawal has failed and funds are returned:**

   - Confirm the funds are credited back to the player’s game account.  
   - Offer to assist with resubmitting the withdrawal request if requested.  
   - Ensure the player understands that no further action is usually needed on their part.

8. **If the player requests to unbind or change withdrawal accounts:**

   - Collect the following information:  
     - Full name, username, account number to delete, reason, and a picture of valid ID plus selfie with ID.  
   - Process the unbinding request in accordance with the current policy:  
     - Only one withdrawal account can be unbound at a time.  
   - Confirm unbinding completion and advise to bind a new account if needed.

9. **Guide the player on withdrawal record retrieval:**

   - Explain how to access withdrawal records:  
     - Homepage > Member > Withdrawal Record.  
   - Recommend taking a screenshot for future reference or to provide as proof if necessary.

10. **Communicate expected processing times and next steps:**

    - Standard withdrawals are processed within 3–5 minutes, but delays may occur during high volume or technical issues.  
    - Advise patience and check withdrawal status periodically.  
    - If delays extend beyond normal processing times, escalate to the support or finance department with proper documentation.

## Notes

- Always verify withdrawal status before providing explanations.  
- When facing system issues (particularly with GCash), suggest using PayMaya or alternative methods.  
- Ensure the player understands that their funds are safe and that delays are usually temporary.  
- Collect all supporting evidence (screenshots, transaction IDs) for escalations involving unresolved delays or failures.

## Key points for communicating with players

- Clarify that withdrawal processing times are usually 3–5 minutes but can extend during system congestion.  
- Inform players about specific limits for GCash (500 PHP – 20,000 PHP) and recommended alternatives for amounts below 500 PHP.  
- Reassure players during system issues that their funds are secure and delays are temporary.  
- Emphasize the importance of providing screenshot evidence, especially when requesting unbinding or supporting withdrawal issues.