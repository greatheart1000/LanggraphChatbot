# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify Player’s Eligibility for Withdrawal**
   - Confirm the player has completed at least 1 full turn of slot play with the current balance.
   - Ensure the player's account details are complete and verified.
   - Check that the account is not under review, restricted, or flagged for unusual activity.

2. **Collect Necessary Documentation and Information**
   - Request the player's username, withdrawal name, and verified contact number.
   - Ask for the withdrawal account number or preferred payment method details (e.g., GCash or PayMaya).
   - Require the player to submit a screenshot of their last deposit receipt from their chosen payment provider.
   - Request a selfie holding a valid ID plus a copy of the ID itself.
   - Confirm if any turnover or betting activity requirements are met, especially if applicable.

3. **Review Submission Completeness and Validity**
   - Ensure all requested information and documents are provided:
     - Complete account details,
     - Deposit receipt,
     - ID with selfie.
   - If any information or documents are missing, inform the player to provide the necessary details before proceeding.

4. **Inspect for Potential Review Triggers**
   - Check for signs of unusual activity, such as abnormal betting patterns or bets on Live Games.
   - If unusual activity is detected, temporarily cancel or hold the withdrawal for review.
   - Notify the player that the withdrawal will resume once the review is complete and any necessary checks are satisfied.

5. **Submit Withdrawal Request for Processing**
   - Log the withdrawal request in the system.
   - The system will review activity for normalcy and compliance.
   - If all checks pass, the request will be approved for processing.

6. **Process the Withdrawal**
   - Process the withdrawal request on a first-come, first-served basis.
   - Be aware that withdrawals are typically processed within 24 hours, but delays can occur during high volume periods.
   - Large cashouts may take 24-48 hours or longer depending on the queue and game center review.

7. **Manage Delays and Queues**
   - Explain to the player that withdrawals may be queued during periods of high volume or system load.
   - Remind the player that processing times are not guaranteed and may take longer during busy times.
   - Keep the player informed when the withdrawal has been processed and credited to their account.

8. **Handle Special Payment Methods (GCash / PayMaya)**
   - Confirm the account information provided is complete and verified.
   - Ensure the player has submitted required documentation:
     - Screenshot of deposit receipt,
     - Valid ID with selfie.
   - Proceed with processing once all details and documents are verified.

9. **Notify Player of Completion or Delay**
   - Once the withdrawal is processed and credited, notify the player.
   - If delays occur due to high volume or system issues, inform the player of the situation and assure them their request is being processed.

10. **Escalate if Necessary**
    - If the withdrawal remains delayed beyond expected times or if any issues arise:
      - Check for possible account restrictions,
      - Review for abnormal activity,
      - Escalate to compliance or technical teams if needed.

## Notes

- Withdrawals require verified account details, submission of deposit receipts, and valid ID with selfie.
- Withdrawals are processed sequentially; delays during high volume are common.
- Large withdrawals can take longer to process (24-48 hours or more).
- Withdrawals may be canceled or delayed if abnormal betting activity is detected, especially on Live Games.
- Ensure players understand that processing times are approximate and during peak periods, delays are possible.

## Key points for communicating with players

- Confirm the player has met all withdrawal requirements before processing.
- Clearly explain that withdrawals are processed on a first-come, first-served basis.
- Inform players of potential delays during high volume periods.
- Request all supporting documents upfront to prevent processing delays.
- Advise players that withdrawal times are typically up to 24 hours but can extend during busy times or special circumstances.