# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player's withdrawal inquiry**
   - Confirm the player's identity by requesting their user ID or account details.
   - Collect transaction-specific information such as the withdrawal amount and date of the request.
   - Ask if the withdrawal is pending, delayed, or rejected for additional context.

2. **Verify player's account status**
   - Check if the player's account is verified and meets the eligibility criteria for withdrawal (verified account, no illegal activity flagged).
   - Confirm that the account has no restrictions or flags that could disable withdrawal features.
   - Ensure the withdrawal request complies with platform policies, including minimum or maximum limits if specified.

3. **Check for possible withdrawal disablement or restrictions**
   - Determine if withdrawal features are disabled due to suspected illegal activity, account under review, or system-imposed restrictions.
   - If withdrawal features are disabled:
     - Inform the player of the status.
     - Advise the player to contact customer support for resolution.
     - Note that withdrawals may be temporarily disabled for security reasons or system issues.

4. **Verify necessary security and account requirements**
   - Ensure the player has set and is using a valid withdrawal password or security PIN.
   - If the player requests to change or reset the withdrawal password:
     - Confirm their account ownership via user ID and additional security details.
     - Provide instructions for resetting or updating the password in accordance with security protocols.

5. **Initiate withdrawal processing**
   - Within the system, submit the withdrawal request:
     - Ensure the request is complete and all required information is provided.
   - Check if the player has fulfilled all requirements, such as turnover or playtime, if applicable.
   - Confirm that no illegal activities or violations are detected on the account.

6. **Monitor withdrawal status**
   - Track the request within the system:
     - Typically, system processing times vary and should be communicated to the player if known.
   - If the withdrawal is pending or delayed:
     - Reconfirm that the account remains verified and unrestricted.
     - Check for any security flags or additional verification needs.
     - Advise the player that delays may occur and they should await further updates.
   - If the withdrawal is rejected:
     - Notify the player and suggest they review the withdrawal policy or contact support for more details.
     - Request a screenshot of the withdrawal order if further investigation is required.

7. **Handle withdrawal delays or issues**
   - If the withdrawal remains delayed:
     - Ensure the player’s account is in good standing, verified, and free from restrictions.
     - Contact customer support for assistance if the delay exceeds typical processing time.
   - If the withdrawal is canceled or rejected due to restrictions:
     - Explain possible reasons such as illegal activity detection or account review.
     - Guide the player to resolve these issues with support.

8. **Close the case**
   - Confirm that the player has been informed of the withdrawal status.
   - Provide guidance on further steps if necessary (e.g., re-submitting request, providing additional verification).
   - Document the interaction and update the transaction record accordingly.

## Notes
- Always ensure the player is verified and compliant with platform policies before processing withdrawals.
- Withdrawals may be disabled or blocked automatically due to suspected illegal activity or violations, requiring player contact with customer support.
- Delays in processing can be due to security checks, account restrictions, or system issues.
- When requesting additional verification or password resets, follow the site’s security protocols.
- Collect and review relevant transaction details and screenshots if a player reports issues with pending or rejected withdrawals.

## Key points for communicating with players
- Inform players that withdrawal processing times vary per platform.
- Clearly advise players to verify their accounts if withdrawals are delayed.
- Reassure players that delays or issues are often due to account security checks or policy compliance.
- Encourage players to contact support directly if further assistance is needed or if their withdrawal remains pending beyond normal processing times.