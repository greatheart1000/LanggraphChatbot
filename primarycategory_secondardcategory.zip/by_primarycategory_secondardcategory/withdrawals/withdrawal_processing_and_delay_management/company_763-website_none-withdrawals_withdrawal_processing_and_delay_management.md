# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request and verify their account details:**
   - Confirm the player's identity and account information.
   - Verify the withdrawal amount entered by the player.

2. **Check the player's deposit activity (if applicable):**
   - Determine if the player has deposited in the past month.
   - If no recent deposit activity is detected, instruct the player to recharge with an amount equal to their current balance before proceeding.

3. **Verify withdrawal amount and select appropriate options:**
   - Confirm if the requested withdrawal falls within allowed limits:
     - GCash: 500 PHP to 20,000 PHP per transaction.
     - If below 500 PHP, recommend using PayMaya.
   - Ensure the selected withdrawal method is available. If one method (e.g., GCash) is unavailable due to system issues, advise using the alternative (PayMaya).

4. **Instruct the player to initiate the withdrawal process:**
   - Guide them to:
     - Click "Withdraw" on the homepage.
     - Swipe/select the preferred e-wallet (GCash or PayMaya).
     - Enter the withdrawal amount.
     - Input their transaction password.
     - Click "Submit."

5. **Monitor the withdrawal request status:**
   - If the status changes to "Transferring," it means the request has been approved and is being processed.
   - Advise the player to allow 3–5 minutes for normal processing; during high volume periods, processing may take longer.

6. **Handle delays, failures, or rejections:**
   - If the withdrawal is slow or fails:
     - Instruct the player to re-submit the request.
     - Inform that the finance team will expedite pending requests when possible.
   - If a withdrawal has been rejected:
     - Ask the player to provide a screenshot of the withdrawal record.
     - Check whether the withdrawal is still processing or has been rejected.
     - If rejected, advise re-submitting or following up with support, providing the withdrawal details.

7. **Verify withdrawal success or failure:**
   - Confirm whether the funds have been credited to the player's wallet.
   - For failed withdrawals:
     - Inform the player that returned funds are in their wallet.
     - Suggest re-initiating the withdrawal if needed.

8. **Assist with withdrawal record retrieval:**
   - Guide the player to view their withdrawal record:
     - Click "Member" on the homepage.
     - Select "Withdrawal Record."
     - Recommend taking a screenshot for verification or future reference.

9. **Handle account unbinding or method change requests (if applicable):**
   - Collect necessary information from the player:
     - Full name, username, phone number to delete, reason, photo ID, and selfie with ID.
   - Submit a request for unbinding or changing the withdrawal account to the relevant team.

10. **Address temporary unavailability of specific withdrawal methods:**
    - If GCASH withdrawals are temporarily unavailable, advise using PayMaya or alternative methods like Online Banking.
    - Inform the player they may need to wait and possibly re-submit after system maintenance or high traffic periods.

11. **Follow up on outstanding or pending withdrawals:**
    - Reiterate that high transaction volumes can cause delays.
    - Encourage players to check their withdrawal status regularly, and re-submit requests if necessary.

## Notes

- Withdrawals may take 3–5 minutes under normal conditions; delays may occur during system issues.
- For withdrawals below 500 PHP, use PayMaya as an alternative.
- Always verify if the withdrawal is still processing or has been rejected before advising re-submission.
- Players may be asked to provide a withdrawal record screenshot to verify their request.
- Ensure players understand that withdrawals cannot be canceled once processed.

## Key points for communicating with players

- Inform players that withdrawal processing times can vary, especially during high transaction periods.
- Clarify that withdrawals show a "Transferring" status while being processed.
- Remind players to submit screenshots or records if issues arise or for verification purposes.
- Encourage re-submission of withdrawal requests if delays or failures occur.
- Make them aware that technical issues can temporarily affect availability of certain withdrawal options, and suggest alternatives accordingly.