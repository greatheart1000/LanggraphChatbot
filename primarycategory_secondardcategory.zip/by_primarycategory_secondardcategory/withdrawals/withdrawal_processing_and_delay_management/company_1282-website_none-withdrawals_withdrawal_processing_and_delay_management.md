# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and verify player's withdrawal request**
   - Ask the player to provide their username and the transaction details, including the withdrawal amount, method, and date.
   - Request a clear screenshot of the withdrawal issue if applicable.
   - Confirm that the withdrawal amount is within the minimum of 100 per day and the maximum of 50,000 per day limits.

2. **Check the player's account verification status**
   - Ensure the player's account is fully verified as per site policy before processing withdrawal requests.
   - If the account is not verified, inform the player that verification is required before withdrawal processing.

3. **Review the transaction details**
   - Confirm the transaction record matches the request, and verify the amount, method, and date.
   - Check for any delays or issues related to the transaction in the system logs or transaction records.

4. **Assess the timing and queue status**
   - Determine if the withdrawal request was submitted during high volume periods, which may cause delays.
   - Verify if the request is within the standard processing time of up to 24 hours.

5. **Identify if the withdrawal involves a large sum**
   - For large cashouts, notify the player that their withdrawal may be subject to review by the finance team, possibly extending processing time to 24-48 hours or longer.
   - No additional documents are generally required unless explicitly requested by the finance team.

6. **Check for system overload or high transaction volume**
   - If the withdrawal has not been processed within 24 hours, inform the player that delays are often caused by high transaction volume.
   - Advise the customer to wait patiently, as the system processes requests sequentially.

7. **Investigate potential delays or issues**
   - If the withdrawal is delayed beyond 24 hours without resolution, escalate as appropriate.
   - Guide the player to contact customer support with the transaction details and any relevant screenshots for further assistance.

8. **Confirm the status of the withdrawal in the system**
   - Verify whether the withdrawal is still pending, under review, or has been completed.
   - If the transaction does not appear in the account records or system logs after the typical processing time, advise the player to check again and escalate if necessary.

9. **Resolve and communicate the status**
   - If the withdrawal has been successfully processed, inform the player accordingly.
   - If delayed or under review, explain that the process may take additional time due to system workload or review policies.
   - Provide an estimated timeframe, generally up to 24 hours, but inform the player if longer delays are possible during high volumes.

10. **Follow up and close the case**
    - Once the withdrawal is completed, confirm with the player.
    - Record all communications and actions taken.
    - Advise players to monitor their transaction records and contact support again if issues persist.

## Notes

- Always verify that the withdrawal request is within the daily limits of 100 minimum and 50,000 maximum.
- Delays are generally caused by high transaction volume or large cashout review processes.
- No extra documentation is required for large withdrawals unless specifically requested by the finance team.
- Maintain patience and communicate clearly about current processing times, especially during peak periods.

## Key points for communicating with players

- Encourage patience during high volume days or system overloads.
- Clarify that withdrawals are processed on a first-come, first-served basis.
- Remind players to check their transaction records and contact support if delays extend beyond 24 hours.
- Confirm the account verification status before processing requests.