# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request** and verify the details:
   - Confirm the withdrawal method (GCash, PayMaya, Maya).
   - Ask for the withdrawal amount.
   - Collect the player's full name, username, and transaction password.
   - Request a screenshot of the withdrawal record (from 'Member' > 'Withdrawal Record') if the player reports delays or issues.

2. **Check the player's account status**:
   - Ensure all wagering or turnover requirements are met. If not, inform the player to continue playing until requirements are fulfilled.
   - Verify if the withdrawal amount is within the current permitted limits:
     - For GCash: 500 PHP to 20,000 PHP.
     - For amounts below 500 PHP, advise using PayMaya.
   - Confirm recent deposit activity:
     - If no deposit in the past month, instruct the player to recharge with an amount equal to the current balance.

3. **Review withdrawal timing and system status**:
   - Note that the withdrawal service has a brief daily pause at 00:00 (GMT +8). If the request is made during this time, advise the player to refresh after 5 minutes.
   - Check if the withdrawal method (GCash, Maya) is currently operational:
     - If GCash is unavailable due to technical issues, inform the player to update their withdrawal info to Maya.
     - GCash transaction issues can also result in delays; recommend using PayMaya if issues persist.
   - Confirm the system is not in maintenance mode (e.g., Maya offline).

4. **Initiate withdrawal processing**:
   - Log the withdrawal request into the system.
   - Set the status as 'Approved' if all checks pass.

5. **Monitor withdrawal status**:
   - If the status is 'Approved', the withdrawal is being processed and waiting for transfer.
   - When the status shows 'transferring', it indicates the payment is being transferred by the financial department.
   - Normal processing time is approximately 3-5 minutes.
   - If the withdrawal status remains 'transferring' beyond this period, advise the player to wait.

6. **Handle failed or unsuccessful withdrawals**:
   - If the withdrawal attempt fails:
     - The amount will be automatically refunded to the player's wallet.
     - Instruct the player to wait 30 to 45 minutes if using GCash, as delays can occur due to technical issues.
     - Recommend resubmitting the withdrawal request.
   - If a withdrawal is rejected:
     - The system refunds the amount automatically.
     - Advise the player to check their account and try again once issues are resolved.

7. **Address specific issues and delays**:
   - For GCash:
     - Limit from 500 PHP to 20,000 PHP.
     - If a GCash withdrawal fails or is delayed, advise the player to switch to PayMaya for amounts below 500 PHP.
   - For Maya:
     - Use Maya when GCash is unavailable or experiencing issues.
   - During high transaction volume, processing may take longer; advise patience.
   - If players reach maximum withdrawal limit in a day, inform them to resubmit after 00:00 (GMT +8) the next day.

8. **Provide players with evidence or status updates**:
   - Request and review screenshots of withdrawal records.
   - Explain that 'transferring' means the withdrawal has been approved and is awaiting transfer.
   - If a withdrawal is slow or stuck, inform players to wait or resend the request.

9. **Guide players on account modifications**:
   - To delete or change withdrawal account details:
     - Collect full name, username, account number to delete or update, reason, and valid ID with a selfie.
     - Submit these documents for back-office review.
   - To reset withdrawal password:
     - Verify identity using ID and a clear selfie.
     - Await confirmation before creating a new password.

10. **Escalate issues as needed**:
    - If delays exceed typical processing time or there’s a suspected technical fault, escalate to the technical team.
    - Confirm with the player about ongoing system issues or maintenance.

## Notes

- Withdrawals are generally processed within 3-5 minutes; delays beyond this are likely due to high volume or technical issues.
- During GCash technical problems, switch to PayMaya or Maya.
- Do not cancel a withdrawal once processed; returns are automatic if rejected.
- Be transparent with players about delays caused by high transaction volumes or system maintenance.

## Key points for communicating with players

- Remember to inform players about processing times and potential delays.
- Confirm their withdrawal method and limits before proceeding.
- Advise switching to alternative methods (PayMaya, Maya) if GCash is unavailable or causing issues.
- Request screenshots or proof for delays or disputes.
- Clearly explain withdrawal statuses ('Approved', 'transferring') to ensure transparency.