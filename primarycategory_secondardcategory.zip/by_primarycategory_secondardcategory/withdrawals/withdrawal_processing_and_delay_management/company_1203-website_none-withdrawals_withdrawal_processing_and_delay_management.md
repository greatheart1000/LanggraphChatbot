# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal inquiry**
   - Confirm the player's account information, including username and linked payment methods (e.g., GCash, Maya).
   - Verify that the player has completed all required verification steps, such as account verification and linking the correct withdrawal method.

2. **Check the player's withdrawal request status**
   - Determine if a withdrawal request has already been submitted.
   - If no request exists, advise the player to submit a new withdrawal request via the platform.
   - If a request exists, inform the player of its current status (Pending, Processing, On Hold, or Canceled).

3. **Review the player's account and transaction details**
   - Confirm that the account details are verified and correct.
   - Verify that all turnover or betting requirements are fulfilled, if applicable.
   - Check whether the withdrawal request is within any applicable limits or rules.

4. **Assess whether any unusual activity or verification is required**
   - Determine if recent activity triggers a system review or manual review process.
   - If unusual activity or verification is needed, inform the player that their withdrawal is on hold pending review.
   - Advise the player to submit any requested documentation or screenshots if further investigation is needed.

5. **Explain the typical processing timeline**
   - Clarify that withdrawals are handled in a first-come, first-served queue.
   - Inform the player that the standard maximum processing time is up to 24 hours.
   - During high withdrawal volume, delays may occur.
   - Advise the player to wait patiently while their request is processed.

6. **Guide the player on potential delays and reasons**
   - Explain that delays can happen due to system review, high transaction volume, banking issues, or verification procedures.
   - If the withdrawal has been delayed beyond 24 hours, instruct the player to contact support with transaction details.

7. **Advise on what to do if the withdrawal has not arrived after 24 hours**
   - Ask the player to verify whether the withdrawal status is still pending or on hold.
   - Request the player to check their linked payment account for delayed credits.
   - Urge the player to submit a support ticket with their username and transaction details if delays persist.

8. **If a withdrawal is canceled or delayed due to abnormal betting activity**
   - Inform the player that withdrawals may be canceled or delayed if abnormal betting is detected on live games.
   - Recommend that the player place bets on slot games with a valid bet equal to or greater than their winning amount.
   - Advise them to wait until the next day to reapply for withdrawal after such activity.

9. **Handle canceled or rejected withdrawal requests**
   - Confirm whether the request was canceled before completion or rejected.
   - If the withdrawal was canceled intentionally (e.g., due to system review), inform the player accordingly.
   - Suggest that the player resubmit the withdrawal request after satisfying all requirements and resolving any flagged activity.

10. **Assist with withdrawal cancellations, if applicable**
    - Explain that withdrawal requests can only be canceled if they are still under review and have not yet been approved or paid.
    - If cancellation is needed, advise the player to request support promptly with their username and withdrawal details.

11. **If the player requests changes or updates to their withdrawal**
    - Inform the player that requests cannot be changed once in processing.
    - Suggest that they contact support if they believe an update is necessary before processing is complete.

12. **Monitoring and escalation**
    - If the issue persists beyond standard processing times, escalate the case to the appropriate review team.
    - Request the player to provide relevant documentation or screenshots if recommended.

## Notes

- Withdrawals are processed sequentially on a first-come, first-served basis.
- The maximum processing duration under normal circumstances is 24 hours.
- Delays are common during high request volumes, system reviews, or verification procedures.
- Ensure the player has linked a verified mobile number and payment method (GCash or Maya).
- For handling delays beyond 24 hours, advise players to contact support with transaction details.

## Key points for communicating with players

- Keep the player informed about the typical 24-hour processing window.
- Explain that delays often stem from high volume or verification checks.
- Encourage patience and advise to reach out to support with transaction proof if delays extend beyond 24 hours.
- Remind players that withdrawals are handled in order, and requests cannot be canceled once processing starts.
- In cases of abnormal activity, inform players of the need to play on slot games and reapply the next day.