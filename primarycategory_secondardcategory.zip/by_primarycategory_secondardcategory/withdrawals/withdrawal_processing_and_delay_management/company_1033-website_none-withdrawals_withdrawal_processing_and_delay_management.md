# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal inquiry or request.**  
   Confirm the player’s username or PLAYER ID and gather any relevant details about the transaction.

2. **Request the player to provide a screenshot of the withdrawal transaction.**  
   This screenshot helps the support team identify the transaction and facilitate investigation.  

3. **Verify the player's account information and compliance.**  
   - Ensure the player has completed all required verifications (such as account details and phone number).  
   - Confirm there are no violations, such as abnormal betting activity, that may prevent withdrawal processing.

4. **Check the transaction details and status in the system.**  
   - Confirm the withdrawal is in the system queue and its current status (e.g., 'Processing', 'Pending', 'Under review').  
   - Note: Processing generally means the withdrawal is being handled, but there is no fixed ETA due to potential delays from high volume or system review.

5. **Assess the withdrawal limits and policies.**  
   - Verify the amount falls within the permitted withdrawal limits (PHP 500 to PHP 20,000 per transaction).  
   - For large amounts or special cases, expect additional review, such as checking game history.

6. **Determine if the withdrawal is under review or delayed.**  
   - Delays often occur due to high transaction volume or system review.  
   - If the withdrawal has been pending or under review for more than 24 hours, proceed to next steps.

7. **Advise the player on expected processing times and delays.**  
   - Typically, withdrawals are processed within 24 hours but may take longer during peak times.  
   - Inform the player to wait patiently as requests are processed on a first-come, first-served basis.

8. **If the withdrawal is delayed beyond 24 hours or remains unresolved:**  
   - Prompt the player to provide additional details if not previously supplied, including a screenshot and transaction reference.  
   - Escalate the case to the relevant department if delays exceed standard processing times or if the transaction is stuck in review.

9. **Guide the player on necessary actions if the withdrawal attempt fails.**  
   - Ask for a screenshot of the failure message.  
   - Confirm their username or PLAYER ID.  
   - Advise following any instructions from the support team to resolve the issue.

10. **If the withdrawal is successfully processed:**  
    - Confirm the player receives the funds in their e-wallet or designated payment method.  
    - Remind them that processing may sometimes take longer due to high volume or queue order.

11. **Communicate clearly with the player throughout the process.**  
    - Manage expectations regarding potential delays.  
    - Encourage patience and advise to contact support only if delays surpass 24 hours or if instructed to do so.

12. **Close the case once the withdrawal is completed or resolved.**  
    - Ensure the player has received their funds or the issue is thoroughly explained and documented.

## Notes

- Always request a screenshot of the withdrawal transaction and the username for investigation.
- Withdrawal processing times are normally within 24 hours, but delays are possible during high volume.
- Withdrawals are processed on a first-come, first-served basis; patience is advised.
- Large withdrawal amounts undergo additional review, including game history checks.
- Escalate cases where delays extend beyond usual processing times or if the transaction remains under review for over 24 hours.

## Key points for communicating with players

- Clearly explain that processing times vary and delays can occur due to system review or high volume.
- Encourage patience and reassure players that their requests are being handled as quickly as possible.
- Instruct players to provide complete information (screenshots and transaction details) if escalation is needed.
- Remind players that withdrawal attempts may fail and to provide relevant screenshots if so.