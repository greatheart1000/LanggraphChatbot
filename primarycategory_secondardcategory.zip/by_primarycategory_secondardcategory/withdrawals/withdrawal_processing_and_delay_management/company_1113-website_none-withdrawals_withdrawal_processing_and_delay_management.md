# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the withdrawal inquiry or request from the player.**  
   - Confirm the player's identity by requesting their username and verify they have an active account.

2. **Gather necessary information for verification.**  
   - Ask for a screenshot of the withdrawal transaction if available.  
   - Collect relevant details such as:
     - Player's username  
     - Nickname  
     - Withdrawal name  
     - Email  
     - Phone number  
     - Balance  
     - Last game played  
     - GCash or PayMaya account name  
     - Selfie holding a valid ID and clear photo of the ID  
     - Last deposit receipt (if requested for security verification)

3. **Check the withdrawal status in the system.**  
   - Verify if the withdrawal request is in "processing" status or pending.  
   - Confirm whether the withdrawal has been completed or still in queue.  
   - Review if the withdrawal is being processed according to system records.

4. **Determine processing time and potential delays.**  
   - Inform the player that withdrawal times typically take up to 24 hours but may extend beyond due to:
     - Payment method (e.g., GCASH, PayMaya) processing times  
     - High withdrawal volume affecting processing order  
     - Bank processing times and queues  
     - Site activity and maintenance windows

5. **Advise the player on current processing status.**  
   - If the withdrawal is "processing," tell the player it is currently in the queue and being processed.  
   - If the withdrawal is delayed beyond 24 hours:
     - Instruct the player to provide a screenshot of the transaction and their username for support investigation if they haven't already done so.  
     - Suggest checking their account or system notifications for updates.

6. **If the withdrawal is pending or not yet processed:**
   - Explain that withdrawals are processed on a first-come, first-served basis.  
   - Remind the player that processing times vary depending on volume and method.  
   - If the process is delayed, advise patience and recommend providing the requested documentation for support to investigate.

7. **If the withdrawal is completed but the player has not received funds:**  
   - Ask the player to provide a screenshot of the transaction and their username.  
   - Escalate the case for internal investigation to identify any issues with transfer or bank processing.

8. **If the player requests cancellation of an ongoing withdrawal:**  
   - Check whether the withdrawal is still in "processing" status.  
   - If yes, request the player to submit a cancellation request promptly.  
   - If the withdrawal has already been processed or completed, inform the player that cancellation is no longer possible.

9. **If a withdrawal issue or discrepancy is reported:**  
   - Collect all relevant documentation, including transaction screenshots and IDs.  
   - Confirm that all account details (e.g., GCash or PayMaya account name) match the registration details.  
   - Forward the case to support for review and resolution.

10. **Inform the player of policies and the importance of correct account info.**  
    - Reinforce that withdrawal requests are subject to system review, and funds are safe once review is complete.  
    - Advise verifying account information before requesting withdrawal to prevent delays.

11. **Communicate estimated timelines and advise on next steps.**  
    - Highlight that typical processing is within 24 hours but may take longer during high volume or bank delays.  
    - Encourage the player to contact support with transaction proof if delays extend beyond normal times.

12. **Close the interaction once the case is resolved or further action is required.**  
    - Provide an update on the withdrawal status or next steps.  
    - Advise the player to monitor their account and keep supporting documentation ready if needed for ongoing cases.

## Notes

- Withdrawal processing times are generally up to 24 hours, but delays can occur due to banking or system factors.  
- Always verify the completeness of transaction details with players when delays are reported.  
- Ensure documentation like transaction screenshots and IDs are provided for security verification and complaint resolution.  

## Key points for communicating with players

- Be clear that processing is usually within 24 hours but affected by external factors.  
- Remind players that system review is necessary for security and compliance.  
- Encourage patience during high volume periods and when delays happen.  
- Collect all relevant documentation early to facilitate quicker resolution.