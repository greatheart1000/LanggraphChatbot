# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request and verify the provided information.**  
   - Collect the player's username or game ID and the screenshot of the withdrawal order.  
   - Ask the player if they have completed the required wagering or turnover (e.g., 10 times the amount), and if their account is fully verified.

2. **Check the player's account status and compliance with withdrawal policies.**  
   - Confirm that the account has sufficient balance for the requested withdrawal amount (minimum of 100 PHP, maximum of 25,000 PHP per day).  
   - Verify that all necessary documentation and verification conditions are fulfilled, including identity verification if required.

3. **Review the withdrawal request in the system.**  
   - Ensure the transaction receipt is valid and matches the transaction history.  
   - Determine if the withdrawal is under review or pending due to system processes.  
   - Check for any missing or incorrect documentation such as withdrawal receipts, account details, or ID copies if verification is incomplete.

4. **Identify and address common issues that may cause delays or rejections.**  
   - If the withdrawal is pending or rejected, verify whether system review is ongoing.  
   - Confirm that all documents are correct and complete, including proofs of transaction, ID, and account information.

5. **For withdrawal requests under review or pending, communicate delay reasons and estimated processing times to the player.**  
   - Explain that the withdrawal is being processed and may take some time if under system review.

6. **If the withdrawal request is rejected or remains unresolved after review, ask the player to provide further clarification or additional documentation as needed.**  
   - Request any missing proofs, transaction receipts, or ID copies.

7. **Address withdrawal issues caused by missing or incorrect documentation.**  
   - Confirm the accuracy of submitted documents.  
   - Instruct the player to resubmit correct documentation if necessary.

8. **For withdrawal issues related to account verification or password recovery, guide the player through the reset process.**  
   - Collect user ID or username, full name, ID copy (front and back), linked email, phone number or wallet ID, account balance, and a screenshot of the last successful recharge or transfer.  
   - Advise the player that a new password will be sent if the information provided matches their records.

9. **Notify the player of any specific withdrawal limits or restrictions applicable to their account.**  
   - Clarify that the platform’s policy states a minimum of 100 PHP and a maximum of 25,000 PHP per day.  
   - Mention that limits may vary based on VIP level or verification status; refer them to the official policy or support for detailed limits if needed.

10. **Once all conditions are satisfied and the withdrawal request is approved, process the withdrawal in the system.**  
    - Confirm that the transaction details are correct and initiate the payout.  
    - Advise the player on expected processing time.

11. **Communicate clearly with the player about the status of their withdrawal.**  
    - Inform them if the withdrawal has been successfully processed or if additional delays are expected.

12. **If issues persist or the withdrawal remains pending beyond normal processing times, escalate the case to the appropriate support or verification team for further review.**  
    - Ensure all collected documents and communication logs are available for review.

13. **Close the case once the withdrawal has been successfully processed or resolved.**  
    - Confirm with the player and document the resolution in the support system.

## Notes

- Always request a screenshot of the withdrawal order for verification or troubleshooting purposes.  
- If a withdrawal is stuck in review or pending, advise the player to wait for system processing.  
- Communicate delays or rejections clearly, explaining the need for documentation or verification checks.  
- Follow the current site policies and platform configuration for specifics such as turnover, verification steps, and limits.