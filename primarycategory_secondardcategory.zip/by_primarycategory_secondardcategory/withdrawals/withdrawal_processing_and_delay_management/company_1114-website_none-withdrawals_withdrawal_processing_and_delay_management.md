# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and review the player's withdrawal request**
   - Confirm the player has initiated a withdrawal via the appropriate platform.
   - Verify that the player's account information, including GCash, Pay-Maya, or bank details, are correctly linked and verified.
   
2. **Check withdrawal amount against available limits**
   - Ensure the requested withdrawal amount does not exceed the per-method withdrawal limit.
   - If the amount is above the limit for the selected method, advise the player to use an alternative method within the limit.

3. **Review transaction details and prepare for processing**
   - Confirm the accuracy of all details provided by the player.
   - Take note of the username and transaction ID.
   
4. **Submit the withdrawal request for processing**
   - Proceed to process the withdrawal request through the system.
   - Inform the player that withdrawals are processed on a first-come, first-served basis and may experience delays during high volume periods.

5. **Monitor the withdrawal queue and processing time**
   - Acknowledge that processing may take longer during periods of high volume, as requests queue and are processed in order.
   - Inform the player that the standard processing time is up to 24 hours and that delays may occur, especially for large withdrawals or during system maintenance.
   
6. **Handle delayed or pending withdrawals**
   - If the withdrawal is pending or delayed beyond the expected timeframe, verify that all verification steps are completed.
   - Ensure all account information is accurate and complete.
   - If verification details are correct but delays persist, advise the player to wait within the policy timeframe (up to 24 hours) and inform them to contact support if the issue continues.

7. **Address failed or unsuccessful transactions**
   - If the withdrawal fails or is unsuccessful, request the player to provide a screenshot of the transaction and their username.
   - Review the transaction in the back office.
   - If needed, escalate to support for further investigation.

8. **Respond to player inquiries about unreceived funds**
   - If the player reports not receiving funds, ask for a screenshot of the transaction and the username.
   - Review the transaction status and inform the player of the findings or further steps to resolve the issue.

9. **Escalate unresolved or complex issues**
   - If verification is incomplete, delays persist beyond 24 hours, or there are discrepancies, escalate to the appropriate support team with all relevant details.

## Notes
- Withdrawals are processed on a first-come, first-served basis and may be delayed during high volume.
- Large withdrawals may require additional verification.
- Ensure that all account details are verified and complete to avoid delays.
- Requests exceeding limits for specific methods should be routed via alternative methods that fit the limits.

## Key points for communicating with players
- Reassure players that withdrawals are processed within 24 hours, but delays can occur during peak periods.
- Remind players to verify their account details to facilitate smooth processing.
- Encourage patience for queued requests and advise to contact support with transaction details if issues persist beyond the standard timeframe.