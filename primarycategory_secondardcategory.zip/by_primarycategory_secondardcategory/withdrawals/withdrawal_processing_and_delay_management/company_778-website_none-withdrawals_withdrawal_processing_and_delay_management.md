# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal inquiry or request.**
   - Confirm the player wants to withdraw funds and gather the following information:
     - Selected withdrawal method (e-wallet e.g., GCash, PayMaya, Maya)
     - Withdrawal amount
     - Player’s transaction password
     - Player’s account details (e-wallet number, account name)

2. **Verify the player's withdrawal eligibility and requirements.**
   - Check if the player's account meets the general withdrawal conditions, including:
     - Meeting the current turnover requirements
     - No detection of prohibited activities or irregular betting
   - Ensure the withdrawal amount complies with the method-specific limits:
     - GCash: 500 PHP to 20,000 PHP per transaction
     - PayMaya: use for amounts below 500 PHP or if GCash is unavailable
     - Other methods: refer to official limits if specified

3. **Check the availability and suitability of the selected withdrawal method.**
   - If the player selected GCash:
     - Confirm whether GCash withdrawals are available and not restricted
     - Inform the player if GCash is temporarily unavailable or restricted
     - For amounts below 500 PHP, advise using PayMaya as an alternative
     - If the GCash platform is down or unsupported, suggest Maya or PayMaya

4. **Initiate the withdrawal process in the system.**
   - Instruct the player or perform:
     - Log into the back office system
     - Select 'Withdraw' from the homepage
     - Choose the appropriate e-wallet (GCASH, Maya, or PayMaya)
     - Enter the withdrawal amount
     - Input the transaction password
     - Submit the withdrawal request

5. **Provide feedback on expected processing time.**
   - If GCash withdrawal is used:
     - Inform the player to allow approximately 30 to 45 minutes for processing
   - For other methods, inform about the typical processing time if available, usually 3–5 minutes under normal conditions

6. **Monitor the withdrawal status.**
   - Check the withdrawal record via:
     - Homepage > Member > Withdrawal Record
     - Take a screenshot of the record if requested for verification
   - Advise the player to do the same and share the screenshot if escalation is needed

7. **Handle failed or delayed withdrawals systematically.**
   - If the withdrawal fails:
     - Ensure the withdrawal method is allowed and the details are correct
     - Re-submit the withdrawal request if applicable
     - Advise the player to retry after some time if system issues persist
   - If delays occur:
     - Inform the player that delays may be caused by high transaction volume or system maintenance
     - Recommend waiting a few minutes and checking again

8. **Assist with withdrawal record retrieval.**
   - Guide players to obtain their withdrawal record:
     - Homepage > Member > Withdrawal Record
     - Take a screenshot
   - Encourage the player to send the screenshot to support for review or issue resolution

9. **Address issues with specific withdrawal methods.**
   - For GCASH issues:
     - Inform the player that GCASH withdrawals are sometimes limited or affected by operator/system issues
     - Suggest switching to Maya or PayMaya if problems persist
   - For withdrawals outside allowed ranges:
     - Advise using an alternative method (e.g., PayMaya for amounts below 500 PHP)
   - Reiterate that all funds are safe during system issues and delays

10. **Unbinding or updating withdrawal accounts if required.**
    - If the player requests to change or unbind their withdrawal account:
      - Collect the full name, username, account details to delete, and a clear ID photo with a selfie holding the ID
      - Process the unbinding request according to company procedures

11. **Ensure compliance with all policies.**
    - Confirm that the player has met all relevant policies related to withdrawal limits and requirements
    - Advise that withdrawal policies may vary and refer to official rules if necessary

12. **Close the case after resolution.**
    - Confirm withdrawal completion or issue resolution with the player
    - If the withdrawal is successful, ensure the player receives confirmation and records
    - If issues remain unresolved, escalate as per standard procedures

## Notes

- Always verify the latest system status and withdrawal limits before processing.
- If withdrawal problems are suspected to be system-related, advise players to try again later.
- During high-volume periods or system maintenance, withdrawal processing may be slower.
- Do not provide estimates beyond what is officially stated (30–45 minutes for GCash, 3–5 minutes normally).
- Make sure to instruct players on how to obtain and send their withdrawal records when necessary.

## Key points for communicating with players

- Remind players to use allowed withdrawal methods within specified limits.
- Clarify that GCASH withdrawals are limited to 500 PHP–20,000 PHP and may be temporarily unavailable.
- Reassure players that all funds are secure, even if delays occur.
- Encourage patience during system downtime or high transaction periods.
- Guide players on how to view and obtain their withdrawal records for transparency.