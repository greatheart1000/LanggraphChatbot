# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request.**  
   - Confirm the request details, including the withdrawal amount and preferred e-wallet method.

2. **Verify player identity and account status.**  
   - Ensure the account has completed any necessary verification steps.  
   - Check for account inactivity: if inactive over the past month, instruct the player to recharge with an amount equal to their current balance before proceeding.

3. **Check withdrawal limits and method availability.**  
   - For GCash withdrawals: confirm the amount is between 500 PHP and 20,000 PHP.  
   - For amounts below 500 PHP or if GCash is unavailable, advise using PayMaya instead.  
   - If GCash is unavailable due to technical issues, instruct the player to update withdrawal info to Maya.

4. **Assess current system conditions for the requested method.**  
   - Inform the player about potential delays during high transaction volume or system issues.  
   - Advise using alternative methods if available, e.g., switch to PayMaya when GCash is experiencing issues.

5. **Instruct the player on how to initiate the withdrawal in the system.**  
   - 1) Click 'Withdraw' on the Homepage.  
   - 2) Swipe and select the preferred e-wallet.  
   - 3) Input the withdrawal amount.  
   - 4) Input the transaction password.  
   - 5) Click 'Submit.'

6. **Monitor the withdrawal status after submission.**  
   - If status shows 'Transferring,' it indicates the request has been approved, and the financial department is processing the transfer.

7. **Handle withdrawal failures or delays.**  
   - If the withdrawal fails:  
     - Confirm the amount has been refunded to the player's wallet promptly.  
     - Advise the player to resubmit the request.  
   - For delays or failures caused by high system volume:  
     - Inform the player of possible slow processing (exceptions include GCash or PayMaya delays of 30-45 minutes).  
     - If the withdrawal has been delayed beyond normal processing times, advise to wait or contact support.

8. **Investigate delayed or failed GCash withdrawals.**  
   - If experiencing GCash issues, suggest switching to PayMaya or updating the withdrawal info to Maya.  
   - In case of ongoing GCash unavailability, confirm the player updates their withdrawal method to Maya if applicable.

9. **For withdrawal success or completion.**  
   - Advise the player to review their 'Withdrawal Record' by:  
     - 1) Clicking 'Member' on the homepage.  
     - 2) Selecting 'Withdrawal Record.'  
     - 3) Taking a screenshot for their reference or for verification purposes.

10. **Manage deposits and withdrawal verification.**  
    - For withdrawal after inactivity, confirm the player has recharged with an amount equal to their current balance if needed.  
    - If the player encounters repeated delays or failures, review transaction records, and ensure account details are correct.

11. **Escalate issues if necessary.**  
    - If there are persistent problems—such as system errors, accounts stuck in 'Transferring' status, or technical issues with GCash or Maya—escalate to the technical support team or the relevant department.

## Notes

- Withdrawals generally process within 3-5 minutes under normal conditions, but delays are common during system high volume or technical issues.  
- For GCash withdrawals, delays of 30-45 minutes are typical when system issues occur.  
- When GCash is unavailable, switch to Maya and ensure account info is updated accordingly.  
- Always verify that withdrawal limits are adhered to, and request players to resubmit if a withdrawal fails or is rejected.  
- In cases of account inactivity, players must recharge with an amount equal to their current balance to proceed with withdrawals.

## Key points for communicating with players

- Clearly inform players about current GCash withdrawal limits (500 PHP to 20,000 PHP).  
- Remind players that GCash withdrawals may be delayed or temporarily unavailable due to technical issues.  
- Guide players to view their withdrawal record by accessing the 'Member' > 'Withdrawal Record' section and taking a screenshot.  
- Encourage players to resubmit the withdrawal request if it fails or delays, and to contact support if issues persist.  
- Always confirm the latest system status or method availability before advising the player to proceed.