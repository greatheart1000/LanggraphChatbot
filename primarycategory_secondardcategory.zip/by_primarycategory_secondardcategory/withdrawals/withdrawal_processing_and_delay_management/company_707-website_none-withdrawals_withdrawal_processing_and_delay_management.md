# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player inquiry or withdrawal request**
   - Confirm the player is requesting to withdraw funds.
   - Verify they have met all eligibility requirements, including turnover/wagering if applicable.

2. **Collect necessary information from the player**
   - Withdrawal method (e-wallet preferred: GCash, PayMaya, etc.).
   - Withdrawal amount.
   - Transaction password.
   - Ensure the amount is within the allowed limits:
     - Minimum: 100 PHP.
     - Maximum: 20,000 PHP.
     - For GCash: 500 PHP to 20,000 PHP per transaction.
     - For amounts below 500 PHP, advise using PayMaya.

3. **Check account status and conditions**
   - Confirm the player has fulfilled the turnover requirement.  
   - If withdrawal is blocked due to inactivity, advise recharge of an amount equal to current balance.
   - Verify that the account details (e-wallet info, linked accounts) are correct and valid.
   - Ensure the player has a valid linked e-wallet account (e.g., GCash, Maya/PayMaya).

4. **Initiate withdrawal in the back system**
   - Log into the back office system.
   - Open the withdrawal interface.
   - Enter the player's withdrawal details:
     - E-wallet selection.
     - Amount.
     - Transaction password.
   - Submit the withdrawal request.

5. **Monitor withdrawal status**
   - Confirm if the status is "transferring."
   - If status is "transferring," the request has been approved and is awaiting transfer.
   - Note: Withdrawal processing can take approximately 30–45 minutes.
   - If the withdrawal request is pending or delayed beyond normal times, check for system issues or contact the finance team.

6. **Handle technical issues or limits**
   - If GCash withdrawals are unavailable or limited, advise using alternative methods such as PayMaya, USDT, or Online Banking.
   - For GCash withdrawals:
     - Allowed if the amount is between 500 PHP and 20,000 PHP.
     - Withdrawals below 500 PHP should use PayMaya for smoother processing.
   - For failed or delayed GCash withdrawals, inform the player to wait 30–45 minutes for processing.

7. **Review withdrawal records**
   - Guide the player to view withdraw records via Home > Member > Withdrawal Record.
   - Advise taking a screenshot if they need support or to verify request status.

8. **Inform player about potential delays and alternative routes**
   - If technical issues occur, advise using other supported payment methods such as Maya, USDT, or Online Banking.
   - Explain that delays may occur during high transaction volumes or due to operator issues; reassurance that funds are safe and will be processed once system stability resumes.

9. **Address special cases**
   - If a withdrawal is rejected or funds are deducted due to abnormal betting activity, inform the player and suggest contacting support for review.
   - If withdrawal is blocked due to an incomplete turnover, remind the player to fulfill wagering requirements first.

10. **Escalate or further assist if needed**
    - If player reports issues with withdrawal processing, verify all details, check for system notices, and escalate to the finance or technical team if necessary.

## Notes

- Withdrawals can only be canceled if they are not yet in processing.
- Processing times may vary; patience is advised, especially during peak times or system outages.
- Always ensure the player’s account details and e-wallet accounts are fully verified to prevent delays.

## Key points for communicating with players

- Confirm withdrawal amounts are within allowed limits.
- Remind players GCash is limited to 500 PHP–20,000 PHP and advise PayMaya for smaller amounts.
- Explain that "transferring" status indicates the request has been approved and is being processed.
- Advise to wait approximately 30–45 minutes for processing, and inform about alternative methods if GCash is unavailable.
- Encourage players to check withdrawal records regularly and share screenshots if needed.