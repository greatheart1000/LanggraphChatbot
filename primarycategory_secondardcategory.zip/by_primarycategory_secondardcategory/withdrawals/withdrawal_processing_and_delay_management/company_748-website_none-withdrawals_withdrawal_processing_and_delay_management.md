# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player’s withdrawal inquiry.**
   - Confirm if the player is requesting to view their withdrawal record, inquire about withdrawal delays, failures, or specific issues.
   - Collect necessary information if required to assist (e.g., player ID, username, transaction details).

2. **Verify player eligibility for withdrawal.**
   - Ensure the player has completed any required turnover or wagering if applicable.
   - Check recent deposit activity if relevant; advise re-depositing if no deposit in the past month to proceed with withdrawal.

3. **Guide the player to check their withdrawal record for verification.**
   - Instruct to access the account dashboard:
     - Click on 'Member' from the homepage.
     - Select 'Withdrawal Record.'
     - Take a screenshot of the withdrawal record for verification purposes or future reference.

4. **Assist with withdrawal request details.**
   - Confirm the selected e-wallet method (e.g., GCash, PayMaya, Bank Transfer).
   - Ensure the withdrawal amount adheres to the specific limits:
     - GCash: 500 PHP to 20,000 PHP.
     - For amounts below 500 PHP, recommend using PayMaya.
   - Verify the transaction password entered by the player.

5. **Initiate or verify withdrawal submission.**
   - Ensure the player submits the withdrawal request successfully.
   - Inform that once a withdrawal shows 'success,' it cannot be reversed.
   - Clarify that if the withdrawal is marked 'transferring,' it means it has been approved, and the funds are being transferred by the financial department.

6. **Explain processing times and potential delays.**
   - Typically, withdrawals are processed within 3–5 minutes.
   - During high volume or system maintenance, delays may occur, especially at 00:00 daily withdrawal maintenance.
   - In case of delays:
     - Advise the player to refresh the page after 5 minutes.
     - For GCash withdrawals, allow 30–45 minutes for processing.
     - If GCash is temporarily unavailable or down, suggest alternatives like PayMaya, Maya, or Online Bank Transfer.

7. **Handle failed withdrawal situations.**
   - Inform that if a withdrawal fails, the funds will automatically return to the account.
   - Advise the player to resubmit the withdrawal request.
   - If there were errors in bank details or transaction info, inform the player that PHSPIN is not liable; suggest unbinding incorrect details and submitting a new request.

8. **Address delayed or pending withdrawals.**
   - Confirm whether the withdrawal status shows 'transferring':
     - If yes, reassure that the request has been approved, and the transfer is pending.
   - For withdrawals showing 'transferring' for a prolonged period:
     - Advise patience and suggest checking the withdrawal record.
     - If extremely delayed, escalate to the finance support team.

9. **Advise on handling technical issues and unavailability.**
   - If GCash withdrawals are temporarily unavailable due to maintenance or technical issues:
     - Recommend using alternative methods such as PayMaya, Maya, or Bank Transfer.
     - For ongoing GCash withdrawal requests, advise waiting 30–45 minutes or until service is restored.

10. **In case of withdrawal delay or absence of received funds.**
    - Confirm if the withdrawal shows 'success' or 'transferring.'
    - If 'success,' but funds are not received:
      - Clarify no action can be taken once marked successful; advise patience.
    - If 'transferring,' wait until the transfer completes.
    - Suggest reviewing the withdrawal record or receipt for details.
    - If issues persist, escalate to the support or finance team with relevant information.

11. **Proceed with support or escalation if necessary.**
    - When delays exceed normal processing times or if technical issues persist, escalate to the finance or technical support team for further investigation.
    - Collect all relevant documentation (screenshots, transaction IDs).

12. **Close the case.**
    - Confirm with the player that the issue is resolved or that they are informed of ongoing investigation.
    - Advise the player to keep records of the transaction for reference.
    - Provide further contact options if needed.

## Notes

- Always verify withdrawal records and screenshots for evidence.
- Remind players that withdrawal times can be affected by high volume or technical issues.
- Emphasize the importance of correct transaction details; errors are not the platform’s liability.
- Keep players informed on alternative withdrawal methods if their primary method is temporarily down.

## Key points for communicating with players

- Clarify that normal withdrawal processing times are 3–5 minutes, but delays may happen.
- Explain that 'transferring' status indicates approval and pending transfer.
- Recommend alternative channels in cases of GCash unavailability.
- Emphasize patience during high volume periods or system maintenance.
- Remind players to review withdrawal records and keep receipts for verification.