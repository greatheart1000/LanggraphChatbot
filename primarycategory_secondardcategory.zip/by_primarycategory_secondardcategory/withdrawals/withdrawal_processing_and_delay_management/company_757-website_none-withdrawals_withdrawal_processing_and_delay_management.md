# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player's withdrawal request.**  
   - Collect essential information: player’s username, full name, withdrawal amount, preferred e-wallet (e.g., GCash, PayMaya), and transaction password.  
   - Verify that the player has fulfilled all requirements, such as completing the turnover requirement by playing slots or fish games before withdrawing.

2. **Check withdrawal eligibility based on account activity.**  
   - If the player has not deposited in the past month, instruct them that they must recharge with an amount equal to their current balance to proceed.  

3. **Verify withdrawal account details and binding status.**  
   - Confirm the withdrawal account is properly bound.  
   - If the player requests to unbind or change their withdrawal account, instruct them to provide:  
     - Full name, username, number to delete, reason for deletion, valid ID picture, and a selfie holding the ID (ensuring all details are clear).  
     - Process according to verification and security procedures.

4. **Review withdrawal amount against limits.**  
   - For GCash: limited to 500 PHP to 20,000 PHP.  
   - For withdrawals below 500 PHP: recommend using PayMaya for smoother transactions.  
   - If the amount exceeds limits or if the withdrawal method is unavailable, advise the player accordingly.

5. **Ensure the player's turnover requirement is met.**  
   - Confirm the player has completed the necessary wagering (e.g., playing slots or fish games) before processing the withdrawal.  
   - If not met, inform the player they must fulfill this requirement before withdrawing.

6. **Initiate the withdrawal process in the system.**  
   - In the back office, create or verify the pending withdrawal request with correct details.  
   - Ensure the transaction status updates to ‘transferring’ indicating approval and ongoing processing.

7. **Handle high transaction volumes or failures.**  
   - Inform the player that due to massive transaction volume, withdrawals may be slow or may fail.  
   - If the withdrawal status shows failure or gets stuck, advise the player to resubmit the withdrawal request.  
   - Note that in case of failure, funds are automatically refunded to the wallet.

8. **Monitor the status of withdrawal requests.**  
   - Check for statuses such as ‘transferring’ (waiting for payment), ‘audit failure’ (cancelled and funds returned), or ‘failed’.  
   - When the status is ‘transferring’, wait for the financial department to complete the transfer.

9. **Confirm withdrawal completion.**  
   - Once the withdrawal status updates to ‘transferred’ or equivalent, instruct the player to log into their e-wallet to verify receipt.  
   - Remind players that GCash withdrawals may take 30 to 45 minutes if processed successfully; GCash may also be temporarily unavailable due to technical issues.  
   - For issues with GCash, advise switching to Maya or PayMaya as alternatives.

10. **Provide withdrawal record for verification.**  
    - Guide the player to view their withdrawal record:  
      1. On the homepage, click ‘Member’.  
      2. Select ‘Withdrawal Record’.  
      3. Take a screenshot to share or review the withdrawal details such as amount, account number, reference, date, and time.

11. **Address delays or failures.**  
    - In case of slow or failed withdrawals, advise the player to resubmit the request after verifying the correct details and waiting the recommended processing times.  
    - Remind players that during high transaction times, delays are normal and re-submissions may be necessary.

## Notes

- All withdrawals are subject to the completion of required turnover.  
- Withdrawal attempts during technical issues with GCash may be affected; switching to Maya or PayMaya is recommended when GCash is unavailable.  
- For successful withdrawal processing, ensure all details are accurate and matches the linked account.  
- If a withdrawal shows ‘audit failure’, the request was canceled, and funds were returned automatically.  
- Players should be aware that withdrawal processing times may vary depending on transaction volume and system status.

## Key points for communicating with players

- Confirm their account activity status and current balance if relevant.  
- Remind them of limits for GCash and alternative options like PayMaya.  
- Explain that high transaction volume may cause delays or failures, and re-submission might be necessary.  
- Advise on required documentation for unbinding or resetting withdrawal details.  
- Reinforce that withdrawal requests can take 30 to 45 minutes for GCash, or longer during system issues.