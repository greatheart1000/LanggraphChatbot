# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request.**  
   Collect the following information:
   - Player's account details  
   - Valid withdrawal number (e.g., Maya or GCash number)  
   - Screenshot of the withdrawal transaction (if required)  
   - Any additional ID verification if requested  

2. **Verify accuracy of the withdrawal details.**  
   - Confirm that the withdrawal number has been entered correctly.  
   - Inform the player that withdrawal numbers cannot be deleted once bound; they can add a new number for future withdrawals.  
   - Advise to double-check the number before submitting to avoid errors.

3. **Check for required documentation and account information.**  
   - Ensure that all account details are accurate.  
   - Confirm that the player has provided necessary screenshots or verification details.  
   - If applicable, verify ID or other documentation to prevent delays.

4. **Submit the withdrawal request for processing.**  
   - Place the request into the system for review and processing.  
   - Note that withdrawals are processed on a first-come, first-served basis.

5. **Inform the player about the processing time.**  
   - Notify the player that withdrawal processing may take up to 24 hours.  
   - Explain that delays can occur during high volume periods.  
   - Reassure the player that all pending withdrawals will be completed as soon as possible.

6. **Monitor withdrawal status.**  
   - Advise the player to check the status via the system's 'Processing' queue.  
   - Remind that they should wait patiently as the system processes their request in order.

7. **Handle delays or issues.**  
   - If the withdrawal remains pending beyond 24 hours, confirm that the transaction is in the processing queue.  
   - If delays exceed the standard processing time, request the player to contact customer support and provide proof of transaction.

8. **Address withdrawal or deposit delays.**  
   - Advise the player to wait patiently, as transactions are processed in order.  
   - If delays persist, escalate to support with all relevant proof.

9. **Resolve any issues with withdrawal details or status.**  
   - If the player has provided incorrect details (e.g., wrong withdrawal number), explain that they cannot delete or modify existing bound numbers but can add new ones for future use.  
   - Ensure the player verifies details before re-submitting or adding new numbers.

10. **Complete the case or follow-up.**  
    - Once the withdrawal is processed and confirmed, update the player accordingly.  
    - Provide any additional support if needed to clarify the status or next steps.

## Notes

- Withdrawals are processed on a first-come, first-served basis.  
- The maximum processing time is up to 24 hours.  
- Delays can occur during periods of high transaction volume.  
- Always verify withdrawal details before submission to avoid errors or delays.  
- If a withdrawal remains pending beyond the standard window, contact support with proof of the transaction for further assistance.

## Key points for communicating with players

- Clearly inform players that processing can take up to 24 hours.  
- Remind players to double-check withdrawal numbers before submitting.  
- Explain that delays, though uncommon, may happen during busy periods.  
- Encourage patience and instruct them to contact support if their withdrawal is delayed beyond the expected timeframe.