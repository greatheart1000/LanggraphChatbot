# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal inquiry**  
   - Determine whether the issue is a delay, non-receipt, or general question about processing times.  
   - Ask the player for their withdrawal reference number and account details to locate the transaction.

2. **Verify player's account and withdrawal request**  
   - Confirm that the e-wallet account (e.g., GCash) is correctly linked and verified.  
   - Check the player's account balance and ensure no pending issues or discrepancies.  
   - Verify if the player has met any pre-withdrawal requirements, such as wagering or bonus conditions, if applicable.

3. **Check the withdrawal status in the system**  
   - Access the transaction in the back office to determine the current processing stage.  
   - Explain to the player that processing times are normally fast but may be delayed during high transaction volume, and updates are provided as progress occurs.

4. **Inform the player about potential delays**  
   - Advise that withdrawal processing can take up to 24 hours during periods of high transaction volume.  
   - Clarify that there is no guaranteed processing time, and delays may occur due to system checks or volume.

5. **If the withdrawal is pending or processing**  
   - Instruct the player to check the withdrawal status periodically in their account.  
   - Confirm that the player’s linked e-wallet account details are correct and that they have submitted all required verification if requested.

6. **If funds are delayed beyond typical processing time**  
   - Ask the player if they have already received the withdrawal or if the funds are still not credited after a significant delay.  
   - If not received after a reasonable period, advise the player to send a screenshot of the transaction receipt and wait for the finance team to verify.

7. **Follow up if necessary**  
   - Escalate to the back office or finance team with all transaction details if the delay persists.  
   - Keep the player informed that review and processing are ongoing, emphasizing patience during high volume periods.

8. **Address issues with uncredited deposits or withdrawals**  
   - Confirm the transaction receipt details provided by the player.  
   - Advise the player to wait for system verification, as delays may be caused by bank or system issues.  
   - If needed, request additional proof or documentation to assist in resolution.

9. **Warn about policies regarding delays**  
   - Explain that withdrawal requests are processed on a first-come, first-served basis.  
   - Inform the player that delays are typically due to high transaction volume and system checks, and that the processing time can be within 24 hours but may be longer.

10. **In case of unresolved issues or further delays**  
    - Advise the player to contact support again with their withdrawal reference number.  
    - Reiterate that processing times can vary and that progress updates are provided when available.

## Notes
- Always request and record the withdrawal reference number and screenshots if the player provides them.  
- Emphasize that processing times are subject to system volume and bank processing times.  
- Remind players that they can see the withdrawal status within their account dashboard, but updates are only provided when available.  
- Ensure players are aware that they may need to meet specific requirements (e.g., wagering) before withdrawal processing can proceed, if applicable.

## Key points for communicating with players
- Clearly inform players about the no-guaranteed processing time and possible delays during high volume periods.  
- Encourage patience and reassure that their withdrawal will be credited once processed.  
- Always verify transaction details before escalating issues to technical or finance teams.  
- Request screenshots or transaction receipts when no funds are received after expected times for efficient resolution.