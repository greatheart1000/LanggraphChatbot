# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify Player Identity and Withdrawal Details**
   - Confirm the player’s registered name matches exactly with the name on the linked e-wallet (e.g., GCash, PayMaya) to ensure proper processing.
   - Ask the player to provide the relevant withdrawal method (e-wallet), withdrawal amount, and their transaction password.
   - Ensure the withdrawal amount complies with the minimum and maximum limits:
     - For GCash: between 500 PHP and 20,000 PHP per transaction.
     - For PayMaya and other methods: as applicable, but note that withdrawals below 500 PHP may need to use PayMaya for smoother processing.

2. **Check the Player’s Withdrawal Method Binding**
   - Verify the withdrawal method (GCash, PayMaya, Online Bank Transfer, USDT) is correctly bound to the player’s account.
   - If a withdrawal method is not yet set up, guide the player on how to bind the method by adding the relevant e-wallet and creating a transaction password.

3. **Identify the Selected Withdrawal Option and Systems Status**
   - Determine the player’s chosen withdrawal method.
   - Check if the method (e.g., GCash) is temporarily unavailable due to technical issues or maintenance.
   - If the selected method is GCash and unavailable, instruct the player to switch to an alternative method such as PayMaya, Maya (PayMaya), USDT, or Online Bank Transfer.

4. **Review Previous Withdrawals and Pending Transactions**
   - View the player’s Withdrawal Record: on the homepage, click Member > Withdrawal Record to verify the status and history.
   - If there is a pending withdrawal marked as "Transferring," inform the player that requests cannot be canceled once they are in this status.

5. **Process the Withdrawal Request**
   - Submit the withdrawal request by clicking “Submit” after entering all required information.
   - The request will be processed by the finance team, usually within 3-5 minutes.
   - If the withdrawal is via GCash and within the limits, allow 30–45 minutes for completion if the transaction is already initiated.

6. **Handle Technical or System-Related Delays**
   - If the withdrawal is delayed beyond the expected processing time:
     - Check for high transaction volume or system issues.
     - Remind the player that delays can occur during peak times or maintenance.
     - If the withdrawal remains pending beyond the stated window, suggest the player contact customer support with proof of the transaction.

7. **Address Withdrawal Failures or Unavailability**
   - If the withdrawal fails or GCASH is temporarily unavailable:
     - Advise switching to an alternative method such as PayMaya, Maya, USDT, or Online Bank Transfer.
     - Inform the player that if they experience persistent system issues with GCASH, using alternatives will usually result in smoother processing.
   - If a withdrawal was deducted but not credited, reassure that reimbursements typically occur within 2–3 days.

8. **Handle Special Cases and Issues**
   - For failed GCASH withdrawals due to operator or technical issues, allow the player to retry or switch methods.
   - If a withdrawal is blocked due to inactivity or verification issues, advise the player to recharge an amount equal to their current balance before attempting another withdrawal.
   - For delayed or problematic transactions, verify the details and receipts, then escalate if necessary.

9. **Final Confirmation and Record Keeping**
   - Confirm the withdrawal request status with the player.
   - Send a screenshot of the withdrawal record if proof is needed for further support.
   - Advise the player to monitor their withdrawal record under Member > Withdrawal Record for updates.

## Notes

- Always ensure the player’s withdrawal details are accurate to avoid processing issues.
- GCASH withdrawals are subject to limits and may be temporarily unavailable; use PayMaya or other alternatives when necessary.
- Normal withdrawal processing time is approximately 3-5 minutes, but delays of 30–45 minutes can occur with GCash.
- For any issues beyond standard processing times, guide players to contact support with proof of transaction.
- Reimbursements are typically processed within 2-3 days if a withdrawal fails after deduction.

## Key points for communicating with players

- Emphasize the importance of matching names on accounts and e-wallets for smooth withdrawal processing.
- Clearly inform players about the withdrawal limits and when to consider alternative methods.
- Reassure players that delays can happen during high volume or system maintenance and advise patience.
- Walk players through the process step-by-step and provide alternative options if the primary method is unavailable.