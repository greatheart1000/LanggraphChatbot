# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player inquiry regarding withdrawal delay or failure**  
   - Ask the player to provide relevant details, such as withdrawal request time, method used, transaction ID/reference number, and any screenshots they can share of their withdrawal record.
   - Confirm whether the player has met the necessary turnover (wagering) requirements for the withdrawal or promotion, if applicable.

2. **Check the player's withdrawal record**  
   - Log into the back office system or relevant platform.
   - Navigate to the player’s profile and locate the Withdrawal Record section.
   - Verify the status of the withdrawal request:
     - If the status is **"transferring"**, it means the withdrawal has been approved and is waiting for the financial department to transfer funds.
     - If the status is **"approved"**, the withdrawal is in the process of being transferred.
     - If the status is **"failed"** or **"not received"**, proceed to the next step.

3. **Verify processing times and potential delays**  
   - Standard processing time for withdrawals is **3-5 minutes**.
   - During high system load or large transaction volumes, delays are possible.
   - For GCash or Maya (PayMaya) withdrawals, allow **30-45 minutes** for processing after submission.
   - If the withdrawal is more than the expected processing time:
     - Resubmit the withdrawal request, ensuring all details are correct.
     - Confirm the player has submitted all required information or documentation.
     - Advise the player to wait at least this period before following up.

4. **Check for technical or system issues that may cause delays**  
   - Confirm if GCash or other e-wallet services are experiencing reported outages or delays.
   - If GCash withdrawals are temporarily unavailable or delayed:
     - Suggest switching to an alternative method such as PayMaya, GrabPay, Gotyme, USDT, or Online Bank Transfer.
   - If the player’s withdrawal method is GCash:
     - Remind that limits are **500 PHP to 20,000 PHP** per transaction.
     - For smaller amounts below 500 PHP, advise using PayMaya for smoother processing.

5. **Instruct the player on actions if withdrawal has failed or funds are returned**  
   - If the withdrawal attempt fails, the funds are automatically returned to the player's wallet.
   - Advise the player to verify their wallet balance.
   - Recommend re-initiating the withdrawal with correct details if needed.
   - Ensure the player has met all requirements, including turnover and correct transaction information.

6. **If withdrawal is delayed or stuck beyond normal processing time**  
   - Instruct the player to **resubmit the withdrawal request**.
   - Ask them to provide any supporting documentation or screenshots of their withdrawal record.
   - Confirm all entered details are correct before resubmission.

7. **Escalate to support or finance team if issues persist**  
   - Collect all relevant information, including transaction IDs, timestamps, screenshots, and communication notes.
   - Escalate the case according to internal procedures for further investigation.
   - Inform the player that their case is being escalated and will be followed up promptly.

8. **Advise on best practices and key points for communication**  
   - Remind players that withdrawals are normally processed within 3-5 minutes.
   - During high volume, delays are normal, and resubmission may be necessary.
   - Always verify that the correct details and documentation are provided.
   - Emphasize that funds are secure during the processing period.
   - When GCash is temporarily unavailable, recommend alternative methods as specified.
   - Encourage players to keep screenshots of withdrawal records for their reference.

## Notes
- Always confirm the withdrawal status in your back end before advising the player.
- GCash withdrawal limits per transaction are **500 PHP to 20,000 PHP**.
- If a GCash withdrawal is delayed or fails, suggest switching to PayMaya or other available methods.
- Withdrawal processing times can extend during high volume or technical outages.
- Funds are secure during the processing period; no action needed to safeguard them.
- Collecting clear records and screenshots helps facilitate case escalation and resolution.

## Key points for communicating with players
- Clarify that withdrawal processing normally takes 3-5 minutes, with additional time for GCash (30-45 minutes).
- Explain delays may occur during high system loads or technical issues.
- Always advise resubmission if the withdrawal does not arrive after the expected time.
- Recommend alternative withdrawal methods if delays persist or if technical issues are reported.
- Encourage players to provide screenshots and withdrawal records for faster resolution.