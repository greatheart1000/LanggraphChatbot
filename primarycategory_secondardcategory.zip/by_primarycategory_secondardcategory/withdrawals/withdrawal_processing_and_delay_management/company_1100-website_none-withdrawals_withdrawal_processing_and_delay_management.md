# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's account details and requirements**
   - Confirm the player's account is verified, including phone number verification, which may take around 25 minutes.
   - Check if the account has any ongoing violations or restrictions that prevent withdrawal.
   - Ensure the player's withdrawal account is properly linked (e.g., e-wallet like GCash or PayMaya).

2. **Ensure the player has completed all betting and turnover requirements**
   - Confirm the remaining turnover (wagering) on the player's balance is zero, meaning all wagering requirements have been fulfilled.
   - Advise the player to fulfill remaining turnover via slot games, as every slot bet counts toward turnover.
   - If the player has betting activity on live games suspected of being abnormal or suspicious, instruct them to switch to slot games and ensure bets are valid and match or exceed their winnings.

3. **Handle any abnormal betting activity or blocked withdrawals**
   - If a withdrawal is blocked due to suspected abnormal betting on live games:
     - Instruct the player to switch to slot games.
     - Confirm the player's slot bets are valid and at least equal to their live game winnings.
     - Once the player completes the turnover in slot games, advise them to reattempt the withdrawal.

4. **Submit a withdrawal request**
   - Once verification and wagering requirements are completed:
     - Guide the player to submit their withdrawal request.
     - Ensure all required documentation (e.g., ID, proof of transaction) is provided if needed.

5. **Monitor the withdrawal status in the system**
   - Check if the withdrawal status is "Processing," indicating it is in the queue.
   - Explain to the player that withdrawal processing is handled on a first-come, first-served basis and delays may occur during high volume periods.
   - Advise the player not to spam support messages, as this does not speed up processing.

6. **Address delays or issues related to high transaction volume**
   - If the withdrawal remains marked as "Processing" for an extended period:
     - Inform the player that delays are common during high volumes.
     - Recommend logging out and back in after 10–30 minutes to check for updates.
     - If the delay persists beyond typical processing times (up to 24 hours), advise contacting support for status inquiry.

7. **Handle delayed or canceled withdrawals related to betting behavior**
   - If a withdrawal is delayed or canceled due to abnormal betting activity:
     - Confirm the player has switched to slot games with valid bets at least equal to their winnings.
     - Guide the player to reattempt the withdrawal after fulfilling the turnover requirement.

8. **Communicate expected processing times and delays**
   - Clearly explain to the player that withdrawals are processed in order, and delays can occur during peak times.
   - Advise patience, emphasizing that withdrawals will be credited once processed.
   - Mention that processing times usually do not exceed 24 hours, but can be longer depending on the payment method and transaction volume.

9. **Provide guidance on withdrawal limits and requirements**
   - Remind the player that withdrawal limits range from 500 PHP to 20,000 PHP per transaction, depending on account type and verification status.
   - Ensure the player is aware they must meet all requirements before withdrawal (verified phone number, completed wagering, linked account).

10. **Support case closure or further assistance**
    - If the player has fulfilled all conditions and the withdrawal is still delayed, escalate the issue according to internal protocols.
    - Confirm with the player that they understand the process and encourage patience.

## Notes
- All withdrawal requests are processed in the order received and may be delayed during periods of high volume.
- Withdrawals marked as "Processing" are queued and will be completed as soon as possible.
- Spamming support does not accelerate processing; patience is required.
- Ensure players complete all verification and wagering steps before requesting withdrawal to avoid delays.

## Key points for communicating with players
- Emphasize the first-come, first-served processing policy.
- Reassure players that their withdrawal will be completed once it reaches the front of the queue.
- Advise against repeated messages or requests to speed up processing.
- Remind players to verify their account details and fulfill wagering requirements to prevent delays.