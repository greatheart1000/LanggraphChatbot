# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify player identity and withdrawal eligibility**
   - Ensure the player has completed all KYC requirements, including providing valid ID and selfie holding the ID if requested.
   - Confirm the player’s account is active and unlocked.
   - Check if the player has met the turnover requirements for withdrawal:
     - Confirm whether the player has placed qualifying bets on eligible games.
     - Verify if the player has fulfilled any deposit or wagering requirements related to ongoing promotions.
   - Determine if the player’s withdrawal amount adheres to the withdrawal limits:
     - GCash withdrawals: PHP 500 to PHP 20,000.
     - PayMaya or other methods for amounts below PHP 500.

2. **Check the status of the withdrawal request**
   - Confirm the player has initiated the withdrawal by clicking 'Withdraw' on the homepage.
   - Ask the player to provide the withdrawal reference or record if they have one.
   - Guide the player to the Withdrawal Record:
     - Instruct them to go to 'Member' > 'Withdrawal Record'.
     - Advise them to take a screenshot of the withdrawal record for support if necessary.

3. **Ensure the withdrawal request complies with system and service constraints**
   - Verify the selected withdrawal method (GCash or PayMaya):
     - GCash: PHP 500–PHP 20,000; note that withdrawals below PHP 500 should use PayMaya.
     - Confirm if the GCash service is operational; if delayed or failed, advise using PayMaya.
   - Confirm the player has entered the correct transaction password.
   - Check if the player has reached the maximum number of withdrawal requests per day; if limits are hit, inform them they can submit another request the next day.

4. **Assess potential delays or issues with the withdrawal**
   - Inform the player that withdrawals are typically processed within 3–5 minutes.
   - If the player reports delays longer than this:
     - Check for high volume or network issues such as GCash outages.
     - Advise the player that during high transaction volume, processing may take longer.
     - Remind that funds are secure and will be processed once the delay clears.

5. **Handle specific issues or failures**
   - For failed withdrawal attempts:
     - Confirm the reason for failure if provided (e.g., incorrect details, technical issues).
     - Advise the player that funds are returned to their wallet if the request fails.
     - Recommend re-submitting the withdrawal request after resolving the issue.
   - If GCash withdrawals are slow or failing:
     - Suggest using PayMaya as an alternative for withdrawals below PHP 500.
     - For larger amounts within PHP 500–PHP 20,000, re-submit or wait for system resolution.
     - Encourage the player to check the status in their Withdrawal Record.
   - For delayed withdrawals, ask the player to share their withdrawal record and reference for support follow-up.

6. **Request additional information if needed**
   - If the player reports issues, request a screenshot of the withdrawal record.
   - Collect necessary details such as the full name, username, and any relevant transaction IDs or reference numbers.

7. **Escalate or further assist based on the situation**
   - If a withdrawal fails repeatedly or is not received after the normal processing time:
     - Escalate to the finance team or relevant support department.
     - Advise the player to provide the withdrawal record screenshot and reference number.
     - Confirm the player’s withdrawal account details are correctly linked and not unbound or reused for other accounts.

8. **Instruct on withdrawal record management**
   - Guide the player to view or export their withdrawal record:
     - From the 'Member' > 'Withdrawal Record' page.
     - Take a clear screenshot for any further communication or proof.

9. **Follow up and close the case**
   - Confirm with the player that their withdrawal is now processed or provide an estimated time if pending.
   - Advise them to monitor their e-wallet account for the arrival of funds.
   - Thank the player for cooperation and remind them to keep records of their withdrawal history for reference.

## Notes
- Withdrawal processing times are normally 3–5 minutes, but delays are common during high volume periods.
- GCash withdrawals are supported for amounts PHP 500–PHP 20,000; smaller amounts should use PayMaya.
- During system issues, use alternative methods or wait until the system stabilizes.
- Always verify that the player’s withdrawal account is properly linked; only one account per e-wallet should be linked to avoid security issues.
- Re-submission of withdrawal requests is allowed if previous attempts fail or are delayed, within the system’s processing limits.

## Key points for communicating with players
- Clearly inform players of the normal processing time (3–5 minutes).
- Explain the possible reasons for delays and the security of their funds.
- Guide players on how to view and share their withdrawal record.
- Encourage patience during high volume periods and instruct on alternative methods if needed.
- Remind players that withdrawal limits depend on the method and amount requested.