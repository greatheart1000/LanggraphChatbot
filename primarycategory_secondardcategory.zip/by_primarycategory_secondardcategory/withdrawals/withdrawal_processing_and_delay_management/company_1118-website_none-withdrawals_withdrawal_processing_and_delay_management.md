# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and log the withdrawal request**  
   - Collect the player's username and withdrawal details.  
   - Request relevant documents if needed (e.g., proof of transaction, identification).  
   - Verify that the user has provided all necessary information.  

2. **Check for potential suspicious activity or betting irregularities**  
   - Review the player's recent betting activity, especially on Live games.  
   - If abnormal betting is detected, inform the player that withdrawals may be delayed or canceled.  
   - Advise the player to play approved games and re-apply the next day to speed up processing.  

3. **Verify user account and withdrawal eligibility**  
   - Confirm that the withdrawal amount complies with site policies.  
   - Check that the user's account details (e-wallet, bank information) match the registered info, especially for e-wallet methods like GCash or Pay-Maya.  
   - Ensure the user has submitted any required verification documents or proofs of transaction, if requested.  

4. **Assess withdrawal status and processing time**  
   - Understand that withdrawal processing can take up to 24 hours.  
   - Consider current system volume, as delays during high-volume periods are normal and result in first-come, first-served processing.  

5. **Monitor the withdrawal review process**  
   - Check the transaction status in the internal system.  
   - Confirm whether the withdrawal is under review or processing.  
   - Do not attempt to cancel the withdrawal if it is already under review unless account transaction limits are exceeded, which may cause automatic cancellation.  

6. **Address delays or issues**  
   - If the withdrawal is delayed beyond 24 hours, inform the player that delays can occur due to high volume or system review.  
   - Reassure the player that their withdrawal will be processed as soon as possible.  
   - Advise the player to refrain from spamming support messages and ensure all verification documents are accurate and complete.  
   - If necessary, request a screenshot of the transaction and the user's username to assist further.  

7. **Handle unavailability or failed withdrawals**  
   - For unavailable withdrawal methods (e.g., GCash), suggest alternative options such as another GCash number or Pay-Maya.  
   - If the withdrawal is canceled or not received after a long period, escalate for review and request additional information from the player.  
  
8. **Communicate clearly with the player**  
   - Provide updates about processing times, delays, or issues based on the current system status.  
   - Explain that withdrawals cannot be canceled once under review unless restrictions apply.  
   - Remind the player that all transactions are processed on a first-come, first-served basis and delays are temporary.  

9. **Close the case once the withdrawal is credited**  
   - Confirm receipt with the player if possible.  
   - Document the transaction details and resolution step in the system.  
   - Advise the player to contact support immediately if they encounter further issues.  

## Notes
- Delays are common during high volume periods and do not indicate system failure.  
- Suspicious betting activity, especially on Live games, can restrict withdrawals; players should be advised to adhere to approved games.  
- Providing a screenshot of the withdrawal transaction and username helps expedite review and resolution.  

## Key points for communicating with players  
- Be transparent about processing times (up to 24 hours).  
- Inform players that delays may happen and are temporary.  
- Clearly explain that withdrawals cannot be canceled once under review, unless specific restrictions apply.  
- Recommend alternative withdrawal methods if the original is temporarily unavailable.