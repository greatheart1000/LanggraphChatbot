# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the withdrawal inquiry or request from the player.**
   - Determine the player’s purpose: check if they want to verify their withdrawal status, resubmit a request, or troubleshoot delays.

2. **Verify player's identity and account details.**
   - Request and confirm the player's username.
   - Ask for a screenshot of the withdrawal record if needed (navigate: Member → Withdrawal Record → take a screenshot).
   - If applicable to unbinding or resetting passwords, collect:
     - Full Name
     - User ID/username
     - Reason for unbinding/reset request
     - Clear, valid ID picture
     - Selfie with ID (ensure clarity and readability)
   - Note: Only one withdrawal account can be unbound at a time.

3. **Check the player's withdrawal record and current status.**
   - Access the withdrawal record:
     - Navigate: Member → Withdrawal Record
     - Confirm the latest request details and status.
   - Understand the status:
     - **"Transferring"**: The request is approved and being processed.
     - **"Successful"**: Funds credited.
     - **Failed/Rejected**: Refunds or further action needed.

4. **Confirm the withdrawal request details.**
   - Ensure:
     - The withdrawal amount is within the allowed minimum (100 PHP) and maximum (20,000 PHP).
     - The amount meets the GCash or PayMaya limits (GCash: 500 PHP to 20,000 PHP).
   - Check if the player has completed the necessary turnover/betting requirement:
     - Player must have played enough slots or fish games to meet the platform's turnover policy before proceeding.
   - Verify there are no outstanding issues, such as pending documentation or account unbinding actions.

5. **Assess any issues or delays.**
   - If the status is "transferring," inform the player:
     - "Your withdrawal request has been approved, and the payment is currently being processed by our financial department. Please wait."
   - If withdrawal failed or delayed:
     - Advise the player to resubmit the request if needed.
     - Provide guidance to check their withdrawal record periodically.
   - For withdrawal failures, suggest resubmission and verify if the issue persists.

6. **Handle specific cases and common issues.**
   - If the player's withdrawal is pending and they are below the minimum amount, advise to recharge with an amount that covers their current balance.
   - For high volume delays, inform the player that processing may take longer than the usual 3–5 minutes.
   - If the withdrawal method is GCash and the status shows "transferring," wait 30-45 minutes for processing.
   - During GCash or other e-wallet maintenance:
     - Advise using alternative methods like PayMaya.
   - If the withdrawal is within limits but still not processed:
     - Confirm the player’s account has no restrictions or missing verification documents.

7. **Assist with management of withdrawal limits and request quotas.**
   - Inform the player if they have reached the maximum number of withdrawal requests (10 per account).
   - Advise waiting until the next reset period if limits are hit.

8. **For unbinding or resetting withdrawal accounts/passwords:**
   - Collect required documents as per policy:
     - Full Name, Username, reason, valid ID picture, selfie with ID.
   - Ensure all parts are clear and readable.
   - Process the unbinding request following current policies—one account at a time.

9. **Guide the player on checking and downloading withdrawal records or receipts.**
   - Provide instructions:
     - Navigate: Member → Withdrawal Record
     - Take a screenshot for verification or reference.
   - Use receipt references for future inquiries or proof of withdrawal.

10. **Escalate if needed.**
    - If issues cannot be resolved with initial checks (e.g., system delays, verification errors), escalate to the back office or relevant department.
    - Request support from the finance team if the withdrawal has been "transferring" beyond normal processing time.

11. **Close the case after resolution.**
    - Confirm the player understands the current status.
    - Advise them to wait for the completion of processing if pending.
    - Remind about the turnover requirement if they request withdrawal before fulfilling it.
    - Provide tips on monitoring withdrawal status regularly.

## Notes

- Withdrawals are typically processed within 3–5 minutes; longer delays may be due to high system volume or method maintenance.
- All documentation used for verification must be clear and readable; blurry images may cause delays.
- Only one withdrawal account can be unbound at a time; multiple requests require separate submissions.
- Players should complete the necessary turnover/betting requirements before requesting withdrawal.
- When GCash is under maintenance, suggest using PayMaya or other available methods.
- Rejected withdrawals are automatically refunded; resubmission may be necessary.

## Key points for communicating with players

- Clearly explain the meaning of "transferring" status.
- Remind players to ensure their account meets all requirements before requesting withdrawal.
- Encourage patience during high-volume periods or maintenance.
- Emphasize the importance of providing complete, clear documentation for verification or unbinding requests.