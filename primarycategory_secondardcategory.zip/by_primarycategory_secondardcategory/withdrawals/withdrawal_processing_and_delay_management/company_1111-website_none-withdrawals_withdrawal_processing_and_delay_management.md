# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request.**  
   Collect the following information:
   - Player's username or account ID.
   - Withdrawal amount.
   - Method of withdrawal selected.
   - Any relevant receipts or screenshots if the player reports delays or issues.

2. **Verify account verification status.**  
   Check if the account and linked phone number are verified.  
   - If not verified, inform the player that verification is required for processing withdrawals.

3. **Assess eligibility based on game activity and turnover.**  
   - Confirm if the player has completed at least one full turn of the total balance across eligible games (e.g., SLOT GAMES).  
   - If the account is suspected of abnormal betting, it may be restricted from withdrawal until review.

4. **Check for any unusual activity or restrictions.**  
   - If unusual withdrawal activity is detected, the withdrawal may be paused until the player completes the necessary actions.  
   - Advise the player to fulfill the turnover requirement by playing remaining balance in eligible games.

5. **Review the withdrawal request in the back office/system.**  
   - Ensure the request is processed on a first-come, first-served basis.  
   - Confirm that the amount adheres to any site-specific limits.

6. **Inform the player about the standard processing time.**  
   - Clarify that withdrawals are typically processed within 24 hours.  
   - Advise patience as delays may occur during high volume or for larger amounts requiring extra checks.

7. **Identify if additional review is necessary.**  
   - If the withdrawal is for a large amount or the system flags it for review, processing may extend to 24-72 hours or longer.  
   - Larger or complex withdrawals may require financial review.

8. **Provide resolution or status updates to the player.**  
   - Check transaction history via the account to verify status or ask the player to do so.  
   - If the withdrawal is pending or delayed beyond the usual timeframe, request a screenshot or detailed description of the issue to escalate to support.

9. **Handle delays or issues.**  
   - For delays exceeding 24 hours or as per specific cases, instruct the player to provide a screenshot showing the processing status or error message.  
   - Attach relevant evidence to the support ticket or chat, and offer to review the case further.

10. **Communicate actively with the player.**  
    - Keep the player informed about the processing status, expected timeframes, and any required actions.  
    - Apologize for delays if applicable and reassure the player that their request is being handled in order.

11. **Conclude the process once withdrawal is completed.**  
    - Confirm with the player that the funds have been successfully transferred to their selected method.  
    - Advise checking the account or bank statement for confirmation.

## Notes

- Withdrawals are processed on a first-come, first-served basis and may take up to 24 hours, or longer during high volume or for large amounts requiring additional checks.
- Ensuring account verification and meeting turnover requirements can prevent delays.
- For delays longer than 24 hours, supporting screenshots or detailed descriptions help facilitate investigations.
- Large or suspicious withdrawals may be subject to further review, causing additional processing time.
- Always inform players of the standard processing time and advise patience during busy periods.

## Key points for communicating with players

- Explain that withdrawal requests are usually processed within 24 hours but may take longer during high-volume periods.
- Remind players to complete necessary turnover requirements and verification steps to avoid delays.
- If a delay occurs, ask for screenshots of the withdrawal status and advise patience until the process completes.
- Emphasize that requests are handled on a first-come, first-served basis and that larger amounts may require extra review time.