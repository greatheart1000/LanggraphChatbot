# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive withdrawal inquiry or request from the player.**
   - Confirm the player's withdrawal method (e-wallet such as GCash, PayMaya, or other available options).
   - Verify if the player has submitted all necessary account details (e-wallet number, transaction password).

2. **Check the player's withdrawal eligibility and current status.**
   - Confirm the player has not exceeded the daily maximum request limit of 10 withdrawal requests, if applicable.
   - Verify whether the player's account has completed the required turnover or wagering conditions.
   - Check for any system notifications related to maintenance, delays, or technical issues with the withdrawal method (e.g., GCash downtime).

3. **Inform the player of current withdrawal limits and processing times.**
   - For GCash: Limit of 500 PHP to 20,000 PHP per transaction.
   - For withdrawals below 500 PHP, suggest using PayMaya for a smoother process.
   - Mention typical processing times: 3-5 minutes under normal circumstances, but allow 30-45 minutes for GCash withdrawals.
   - Explain that delays may occur during high transaction volume or system issues.

4. **Validate the withdrawal request details.**
   - Ensure the withdrawal amount is within the specified limits.
   - Confirm the player's account details are correct and active.
   - For first-time or new accounts, verify account binding: 
     - Confirm that the e-wallet account (GCash, PayMaya, etc.) is properly bound with a valid account number.
     - If account binding is incomplete or incorrect, guide the player to complete this via the appropriate instructions.
   
5. **Handle requests involving GCash or PayMaya.**
   - **If the player chooses GCash and the amount is within limits:**
     - Proceed with the withdrawal.
     - Inform the player that GCash withdrawals typically process within 30-45 minutes.
   - **If the player requests a withdrawal below 500 PHP and prefers GCash:**
     - Recommend using PayMaya for better processing experience.
   - **In case of withdrawal rejection or failure:**
     - Check if the rejection is due to reaching the monthly GCash limit.
       - If yes, advise the player to apply for an additional GCash account.
     - If withdrawal fails due to incomplete turnover:
       - Explain that the player needs to play fish or slot games to complete the required turnover before subsequent withdrawal attempts.
     - If the transaction is rejected or fails for other reasons:
       - Confirm the funds will be returned promptly to their wallet.
       - Advise to re-submit the request after confirming all details.

6. **For withdrawal requests via GCash that are delayed or rejected:**
   - Communicate the possibility of technical problems and delays.
   - Suggest using PayMaya or alternative methods if GCash remains unavailable.
   - Instruct the player to wait for the processing time; if delays persist beyond 45 minutes, escalate to support with the withdrawal receipt.

7. **Record-keeping and record viewing.**
   - Instruct the player to access the withdrawal record:
     - Go to 'Member' on the homepage.
     - Select 'Withdrawal Record'.
     - Take a screenshot of the record for verification or support submission.
   - Confirm the record shows the correct amount, reference number, date, and time.

8. **If a withdrawal attempt is unsuccessful or delayed:**
   - Confirm the account details are correct.
   - Advise the player to wait approximately 3-5 minutes for processing or up to 3-5 days if system delays are ongoing.
   - If the withdrawal remains unprocessed after this period, escalate to support with all relevant receipt screenshots.

9. **In case of withdrawal inactivity:**
   - Advise the player to recharge an amount equal to their current balance to reactivate withdrawal eligibility.
   - Once recharged, recommend re-initiating the withdrawal following the standard process.

10. **Unbinding or updating withdrawal accounts.**
    - To unbind a bound wallet:
      - Click 'Withdraw', then '+' or 'Add' to set up a new account.
      - Use the unbinding option if needed—note only one account can be unbound at a time.
      - Re-binding should be done with your new account details.
      - Do not reuse an account across multiple player accounts; this may lead to suspension.

11. **If the player’s withdrawal method is down or experiencing issues:**
    - Advise using alternative options such as GrabPay or Online Banking.
    - Assure the player that funds are safe and the process will resume once the method is operational.
    - Monitor official system notifications for updates on service status.

12. **During system delays or maintenance:**
    - Inform the player of current downtime affecting GCash or other payment methods.
    - Recommend waiting for system stabilization.
    - Encourage the player to attempt withdrawal again after confirmation of service resumption.

13. **For excessive delays or persistent failures:**
    - Request supporting documents or withdrawal receipts.
    - Escalate the case to the technical or finance team for investigation.
    - Keep the player informed of any updates or resolutions.

## Notes
- Always verify that the withdrawal method is currently operational; GCash withdrawals are temporarily unavailable due to local operator issues, and the system may recommend alternative methods like Maya.
- Ensure the player understands that processing times can vary; normal processing is 3-5 minutes but may extend up to 45 minutes during periods of system volume or issues.
- Remind players to keep records (screenshots, receipts) for verification support in case of delays or disputes.

## Key points for communicating with players
- Inform players of the current GCash withdrawal limits (500 PHP to 20,000 PHP).
- Advise alternative payment methods if GCash is unavailable.
- Explain typical processing times and possible delays.
- Guide players on how to view and save withdrawal records.
- Emphasize the importance of completing turnover requirements before withdrawal if applicable.
- Notify players that withdrawal requests are processed within 3-5 minutes under normal circumstances, but delays may occur.
- Encourage patience and remind players they can contact support with receipts for further assistance.