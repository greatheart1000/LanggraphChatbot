# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's withdrawal request details**
   - Confirm the requested withdrawal amount is within the allowed limits (500 PHP minimum, 20,000 PHP maximum per transaction).
   - Ensure the player has submitted all necessary account information, including verified phone number and linked e-wallet if applicable.
   - Instruct the player to review and confirm that all withdrawal details are correct before submission, as cancellations or modifications are not possible once processing begins.

2. **Check the player's account eligibility**
   - Confirm the player has met the required minimum turnover or betting activity needed to qualify for withdrawal.
   - Verify the player's identity according to the firm's verification procedures if required, especially for withdrawal requests.

3. **Submit the withdrawal request in the system**
   - Enter the withdrawal request into the designated platform.
   - Request a screenshot or proof of the submission from the player if needed to track the request.

4. **System review and approval process**
   - The withdrawal will undergo system checks, including verification of account details and bet slip or gaming activities.
   - Processing is on a first-come, first-served basis.
   - Expect system review and approval to take up to 24 hours, depending on system workload and verification status.

5. **Monitor processing status**
   - Keep the player informed about the status of their withdrawal, emphasizing that delays can occur during high-volume periods.
   - Advise the player to wait patiently while the system performs necessary checks and reviews.

6. **Handle delays and customer inquiries**
   - Explain to the player that withdrawal processing time can vary from minutes to several hours or more.
   - Remind the player that withdrawals are processed in order and delays are normal during peak times.

7. **Final resolution and confirmation**
   - Once approved, confirm with the player that the funds have been processed and transferred.
   - If the withdrawal is delayed beyond a reasonable timeframe, verify if the request is still in queue or if additional verification is required.

## Notes

- Ensure all account details are accurate before submitting withdrawal requests; incorrect details cannot be modified once processing starts.
- Withdrawals are subject to system review, which may cause varying processing times.
- Always inform players patiently about normal delays during high system volume periods.

## Key points for communicating with players

- Confirm withdrawal limits (500 PHP to 20,000 PHP per transaction).
- Advise players to ensure account details and necessary verification are complete.
- Remind players that once submitted, withdrawal requests cannot be canceled or modified.
- Explain that processing time is up to 24 hours but can be longer during peak times.
- Emphasize patience during the review process and that delays are normal.