# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request or inquiry**
   - Confirm the player’s identity and account details.
   - Clarify the preferred withdrawal method (e-wallet, GCash, PayMaya, etc.).

2. **Verify withdrawal eligibility and limits**
   - Ensure the player’s account is verified and in good standing.
   - Confirm the requested withdrawal amount:
     - Check if it does not exceed the maximum of ₱20,000 per transaction.
     - For GCash or GCASH, verify if the amount is between 500 PHP and 20,000 PHP.
     - For amounts below 500 PHP, advise using PayMaya or alternative methods.
   
3. **Check the player's withdrawal history and record**
   - Guide the player to view their withdrawal record by:
     - Going to Member > Withdrawal Record from the homepage.
     - Taking a screenshot of the relevant record for verification.
   - Confirm if previous withdrawals are pending or completed as expected.
   
4. **Instruct the player on submitting the withdrawal request**
   - Direct the player to click **Withdraw** on the homepage.
   - Have them select their preferred e-wallet option (e.g., GCash, PayMaya).
   - Instruct to enter the withdrawal amount.
   - Ask them to input their transaction password.
   - Confirm they click **Submit** to finalize the request.
   
5. **Advise on receipt or reference retrieval**
   - Inform the player that withdrawal receipts are available in the Withdrawal Record.
   - Instruct to take a screenshot of the withdrawal record for proof, showing the amount, reference number, and date/time.
   
6. **Monitor the withdrawal status**
   - Check if the status shows as "transferring," meaning pending processing.
   - Inform the player that:
     - Processing may take approximately 30 to 45 minutes if using GCash, PayMaya, or similar methods.
     - Delays can happen during high transaction volume periods.
   - If the status remains unclear or delayed beyond this period:
     - Verify if the withdrawal has been properly submitted.
     - If issues persist, escalate or advise the player to contact support.
   
7. **Handle withdrawal issues or delays**
   - For failed or delayed withdrawals:
     - Re-submit the request if no errors are indicated.
     - Confirm the player has entered correct details and the transaction password.
     - Remind the player to check for system issues if using GCash; if unavailable, instruct to use PayMaya or alternative methods like GrabPay, Gotyme, USDT, or bank transfer, as applicable.
   - If a withdrawal is temporarily unavailable (e.g., GCash issue), advise using the alternative method.
   
8. **Manage unbinding/removing withdrawal accounts (if requested)**
   - Collect the necessary documentation:
     - Full name, username, account number to delete, reason for deletion.
     - A clear photo of a valid ID and a selfie holding the ID.
   - Process the unbinding request following the current verification procedures.
   
9. **Confirm completion and close the case**
   - Ensure the player received confirmation of successful withdrawal.
   - Advise to recheck the withdrawal record to confirm the transaction processed.
   - Offer further assistance if needed, or close the ticket once resolved.

## Notes

- GCash and GCash withdrawals are limited to 500 PHP–20,000 PHP per transaction.
- For withdrawals below 500 PHP, use PayMaya as an alternative.
- Withdrawal processing times are approximately 30–45 minutes but may vary during high volume.
- Withdrawal status "transferring" indicates pending processing.
- If a withdrawal fails or cannot proceed due to technical issues, advise switching to alternative payment methods.
- Always verify the player’s withdrawal record by taking a screenshot for documentation and support purposes.

## Key points for communicating with players

- Explain that delays could occur during peak times but are typically resolved within 30–45 minutes.
- Emphasize the importance of correct details, especially the transaction password.
- Remind players of withdrawal limits for specific methods and advise alternatives for lower amounts.
- Encourage players to check their withdrawal record for confirmation.
- Direct players to support if issues persist beyond expected processing times.