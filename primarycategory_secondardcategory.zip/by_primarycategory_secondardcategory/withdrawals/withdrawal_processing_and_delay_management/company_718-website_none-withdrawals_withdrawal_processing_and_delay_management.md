# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Gather initial information from the player**  
   - Confirm the player's account details, including withdrawal amount and method.  
   - Ask if the withdrawal has been attempted before and if any error messages appeared.  
   - Determine if the player has recently experienced delays or failed transactions.

2. **Check the current status of the withdrawal system**  
   - Verify if the withdrawal system is under scheduled maintenance or experiencing technical issues.  
   - Inform the player that if the withdrawal system is under maintenance, they should try again after 1–2 hours.  
   - Note: During scheduled maintenance, withdrawals are temporarily unavailable.

3. **Review recent withdrawal attempts**  
   - Check the player's withdrawal history in the system for multiple failed attempts.  
   - If the player reports frequent failures, inform them that this may be due to system maintenance or technical issues, and advise waiting a few hours before trying again.  
   - Confirm whether the player’s bank or payment method has any delays.

4. **Verify withdrawal processing time**  
   - Check the specific withdrawal time frame:  
     - Usually processed within 5 minutes.  
   - If the withdrawal was initiated recently, advise the player to wait.  
   - If the withdrawal was made over 5 minutes ago but not received, proceed to the next step.

5. **Investigate potential delays and errors**  
   - If the withdrawal is delayed beyond 5 minutes, inform the player that bank or payment delays can extend processing time to 1–2 hours.  
   - Advise the player to check with their bank or payment provider.  
   - If the delay exceeds this period or if the funds are not received after this, escalate to technical support or finance team for further investigation.

6. **Handle withdrawal failures or issues**  
   - If multiple attempts have failed, confirm possible reasons such as system maintenance or technical issues.  
   - Advise the player to wait a few hours and try again later.  
   - If the failure continues, escalate the issue according to internal procedures and inform the player that support will follow up.

7. **Special case: withdrawal to Jazzcash**  
   - If the player chooses Jazzcash, instruct them to:  
     - Open the game and go to Withdraw.  
     - Select Jazzcash as the withdrawal method.  
     - Proceed if their Jazzcash account is already linked; otherwise, link it first via account settings.  
   - Confirm that the withdrawal process follows this procedure.

8. **Final confirmation and communication**  
   - Confirm with the player whether they have completed all steps correctly and have received the transfer if applicable.  
   - Advise on next steps if delays persist or failures continue, including contacting their bank/payment provider and support escalation if necessary.

## Notes

- Withdrawals are typically processed within 5 minutes, but delays of 1–2 hours can occur due to bank or system issues.  
- During scheduled maintenance, withdrawals are temporarily unavailable; players should wait until maintenance is complete.  
- Repeated failed withdrawal attempts may be caused by system maintenance or technical problems; advise patience and retry later.

## Key points for communicating with players

- Clearly inform players that withdrawal delays can happen due to system maintenance or bank processing times.  
- Remind players to check with their bank or payment provider if delays exceed 1–2 hours.  
- Reinforce that during scheduled maintenance, withdrawal features are temporarily disabled and players should wait until the maintenance window closes.