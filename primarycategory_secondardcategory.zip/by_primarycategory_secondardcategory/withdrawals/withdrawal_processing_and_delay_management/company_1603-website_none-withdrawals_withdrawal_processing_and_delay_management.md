# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's withdrawal request and account details**
   - Confirm that the player has submitted a withdrawal request via the platform.
   - Ensure the withdrawal amount is **at least 100**, as per minimum withdrawal limit.
   - Check if the player's bank or e-wallet account is properly linked and verified.
   - Confirm that the linked account details are correct.

2. **Initial system check and processing time estimate**
   - Note that withdrawal requests can take up to **1 hour** to process initially, depending on verification and system checks.
   - If it's the player's first withdrawal, be aware that processing may take **approximately 3 to 5 hours** after linking the bank or e-wallet, due to risk management procedures.

3. **Review the withdrawal request status in the back-office system**
   - Check for any system messages or errors indicating issues with the request.
   - Verify if the account details and identity information meet the platform’s requirements.
   
4. **Address unsuccessful or delayed withdrawals**
   - If the withdrawal fails or is not received:
     - Confirm that the account remains properly linked and verified.
     - Ask the player to provide the transaction ID, username, and proof of transfer if needed.
   - If a withdrawal is delayed:
     - Inform the player that delays are usually within **3-5 hours** for initial requests.
     - Advise the player to contact support if the delay exceeds this timeframe or if the funds are not received.

5. **Handling withdrawal failure or unavailability**
   - Notify the player that:
     - Withdrawals may be temporarily unavailable during maintenance.
     - If this is the case, advise waiting until the maintenance window ends and attempting again later.
   
6. **Additional verification if issues persist**
   - If the withdrawal continues to encounter problems, escalate the case, requesting support review the transaction, account verification, or system status.
   - Collect all relevant information from the player, including screenshots or proof of transfer if necessary.

## Notes

- Ensure all required fields and verification steps are completed before accepting the withdrawal request.
- Remind players that delays beyond the standard 3-5 hours should be reported with supporting proof.
- Addressing unsuccessful withdrawal attempts involves verifying account link status and providing support with transaction details.

## Key points for communicating with players

- Confirm the withdrawal amount is **minimum 100**.
- Process times can range from **1 hour** (initial processing) to **3-5 hours** for first-time requests.
- Contact support if delays or failures exceed these timeframes or if funds are not received.
- Remind players that withdrawal availability may be affected during maintenance periods.