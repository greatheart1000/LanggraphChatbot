# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player’s withdrawal request and verify the details**
   - Confirm the withdrawal amount.
   - Check the selected withdrawal method (e-wallets such as GCASH, PayMaya, GrabPay, Gotyme, USDT, or Online Bank Transfer).
   - Verify that the player has completed necessary verification steps and has met turnover requirements, especially if the withdrawal amount is large or if there are restrictions for non-deposit users (max withdrawal limit of 100 PHP).

2. **Check withdrawal method and limits**
   - For GCASH:
     - Confirm the amount is within 500 PHP to 20,000 PHP.
     - If the amount is below 500 PHP, advise using PayMaya as an alternative.
   - For other methods:
     - Confirm they are supported and available; advise alternatives if not.

3. **Process the withdrawal in the system**
   - Initiate the withdrawal request through the back-end system.
   - Note: Normal processing is usually quick but can take several hours, especially for larger amounts due to verification.
   - For GCASH or GCash withdrawals, inform players that processing may take 30-45 minutes if initiated recently.

4. **Collect and Provide withdrawal record for player's reference**
   - Direct the player to the Withdrawal Record:
     - Navigate: Member > Withdrawal Record.
     - Instruct the player to take a screenshot of the withdrawal record.
     - Advise sending the screenshot to support for verification and record-keeping.
   - The withdrawal receipt reference is the number shown on the record.

5. **Monitor the withdrawal status**
   - Track the progress in the Withdrawal Record section.
   - For GCash or PayMaya withdrawals:
     - Processing can take 3 to 5 business days (excluding weekends).
   - For other methods, refer to the system’s specific processing times.

6. **Handle delays or issues with withdrawals**
   - If it is a GCASH withdrawal being delayed or not received:
     - Confirm the transaction is within the 30-45 minutes window if just initiated.
     - If delays or rejections occur, advise using alternative methods such as PayMaya or bank transfer.
     - Remember, GCASH withdrawals may be affected by system issues; support should advise on alternative methods and escalate if necessary.
   - If the withdrawal is rejected or not received:
     - Verify the withdrawal record.
     - Ensure the account meets all requirements, and no irregular activity detected.
     - Remind the player that delays might be due to system maintenance or high demand.

7. **Advise the player on next steps if withdrawal is delayed or failed**
   - For slow or failed GCASH withdrawals, recommend alternative methods (PayMaya, bank transfer).
   - For completed withdrawals, confirm the funds are safely transferred and advise the player to check their wallet or bank account.
   - Document any issues and escalate if needed.

8. **Troubleshooting and escalation**
   - If the player reports a rejection or non-receipt:
     - Request the withdrawal record screenshot.
     - Confirm if the withdrawal was initiated within supported limits.
     - Escalate if systemic issues or suspected illegal activity are suspected, noting possible deduction of profits from illegal betting.
   - For unprocessed requests after the typical timeframe, verify back-end processing or system issues.

## Notes
- Withdrawals are generally processed quickly but may take several hours depending on verification and system demand.
- For small withdrawals below 500 PHP, players are advised to use PayMaya for smoother processing.
- GCASH withdrawals have specific limits (500 PHP to 20,000 PHP). Use alternative methods if outside this range.
- Always verify the withdrawal record by the screenshot for troubleshooting.
- Ensure the player has met all verification and turnover requirements to avoid delays.
- GCASH withdrawal delays may occur during system maintenance or issues; support should recommend alternative methods when needed.

## Key points for communicating with players
- Inform players about approximate processing times (30-45 minutes for GCASH if just initiated, longer for bank transfers).
- Advise using alternative methods like PayMaya or bank transfer for small amounts or when GCASH is slow/unavailable.
- Request a screenshot of the withdrawal record for verification.
- Confirm that the withdrawal request complies with method limits and verification requirements before processing.
- Remind players that delays can happen during high demand or system maintenance and provide alternative solutions promptly.