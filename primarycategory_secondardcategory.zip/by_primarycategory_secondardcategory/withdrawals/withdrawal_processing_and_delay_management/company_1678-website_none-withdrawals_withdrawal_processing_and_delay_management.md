# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Gather player information and review withdrawal request**
   - Verify the identity and account details of the player initiating the withdrawal.
   - Collect relevant transaction details: transaction ID, amount, and withdrawal method (e.g., GCash, Maya).
   - Confirm the withdrawal method used matches the available channels and the player's account setup, especially if main account access is an issue.

2. **Check withdrawal status and system messages**
   - Access the back office system to review the withdrawal record.
   - Identify the status of the withdrawal: pending, successful, failed, or under maintenance.
   - Note that withdrawals may be under maintenance or experience delays; processing times can vary and are subject to system status.
   - If the status shows **success** but the player reports non-receipt:
     - Advise the player to check their account for the funds.
     - Request proof of transaction or receipt if necessary to verify the transfer.

3. **Inform the player of potential delays or maintenance**
   - If the withdrawal is delayed or under maintenance, explain that processing times can vary.
   - Emphasize that delays are often due to system status, platform maintenance, or other operational factors.
   - Advise the player to wait and to check their account periodically.

4. **Assist the player in case of missing funds or delayed receipt**
   - If the withdrawal has marked as successful but the funds have not arrived in their GCash or Maya account:
     - Confirm that the correct account details were used.
     - Encourage the player to wait since the transaction may still be processing.
     - Instruct the player to verify the transaction status through the platform if available.
     - If the funds are still not received after a reasonable wait, request a transaction receipt or proof of transaction and escalate for further investigation or support.

5. **Manage withdrawal cancellations**
   - Check if the withdrawal is still **pending**.
   - If so, determine whether the player wishes to cancel the withdrawal and inform them that cancellations are possible before processing.
   - Cancel the withdrawal in the system if the request is valid and before it has been processed.
   - Note that once a withdrawal is processed, cancellation may not be allowed.

6. **Handle withdrawal cancellations and reprocessing**
   - If the player’s request to cancel is received prior to processing, perform the cancellation in the system.
   - If the withdrawal has already been processed, explain that cancellation is not possible and advise on appropriate next steps (e.g., contacting support if funds are missing).
   
7. **Provide guidance on withdrawals via alternative channels**
   - If the player's main account access is restricted or unavailable, suggest withdrawal via GCash or Maya, provided they are available under their account setup.
   - Confirm that the player has the correct account details for these channels.

8. **Follow-up and closure**
   - For unresolved issues, escalate the case to relevant back office or technical support teams with all collected information and evidence.
   - Ensure the player is kept informed about ongoing investigations or delays.
   - Close the case once the issue is resolved or the player confirms receipt of funds or cancellation.

## Notes

- Interviews should always include verifying the transaction receipt or proof of transaction if the withdrawal status is marked successful but funds are not received.
- Remind players that processing times can be affected by system status, maintenance, or operational delays.
- Loss of funds after a successful withdrawal should be escalated as an urgent issue with supporting documentation.

## Key points for communicating with players

- Clearly explain that withdrawal times may vary due to system maintenance or delays.
- Confirm correct account details for withdrawal methods like GCash or Maya.
- Advise patience and instruct to verify transaction status via the platform.
- Emphasize that cancellation is only possible if the withdrawal remains pending.