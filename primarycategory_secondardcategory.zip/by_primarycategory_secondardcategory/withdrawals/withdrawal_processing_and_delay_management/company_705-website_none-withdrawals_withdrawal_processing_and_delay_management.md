# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify player's withdrawal request details:**
   - Ensure the player has provided all necessary information:
     - Selected e-wallet (e.g., GCash, PayMaya)
     - Correct withdrawal amount within allowed limits (see step 3)
     - Transaction password

2. **Check withdrawal amount against limits:**
   - Confirm the withdrawal amount adheres to the following:
     - For GCash: between 500 PHP and 20,000 PHP
     - For PayMaya: below 500 PHP (recommended for amounts under 500 PHP)
   - Advise the player to switch to PayMaya if withdrawal is below 500 PHP or if GCash is experiencing issues.

3. **Process the withdrawal request:**
   - Instruct the player to:
     - Click "Withdraw" on the homepage
     - Swipe and select the preferred e-wallet
     - Input the withdrawal amount
     - Input the transaction password
     - Click "Submit"

4. **Inform the player about the current processing times and potential delays:**
   - Normally, withdrawals are completed within 3 to 5 minutes.
   - During high transaction volume or system maintenance, delays may occur; inform the player that the finance team is working to process all requests promptly.
   - For GCash withdrawals experiencing issues, advise to wait 30 to 45 minutes for processing.

5. **Monitor withdrawal status:**
   - Check the system for the current status of the withdrawal:
     - "Transferring" indicates approval and awaiting transfer by the financial department.
     - If rejected, the system refunds the amount automatically to the player's account.

6. **Guide the player on viewing withdrawal records:**
   - Instruct to:
     - Log into their account
     - Navigate to "Member"
     - Select "Withdrawal Record"
     - Take a screenshot of the record for reference or support purposes

7. **If withdrawal fails or is delayed:**
   - Advise the player to resubmit the request if the status is "transferring" but funds are not received after a reasonable wait.
   - For rejected withdrawals, confirm the refund process has occurred.
   - Encourage patience during system issues, especially with GCash.

8. **If technical issues with GCash persist:**
   - Recommend switching to PayMaya or Maya (Maya) as an alternative withdrawal method.
   - Notify the player to avoid multiple rapid requests to prevent delays or system lockouts.

9. **Handling exceptional cases (e.g., inactive accounts or insufficient verification):**
   - Inform the player that withdrawal may be delayed or blocked if verification steps are incomplete.
   - Advise re-verification if necessary.
   - Remind that balances may be temporarily frozen during maintenance and will be restored automatically afterwards.

10. **Escalate cases of persistent delays or unresolved issues:**
    - Collect all relevant screenshots, withdrawal records, and transaction details.
    - Forward to the finance or technical team for further investigation.

## Notes
- Withdrawals via GCash may be temporarily limited or experience delays (range 2,000-20,000 PHP) due to banking system issues.
- Make players aware that massive transaction volumes can cause slow or failed withdrawals.
- Remind players to regularly check their withdrawal record for updates.
- Emphasize the importance of screenshot evidence for support requests.

## Key points for communicating with players
- Clearly explain the current withdrawal limits and recommended e-wallets.
- Advise patience during high volume periods or system maintenance.
- Guide players on how to view and save withdrawal records.
- Encourage switching to PayMaya or Maya if GCash issues persist.
- Remind players that rejected withdrawals are automatically refunded.