# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request**  
   - Confirm that the player has accessed the Member Center and selected 'Withdraw'.  
   - Ensure the player has chosen their preferred payment channel (e.g., GCash, Maya/GrabPay, bank).  
   - Verify the player has filled out the withdrawal form with the following details:  
     - Username  
     - Registered phone number  
     - Withdrawal account number (bank or e-wallet)  
     - Date of withdrawal  
     - Withdrawal amount  

2. **Check account restrictions and conditions**  
   - If the player is a no-deposit player:  
     - Confirm the withdrawal amount does not exceed ₱100; requests above this limit will be rejected.  
   - If the account has been recently bound:  
     - Confirm that at least 3 hours have passed since the account was linked; withdrawals cannot be processed before this period.  
   - For promotional or bonus withdrawals, verify the applicable limits (e.g., maximum of 100 units for certain promos) and rules regarding profits and wagering multipliers.  
   - Ensure that the account is not flagged for sharing IP addresses or other violations, which could lead to account disabling or withdrawal denial.  

3. **Verify provided information**  
   - Confirm that all required details are complete and accurate.  
   - Cross-check the registered phone number and withdrawal account details for consistency and validity.  
   - Note that if the information is incomplete or incorrect, advise the player to update their details before re-submitting.  

4. **Process the withdrawal request**  
   - Submit the request into the system for manual review and processing.  
   - Inform the player that withdrawals are processed within 24 hours and that multiple follow-ups within this window will not speed up processing.  

5. **Acknowledge potential delays and processing times**  
   - Explain to the player that delays are normal due to high volume requests or system maintenance.  
   - Emphasize that there is no guaranteed exact processing time beyond the 24-hour window.  
   - If the withdrawal has not been received after 24 hours from submission, advise the player to contact customer support for escalation.  

6. **Monitor the withdrawal status**  
   - Check the system for updates on the withdrawal status periodically.  
   - If the request is queued or delayed, inform the player that it is normal and that they should wait for system processing.  

7. **Handle withdrawal cancellations**  
   - Inform the player that once a withdrawal request has been forwarded to the payment partner, it cannot be canceled.  
   - If the withdrawal requests a payment account that cannot process the payment, notify the player and advise linking or using a different account, then resubmit the request.  

8. **Resolve issues and escalate if necessary**  
   - If the withdrawal is delayed beyond 24 hours without any update, escalate the case to support or check for any system issues.  
   - For disputes or problems related to payment cannot be processed, advise the player to contact customer support with the following verification information for further investigation:  
     - Username  
     - Registered phone number  
     - Withdrawal account number  
     - Date of withdrawal  
     - Withdrawal amount  

## Notes

- Withdrawal requests are automatically queued for manual review; multiple follow-ups within 24 hours will not accelerate processing times.  
- Newly linked accounts cannot be used for withdrawal until 3 hours have passed since binding.  
- If a withdrawal method is temporarily unavailable (e.g., GCash), the player should use an alternative method such as PayMaya or bank transfer as applicable.  
- Be aware of promotional limits, such as maximum withdrawal of 100 units for specific promos, and inform players accordingly.  
- Ensure that players are aware that violations, such as sharing accounts or multiple accounts, can result in withdrawal denial and account suspension.  

## Key points for communicating with players

- Remind players that withdrawals are processed within 24 hours and delays are common during high volume periods.  
- Clarify that once a withdrawal request is submitted and forwarded to the payment partner, it cannot be canceled.  
- Advise players to contact support if they do not receive funds after 24 hours, providing necessary verification details to assist in escalation.