# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player inquiry or withdrawal request**
   - Collect essential player details: user ID, name, phone number, email.
   - Obtain the withdrawal request information: amount, selected payment method (e-wallet or bank account), and any screenshots if applicable.

2. **Verify withdrawal eligibility and details**
   - Check that the player’s current balance covers the requested withdrawal amount.
   - Confirm that the withdrawal amount meets the minimum withdrawal limit.
   - Ensure the provided wallet or bank details are correct and match the information on file.

3. **Initiate withdrawal request in the system**
   - Submit the withdrawal request via the back-office system.
   - Note that withdrawal requests are processed automatically after verification and may take up to 72 hours for completion, depending on the system and payment method.

4. **Inform the player of processing time and conditions**
   - Relay that withdrawal processing may be delayed due to system load or maintenance.
   - Advise the player to wait a few minutes to a few hours for the transaction to reflect.
   - Explain that delays exceeding 1-2 hours should be reported with the withdrawal request details and screenshots.

5. **Monitor the system and transaction status**
   - Check for automatic processing updates.
   - If the transaction is delayed beyond 1-2 hours without progress, request the player to provide:
     - Screenshots of the withdrawal request and transaction proof.
     - Any relevant transaction IDs or details.

6. **Address delays or failures**
   - If the player’s withdrawal has not reflected after 1-2 hours, and the transaction details are correct:
     - Verify if system maintenance or overload could cause delays.
     - Instruct the player to wait a bit longer if needed.
   - If delays persist beyond 72 hours or if there is a failure:
     - Escalate the case according to the company's procedures.
     - Notify the player that the issue is under investigation and advise on next steps.

7. **Assist with failed or delayed withdrawals**
   - Check for discrepancies in account details.
   - Confirm that the player has submitted all required verification documents (e.g., ID, recent transaction proof).
   - If verification issues arise, guide the player to complete verification or re-submit necessary documents.

8. **Reset withdrawal password if requested**
   - If the player requests a password reset:
     - Collect the required information: user ID, name, phone number, email, current balance, ID card images (front and back), and recent transaction proof if available.
     - Verify the submitted information.
     - Send a new password to the player once verification completes.
     - Remind the player to store the new password securely.

## Notes
- System processing times can be affected by maintenance, system load, or verification procedures.
- Always verify that all submitted information (wallet details, ID, transaction proof) is correct to avoid delays.
- Delays exceeding 1-2 hours should prompt players to contact support with details and screenshots.
- Withdrawal requests are processed automatically after verification but may require manual intervention in case of issues.

## Key points for communicating with players
- Clearly inform players that withdrawal processing may take up to 72 hours.
- Advise patience during system load or maintenance periods.
- Emphasize the importance of submitting correct details and verification documents.
- Instruct players to contact support with screenshots if delays exceed 1-2 hours.