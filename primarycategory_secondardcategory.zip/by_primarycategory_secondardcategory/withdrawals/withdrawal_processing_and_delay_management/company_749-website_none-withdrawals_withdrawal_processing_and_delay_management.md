# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and interpret the player's withdrawal request**  
   - Confirm the player's intent to withdraw and verify the selected E-wallet method.  
   - Ensure the player has input the withdrawal amount and transaction password correctly.

2. **Verify withdrawal eligibility**  
   - Check if the player has recent deposit activity within the past month.  
   - If no recent deposit, inform the player they must recharge with an amount equal to their current balance to proceed with withdrawal.

3. **Check withdrawal limits**  
   - Confirm the requested amount meets the minimum of PHP100 and does not exceed the maximum of PHP20,000.  
   - For GCash withdrawals specifically, ensure the amount is within 500 PHP to 20,000 PHP; for smaller amounts, recommend PayMaya.

4. **Perform system and account checks**  
   - Verify if the player has completed the required turnover by playing the designated games (FISH or SLOT JILI GAMES).  
   - If the turnover requirement is not met, inform the player that they need to complete it before withdrawal can be processed.

5. **Process the withdrawal request**  
   - Submit the withdrawal request in the system, which will change the status to either 'Pending' or 'Approved' depending on system processing.

6. **Monitor withdrawal status**  
   - Most withdrawals are normally processed within 3-5 minutes; inform the player accordingly.  
   - If the status shows 'Transferring,' explain that the request has been approved and is being processed by the financial department.  
   - If the status remains pending longer than the normal timeframe, advise patience and mention that processing is ongoing.

7. **If GCash withdrawal issues are reported or detected**  
   - Notify the player that GCash transaction issues are ongoing and funds are safe.  
   - Suggest alternative methods such as PayMaya, USDT, or Online Bank Transfer for smoother transactions.  
   - Remind them to allow 30 to 45 minutes for GCash transactions if already initiated.

8. **Handle delays or failures**  
   - If the withdrawal is delayed beyond the normal processing time, confirm the transfer status with the financial department.  
   - In case of failure or cancellation, inform the player that the funds will be automatically returned to their account.  
   - Advise the player to resubmit their withdrawal request if necessary.

9. **Cancellations and rejection**  
   - Inform the player that withdrawal requests cannot be canceled or rejected once they are in 'Transferring' or 'Approved' status.  
   - If the request has not yet entered these statuses, check if cancellation is possible and assist accordingly.

10. **Viewing withdrawal record**  
    - Guide the player to check their withdrawal record by navigating to 'Member' on the homepage, then 'Withdrawal Record.'  
    - Suggest taking a screenshot of the record for verification.

11. **Unbinding or rebinding withdrawal accounts**  
    - If the player wishes to bind or unbind GCash or PayMaya accounts, instruct them to provide the required details and upload necessary verification documents as per the official process.

## Notes
- Withdrawal processing is handled by the finance team and typically completes within 3–5 minutes.  
- During system issues or high transaction volume, delays beyond normal processing times are possible; advise patience.  
- For GCash withdrawal issues, always suggest alternative methods and inform players that their funds remain safe.  
- Withdrawal limits are strictly enforced; withdrawals outside specified ranges will be rejected or require adjustment.

## Key points for communicating with players
- Clearly explain the meaning of statuses like 'Transferring' and 'Approved.'  
- Remind players that withdrawal requests cannot be canceled once in 'Transferring' status.  
- Encourage patience if delays occur and inform that funds will automatically return if the withdrawal fails or is canceled.  
- Use alternative methods like PayMaya when GCash transactions are problematic.