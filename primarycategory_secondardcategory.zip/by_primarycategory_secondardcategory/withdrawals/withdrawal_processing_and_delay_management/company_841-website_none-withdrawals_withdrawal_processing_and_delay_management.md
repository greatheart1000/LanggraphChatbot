# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and review player's withdrawal request:**
   - Confirm the player has submitted a withdrawal request via the platform's 'Withdraw' option on the homepage.
   - Record the requested withdrawal amount and the selected e-wallet or banking method.

2. **Verify withdrawal eligibility:**
   - Ensure the player has completed all necessary verification and account security procedures.
   - Check if the player has fulfilled any turnover or wagering requirements associated with the withdrawal.
   - Confirm the player's account details and identity are verified (see step 4).

3. **Determine the chosen withdrawal method:**
   - Identify the selected method: GCash, PayMaya, USDT, or Online Bank Transfer.
   - Check if the withdrawal amount aligns with the method-specific limits:
     - For GCash: between 500 PHP to 20,000 PHP.
     - For amounts below 500 PHP, advise using PayMaya.
   - If the withdrawal method is GCash:
     - Notify the player of the 30 to 45-minute processing time.
     - If GCash is temporarily unavailable or system issues occur, suggest alternative methods such as PayMaya or other supported options.

4. **Perform system and account checks:**
   - Verify that GCash or relevant e-wallet service is operational during the request.
   - If GCash withdrawal is in progress:
     - Allow 30 to 45 minutes for processing.
     - If delayed beyond this, advise using an alternative method or contact support.
   - Check for any system issues, especially during high-volume periods, which may slow processing.

5. **Process the withdrawal request:**
   - Submit the request to the finance team for approval.
   - Confirm all required data (amount, method, transaction password) are correctly entered.
   - If the transaction password is missing or incorrect, advise the player to reset or recover it:
     - Collect identity details (full name, username, ID photo, selfie with ID).
     - Guide to Profile > Security Center > Transaction Password for reset or recovery.

6. **Await and confirm withdrawal processing:**
   - Monitor for notification of approval or rejection:
     - Approved: Provide the player with the receipt/reference number.
     - Rejected: Clarify reasons if applicable, or advise resubmission after resolving issues.
   - Confirm that the funds are processed and transferred to the player's selected account or e-wallet within the expected time frame.

7. **Handle delays, failures, or system issues:**
   - For delays beyond 45 minutes with GCash, or issues experienced:
     - Advise the player to consider alternative methods such as PayMaya or banks.
     - Remind players that funds are safe and will be processed once the system issues are resolved.
   - If a withdrawal fails:
     - Encourage resubmission.
     - Ask for relevant transaction receipts if available.
     - If a GCash withdrawal fails, recommend using PayMaya, which has no limits and offers higher stability.

8. **Document and communicate to the player:**
   - Send a confirmation email or message with the receipt or reference number.
   - Explain that processing times may vary during high-volume periods.
   - Advise patience and inform that the finance team works to expedite all withdrawal requests.

9. **Escalate or review suspicious or problematic cases:**
   - If there are discrepancies, delayed withdrawals beyond expected times, or suspected issues, escalate to the relevant back-office team.
   - Collect all supporting documentation, including screenshots or transaction receipts.

## Notes
- Support may advise players to switch to an alternative withdrawal method if their primary method is slow or unavailable.
- GCash withdrawals are limited to a range of 500 PHP to 20,000 PHP per transaction; amounts below 500 PHP should use PayMaya.
- During system issues, funds are safe and will be processed once normal operation resumes.
- Withdrawal processing normally takes 3-5 minutes under normal circumstances, but delays may occur due to technical or volume-related factors.

## Key points for communicating with players
- Clearly inform players of the withdrawal limits for GCash and the expected processing times.
- Advise to wait 30-45 minutes for GCash transactions; suggest alternative methods if delays persist.
- Emphasize the importance of account verification and completing all security procedures.
- Encourage players to submit detailed screenshots if they experience delays or failures.
- Reassure players that all funds are secure and will be processed accordingly once system issues are resolved.