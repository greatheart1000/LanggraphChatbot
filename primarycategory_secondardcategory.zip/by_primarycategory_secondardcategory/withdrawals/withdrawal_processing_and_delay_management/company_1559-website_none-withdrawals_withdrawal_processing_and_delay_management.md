# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request**  
   - Confirm the player has contacted customer support via the official platform to initiate the withdrawal.
   - Collect necessary information from the player: verified account status, linked payment methods (bank account or e-wallet), amount to withdraw, and transaction password if applicable.

2. **Verify account eligibility for withdrawal**  
   - Ensure the player's account is at VIP level 1 or higher.  
   - Confirm that the account is fully verified, with personal information bound and payment methods linked.  
   - Check that the player has set a transaction password.  
   - Verify deposit amount: for withdrawal, a minimum deposit of 101 PHP is required, and the player must have completed an after-deposit turnover of at least the same amount.  
   - Confirm no account restrictions are in place.

3. **Check withdrawal amount and details**  
   - Confirm the withdrawal amount meets minimum limit requirements; withdrawals below 100 PHP are not permitted.  
   - Ensure the player’s provided withdrawal details (wallet address or bank account info) are correct and up to date.

4. **Review pending deposit and turnover requirements**  
   - Verify that the player has fulfilled the necessary turnover or wagering requirements related to their deposit, especially if specific to current promotions or bonus conditions (e.g., the after-deposit turnover requirement).  
   
5. **Process the withdrawal request**  
   - Submit the withdrawal request through the back-end system.  
   - Initiate verification of the submitted documents or information if needed (e.g., transaction receipts or proof of identity).  
   - Review for any discrepancies or outstanding issues that may delay processing.

6. **Communicate processing status to the player**  
   - Inform the player that their request is under review and note that processing typically begins immediately upon verification.  

7. **Handle delays or issues in processing**  
   - If the withdrawal has not been reflected in the player’s account within the expected time, verify for common causes:  
     - Payment channel maintenance or technical issues.  
     - Errors in the provided e-wallet number or bank details.  
   - If issues are found, communicate with the player accordingly and instruct on corrective steps if applicable.  
   - If no clear reason and the delay persists, escalate or advise the player to contact support again.

8. **Confirm successful withdrawal and update system records**  
   - Once the withdrawal is successful, notify the player.  
   - Update the player's transaction history and account status to reflect the withdrawal completion.  
   - If the request is rejected or delayed due to non-compliance with conditions, explain the reason clearly to the player (e.g., account not verified, insufficient turnover).

## Notes
- Always ensure the player's account meets all necessary conditions before processing the withdrawal to prevent delays or rejections.
- Remind players that withdrawal processing times may vary, especially during maintenance periods or due to technical issues.
- For delayed withdrawals, focus on verifying payment channel status and correct details before escalating.

## Key points for communicating with players
- Clarify that a minimum deposit of 101 PHP and associated turnover are required to qualify for withdrawal.
- Reiterate that withdrawals below 100 PHP are not allowed.
- Emphasize the importance of correct payment details and account verification.
- Keep the player informed about the status of their withdrawal, especially if delays occur.
- Advise players to contact support if they do not receive their funds after typical processing time or after checking common causes of delay.