# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal inquiry or request.**
   - Collect the player's game ID or username.
   - Ask for any relevant transaction details, such as transaction ID, withdrawal request screenshot, or transfer receipt if available.
   - Identify if the player reports issues such as delays, rejections, or forgotten withdrawal password.

2. **Verify the player's account and request details.**
   - Confirm that the account has no ongoing restrictions or issues.
   - Check that the account balance is sufficient for the requested withdrawal.
   - For password reset requests:
     - Request the player to provide their real name, phone number or wallet number, email, ID card images (front and back), and a screenshot of their last successful recharge or transaction.
     - Verify these details in the system.
   - For withdrawal status checks:
     - Provide your game ID or username to the support team for investigation.
   - For withdrawal rejection or rejection inquiry:
     - Request a screenshot of the withdrawal transaction or request status.

3. **Check the status of the withdrawal request.**
   - Use the system to investigate the current status (pending, approved, rejected, or completed).
   - If the withdrawal is pending or rejected:
     - Obtain the associated transaction ID or request screenshot.
     - Confirm if the request has been processed or rejected.
   - For rejected requests:
     - Inform the player to review the rejection reason, which may involve additional verification or restriction issues.

4. **Determine if additional verification or action is needed.**
   - If the account has not been verified or if verification is required:
     - Ask the player to submit necessary documents (ID, proof of address, etc.).
     - Process the verification before proceeding.
   - If the withdrawal is pending:
     - Explain the typical processing time (usually within a few minutes to hours).
     - Advise the player to wait for the system to process the request.

5. **Manage withdrawal delays or issues.**
   - For delays beyond the expected processing time:
     - Check for system-defined limits and policies, such as daily limits (e.g., 25,000 Taka per day) or verification requirements.
     - If the withdrawal exceeds limits or verification is incomplete, notify the player and advise on necessary actions.
   - For rejected or pending withdrawals:
     - Request the player to provide a screenshot of the transaction or request status.
     - Advise that support will review and update the case, which may vary depending on verification.
     - Escalate the case if needed, especially if the rejection seems unjustified.

6. **Assist with withdrawal recovery or refunds if applicable.**
   - If the player reports a pending or rejected withdrawal:
     - Provide the game ID or username.
     - Upload or ask for a screenshot of the withdrawal request or transaction status.
     - Inform the player that the support team will review the case and update them accordingly.

7. **Resetting or recovering a forgotten withdrawal password.**
   - Request the following details:
     - Game ID or username
     - Registered name, phone number, or wallet number
     - Email address
     - Account balance
     - ID card images (front and back)
     - Screenshot of the last successful recharge or transaction
   - Verify these details within the system.
   - If verification passes:
     - Generate and send a new withdrawal password to the player's registered contact.
     - Notify the player to change the password immediately after receipt.

8. **Communicate clearly with the player throughout.**
   - Explain the status updates, verification requirements, and time estimates transparently.
   - Advise patience if processing is ongoing.
   - Escalate unresolved issues to higher support tiers if necessary, including detailed documentation.

9. **Close the case once resolved.**
   - Confirm that the withdrawal has been successfully processed or properly rejected.
   - Provide the player with relevant details or next steps.
   - Document the case outcome, including screenshots and actions taken.

## Notes
- Always verify player identity thoroughly before processing sensitive requests like password resets or transaction inquiries.
- For transactions over the policy limits or with verification issues, inform the player clearly about the need for additional documentation or restrictions.
- Be aware the platform's withdrawal limits and policies, such as the 25,000 Taka daily limit, and communicate these limits to players if relevant.
- Remember that withdrawal processing typically completes within a few minutes to hours after verification, but delays can occur due to system or policy reasons.

## Key points for communicating with players
- Ensure players understand the need for verification and documentation for security.
- Keep players informed of each step, especially if delays or rejections occur.
- Advise patience and provide clear instructions for next steps if issues arise.