# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and verify the withdrawal request**
   - Confirm that the player has submitted all required verification information:
     - Username, withdrawal name, email, phone number, and current balance.
     - Last game played.
     - Deposit receipt (if applicable).
     - ID selfie holding the ID.
     - Valid ID document.
   - Ensure the account is fully verified before proceeding.
   - If any verification information is missing or incomplete, inform the player to submit the required documents and do not process the withdrawal until verification is complete.

2. **Check withdrawal eligibility and compliance**
   - Verify that the withdrawal request adheres to all relevant rules:
     - Ensure the required documents are provided and verified.
     - Confirm there are no suspicious or large transactions requiring special review.
   - Inform the player that withdrawal requests are processed on a first-come, first-served basis and may take several hours to days.

3. **Submit the withdrawal request to the processing queue**
   - Record the request in the system.
   - Queue the request for processing based on the order of receipt.
   - Notify the player that their request has been received and is being processed in the sequence.

4. **Monitor the processing queue and system status**
   - Keep track of current processing times.
   - Be aware that higher demand may cause delays.
   - Notify the player if processing times are extended beyond typical hours due to high volume.

5. **Process the withdrawal request in system**
   - Handle each request individually in the sequence received.
   - Perform any necessary system or compliance reviews, especially for large or suspicious transactions.
   - Complete the processing once all verification and review steps are passed.

6. **Notify the player and credit funds**
   - Once processed, inform the player via notification that their withdrawal has been completed.
   - Confirm that funds have been credited to the linked wallet account.
   - If the withdrawal cannot be completed immediately, provide an estimated timeframe based on current queue and review status.

7. **Address delayed or stuck withdrawals**
   - If a withdrawal is delayed beyond the expected timeframe, check for any additional review requirements.
   - Communicate transparently with the player about possible delays caused by system volume or review process.
   - Escalate any issues or suspicious transactions as per company protocol.

## Notes

- Withdrawals are processed strictly on a first-come, first-served basis.
- The processing time may vary from several hours to days depending on queue length and review procedures.
- Large or suspicious transactions might undergo additional review by the finance team, impacting the timing.
- Players must ensure their account is fully verified with the required documentation before withdrawal processing.

## Key points for communicating with players

- Inform players that their withdrawal will be processed in order and might take time.
- Notify players when their withdrawal is complete or if there are delays.
- Remind players to keep their account verification information up to date to avoid processing delays.
- Clearly explain if delays are due to high demand or additional reviews.