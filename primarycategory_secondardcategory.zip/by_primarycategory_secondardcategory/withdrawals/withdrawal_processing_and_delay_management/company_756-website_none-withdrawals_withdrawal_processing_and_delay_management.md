# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's withdrawal request**
   - Ask the player to provide the preferred e-wallet (GCash or PayMaya).
   - Confirm the withdrawal amount entered by the player.
   - Ensure the player has sufficient funds in their account.
   - Check if the player has met the relevant turnover requirement before withdrawal.

2. **Collect necessary information for withdrawal processing**
   - Confirm the transaction password provided by the player.
   - For unbinding or deleting a linked withdrawal account:
     - Request the full name, username, withdrawal account number to delete, and reason for deletion.
     - Instruct the player to upload clear copies of a valid ID and a selfie holding the ID.
     - Inform that only one GCash/Maya account can be unbound per day; additional unbind requests must wait 24 hours.
   
3. **Perform system checks and preliminary validation**
   - Check for daily withdrawal service pause at 00:00; advise the player to wait and try again if a delay occurs.
   - Verify if any active betting or wagering turnover requirements are met.
   - Confirm if the withdrawal is not flagged due to abnormal betting activity.
   - If flagged or require active play, advise the player to complete the necessary turnover and retry later.
   
4. **Handle specific withdrawal scenarios**
   - If the player's withdrawal is delayed or failing, inform them that system delays may occur, especially with GCash, and suggest using PayMaya as an alternative.
   - In case of system delay or high volume, inform the player that processing times may extend beyond the usual 3-5 minutes.
   - If a withdrawal is delayed due to inactivity audit, inform the player that they may need to recharge an amount equal to their current balance to proceed.
   - If the withdrawal is under review or audit, inform the player they should wait until the process is completed, and the system will reprocess the request.
   
5. **Submit withdrawal request**
   - Once all information is verified and validation passes, click the "Submit" button to initiate the withdrawal.
   - Notify the player that the request has been received and that processing is underway.

6. **Post-submission procedures**
   - Advise the player to check their account and e-wallet after the expected processing time.
   - Inform the player that if the withdrawal is unsuccessful or delayed beyond the normal timeframe, they should contact support with their transaction details.
   
7. **In case of failed or delayed withdrawals**
   - If the withdrawal fails, confirm the funds are returned to the player's wallet.
   - Guide the player to retry the withdrawal after addressing any flagged issues or completing necessary turnover.
   - If the delay persists, escalate the case for support review.

8. **Additional considerations**
   - Remind players that withdrawal cancellations cannot be reversed once submitted.
   - Clarify that only one withdrawal account unbind per day is allowed; if more unbinds are needed, wait 24 hours between requests.
   - Reassure players that all funds are secure during delays, especially during high transaction volume periods.

## Notes

- Withdrawals may be paused briefly at 00:00 daily; advise players to wait and try again after about 5 minutes.
- Withdrawals can experience delays during high transaction volumes; processing times can extend beyond 3-5 minutes.
- Players must meet turnover requirements before withdrawal, and withdrawals may be blocked if the system flags abnormal betting activity.
- For links to unbind accounts, ensure clear IDs and selfies are provided, and only one unbind request is processed per day.
- If a withdrawal is delayed or not reflected, verify the status and inform the player that typical delays are due to processing workload.

## Key points for communicating with players

- Remind players that delays are usually caused by system volume or audits; their funds remain safe.
- Instruct players to refresh the page if they experience delays around settlement times.
- Clarify that withdrawal cancellations are not allowed once requests are submitted.
- Encourage patience and advise players to contact support with relevant details for unresolved delays or failures.