# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's eligibility for withdrawal:**
   - Confirm the player has completed the necessary requirements:
     - Bound and verified their phone number.
     - Linked a bank account or e-wallet.
     - Fulfilled the required turnover/multiplier condition (if applicable).
   - Ensure the player’s account balance is sufficient for the desired withdrawal amount.

2. **Gather player information:**
   - Confirm the player's registered username.
   - If the player has not linked a withdrawal account:
     - Instruct them to tap the (+) button in the app and fill in these details:
       - Name
       - Bank Institution or E-wallet provider
       - Account Number
       - Transaction payment/password
   - If the withdrawal account is already linked, proceed with details.

3. **Check withdrawal limits and balance:**
   - Confirm the requested amount is at least PHP 100 (minimum per transaction).
   - Ensure the amount does not exceed PHP 50,000 (maximum per transaction).
   - Verify the total withdrawal amount for the day does not surpass PHP 500,000.
   - Confirm the account balance meets the requested withdrawal amount.

4. **Process the withdrawal request:**
   - Enter the withdrawal amount.
   - Ask the player to input their payment or transaction password.
   - Submit the request by tapping "Submit."
   - Ensure all data is correct before confirmation.

5. **Evaluate additional requirements:**
   - Make sure all verification steps are complete (phone verification, account linking).
   - Check if the account’s turnover requirement is fulfilled; if not, advise the player to complete it before requesting withdrawal.
   - If deposits with promotions are involved, verify any applicable turnover conditions.

6. **Handle the request in the back office:**
   - Confirm the request details against the system:
     - Amount, linked account, and verification status.
   - Process the withdrawal request:
     - Based on the system’s processing time, which is usually immediate but can vary.
   - Do not process cancellations as withdrawals are generally processed immediately; only attempt to cancel if the request is still pending and supported by system policies.

7. **Communicate with the player:**
   - Notify the player of successful submission.
   - Inform them that withdrawal will be processed according to the usual timeframe.
   - In case of delays or issues, check for system delays or additional verification requirements.

8. **In case of delays or issues:**
   - Investigate if the withdrawal is pending or delayed due to system processing or verification issues.
   - Remind the player of the limits and requirements if their request is denied or delayed.

9. **Follow-up and closure:**
   - Confirm with the player once the withdrawal is processed.
   - Advise the player to check their linked bank account or e-wallet for the funds.
   - If issues persist, escalate as per company protocol.

## Notes

- Withdrawals are processed immediately once all requirements are met.
- Requests cannot be canceled after submission unless still pending and supported by the system.
- Ensure the player has completed all verification and turnover requirements before submitting the withdrawal.

## Key points for communicating with players

- Clearly remind players of the minimum PHP 100 and maximum PHP 50,000 per transaction limits.
- Verify that they've linked and verified their bank account or e-wallet.
- Confirm they have met any turnover requirements if applicable.
- Explain that withdrawals are processed promptly but may be delayed due to verification or system issues.
- Advise to contact support immediately if they experience delays or problems with their withdrawal request.