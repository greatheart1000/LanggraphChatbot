# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and understand the player's withdrawal inquiry**
   - Ask the player for details about their withdrawal request, including the amount, payment method, and any relevant account information.
   - Confirm if the player has completed all necessary account verification procedures, as incomplete verification can cause delays.
   
2. **Check the withdrawal request details in the system**
   - Verify the requested amount against the platform’s withdrawal limits, which depend on the player’s account type.
   - Ensure the withdrawal request is correctly submitted and registered in the system.
   
3. **Assess the processing conditions**
   - Determine if there are any system-wide high volume periods or delays that could affect processing times (withdrawals are typically processed within 24 hours, but delays can occur during high volume).
   - Confirm whether the withdrawal request has already been queued and is pending processing.
   
4. **Monitor the status of the withdrawal request**
   - Check if the withdrawal is still in the queue or if processing has begun.
   - If the request remains unprocessed beyond 24 hours, inform the player that processing times may be extended due to high transaction volume but reassure that transactions are processed on a first-come, first-served basis.
   
5. **Handle delayed withdrawals**
   - If the withdrawal is delayed beyond the typical processing time, advise the player to wait patiently.
   - Instruct the player to contact support for an update if the delay persists longer than expected.
   
6. **If the withdrawal fails**
   - Confirm the success of the verification procedures and whether the player has used an alternative payment method like PayMaya if the initial method failed.
   - Verify if the withdrawal request faced any specific errors; if so, guide the player to address the issues or try again.
   - If the failure is due to system or policy reasons, inform the player about the standard processing times and possible retry options.
   
7. **Follow up and close the case**
   - Provide the player with updates or additional instructions if needed.
   - Once the withdrawal is completed or the issue is resolved, update the case with the outcome.

## Notes

- Withdrawal processing times may vary based on system volume; usual processing time is within 24 hours.
- Delays are generally caused by high transaction volumes; patience is advised.
- Ensuring all account verification procedures are completed can prevent delays and failures.
- Contact support for updates if the withdrawal exceeds the typical processing window.

## Key points for communicating with players

- Remind players that withdrawals are processed in order and may take some time during high volume periods.
- Encourage patience and advise them to contact support for updates if delays extend beyond 24 hours.
- Inform players to verify their account details and complete all verification steps to avoid processing delays.
- Suggest alternative payment methods like PayMaya if their initial withdrawal method fails.