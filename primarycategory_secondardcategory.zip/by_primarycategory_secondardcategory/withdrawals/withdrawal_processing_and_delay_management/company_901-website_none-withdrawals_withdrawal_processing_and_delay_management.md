# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the player's withdrawal request**
   - Collect the following information:
     - Game ID / Username
     - Withdrawal amount
     - Preferred withdrawal method (bank transfer, e-wallet, etc.)
     - Valid contact details (email, phone number)
     - Wallet ID or bank account number linked to the account
   - Confirm that the player is aware of the daily withdrawal limit and VIP level restrictions.

2. **Verify the player's identity and account details**
   - If the player has requested a password reset for withdrawals:
     - Ask for:
       - Real name (withdrawal name)
       - Phone number on the account
       - Email address
       - Government-issued ID for name verification
       - Additional info such as wallet ID or bank account number
     - If the information provided is correct, inform the player that a new withdrawal password will be sent; they can set a new one after login.
   
3. **Check withdrawal eligibility and limits**
   - Confirm whether the requested amount is within the player's daily limit (e.g., 5,000 PHP per 24 hours as standard; varies based on VIP level).
   - Verify the player's VIP level to determine if any higher withdrawal limits apply.
   - Ensure that the account balance covers the withdrawal amount.

4. **Review transaction status and potential delays**
   - Note that delays may occur due to high transaction volumes or banking reasons; transactions are processed sequentially.
   - Advise the player they may experience longer processing times, especially during peak periods.
   
5. **Initiate the withdrawal request in the system**
   - Submit the withdrawal for processing.
   - If the withdrawal cannot be canceled (e.g., already being processed or transferred), inform the player accordingly.
   
6. **Communicate to the player about processing time and potential delays**
   - Explain that deposits and withdrawals might take from a few minutes to several hours to complete.
   - Warn that delays can occur during high volume periods and due to banking reasons.
   
7. **Monitor the transaction**
   - Check the status of the withdrawal in the system regularly.
   - If the transaction remains pending longer than typical:
     - Request additional proof from the player if needed (screenshots of transaction receipt, proof of transaction, etc.).
     - Escalate cases where delays are abnormal or for unresolved issues.
   
8. **Handle transfer or processing completion**
   - Once the withdrawal is processed and transferred to the player's bank or e-wallet, notify the player.
   - If the withdrawal is delayed beyond the normal timeframe, inform the player of the current status and reassure that their funds are secure.

9. **Address issues with delayed or missing transactions**
   - If the withdrawal has not appeared in the player's account:
     - Ask the player to submit evidence of the successful transaction (screenshots or receipts).
     - Verify the details and transaction with the banking or payment partner.
     - Keep the player informed of ongoing investigations or processing status.

10. **Conclusion and final verification**
    - Confirm from the player if the withdrawal has been successfully received.
    - Advise on the importance of keeping their withdrawal password secure and to remember it after resetting.
    - If issues persist, escalate to the relevant department for further investigation.

## Notes
- Cancellations of withdrawals are only possible before the processing begins; once processing has started, cancellations cannot be made.
- Always verify the player’s information thoroughly when resetting passwords or handling large transactions.
- Be transparent about potential delays due to banking and processing times, and remind players that their funds are secure during delays.

## Key points for communicating with players
- Inform players of the daily withdrawal limit based on their VIP level.
- Explain that delays are common during high volume periods or banking reasons and ask for patience.
- Clarify that withdrawal cancellations are only possible before processing starts.
- Advise players to submit clear transaction evidence if their withdrawal is delayed or missing.