# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify the player's withdrawal request details.**
   - Confirm the player has provided the withdrawal amount, selected the withdrawal method (e-wallet or bank account), and entered the correct transaction password.
   - Ensure the player’s account has completed all necessary verification (e.g., identity verification as per system requirements).

2. **Check the player's withdrawal eligibility and requirements.**
   - Confirm the player has made the minimum deposit required for withdrawal.
   - Verify if the player has met any applicable turnover requirements; withdrawal may only be permitted after meeting these.
   - Ensure the player's account is not under any special restrictions or holds.

3. **Assess the current status of the selected withdrawal method.**
   - Check if the chosen withdrawal method (bank transfer, GCash, Maya, PayMaya, etc.) is available and not under maintenance.
   - If the method is unavailable due to maintenance or delay, advise the player to use an alternative method (e.g., GCash if Maya is under maintenance).
   
4. **Process the withdrawal request through the system.**
   - Submit the withdrawal amount and transaction password via the website or mobile app.
   - Confirm that the request is successfully submitted.

5. **Perform system verification and approval.**
   - The team will verify the request for completeness and compliance with requirements.
   - Check if any additional document or screenshot is required if there are issues (e.g., failed withdrawal notices, delays).

6. **Monitor for processing time and delays.**
   - Typical processing time is 5–15 minutes; notify the player accordingly.
   - If the withdrawal is delayed beyond this timeframe, check for system status or maintenance notifications for the withdrawal method.

7. **Handle withdrawal failures or delays.**
   - If the withdrawal fails (e.g., due to system issues or method unavailability):
     - Inform the player about the failure.
     - Suggest alternative withdrawal methods if applicable, such as GCash or PayMaya.
     - Request the player to ensure that all turnover requirements are met before retrying.
   - If the method is under maintenance or unavailable:
     - Advise the player to try an alternative method or wait until the maintenance is complete.
     - Request a screenshot if the issue persists to assist support in investigating.

8. **Confirm transaction success.**
   - Verify that the funds have successfully arrived in the player's selected account (bank or e-wallet).
   - If the funds do not arrive within the expected timeframe, escalate the issue for further investigation.

9. **Assist with reset of withdrawal password if needed.**
   - If the player reports issues with transaction password:
     - Guide the player to click 'Forgot Password' on the withdrawal page.
     - Select 'SMS Option', enter their registered mobile number, and receive a 5-digit SMS code.
     - Enter the code, then set a new 6-digit password.

10. **Document and close the case.**
    - Record all relevant details, including any screenshots submitted or steps taken.
    - Confirm with the player that their issue has been resolved or provide next steps if further assistance is required.

## Notes

- Always verify that the player's account is fully verified before processing withdrawals.
- Be aware that bank withdrawals may sometimes be temporarily unavailable; in such cases, advise using alternative methods like GCash or PayMaya.
- For withdrawal delays or failures, the player may be asked to provide screenshots to support investigation.
- Remind players of the typical processing time (5–15 minutes) and that delays can occur due to maintenance or system issues.

## Key points for communicating with players

- Inform players that withdrawals are verified and processed by the team, which may take a few minutes.
- Clearly explain the steps if a withdrawal fails, including methods to resolve it (e.g., using alternative methods).
- Advise players to ensure their account verification and meet all withdrawal requirements before requesting a withdrawal.