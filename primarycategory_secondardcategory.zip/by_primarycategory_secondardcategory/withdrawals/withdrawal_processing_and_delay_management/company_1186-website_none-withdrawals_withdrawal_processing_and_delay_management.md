# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Gather player's withdrawal request details**
   - Request the player to provide the amount they wish to withdraw.
   - Confirm the player's account is verified and that their account details are up to date.
   - Ensure the withdrawal amount is within the platform's policies and limits (minimum of 500 PHP and maximum of 20,000 PHP per transaction).

2. **Verify account and withdrawal eligibility**
   - Check if the player's account has completed all verification processes.
   - Confirm that the player has sufficient funds in their account to cover the withdrawal amount.
   - Ensure the withdrawal complies with all platform rules, including minimum withdrawal amount.

3. **Check for any issues or restrictions**
   - Review for any restrictions or holds on the account that might delay or prevent withdrawal.
   - Verify that the withdrawal request meets all platform policies and rules.

4. **Process the withdrawal request**
   - Submit the withdrawal request through the back office system.
   - Note that withdrawal processing times can vary depending on the platform’s policies and chosen withdrawal method (refer to platform-specific processing times).

5. **Inform the player of processing time**
   - Convey to the player that the withdrawal might take some time and depends on the processing times set by the platform.
   - Clarify that the processing times are outlined in the platform's policy.

6. **Follow-up and manage delays**
   - If the withdrawal does not reflect in the player's account within the expected time, verify the status in the system.
   - Check for common issues such as incorrect account details, non-compliance with withdrawal requirements, or exceeding limits.
   - If the withdrawal fails or is delayed due to specific issues, explain the situation to the player and advise on possible next steps:
     - Rechecking the account information
     - Ensuring compliance with withdrawal policies
     - Contacting support if issues persist, providing relevant error messages for troubleshooting

7. **Resolve and close the case**
   - Confirm successful withdrawal with the player once processed.
   - Advise the player on any further actions if necessary, such as verifying account details or waiting for system updates.
   - Document the case resolution and update system records.

## Notes

- Withdrawal limits are between 500 PHP (minimum) and 20,000 PHP (maximum) per transaction.
- Processing times depend on the platform's policies and the chosen withdrawal method; always inform players accordingly.
- Ensure account verification is complete before processing withdrawal requests to prevent delays or rejections.

## Key points for communicating with players

- Clearly inform players about the possible delay based on platform policies.
- Verify account details and fund sufficiency before proceeding.
- Explain that withdrawal limits are from 500 PHP to 20,000 PHP per transaction.
- Encourage players to contact support with specific error messages if a withdrawal fails or is delayed.