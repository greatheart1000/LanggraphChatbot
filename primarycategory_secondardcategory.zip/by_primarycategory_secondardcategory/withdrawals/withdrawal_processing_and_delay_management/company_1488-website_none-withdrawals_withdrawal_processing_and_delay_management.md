# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify Player Identity and Account Information**
   - Confirm that the player's account is fully verified before processing any withdrawal.
   - Ensure that the bank account or withdrawal method used is in the player's own name.
   - Collect necessary details from the player, such as username, phone number, withdrawal name, birth date, and last deposit date, if needed for password reset or verification.

2. **Confirm Withdrawal Eligibility**
   - Check that the player has met all withdrawal conditions:
     - Fulfilled any wagering or bonus requirements if applicable.
     - The withdrawal amount meets the minimum withdrawal limit (e.g., 300 points).
     - The account has no unresolved issues or restrictions.
   - Ensure the player has provided the correct transaction (withdrawal) password.

3. **Address Password Issues (if applicable)**
   - If the player reports a forgotten or incorrect withdrawal password:
     - Request the player to provide their username, phone number, withdrawal name, birth date, last deposit date, or other relevant details.
     - Submit these details to support for assistance with password reset.
     - Inform the player that support will help reset the password.

4. **Process the Withdrawal Request**
   - If all verification steps are clear:
     - Guide the player to submit the withdrawal request through the designated platform section (e.g., "Member" > "Withdrawal record").
     - Record relevant transaction details, such as date and transaction ID.
   - Confirm that the request is placed successfully and inform the player of the expected processing time (usually within minutes after meeting all conditions).

5. **Review and Monitor Transaction Status**
   - Check the player's withdrawal history:
     - Instruct the player to navigate to "Member" > "Withdrawal record."
     - Assist them in filtering by date or type to locate the specific withdrawal.
   - For pending or failed transactions:
     - Verify the transaction status and ensure all steps were correctly followed.
     - Look for issues like incomplete verification, mismatched bank information, or insufficient funds.

6. **Troubleshoot Delays or Failed Withdrawals**
   - If the withdrawal is delayed or funds have not reflected:
     - Confirm the following:
       - The withdrawal amount is above the minimum limit.
       - All account verification and wagering conditions are met.
       - The bank details are correct and in the player's name.
       - The account is not under maintenance or restrictions.
     - Advise the player to wait 2-3 days for processing if the transaction shows successful but funds are not received.
     - Collect transaction details (amount, withdrawal method, reference number, or transaction ID) and escalate to support if issues persist.

7. **Communicate Next Steps and Resolution**
   - Keep the player informed about the status and anticipated resolution times.
   - If further support is needed, instruct the player to provide specific transaction details for investigation.
   - Emphasize that delays can be caused by unmet requirements, connectivity issues, or bank information mismatches.

## Notes
- Always verify that the withdrawal amount and bank account details conform to site rules.
- Remind players to provide accurate information, particularly for password resets or transaction IDs.
- Ensure that players understand that withdrawal processing can take minutes after all conditions are met, but delays beyond that warrant contacting support with relevant details.

## Key points for communicating with players
- Instruct players to check their withdrawal records via "Member" > "Withdrawal record."
- Advise them to wait 2-3 days if the transaction is marked successful but funds are not received.
- Remind players to submit the correct transaction password and ensure all verification steps are completed.
- Encourage players to contact support with detailed transaction information if issues persist.