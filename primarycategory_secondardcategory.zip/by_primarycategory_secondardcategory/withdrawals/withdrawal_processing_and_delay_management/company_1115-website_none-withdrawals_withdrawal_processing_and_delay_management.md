# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify user's account status and completeness of verification**
   - Confirm that the user has completed all verification procedures, including submitting a valid ID with selfie and the last deposit receipt, if applicable. (Supported by: "Fill out the withdrawal form with your details" and "Ensure your account is verified.")

2. **Confirm that the user has fulfilled the turnover requirement**
   - Ensure the user has completed at least one full turnover from slot games (including remaining balance). This is necessary before they can request a withdrawal. (Supported by: "You must complete at least one full turnover before the withdrawal can be released.")

3. **Review the withdrawal request details**
   - Collect information from the user:
     - User ID or username
     - Payment method details (e-wallet number or bank account)
     - Amount requested
   - Verify that the provided payment details are correct and registered properly. Pay special attention if the withdrawal is to GCASH; confirm that the number is registered and accurate. (Supported by: "Check that the GCASH number is registered and correct.")

4. **Assess for any special conditions or large withdrawal considerations**
   - Determine if the withdrawal amount exceeds normal limits, triggering additional verification or review procedures. Large cash-outs may take 24-48 hours for review by the finance team. (Supported by: "Large cash outs will undergo a review process by the finance team, typically taking 24 to 48 hours.")

5. **Check for withdrawal limits or restrictions**
   - Verify if there are any applicable limits based on the user's account level or chosen payment method. Refer to platform rules if specific limits are needed. (Supported by: "Withdrawal limits vary depending on the payment method and account status.")

6. **Process the withdrawal request in the system**
   - Submit the request for review within the back-office/administration system.
   - The system will automatically review the betting history, especially for large amounts, and conduct preliminary checks for suspicious activity. (Supported by: "The system will review your betting history and, if everything is in order, your withdrawal will be processed.")

7. **Review for delays and high-volume conditions**
   - Inform the user that withdrawals may be delayed during periods of high volume or system backlog. Typical processing times are within 24 hours but can extend during peak periods or for large withdrawals.
   - Advise the user to wait patiently and avoid submitting multiple requests. (Supported by: "Withdrawal processing times depend on the volume of requests.")

8. **Notify the user about potential delays due to suspicious activity or irregular betting**
   - If unusual betting activity is detected, the withdrawal may be canceled or placed under review. Encourage bet patterns consistent with standard activity, such as using slot games rather than live bets. (Supported by: "If unusual betting activity is detected, a withdrawal may be canceled or placed under review.")

9. **Handle failed or delayed withdrawals**
   - If the withdrawal is marked as successful but the funds are not yet received, advise the user to contact the relevant e-wallet provider (e.g., GCash, PayMaya) with transaction details.
   - For GCash, verify if the number is registered and correct; if not, update to a valid number or choose an alternative payment method.
   - If the withdrawal is delayed beyond normal processing times, inform the user and recommend contacting support for status updates. (Supported by: "If a withdrawal has been marked as successful but funds have not yet arrived," and "Check that the GCASH number is registered and correct.")

10. **Advise on withdrawal cancellation procedures**
    - If the user requests cancellation and the withdrawal has not yet been processed, instruct them to contact customer support quickly.
    - Cancellations are only possible before the withdrawal request enters final processing or payment stage. (Supported by: "Contact customer support immediately" and "Withdrawals that are currently under review cannot be canceled.")

11. **Complete the process**
    - Once the review is finished and the system approves, the funds will be transferred via the selected payment method.
    - Confirm with the user about the expected delivery time based on the method used.
    - Remind the user that processing times can vary during high volume and for large amounts.

## Notes
- Withdrawals are processed on a first-come, first-served basis.
- Large withdrawals (not specified in exact amounts) are subject to additional review and may take 24–48 hours.
- Ensure the user complies with all account verification requirements to avoid delays.

## Key points for communicating with players
- Always verify account and payment details before processing.
- Inform users about potential delays during peak times or for large withdrawals.
- Clarify that withdrawals are processed in the order received and may experience queue-related delays.
- Guide users to contact support for delayed or rejected withdrawals, providing transaction details if needed.
- Remind users that withdrawal cancellation is only possible if the request is still under review and before final payment processing.