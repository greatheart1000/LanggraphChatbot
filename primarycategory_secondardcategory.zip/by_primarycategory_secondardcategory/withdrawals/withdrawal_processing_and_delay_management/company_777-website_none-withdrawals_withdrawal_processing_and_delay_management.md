# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and verify player withdrawal request**
   - Confirm the player intends to withdraw funds and has submitted the correct withdrawal amount and selected a supported withdrawal method (e-wallet such as GCash, PayMaya, or Online Banking).
   - Ensure the player has entered their transaction password correctly.
   - Ask the player if the requested amount is within the supported limits:
     - GCash: 500 PHP to 20,000 PHP.
     - PayMaya (for amounts below 500 PHP or as an alternative).
   - Verify that the player has met any applicable turnover (wagering) requirements if the withdrawal relates to bonus funds.

2. **Check the status of the player's account and relevant conditions**
   - Confirm whether the player has fulfilled all the necessary criteria for withdrawal:
     - Pending bonuses or promotions' turnover requirements completed.
     - Account verification completed, if applicable.
     - No outstanding verification or security issues.

3. **Process the withdrawal request in the back office**
   - Submit the withdrawal request via the system.
   - Record the details of the request, including player ID, method, amount, and timestamp.
   - Notify the player about the typical processing times (normally 3–5 minutes under normal conditions).

4. **Inform the player about potential delays or failures**
   - Explain that withdrawal issues may occur during high transaction volume, system maintenance, or technical problems.
   - Advise players to resubmit the request if it fails, and clarify that the finance team is working to expedite pending withdrawals.
   - Emphasize that funds are safe and will be credited once processed.

5. **Monitor the withdrawal status**
   - Check if the withdrawal has been completed within 3–5 minutes.
   - If processed successfully:
     - Confirm with the player that the funds have been credited to their chosen method.
     - Provide the player with a withdrawal record or receipt if requested.
   
   - If the withdrawal has not been processed within the standard time frame or if it fails:
     - Recommend resubmitting the withdrawal request.
     - If issues persist, escalate the case to the finance or technical team for further assistance.

6. **Handle specific issues related to withdrawal methods**
   - **GCASH withdrawals**:
     - Allow 30 to 45 minutes for processing.
     - If a GCASH withdrawal is delayed or fails:
       - Advise the player to wait for further processing.
       - If issues remain after 45 minutes, consider alternative methods such as PayMaya or Online Banking.
     
   - **Unavailability of GCash**:
     - Inform the player that GCASH withdrawals may be temporarily unavailable due to operator issues.
     - Suggest switching to Maya or Online Banking if needed.
     - If a GCash withdrawal was initiated during downtime, advise the player to update to an alternative method.

7. **Confirm completion or take further action**
   - Once the withdrawal is credited:
     - Provide the player with the withdrawal receipt or record, including amount, reference number, date, and time.
     - Confirm no further action is needed.
   
   - If the withdrawal fails repeatedly:
     - Advise the player to verify their account details and ensure all conditions are met.
     - Escalate to technical support if the issue persists, especially during high volume or system errors.

8. **Document and close the case**
   - Save screenshots or records of withdrawal transactions, records, and player communication.
   - Close the ticket or case once the withdrawal is successfully processed, or once the player is satisfied with the resolution.

## Notes

- Withdrawals are typically processed within 3–5 minutes under normal conditions.
- During high transaction volume, delays of 30–45 minutes or more may occur.
- For withdrawals below 500 PHP, advise using PayMaya as an alternative.
- Always verify the correct withdrawal method and details before processing.
- Remember that withdrawals cannot be canceled once processed.
- Check the player's withdrawal history for record-keeping or verification purposes.

## Key points for communicating with players

- Inform players of typical processing times and potential delays during high volume.
- Encourage resubmission of withdrawal requests if they fail.
- Explain that funds are secure and will be credited once processed.
- Advise switching to alternative withdrawal methods if their preferred method is temporarily unavailable.
- Remind players to send withdrawal records or screenshots if requested for verification.