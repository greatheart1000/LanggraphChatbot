# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and verify the player's withdrawal request**
   - Confirm the player has provided necessary details:
     - Selected withdrawal method (e-wallet, GCash, PayMaya, Online Banking, etc.)
     - Withdrawal amount
     - Transaction password
   - Ensure the withdrawal amount meets platform limits:
     - Minimum amount: 100 PHP
     - Maximum amount per transaction: 20,000 PHP

2. **Check player's account and withdrawal eligibility**
   - Verify the player's account status and that all turnover or wagering requirements are met for withdrawal (if applicable).
   - Confirm there are no account restrictions or pending issues that prevent withdrawal.

3. **Determine the withdrawal method and process accordingly**
   - For GCash:
     - Allowed per transaction: 500 PHP to 20,000 PHP.
     - Processing time: approximately 30–45 minutes.
     - For amounts below 500 PHP: advise using PayMaya.
   - For PayMaya:
     - Available for withdrawals below 500 PHP.
   - For other e-wallets or bank options:
     - Follow standard withdrawal steps and processing times as applicable.

4. **Initiate the withdrawal in the system**
   - Enter the withdrawal method, amount, and transaction password.
   - Submit the request.
   - Confirm that the withdrawal status shows as "transferring" (meaning approved and in process).

5. **Monitor the withdrawal status**
   - For GCash or PayMaya:
     - Inform the player that processing may take 30–45 minutes.
     - Remind them to check their wallet balance after this period.
     - If not received after the expected time, advise waiting longer and contacting support if needed.
   - For delays:
     - Explain that delays may occur during high volume periods or due to system issues.
     - Assure the funds are secure and are being processed by the finance team.
     - No fixed ETA can be given for resolution.

6. **Handle withdrawal delays or issues**
   - If the withdrawal is delayed beyond the typical processing time:
     - Ask the player for their withdrawal record (go to Home > Member > Withdrawal Record).
     - Have the player take a screenshot of their withdrawal record.
     - Confirm whether the transaction shows as transferring or pending.
   - For rejected requests:
     - Inform the player that the system refunds the funds automatically.
     - Verify the refund by checking their account balance and transaction history.
   - For failed or canceled withdrawals:
     - Confirm the funds are returned to the player's account.
     - Advise re-initiating the withdrawal once issues are resolved.

7. **If a wallet withdrawal option (e.g., GCash) is temporarily unavailable**
   - Notify the player of the system maintenance or technical issues.
   - Recommend using an alternative supported wallet (e.g., PayMaya, Online Banking).
   - If the player has already initiated a withdrawal and the wallet is offline:
     - Advise them to wait for the system to resume processing.
     - Remind them of the respective processing times and limits.

8. **Unbinding or changing withdrawal accounts**
   - To unbind or update linked withdrawal information:
     - Player must provide full name, username, and the account details to delete.
     - Submit a valid ID and a selfie with the ID for verification.
     - Specify which service (GCASH or PAYMAYA) to unbind.
     - Once reviewed and approved, the account details will be updated.

9. **Review and follow up**
   - If withdrawal remains pending or not credited:
     - Review the withdrawal record in the system.
     - Contact the finance team for further investigation if necessary.
     - Keep the player informed about the status and estimated resolution time.

10. **Close the case**
    - Once the withdrawal is successfully credited or refunded:
      - Confirm with the player.
      - Provide a summary of the transaction or receipt if needed.
      - Encourage them to contact support for any further concerns.

## Notes
- Withdrawals may experience delays during high transaction volume; processing times can be longer than usual.
- There is no fixed ETA for resolving withdrawal issues; the finance team works to process pending requests as quickly as possible.
- Always verify that the player has provided all required information and screenshots before escalating or providing further assistance.
- Encourage players to check their withdrawal records and wallets for updates regularly.

## Key points for communicating with players
- Be transparent about possible delays and the reasons behind them.
- Guide players on how to check their withdrawal status and records.
- Explain the limits and alternative methods clearly.
- Remind players to be patient and retain screenshots for reference.
- Reassure that all funds are secure and will be processed once system issues are resolved.