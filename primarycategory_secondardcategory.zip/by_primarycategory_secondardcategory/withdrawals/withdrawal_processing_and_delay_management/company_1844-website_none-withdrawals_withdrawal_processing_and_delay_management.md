# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive Player Inquiry or Report on Withdrawal Issue**  
   - Determine if the player is requesting information about withdrawal procedures, requesting to recover a forgotten withdrawal password, or reporting a pending/rejected withdrawal.

2. **Verify Player Identity and Withdrawals Details**  
   - Ask the player for their game ID or username, full name, registered email, phone number, and wallet number as applicable.
   - Request a screenshot of the last successful transfer or relevant transaction proof if the issue pertains to withdrawal status or password recovery.
   - If the player reports a forgotten withdrawal password, instruct them to prepare their ID card (front and back copies), recent transaction screenshot, and account balance.

3. **Check Withdrawal Request or Status in the System**  
   - Access the player’s transaction records to verify if the withdrawal request has been successfully processed, is pending, or has been rejected.
   - Confirm if the withdrawal request meets the minimum and maximum withdrawal limits (e.g., up to 25,000 PHP/Taka per day).
   - Review whether the account has completed the required betting turnover and betting cycle for withdrawal eligibility.
   - Check for suspicious activity or automatic system flags that may have caused rejection or delay.

4. **Determine Action Based on Withdrawal Status**  
   - **If withdrawal is successful:**  
     - Confirm with the player that the transaction record is available and provide any necessary assistance if they experience delays.
     - Advise the player to wait for system processing times; processing may take from minutes up to several hours depending on the system status.
   
   - **If withdrawal is pending:**  
     - Inform the player that processing is ongoing and encourage patience.
     - Request additional documentation or screenshots if needed to expedite investigation.
   
   - **If withdrawal is rejected or delayed beyond standard times:**  
     - Review the transaction record for possible issues (e.g., incomplete verification, insufficient balance, policy violations).
     - Ask the player to provide a screenshot of the withdrawal record and any relevant transaction details.
     - Advise the player to ensure eligibility criteria like the betting cycle and limits are met.
   
5. **If the Player Needs to Reset or Recover Withdrawal Password**  
   - Collect required information:  
     - Game ID or username, real name, registered email or phone number/wallet number, account balance, and ID card copies.  
     - Screenshot of the last successful transaction, if relevant.
   - Verify their details against the system.  
   - Once verified, instruct the system or support staff to generate a new withdrawal password.  
   - Notify the player that a new password will be sent once verification is complete.

6. **Assist with Cancellation or Refund Requests**  
   - If the player requests to cancel a withdrawal request and get a refund:  
     - Ask for the transaction details and a screenshot of the withdrawal request.  
     - Forward the request to the support team for review.  
     - Inform the player that cancellations are processed if eligible, based on the system’s policies, and may require additional verification.

7. **Final Verification and Resolution**  
   - Confirm all provided information and transaction screenshots.  
   - Ensure that the withdrawal adheres to all policies: limits, betting requirements, and verification procedures.  
   - If all conditions are met, advise the player to wait for the system to process the withdrawal; if issues persist, escalate to relevant technical or compliance teams.

8. **Close the Case**  
   - Summarize the actions taken and the current status to the player.  
   - Provide guidance on expected processing times or next steps, including how to contact support if issues continue.  
   - Document the case details and resolution steps in the system for future reference.

## Notes

- Screenshots of transactions, especially the last successful transfer or withdrawal request, are essential for verification and troubleshooting.
- Withdrawal processing times can vary; delays beyond standard processing times should be investigated with player cooperation.
- Rejections often relate to incomplete verification, insufficient funds, or policy violations; review transaction details thoroughly before escalating.
- Resetting or recovering a withdrawal password requires comprehensive identification verification, including ID copies and recent transaction proof.
- Proper communication to players about delays or issues helps manage expectations and reduces frustration.

## Key points for communicating with players

- Always verify identity with detailed information and screenshots.
- Explain that withdrawal times may vary and that delays could be due to verification or system checks.
- Remind players of applicable limits (e.g., up to 25,000 PHP/Taka daily).
- Encourage patience and cooperation during investigation of pending or rejected withdrawals.
- Inform players that password recovery involves system verification and may take some time.