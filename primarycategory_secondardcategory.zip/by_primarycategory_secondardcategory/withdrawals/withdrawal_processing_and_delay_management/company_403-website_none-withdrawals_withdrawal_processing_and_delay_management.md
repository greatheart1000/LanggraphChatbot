# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player inquiry regarding withdrawal issues or delays.**  
   - Collect essential information: player's account details, withdrawal method used, withdrawal amount, and any error or delay messages the player received.

2. **Verify the selected withdrawal method.**  
   - Check whether the method used (e.g., GrabPay, GCash, PayMaya) is currently operational.  
   - If the player used GrabPay, inform them that if GrabPay withdrawal is under maintenance, they should try alternative methods such as GCash or PayMaya.  
   - Similarly, if the withdrawal method appears to be under maintenance or unavailable, advise using GCash or PayMaya instead.

3. **Assess the player's eligibility for withdrawal.**  
   - Confirm if the player has met all withdrawal requirements, such as any necessary account verification or review process.  
   - Check for any bonus activation with wagering or turnover requirements, which may prevent withdrawal if not met.

4. **Attempt to process the withdrawal in the system.**  
   - Initiate the withdrawal request via the backend system or cashier interface.  
   - If the withdrawal cannot be processed due to system errors or the method being under maintenance, inform the player accordingly and suggest using an alternative method, specifically GCash or PayMaya.

5. **If withdrawal is delayed or not processing:**
   - Determine if the delay is due to being under maintenance of the payment method in use.  
   - Check if the player has an active bonus that requires meeting turnover obligations.  
   - If the player's account is under review or verification, inform the player that customer support will assist further.  
   - If the player canceled the withdrawal or requested cancellation, advise them to follow up with customer support for next steps.

6. **Advise the player on alternative actions if needed.**  
   - Suggest using GCash or PayMaya for withdrawal if the current method is unavailable or under maintenance.  
   - Guide the player to follow the official withdrawal instructions in the app for GCash or PayMaya if they choose those options.

7. **Record the case details.**  
   - Document the player's issue, the steps taken, and any instructions given, for future reference or escalation if necessary.

## Notes
- Always inform players that some withdrawal methods may be temporarily under maintenance, requiring a switch to GCash or PayMaya.
- Remind players to meet all withdrawal requirements, including wagering and verification, to avoid delays.
- Ensure compliance with site-specific rules: if a withdrawal is delayed due to technical issues or account review, escalate the case to the appropriate support team.
- When instructing players to use GCash or PayMaya, refer them to the official withdrawal guide for step-by-step instructions.

## Key points for communicating with players
- Clearly explain if the chosen withdrawal method is under maintenance and suggest alternative options.
- Confirm if there are any wagering requirements or verification issues delaying withdrawal.
- Reassure players that delays are typically due to system maintenance or review processes and that their case is being handled accordingly.