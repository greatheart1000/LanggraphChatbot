# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive player withdrawal request**  
   - Collect essential details from the player:
     - Selected withdrawal method (e-wallet such as GCash, PayMaya, or Maya)  
     - Withdrawal amount  
     - Player’s transaction password

2. **Verify withdrawal eligibility**  
   - Confirm that the player meets all requirements:  
     - Turnover or wagering requirements are fulfilled (if applicable, e.g., for promotions or bonuses)  
     - No abnormal betting activity is detected  
   - Check for potential account violations (e.g., multiple accounts from the same IP, bank card, or phone number) which could block withdrawal

3. **Check withdrawal limits and method support**  
   - Confirm the withdrawal amount complies with the current limits:  
     - GCash: 500 PHP to 20,000 PHP per transaction  
     - PayMaya: recommended for withdrawals below 500 PHP, no specific limits stated; verify based on the latest policy  
   - If GCash is unavailable due to maintenance or technical issues, inform the player and offer alternatives: Maya, PayMaya, GrabPay, Gotyme, USDT, or Online Bank Transfer

4. **Initiate withdrawal in the system**  
   - Enter the requested withdrawal amount into the system  
   - Submit the request for processing

5. **Inform the player about processing times and potential delays**  
   - Normal processing time: approximately 3-5 minutes  
   - During high volume or technical issues, processing can take 30–45 minutes or longer  
   - If GCash withdrawal is initiated, inform the player to allow 30–45 minutes for processing due to current system stabilization

6. **Monitor withdrawal status in the back office**  
   - Check if the status updates to "transferring," which indicates the withdrawal has been approved and is awaiting transfer by the finance department

7. **If withdrawal is slow or fails:**  
   - Advise the player to resubmit the withdrawal request if the status remains pending or if issues are observed  
   - If an error persists, request a withdrawal record or screenshot showing the transaction details for review  
   - For failed GCash withdrawals, suggest switching to PayMaya or other alternative methods such as Maya or Online Bank Transfer

8. **Review withdrawal record and update player**  
   - Guide the player on how to view their withdrawal history:  
     - Go to Profile > Withdrawal Record  
     - Take a screenshot if needed for further support or escalation  
   - If delays or issues are confirmed, escalate the case with the support or finance team, attaching relevant records

9. **Resolve issues related to withdrawal blockages or delays**  
   - If withdrawal is in "transferring" status for an extended period beyond typical times, verify with the finance department  
   - Remind players: withdrawals are normally processed within 3-5 minutes; delays may occur during high volume  

10. **Advise players on alternative methods if GCash is down**  
    - Recommend using Maya, PayMaya, or Online Bank Transfer if GCash is temporarily unavailable  
    - For withdrawals below 500 PHP, using PayMaya is encouraged for smoother transactions

11. **Communicate clearly with players**  
    - Reassure that all funds are safe and pending storage or transfer  
    - Explain any delays calmly, citing system or volume issues  
    - Encourage resubmission if a withdrawal fails or does not credit within the expected timeframe

## Notes
- Always verify the player’s withdrawal record and take a screenshot for cases of disputes or delays  
- Remind players to provide supporting documents like receipts if a withdrawal is delayed or not reflected for verification  
- Ensure compliance with turnover requirements before processing withdrawals, especially related to bonuses or promotions  
- GCash withdrawals are currently supported but may experience disruptions; always have alternative options ready

## Key points for communicating with players
- Inform players of estimated processing times (3-5 minutes normally, up to 45 minutes during high volume)  
- Advise resubmitting withdrawal requests if they are slow or fail  
- Recommend alternative methods if GCash is unavailable or experiencing issues  
- Request withdrawal records or screenshots when investigating delays or failures