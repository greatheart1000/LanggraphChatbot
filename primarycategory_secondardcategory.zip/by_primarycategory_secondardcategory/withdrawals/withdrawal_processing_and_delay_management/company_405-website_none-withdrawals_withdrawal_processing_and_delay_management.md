# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify player account eligibility for withdrawal**
   - Confirm that the player has completed all required deposit and turnover requirements, especially if they have received any bonuses or promotions, which may require a 3x turnover before withdrawal.
   - Check if the account has been deposited at least once; if not, the account remains at regular rank and cannot withdraw until a deposit of ₱100 is made to activate withdrawals.
   
2. **Confirm minimum withdrawal amount**
   - Ensure the requested withdrawal amount is at least ₱100, which is the minimum allowed.
   
3. **Check withdrawal limits and account status**
   - Verify that the requested amount does not exceed the maximum withdrawal limit of ₱50,000 per transaction.
   - Confirm that the account is verified and complies with all account policies, including linked accounts and verification documents if needed for payout method updates.
   
4. **Gather necessary information from the player**
   - Collect the player's Lodibet username.
   - Obtain the selected withdrawal account details and verify the account (bank card, e-wallet, etc.).
   - Confirm if the player has multiple accounts and assist with swiping to select the correct withdrawal account.
   
5. **Instruct the player to initiate the withdrawal request**
   - Guide the player to select 'Withdraw' on the upper right corner of the home page.
   - Advise them to choose their withdrawal account.
   - If multiple accounts exist, instruct them to swipe left or right to select the appropriate account.
   - Recommend tapping 'Recall Balance' if they want to transfer funds from other games to their main wallet.
   - Instruct the player to enter the withdrawal amount (minimum ₱100).
   - Ensure they input their transaction password correctly.
   
6. **Submit the withdrawal request**
   - Advise the player to click 'Submit' to finalize their request.
   - Confirm that the request is successfully submitted.
   
7. **Understand and communicate processing times**
   - Explain to the player that withdrawals are processed automatically and there is no specific estimated time of arrival.
   - Clarify that processing time depends on the volume of requests and each withdrawal is processed sequentially.
   
8. **Address potential delays or issues**
   - If the withdrawal is delayed or not credited, advise the player to open LiveChat support.
   - Request the player to provide their Lodibet username and any relevant deposit or withdrawal receipts.
   - Inform the support agent to investigate with the relevant departments and provide an estimated resolution.
   
9. **Handling failed withdrawal attempts**
   - If a withdrawal fails, suggest trying an alternative payout method supported by Lodibet, such as PayMaya if applicable.
   - If issues persist, instruct the player to contact support for further assistance.
   
10. **Advise on response and further steps**
    - Inform the player that their withdrawal is being processed and to monitor their account.
    - Remind them of the withdrawal limits and requirements if further actions are needed for subsequent requests.
   
## Notes
- Withdrawals are subject to ongoing turnover requirements, especially if bonuses/promotions are involved.
- Lodge support should be contacted for updates, delays, or to change payout methods such as switching from bank to e-wallet.
- Always verify that the account is fully compliant and verified to prevent disqualification or further delays.
- For withdrawal limits, adhere to the maximum of ₱50,000 per withdrawal request.

## Key points for communicating with players
- Clearly explain the minimum (₱100) and maximum (₱50,000) withdrawal limits.
- Inform players that withdrawals are automatic and processing times depend on volume.
- Emphasize the importance of completing turnover requirements before withdrawal eligibility when applicable.
- Instruct players to contact LiveChat support if there are delays or issues with their withdrawal.