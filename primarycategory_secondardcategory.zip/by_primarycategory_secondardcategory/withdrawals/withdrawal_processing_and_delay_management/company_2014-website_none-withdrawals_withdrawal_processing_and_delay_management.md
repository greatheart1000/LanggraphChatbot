# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Gather withdrawal request details from the player**
   - Confirm the player's identity and verify they are logged into their account.
   - Collect the withdrawal amount the player wishes to withdraw.
   - Ensure the requested amount is within the allowed limits (PHP 500 to PHP 20,000 per transaction).
   - Confirm the player's preferred withdrawal method (e-wallet such as Maya, GCash, PayMaya, etc.).
   - Ask the player to provide or confirm the transaction password.
   - Request a screenshot of the withdrawal record for tracking and support purposes.

2. **Verify the player's eligibility and compliance**
   - Check whether the player has met any necessary requirements, such as turnover or activity requirements, before withdrawal approval.
   - Confirm that the player’s transaction record is correctly recorded in the "Withdrawal Record" section.
   - Verify that the transaction details match the player's input.

3. **Proceed to initiate the withdrawal process**
   - Submit the withdrawal request in the back office system.
   - Notify the player that their request is being processed and may take a few minutes to several hours, depending on system and technical factors.
   
4. **Monitor withdrawal status**
   - Track the status of the withdrawal request:
     - **Approving** or **Transferring** means the request is under processing by the financial department.
   - Be aware that technical issues with local mobile operators or system delays may affect processing times.

5. **Handle delays or issues**
   - If the withdrawal remains pending beyond the expected timeframe:
     - Confirm the player's account details are correct.
     - Check for any system notifications about activity restrictions or illegal betting activity.
     - Resubmit the withdrawal request if necessary.
   - For failed or delayed withdrawals:
     - Advise the player to verify their account details.
     - Encourage the player to resubmit the request if no clear reason is provided.
     - Collect the withdrawal record or supporting screenshot for support escalation.

6. **Resolve and communicate with the player**
   - Inform the player when the withdrawal has been successfully completed.
   - If delays persist without resolution, advise the player to contact support with the screenshot of the withdrawal record for further assistance.
   - Instruct the player to check their e-wallet balance to ensure the funds received match the withdrawal request.

## Notes
- Always ensure the withdrawal request is within the site’s limits and complies with all policies.
- Remind players that withdrawal completion can vary depending on system status and local mobile operator technical issues.
- Confirm that transaction records are accurate to facilitate smooth processing.

## Key points for communicating with players
- Clearly inform players about the potential processing time (a few minutes to several hours).
- Advise players to ensure their account details are correct and consistent.
- Instruct players to submit screenshots of the withdrawal record when requesting support.
- Remind players that withdrawal is subject to meeting any specified requirements and system verification.