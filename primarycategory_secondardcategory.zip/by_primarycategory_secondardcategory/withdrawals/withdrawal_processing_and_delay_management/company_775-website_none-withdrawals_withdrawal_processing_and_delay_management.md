# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive the withdrawal request from the player.**
   - Confirm the method chosen (e.g., GCash, PayMaya, GrabPay, Gotyme, USDT, Online Bank Transfer).
   - Ensure the player has met any preliminary conditions, such as the turnover requirement.

2. **Verify withdrawal details and player information.**
   - Check the withdrawal method and applicable limits:
     - GCash: 500 PHP to 20,000 PHP per transaction.
     - PayMaya: recommended for withdrawals below 500 PHP.
   - Confirm the entered withdrawal amount does not exceed the maximum limit.
   - Ensure the player provided the correct transaction password.
   - Advise the player to take a screenshot of the withdrawal request confirmation for their records.

3. **Process the withdrawal based on method and current system status.**
   - If GCash is available:
     - Initiate GCash withdrawal if the amount is within 500 PHP to 20,000 PHP.
     - If the amount is below 500 PHP, suggest using PayMaya instead.
     - Allow 30–45 minutes for GCash transaction processing.
     - If the GCash system is experiencing issues or is temporarily unavailable, advise using PayMaya or other methods such as Maya, GrabPay, Gotyme, USDT, or Online Bank Transfer.
   - If GCash is unavailable or outside the limits:
     - Select an alternative method (e.g., PayMaya, USDT, Online Bank Transfer).
     - Process the withdrawal accordingly.

4. **Monitor withdrawal status and follow up if delays occur.**
   - Typical processing time for GCash is 30–45 minutes.
   - For other methods, follow the respective system processing times.
   - In case of delays:
     - Verify if the withdrawal has been processed in the back office system.
     - If no update after the expected time, inform the player and advise re-submission or alternative methods.

5. **Handle failed withdrawal attempts.**
   - If a withdrawal fails:
     - Funds will be refunded to the player's account balance.
     - Inform the player of the failure and reason if known.
     - Suggest reattempting or using an alternative method.

6. **Assist the player in viewing withdrawal records.**
   - Guide them to:
     - On the homepage, click 'Member'.
     - Select 'Withdrawal Record'.
     - Take a screenshot if needed for support purposes.

7. **Advise players on technical issues.**
   - During GCash outages or technical disruptions:
     - Recommend using PayMaya or other supported methods.
     - Instruct to wait 30–45 minutes for GCash processing after a withdrawal request.
   - Remind players to avoid multiple submissions during system downtimes.

8. **Escalate issues as needed.**
   - If a withdrawal persists beyond 45 minutes without update:
     - Escalate to the back office or finance team.
     - Confirm if there are ongoing system issues affecting withdrawal processing.

## Notes

- Withdrawal processing times are typically 3–5 minutes, but during high volume or system issues, delays of up to 45 minutes are common.
- For GCash withdrawals, always check for system outages or restrictions and advise players to switch to alternatives if needed.
- Players should allow at least 30 minutes before re-submitting a withdrawal (especially GCash) to avoid duplicate transactions.
- When advising on withdrawal issues, always recommend taking a screenshot of transaction records for support follow-up.

## Key points for communicating with players

- Clearly inform players about the withdrawal limits for GCash (500 PHP to 20,000 PHP).
- Remind players to wait 30–45 minutes after initiating GCash withdrawals before contacting support.
- Promptly suggest alternatives (PayMaya, USDT, Online Bank Transfer) if GCash is experiencing outages.
- Advise players to keep screenshots of their withdrawal requests and transaction records for reference and support.