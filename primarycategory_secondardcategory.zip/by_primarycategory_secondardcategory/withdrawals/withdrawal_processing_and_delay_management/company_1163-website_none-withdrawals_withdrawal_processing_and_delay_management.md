# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Receive and verify player withdrawal request**
   - Collect from the player:
     - Username
     - Valid ID for identity verification
     - Complete and correct transaction details
   - Ensure that all provided information complies with site requirements.

2. **Check for potential issues before processing**
   - Confirm that the player's account details are accurate and up-to-date.
   - Verify if the withdrawal amount adheres to any applicable limits (e.g., minimum or maximum limits, if specified by site policies).
   - Cross-check if there are any outstanding verification requirements or holds on the account.

3. **Initiate withdrawal processing**
   - Submit the withdrawal request to the back office system.
   - Note that the standard processing time is within 24 hours.
   - Record the timestamp of the request for tracking.

4. **Monitor the status of the withdrawal**
   - Check if the withdrawal status is "Processing" or "Under Review."
   - Recognize that such statuses indicate the withdrawal is queued for processing and undergoing system review.
   - Understand that delays can occur due to high system volume or ongoing verification.

5. **Wait for processing completion**
   - Be patient, as withdrawal requests are processed on a first-come, first-served basis.
   - System processing could take up to 24 hours; ensure the player is informed of this timeframe.
   - If delays extend beyond 24 hours, verify the status in the system and assess if additional action is needed.

6. **Handle unsuccessful or returned withdrawals**
   - If a withdrawal is unsuccessful or funds are returned to the player's account:
     - Confirm that the account details are correct.
     - Advise the player to contact customer support if issues persist.
     - Once processed, funds will be transferred to the player's linked GCash or Paymaya account.

7. **Address delays or issues with withdrawals**
   - Explain to the player that delays can occur due to high transaction volume or ongoing review.
   - Reassure that the system processes withdrawals as quickly as possible and ask for patience.
   - If the withdrawal remains under review or processing status beyond the typical time, escalate to the relevant support team for further investigation.

## Notes
- Withdrawals are processed on a first-come, first-served basis.
- The maximum processing time is 24 hours.
- Ensure all player-provided information is accurate to prevent delays.
- Inform players that "Processing" or "Under Review" statuses indicate the withdrawal is in the processing queue and will be completed once review is finished.

## Key points for communicating with players
- Clearly state the standard processing time of 24 hours.
- Explain that delays can happen due to high volume or verification procedures.
- Advise patience and reassure that the system prioritizes quick processing.
- Encourage players to contact support if their withdrawal remains unprocessed beyond the expected timeframe or if they encounter issues.