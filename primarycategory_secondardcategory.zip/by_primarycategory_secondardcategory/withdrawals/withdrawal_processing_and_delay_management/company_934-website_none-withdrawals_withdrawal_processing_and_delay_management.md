# Withdrawals - Withdrawal Processing and Delay Management

## Steps

1. **Verify player’s withdrawal request details**
   - Ensure the player has clicked the 'Withdraw' option.
   - Collect the following information:
     - Preferred withdrawal method (e-wallet or bank account)
     - Withdrawal amount
     - Transaction password
   - Confirm that the player has fulfilled the necessary turnover requirement by playing designated games (e.g., fish or slot).

2. **Check for compliance with withdrawal rules and limits**
   - Confirm the withdrawal amount does not exceed the maximum per transaction limit of 20,000 PHP.
   - Ensure the player has no unresolved issues or restrictions affecting withdrawal.
   - Verify that the player has met the minimum turnover requirement for withdrawal eligibility.

3. **Submit and initiate the withdrawal request**
   - Process the request within the system.
   - Advise the player that normal processing time is approximately 3-5 minutes.
   - Confirm that the withdrawal request status is 'pending' or 'transferring', indicating the request is being processed.

4. **Monitor transaction status and troubleshoot delays**
   - If the withdrawal is pending for more than 30 to 45 minutes, advise the player that delays may occur due to network issues or system delays.
   - Suggest switching to alternative withdrawal methods like PayMaya if delays persist and system stability is affected.
   - Check system logs for transaction issues or delays.

5. **Handle delayed or rejected transactions**
   - If the withdrawal request is delayed beyond the normal period without updates, verify whether:
     - The transaction still has a 'pending' status.
     - Additional requirements or issues have arisen.
   - If the transaction is rejected or cannot be processed, review the transaction details:
     - Confirm that all requirements (turnover, correct details) are met.
     - Inform the player of any issues and advise resubmitting the request if applicable.

6. **Follow up and escalate if necessary**
   - If issues remain unresolved after troubleshooting, escalate the case to the support or finance team for further review.
   - Keep the player informed about the status, delays, or resolution process.

## Notes
- Always verify that the player’s withdrawal request adheres to the rules regarding maximum withdrawals (20,000 PHP per transaction, up to 10 withdrawals per day).
- Remind players that delays might occur due to high transaction volume, and they can retry or switch methods if needed.
- Confirm that players have not been betting abnormally, as this can delay or block withdrawals.

## Key points for communicating with players
- Inform players that withdrawal processing typically takes 3-5 minutes.
- Advise players that delays over 30 to 45 minutes require monitoring and optional switching to alternative methods.
- Reassure players that support will review their transactions in case of issues or delays.